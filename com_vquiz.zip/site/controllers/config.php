<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 www.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerConfig extends VquizController
{
		function __construct()
		{
			parent::__construct();
			$this->registerTask( 'add'  , 	'edit' );
		}
 
		function edit()
		{
			JRequest::setVar( 'view', 'config' );
			JRequest::setVar( 'layout', 'form'  );
			JRequest::setVar('hidemainmenu', 1);
			parent::display();
		}
 
	function apply()
		{
				$model = $this->getModel('config');
				if($model->store()) {
					$msg = JText::_('CONFIGURATION_SAVE');
					$this->setRedirect( 'index.php?option=com_vquiz&view=config', $msg );
				} else {
					jerror::raiseWarning('', $this->model->getError());
					$this->setRedirect( 'index.php?option=com_vquiz&view=config');
				}

		}
		function cancel()
		{
			$msg = JText::_('OPERATION_CANCELLED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=vquiz', $msg );
		}
 
}