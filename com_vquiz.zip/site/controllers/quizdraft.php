<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerQuizdraft extends VquizController
{

		function __construct()
		{
			parent::__construct();
			$this->registerTask( 'add'  , 	'edit' );
		}
 
		function edit()
		{
			JRequest::setVar( 'view', 'quizdraft' );
 			JRequest::setVar( 'layout', 'form'  );
 			JRequest::setVar('hidemainmenu', 1);
 			parent::display();
 		}
		
		function remove()
		{
			$model = $this->getModel('quizdraft');
			if(!$model->delete()) 
			{
				$msg = JText::_( 'COULD_NOT_DELETED' );
			} 
			else 
			{
				$msg = JText::_('GREETING_DELETED');
			}
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=quizdraft'), $msg );
	
		}

 
		function cancel(){
			$msg = JText::_('CANCELLED');
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=quizdraft'), $msg );
		}

}