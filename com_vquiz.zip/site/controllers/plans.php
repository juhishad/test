<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerPlans extends VquizController
{

	function __construct()
	{

		parent::__construct();
		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'unpublish',	'publish' );
		$this->registerTask( 'orderup',   'reorder' );
		$this->registerTask( 'orderdown', 'reorder' );
	}
    function subscribe(){
		    $session = JFactory::getSession();
			
			$user = JFactory::getUser();
			//echo $user->id;//$user_id = $session->get('user_id','');
			//exit;
			
			if ($user->id!=0)
			{
				$model = $this->getModel('plans');	
				
				$config = $model->createUserOrderBeforePay();
				//echo $user->id;exit;
				if($config)
				{
                 $link = JRoute::_('index.php?option=com_vquiz&view=orders&order_key='.JRequest::getString('order_key', 0));					
                 $this->setRedirect( $link);
				}
				else
				{
					
					JRequest::setVar( 'view', 'plans' );
					JRequest::setVar( 'layout', 'form'  );
					parent::display();	
				}
            }
			else
			{
			
			JRequest::setVar( 'view', 'plans' );
			JRequest::setVar( 'layout', 'form'  );	
			parent::display();	
			}
			
	}
	public function subscribes(){
		    $model = $this->getModel('plans');
	        $ch = self::_doStartRegistration();
			
			$config = $model->createUserOrderBeforePay();
			$link = JRoute::_('index.php?option=com_vquiz&view=orders&&order_key='.JRequest::getString('order_key', 0),false); 
			$this->setRedirect($link);	
	}
	function edit()
	{
		JRequest::setVar( 'view', 'plans' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);		
		parent::display();
	}

 	function publish()
	{

		$model = $this->getModel('plans');
		$msg = $model->publish();
		$link = JRoute::_('index.php?option=com_vquiz&view=plans');
		$this->setRedirect($link , $msg );
	}

     function updatequiz()
	{
        $obj = new stdClass();
		$model = $this->getModel('plans');
		$option = $model->updatequiz();
		$options = array();
		foreach($option as $key=>$value){
			$q = new stdClass();
			$q->text = $value['text'];
			$q->value = $value['value'];
			array_push($options,$q);
		}
		$obj->option = $options;
		jexit(json_encode($obj));
	}
	
	function reorder()
	{
      
		$ids = JFactory::getApplication()->input->post->get('cid', array(), 'array');
		$inc = ($this->getTask() == 'orderup') ? -1 : 1;
		$model = $this->getModel('plans');
		$return = $model->reorder($ids[0], $inc); 
		if($return){
		$msg = JText::_('RE_ORDER_SAVED');
		$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=plans'), $msg );
		}

	}

	function saveOrder()
	{  
		$input=JFactory::getApplication()->input;
		$pks=$input->post->get('cid',array(),'array');
		$order=$input->post->get('order',array(),'array');
		JArrayHelper::toInteger($pks);
		JArrayHelper::toInteger($order);
		$model = $this->getModel('plans');
		$return=$model->saveorder($pks,$order);
		if($return){
		$msg = JText::_('NEW_ORDER_SAVED');
	    $this->setRedirect(JRoute::_( 'index.php?option=com_vquiz&view=plans'), $msg );
		}
 		
	}
 

	function save()
	{
		  $model = $this->getModel('plans');
		 if($model->store()) {
			
			$msg = JText::_('CATEGORY_SAVED');
			$this->setRedirect(JRoute::_( 'index.php?option=com_vquiz&view=plans'), $msg );
		} else {
			$msg=$model->getError(); 
			$this->setRedirect(JRoute::_( 'index.php?option=com_vquiz&view=plans'),$msg);
		}
	}


	function apply()
	{
		
		$model = $this->getModel('plans');
		if($model->store()) {
			
			$msg = JText::_('PLANS_SAVED');
			$this->setRedirect(JRoute::_( 'index.php?option=com_vquiz&view=plans&task=edit&cid[]='.JRequest::getInt('id', 0)), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=plans&task=edit&cid[]='.JRequest::getInt('id', 0)) );
		}
	}

	function remove()
	{
		$model = $this->getModel('plans');
		if(!$model->delete()) 
		{
			$msg = JText::_('CATEGORY_COULD_NOT_DELETED');
		} 
		else 
		{
			$msg = JText::_('CATEGORY_DELETED');

		}
		$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=plans'), $msg );
	}


	function cancel()
	{
		$msg = JText::_('OPERATION_CANCELLED');
		$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=plans'), $msg );
	}
	function _isRegistrationUrl()
	{
		$vars = $this->_getVars();
		if($vars['option'] == 'com_vquiz' && $vars['view'] == 'plan' && $vars['task'] == 'login'){
			return true;
		}
		
		return false;
	}	
	
	/** 
	 * @see XiPluginRegistration::_doStartRegistration()
	 * 
	 */
		public function checkusername()
	{
		$args 	= self::_getArgs();
		$db = JFactory::getDbo();
		require(JPATH_COMPONENT.'/assets/elements/response.php');
		$response = XiAjaxResponse::getInstance();
		
		$msg = '';
		$valid = true;
		//$arg[1] :: username
		//$arg[0] :: input field id
		$query = 'SELECT  tbl.`id` AS user_id, tbl.`name` AS realname, tbl.`username` AS username, tbl.`email` AS email
		, tbl.`registerDate` AS registerDate, tbl.`lastvisitDate` AS lastvisitDate
		FROM `#__users` AS tbl where `username`='.$db->quote($args[1]).'
		ORDER BY id ASC';
		$db->setQuery($query);
		$db->Query($query);
		if( $db->getNumRows() ) {
		$msg = JText::_('COM_VQUIZ_USER_USERNAME_ALREADY_REGISTERED');
		$valid = false;
		}
		$response->addScriptCall('xi.registration.validate', $args[0], $valid, $msg);
		$response->sendResponse();
	}
	
	public function checkemail()
	{
		$db = JFactory::getDbo();
		$args 	= self::_getArgs();
		require(JPATH_COMPONENT.'/assets/elements/response.php');
		$response = XiAjaxResponse::getInstance();
		
		
		$msg = '';
		$valid = true;
		
		jimport('joomla.mail.helper');
		if(!JMailHelper::isEmailAddress($args[1])){
			$msg = JText::_('COM_VQUIZ_INVALID_EMAIL_ADDRESS');
			$valid = false;
		}
		
		if($valid){
			
				$query = 'SELECT  tbl.`id` AS user_id, tbl.`name` AS realname, tbl.`username` AS username, tbl.`email` AS email
				, tbl.`registerDate` AS registerDate, tbl.`lastvisitDate` AS lastvisitDate
				FROM `#__users` AS tbl where `tbl`.`email`='.$db->quote($args[1]).'
				ORDER BY id ASC';
				$db->setQuery($query);
				$db->Query($query);
				if( $db->getNumRows() ) {
				$msg = JText::_('COM_VQUIZ_EMAIL_ALREADY_REGISTERED');
				$valid = false;
				}
			
		}
		
		$response->addScriptCall('xi.registration.validate', $args[0], $valid, $msg);
		$response->sendResponse();
	}
	protected function _doStartRegistration()
	{
		$app 				= JFactory::getApplication();
		$planId 			= $app->input->getString('plan_id', false);
		$email 				= $app->input->get('vquizRegisterAutoEmail', false, '@');
		$username 			= $app->input->get('vquizRegisterAutoUsername', false, '@');
		$password 			= $app->input->getString('vquizRegisterAutoPassword', false);
		$fullname			= $app->input->getString('vquizUserFullname', false);
		
		// if $username is not post then redirect to login page again
		if(!$username){
			$this->_app->redirect(JRoute::_('index.php?option=com_vquiz&view=plans&task=subscribe&plan_id='.$planId,false));
		}
		
		// if email is not post then redirect to login page again
		if(!$email){
			$this->_app->redirect(JRoute::_('index.php?option=com_vquiz&view=plans&task=subscribe&plan_id='.$planId));
		}
		
		// if password is not post then redirect to login page again
		if(!$password || JString::strlen(Jstring::trim($password)) === 0) {
			$this->_app->redirect(JRoute::_('index.php?option=com_vquiz&view=plans&task=subscribe&plan_id='.$planId));
		}

        //if captcha code not matched then redirect to login page again
		/* if($this->params->get('show_captcha', 0)){
			$post       = JRequest::get('post');      
			JPluginHelper::importPlugin('captcha');
			$dispatcher = JDispatcher::getInstance();
			if(isset($post['g-recaptcha-response']))
			{
				$postresponse=$post['g-recaptcha-response'];
			}
			else 
			{
				$postresponse=$post['recaptcha_response_field'];
			}
			$res        = $dispatcher->trigger('onCheckAnswer',$postresponse);
			if(isset($res[0]) && !$res[0]){
				$this->_app->enqueueMessage(JText::_('PLG_PAYPLANSREGISTRATION_AUTO_REGISTRATION_SAVE_FAILED_16'));	
				$this->_app->redirect(JRoute::_('index.php?option=com_vquiz&view=plans&task=subscribe&plan_id='.$planId));
            }
		 } */
      //  if(!$this->params->get('show_fullname', 0) || empty($fullname)){
        	//$fullname='Zahee Abbas';
       // }
		$userId = self::_autoRegister($username, $email, $password,$fullname);
		if($userId){
			// registration is completed here so call afterRegistrationComplete
			$this->_setUser($userId);
			return $this->_doCompleteRegistration();
		}
		
		return true;
	}
	
	function _autoRegister($username, $email, $password, $fullname=null)
	{
		$app 				= JFactory::getApplication();
		require_once  JPATH_ROOT.DS.'components'.DS.'com_users'.DS.'models'.DS.'registration.php';
	    if( empty($fullname)){
        	$fullname=$username;
        }
		
		$model 	= new UsersModelRegistration();
		JFactory::getLanguage()->load('com_users');
		
		/* jimport('joomla.mail.helper');
		if(!JMailHelper::isEmailAddress($email)){
			$this->_app->enqueueMessage(JText::_('COM_VQUIZ_INVALID_EMAIL_ADDRESS'));
			return false;
		}
		
		if(JHelperUser::exists('email', $email)){
			$this->_app->enqueueMessage(JText::_('COM_VQUIZ_EMAIL_ALREADY_REGISTERED'));
			return false;
		}
		
		if(JHelperUser::exists('username', $username)){
			$this->_app->enqueueMessage(JText::_('PLG_VQUIZSREGISTRATION_AUTO_USERNAME_ALREADY_REGISTERED'));
			return false;
		} */
		
		// load user helper
		jimport('joomla.user.helper');
		$temp 	= array(	'username'=>$username,'name'=>$fullname,'email1'=>$email,
						'password1'=>$password, 'password2'=>$password, 'block'=>0 );
				
		$config = JFactory::getConfig();
		$params = JComponentHelper::getParams('com_users');

		
		// Initialise the table with JUser.
		$user 	= new JUser;
		$data 	= (array)$model->getData();
		// Merge in the registration data.
		foreach ($temp as $k => $v) {
			$data[$k] = $v;
		}

		// Prepare the data for the user object.
		$data['email']		= $data['email1'];
		$data['password']	= $data['password1'];
		
		// if acc_verification is not set to never_acc_creation, then user activation is required
	/* 	$useractivation 	= $this->_isEmailVerificationRequired() ;
		$useractivation 	= $useractivation
							|| $this->params->get('acc_verification', 'always_email') == 'never_sub_active' || $this->params->get('acc_verification', 'always_email') == 'acc_active_afterpayment';	 */						
		
		// Check if the user needs to activate their account.
		if (1) {
			jimport('joomla.user.helper');
			$data['activation'] = JApplication::getHash(JUserHelper::genRandomPassword());
			$data['block'] = 0;
		}

		// Bind the data.
		if (!$user->bind($data)) {
			$app->enqueueMessage(JText::sprintf('PLG_VQUIZSREGISTRATION_AUTO_BIND_FAILED', $user->getError()));
			return false;
		}

		// Load the users plugin group and Store the data
		JPluginHelper::importPlugin('user');
		if (!$user->save()) {
			$app->enqueueMessage(JText::sprintf('PLG_VQUIZREGISTRATION_AUTO_REGISTRATION_SAVE_FAILED', $user->getError()));
			return false;
		}
		
		/* if($this->params->get('acc_verification', 'always_email') == 'acc_active_afterpayment'){
			$this->_app->enqueueMessage(JText::_('PLG_VQUIZREGISTRATION_ACTIVATE_AFTER_PAYMENT_MSG_ON_INVOICE_CONFIRM'));
			return $user->id;
		} */

		// Compile the notification mail values.
		$data 				= $user->getProperties();
		$data['fromname']	= $config->get('fromname');
		$data['mailfrom']	= $config->get('mailfrom');
		$data['sitename']	= $config->get('sitename');
		$data['siteurl']	= JUri::base();

		//checking if option of never sending any email is set
		/* if(!($this->params->get('acc_verification', 'always_email') == 'never_send_email')){
		
			$emailSubject	= JText::sprintf('PLG_PAYPLANSREGISTRATION_AUTO_ACCOUNT_DETAILS_FOR', $data['name'], $data['sitename']);
			$emailBody 		= $params->get('sendpassword','0')!=0?JText::sprintf('PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG', $data['name'], $data['sitename'], $data['siteurl'], 
											$data['username'], $data['password_clear']):JText::sprintf('PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG_NO_PWD', $data['name'], $data['sitename'], $data['siteurl'], 
											$data['username']);
			
			if ($this->_isEmailVerificationRequired())
			{
				// Set the link to activate the user account.
				$uri 				= JURI::getInstance();
				$base 				= $uri->toString(array('scheme', 'user', 'pass', 'host', 'port'));
				$data['activate'] 	= $base.JRoute::_('index.php?option=com_users&task=registration.activate&token='.$data['activation'], false);

				$emailSubject		= JText::sprintf('PLG_PAYPLANSREGISTRATION_AUTO_ACCOUNT_DETAILS_FOR', $data['name'], $data['sitename']);
				$emailBody 			= $params->get('sendpassword','0')!=0?JText::sprintf('PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG_ACTIVATE', $data['name'], $data['sitename'],
													$data['siteurl'].'index.php?option=com_payplans&view=user&task=activate_user&activation='.$data['activation'],
													$data['siteurl'],$data['username'], $data['password_clear'] ):
													JText::sprintf('PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG_ACTIVATE_NO_PWD', $data['name'], $data['sitename'],
													$data['siteurl'].'index.php?option=com_payplans&view=user&task=activate_user&activation='.$data['activation'],
													$data['siteurl'],$data['username']);
			
				if($this->params->get('acc_verification', 'always_email') == 'manual_acc_active'){
					$emailBody = $params->get('sendpassword','0')!=0?JText::sprintf('PLG_PAYPLANSREGISTRATION_AUTO_EMAIL_REGISTERED_WITH_ADMIN_ACTIVATION_BODY', $data['name'], $data['sitename'],
												$data['siteurl'].'index.php?option=com_payplans&view=user&task=activate_user&activation='.$data['activation'],
												$data['siteurl'], $data['username'], $data['password_clear']):
												JText::sprintf('PLG_PAYPLANSREGISTRATION_AUTO_EMAIL_REGISTERED_WITH_ADMIN_ACTIVATION_BODY_NO_PWD', $data['name'], $data['sitename'],
												$data['siteurl'].'index.php?option=com_payplans&view=user&task=activate_user&activation='.$data['activation'],
												$data['siteurl'], $data['username']);
				}
			} 

			// Send the registration email.
			$return	 = PayplansFactory::getMailer()->setSender( array($data['mailfrom'], $data['fromname']))
												   ->addRecipient($data['email'])
												   ->setSubject($emailSubject)
												   ->setBody($emailBody)
												   ->Send();
		} else {
			$return = true;
		} */
		
		/* if ($params->get('mail_to_admin','0')!=0) {
		// 	Send notification to all administrators
		$subject2 	= sprintf ( JText::_('PLG_PAYPLANSREGISTRATION_AUTO_ACCOUNT_DETAILS_FOR' ), $data['name'], $data['sitename']);
		$subject2 	= html_entity_decode($subject2, ENT_QUOTES);

		// get superadministrators id
		$rows = JHelperJoomla::getUsersToSendSystemEmail();
		foreach ( $rows as $row ){		
			$message2 = sprintf ( JText::_( 'PLG_PAYPLANSREGISTRATION_AUTO_SEND_MSG_ADMIN' ), $row->name, $data['sitename'], $data['name'], $email, $username);
			$message2 = html_entity_decode($message2, ENT_QUOTES);
			$mail     = PayplansFactory::getMailer()->setSender( array($data['mailfrom'], $data['fromname']))
										     ->addRecipient($row->email)
									         ->setSubject($subject2)
									         ->setBody($message2)
									         ->Send();	
		}
		
		// Check for an error.
		if ($return !== true) {
			$this->_app->enqueueMessage(JText::_('COM_USERS_REGISTRATION_SEND_MAIL_FAILED'), 'error');

			// Send a system message to administrators receiving system mails
			if (count($rows) > 0) {
				$db		= PayplansFactory::getDBO();
				$jdate = new JDate();
				// Build the query to add the messages
				$q = "INSERT INTO `#__messages` (`user_id_from`, `user_id_to`, `date_time`, `subject`, `message`)
					VALUES ";
				$messages = array();
				foreach ($rows as $emailUser) {
					$messages[] = "(".$emailUser->id.", ".$emailUser->id.",".$db->quote($jdate->toMySQL()).",".$db->quote(JText::_('COM_USERS_MAIL_SEND_FAILURE_SUBJECT')).",".$db->quote(JText::sprintf('COM_USERS_MAIL_SEND_FAILURE_BODY', $return, $data['username'])).")";
				}
				$q .= implode(',', $messages);
				$db->setQuery($q);
				$db->query();
			}
			return $user->id;
		}
	 }
		// Show what will happen to registration
		if($this->params->get('acc_verification', 'always_email') != 'never_send_email'){
			$this->_app->enqueueMessage(JText::_('PLG_PAYPLANSREGISTRATION_AUTO_'.JString::strtoupper($this->params->get('acc_verification', 'always_email'))));
		} */
		
		// how to find user id 
		return $user->id;
	}
	
	function _isEmailVerificationRequired()
	{
		// get the plan selected
		$isFreePlan = false;
		$plan = PayplansPlan::getInstance($this->_getPlan());
		if(floatval($plan->getPrice()) == floatval(0)){
			$isFreePlan = true;
		}
	
		return $this->params->get('acc_verification', 'always_email') == 'always_email' || ($this->params->get('acc_verification', 'always_email') == 'manual_acc_active')
					|| ($this->params->get('acc_verification', 'freeplan_email') == 'freeplan_email' && $isFreePlan);
	}

	public function _getArgs()
	{
		// collect params
		// XITODO : loop array till argument count
		$args = array(); 
		for($i=1 ; $i < 10 ; $i++){
			$arg = JRequest::getVar('arg'.$i,null);
			
			if($arg == null){
				break;
			}
			
			$args[]= rawurldecode($arg);
		}

		// if it is an ajax request, decode the args 
		// (all ajax args are json-encoded)
		if(JRequest::getBool('isAjax',	false)){
			foreach($args as $index => $arg){
				$args[$index] = json_decode($arg);
			}
		}
		
		// for system starting from 2.0
		$event_args = JRequest::getVar('event_args',null);
		if($event_args !== null){
			$args = $event_args;
		}
		
		return $args;
	}
	public function _setUser($userId)
	{
		$session = JFactory::getSession();
		$session->set('REGISTRATION_USER_ID', $userId);
		return true;
	}
	
	public function _getUser($id = null)
	{
		$session = JFactory::getSession();
		return $session->get('REGISTRATION_USER_ID', 0);
	}
	
	public function _setPlan($planId)
	{
		$session = JFactory::getSession();
		$session->set('REGISTRATION_PLAN_ID', $planId);
		return true;
	}
	
	public function _getPlan()
	{
		$session = JFactory::getSession();
		$planId = JRequest::getVar('plan_id', 0);
		if($planId){
			return $planId;
		}
		
		return $session->get('REGISTRATION_PLAN_ID', 0);
	}
	public function _doCompleteRegistration()
	{		
		$app = JFactory::getApplication();
		$session = JFactory::getSession();
		if(!self::_getPlan()){
			// if plan is not selected then do not create order
			// do not do anything 
			self::_setUser(0);
			return true;		
		}
		$userId	= self::_getUser();
		
						
		// get user id in REGISTRATION_NEW_USER_ID to check it during session expiration checking	
		$session->set('REGISTRATION_NEW_USER_ID', $userId);				
		
		
		// now redirect to confirm action
		return true;
						
	}
}