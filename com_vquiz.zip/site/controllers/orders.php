<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );

class VquizControllerOrders extends VquizController
 
{
	function __construct()
	{
		parent::__construct();
		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'unpublish',	'publish' );
		$user = JFactory::getUser();
		/* if($user->id==0)
		{
			 $link = JRoute::_('index.php?option=com_vquiz&view=plans');					
                 $this->setRedirect( $link);
		} */
	}
		
	function edit(){

		JRequest::setVar( 'view', 'orders' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);
		parent::display();	
	}
	
	function applycoupon(){ 
		$model = $this->getModel('orders');
		$db = JFactory::getDbo();
		
		$session = JFactory::getSession();
		$obj = new stdclass();
		$obj->result = 'error';
		$coupon_key = JRequest::getString('couponkey','');
		$subscription_id = JRequest::getVar('subscription_id','');	
		$order_id = JRequest::getVar('order_id','');	
	
		//$obj->result = 'success';
		$cp_err = true;
		if( strlen( $coupon_key ) > 0 ) { 
		 $q = "SELECT * FROM `#__vquiz_coupons` WHERE `codes`=".$db->quote($coupon_key); //.";"
			$db->setQuery($q);
			$db->Query($q);					
				if( $db->getNumRows() ) { 
					$coupon = $db->loadAssocList(0);
					$coupon = $coupon[0];
					
					if( QuizHelper::validateCoupon( $coupon_key, $subscription_id ) ) { 
						
						 $session->set('coupon_data',$coupon); 
						 if($model->UpdateCouponValue($coupon_key,$subscription_id,$order_id)){
						 
							 $obj->result = 'success';
							 $obj->message = JText::_('COM_VQUIZ_COUPON_FOUND'); 
							 $cp_err = false;
						 }
					} else {
						 $session->clear('coupon_data'); 
						 $obj->message = JText::_('COM_VQUIZ_COUPON_NOT_VALID');
						
					}
					
				}else {
					$session->clear('coupon_data'); 
				 $obj->message = JText::_('COM_VQUIZ_COUPON_NOT_VALID');
			}
		}
		
		jexit(json_encode($obj));
		
	}
	
	function createOrder(){
        $subscr_id = JRequest::getInt('subscr_id','');
		if(empty($subscr_id)){
		    $msg = JText::_('COM_VQUIZ_SELECT_SUBSCRIPTION_TO_ADD_NEW_ORDERS');
			$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=subscriptions',false), $msg );	
		}
		JRequest::setVar( 'view', 'orders' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);
		parent::display();	
	}			
	function save()
	{	
		$model = $this->getModel('orders');
		$sub_id = JRequest::getInt('sub_id',0);
		if($model->store()) {
			$msg = JText::_('ORDERS_SAVE');
			$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=orders&sub_id='.$sub_id,false), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=orders&sub_id='.$sub_id,false));
		}
	}
		
		
	function apply()
	{
		$model = $this->getModel('orders');
		$subscr_id = JRequest::getInt('subscr_id',0);
		if($model->store()) {

		$msg = JText::_('ORDERS_SAVE');

		$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=orders&subscr_id='.$subscr_id.'&task=edit&cid[]='.JRequest::getInt('id', 0), false), $msg );
		} else {

		jerror::raiseWarning('', $model->getError());

			$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=orders&subscr_id='.$subscr_id.'&task=edit&cid[]='.JRequest::getInt('id', 0) ));
		}


	}
		
		 
	public function confirm($order_key = null, $userid = null, $appid = null)
    { 
			$data = JRequest::get( 'post' ); //print_r($data);exit;
		$order = JRequest::getString('order_key','');
				
		$order_key 	   = (empty($order_key)) ? JRequest::getString('order_key','') : $order_key;
			
		if(empty($order_key)){
			
        	$this->setMessage(JText::_('COM_VQUIZ_ORDER_PLEASE_SELECT_A_VALID_PLAN'));
            $this->setRedirect(JRoute::_("index.php?option=com_vquiz&view=plan",false));
            
            return false;
		}		
		
		//session expired or not
		if($userid === null && QuizHelper::checkSessionExpiry()==false){
			return false;
		}
		
		$userid     = (empty($userid)) ? JFactory::getUser()->get('id') : $userid;
  
		//get the user_id from session because at time or new registration user is not activated
		if (empty($userid)){
			$userid = JFactory::getSession()->get('REGISTRATION_NEW_USER_ID', 0);
		}
                    
		$orderDetail	    = QuizHelper::orderDetail(false,$order_key); 
		//print_r($orderDetail);exit;
		$subscriptionDetail	= QuizHelper::subscriptionDetail($orderDetail->subscr_id);
		if($subscriptionDetail->plan_id!=0)
		{
			$planDetail	        = QuizHelper::planDetail($subscriptionDetail->plan_id);
		
		
			// Check Plan is valid or not
			if(QuizHelper::isValidPlan($planDetail->id) === false){			
				$this->setMessage(JText::_('COM_VQUIZ_ORDER_PLEASE_SELECT_A_VALID_PLAN'));
				$this->setRedirect(JRoute::_("index.php?option=com_vquiz&view=plan",false));
				
				return false;
			}
		}
		// if invoice is not attached to the logged-in user
		$buyer		= $orderDetail->buyer_id;
  
        // if invoice is not confirmed by user then show the details of invoice and order
        $postVariables = JFactory::getApplication()->input;
		//print_r($postVariables);exit;
       
       /*  if($postVariables->get('payplans_invoice_confirm', 'BLANK') === 'BLANK'){
            $this->setTemplate(__FUNCTION__);
            return true;
        } */

		//if invoice is for free plan or total amount to pay reduced to 0 on applying discount
        // then redirect to complete order page
        // XITODO : need to check where should redirect
		$modal = $this->getModel('orders');
		 
		$order_stance = $modal->updateOrders($orderDetail->order_id);
		
      	/* if(floatval(0) == floatval($orderDetail->subtotal)){
      		
			//confirm order first
			$order_stance = QuizHelper::getInstance('orders',$orderDetail->order_id);
			$model = $this->getModel('orders');
			$update = $modal->updateOrder($orderDetail->order_id);
			
      				
      		// get the transaction instace of lib
			$transaction = QuizHelper::getInstance();
			$transaction->set('user_id', $invoice->getBuyer())
						->set('invoice_id', $invoice->getId())
						->set('payment_id', 0)
						->set('message', 'COM_VQUIZ_TRANSACTION_OF_FREE_SUBSCRIPTION')
						->save();
						
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=orders&task=thanks&invoice_key='.$invoice->getKey(),false));
			return false;
      	} */
		$payment_app_id=$this->getPaymentId($postVariables->get('payment_type', 0));
		// app_id is required for payment
      	 $appId   = ($appid === null) ?$payment_app_id  : $appid;
		/* if(!$appId){     
			JError::raiseError(500, JText::_('COM_VQUIZ_ERROR_INVALID_APP_ID'));
		} */

        //confirm order and create payment
		
		$order_stance->app_id = $appId;
		$order_stance->store();
        // get payemnt created
		
	    
       // $payment = $order_stance->app_id;
	     $payment = $postVariables->get('payment_type', 0);
		 
				 
		 /* if($payment=='paypal_pro'){
			$url = 'index.php?option=com_vquiz&view=orders&task=pay&payment_key='.$payment.'&order_id='.$orderDetail->order_id.'&card_number='.$card_number.'&expiry_month='.$expiry_month.'&expiry_year='.$expiry_year.'&cvv='.$cvv.'&card_type='.$card_type;
		}else{
			$url = 'index.php?option=com_vquiz&view=orders&task=pay&payment_key='.$payment.'&order_id='.$orderDetail->order_id;
		} 
		$this->setRedirect(JRoute::_($url,false)); */
		
		
		$this->pay($payment,$data,$orderDetail->order_id);  
		
        return false;
	}
	
	/* public function display($cachable = false, $urlparams = false)
	{
		return $this->thanks();
	} */

	public function thanks()
	{
		$userid     = (empty($userid)) ? JFactory::getUser()->get('id') : $userid;

		//get the user_id from session because at time or new registration user is not activated
		if (empty($userid)){
			$userid = JFactory::getSession()->get('REGISTRATION_NEW_USER_ID', 0);
		}

		$itemId = $this->getModel()->getId();

		if($itemId){
			$invoice = PayplansInvoice::getInstance($itemId);
			$buyerId	 = $invoice->getBuyer();

			if(JHelperJoomla::isAdmin($userid) || $buyerId == $userid) {
				return true;
			}

			$url 		= JRoute::_('index.php?option=com_vquiz&view=dashboard');
			$message 	= JText::_('COM_VQUIZ_SUBSCRIPTION_CAN_NOT_VIEW_SUBSCRIPTION_OF_OTHERS_USER');

			$this->setRedirect($url, $message, 'message');
			return false;
		}


		return false;
	}	
	public function paymentDetail(){
	 $payment_id = JRequest::getVar('payment_id','');
	 $obj = new stdclass();
     $obj->result = 'success';
	 $obj->html ='';
	 if(empty($payment_id))
	 jexit(json_encode($obj));
  
     $plugin_detail = self::plugin_detail($payment_id);
		JPluginHelper::importPlugin('vquiz', $plugin_detail->type);
		$dispatcher = JDispatcher::getInstance();

		try
		{
		 $result = $dispatcher->trigger('onPayplansPaymentForm');
		 $obj->html = $result;
		}
		catch(Exception $e)
		{
		$obj->result = 'error';
		$obj->msg =  $e->getMessage();
		jexit(json_encode($obj));
		}

	} 
	public function plugin_detail($pugin_id)
	{
	 $db = JFactory::getDbo();
     $query = 'select * from #__vquiz_payment_plugin';
	 $db->setQuery($query);	
     return $db->loadObject();	 
	}
	public function pay($paymentId = null, $data = null, $order_id=null)
	{
		$user = JFactory::getUser();
		//print_r($order_id);exit;
		//session expired or not
         // $paymentId = JRequest::getString('payment_key',''); 
		
		//$order_id = JRequest::getString('order_id','');	
		//echo $paymentId;echo  $order_id;exit;
		if(!empty($data)){		
		$card_number = $data['card_number'];
		$expiry_month = $data['expiry_month'];
		$expiry_year = $data['expiry_year'];
		$cvv = $data['cvv'];
		$name_on_card = $data['name_on_card'];
		$card_type = $data['card_type'];
		}
		
		if($paymentId=='free'){
			// free subscription
										
			$db=  JFactory::getDBO();
			//$query=$db->getQuery(true);
						
						
			$qv = "select * FROM `#__vquiz_plans_order` WHERE `order_id`=" . $db->quote($order_id);
			$db->setQuery($qv);
			$results = $db->loadObject();

			$query = 'update #__vquiz_plans_order set status = "31", app_id=0 where order_id = '.$db->Quote($results->order_id); //app_id=0 for free
				
			$db->setQuery( $query );

			if(!$db->execute())	{
				
			}
				
			$query1 = 'update #__vquiz_plans_subscription set status = "1" where id = '.$db->Quote($results->subscr_id);							
			$db->setQuery($query1);
				
			if(!$db->execute())	{
				

					jexit();
			}
			
		}
		elseif($paymentId!='' && $order_id!=''){
				
				if($paymentId=='paypal_pro'){
					$plugin=array($paymentId,$order_id,$data);
				}else{
					$plugin=array($paymentId,$order_id,'orderPlan');
				}
                
				
				
                JPluginHelper::importPlugin('vquiz',$paymentId);
                $dispatcher = JDispatcher::getInstance();
				
                try{					
                    $result_plugin=$dispatcher->trigger('OnCheckout', array(&$plugin));
					//print_r($result_plugin);exit;
                }catch(Exception $e){
                    jexit('{"result":"error", "error":"'.$e->getMessage().'"}');
                } 
				
				// print_r($dispatcher); exit;
				
				if(!empty($result_plugin[0]))
				{
					$text_order = JText::_('EMAIL_SEND_ORDER_ITEM_CHECK_YOUR_MAIL');
			        $text_payment =$payment_status;
			        $msg=$text_order.$text_payment;
					
					if($paymentId=='wire'){
						//print_r($result_plugin); print_r($_POST); exit;
						 
						$db=  JFactory::getDBO();
						//$query=$db->getQuery(true);
						
						
						$qv = "select * FROM `#__vquiz_plans_order` WHERE `order_id`=" . $db->quote($order_id);
						$db->setQuery($qv);
						$results = $db->loadObject();
		
						$query = 'update #__vquiz_plans_order set status = "31" where order_id = '.$db->Quote($results->order_id);
							
						$db->setQuery( $query );
	
						if(!$db->execute())	{
							$msg = JText::sprintf("DB_ERROR_MSG", $results->order_key, $results->buyer_id, $db->getErrorMsg());
								$subject = JText::sprintf('DERRORONUSITE', $sitename);
								//$this->notifytocustomer($payer_email,$subject,$msg);
								//$this->notifytocustomer($user->email,$subject,$msg);
								$this->notifyOwner($user->email,$subject,$msg);

								jexit();
						}
							
						$query1 = 'update #__vquiz_plans_subscription set status = "1" where id = '.$db->Quote($results->subscr_id);							
						$db->setQuery($query1);
							
						if(!$db->execute())	{
							$msg = JText::sprintf("DB_ERROR_MSG", $results->order_key, $results->buyer_id, $db->getErrorMsg());
								$subject = JText::sprintf('DERRORONUSITE', $sitename);
								//$this->notifytocustomer($payer_email,$subject,$msg);
								//$this->notifytocustomer($user->email,$subject,$msg);
								$this->notifyOwner($user->email,$subject,$msg);

								jexit();
						}
					}
				}
            }
			else{
				
				
				$this->setMessage(JText::_('COM_VQUIZ_ERROR_INVALID_PAYMENT_ID'));
				$this->setRedirect(JRoute::_("index.php?option=com_vquiz&view=subscriptions"));

				return false;
			}
	
		$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=subscriptions'),$msg);
		return true;
	}
	function getPaymentId($payment_type)
	{
		$payment_type=strtolower($payment_type);
		$db=JFactory::getDBO();
		$query="SELECT id FROM #__vquiz_payment_plugin WHERE alias='".$payment_type."'";
		$db->setQuery($query);
		$result=$db->loadResult();
		//print_r($trp);jexit(); 
	    return $result;
		
	}
	
	function success()
    {

        $msg=JText::_('THANK_YOU');

        $this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=subscriptions'), $msg );

    }

    function cancel()
    {

        $msg=JText::_('Oops something wrong!');

        $this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=subscriptions'), $msg );

    }
	function paypalNotifyOwner()
	{
		$user = JFactory::getUser();
		$db=  JFactory::getDBO();
		$query=$db->getQuery(true);
		$payapp=$this->getPaymentApp();
		
		$paypal_email=$sandbox="";		
		$params = (!empty($payapp->params))?json_decode($payapp->params):new  stdclass();
		//print_r($params);exit;
		if(isset($params->paypal_email)) {
			$paypal_email=$params->paypal_email;
		}
		if(isset($params->paypal_sandbox)) {
			$sandbox=$params->paypal_sandbox;
		}
		
		$config = QuizHelper::getConfiguration();
		$currency=$config->currencyname ;


		if($sandbox)
		$hostname = 'www.sandbox.paypal.com';
		else
		$hostname = 'www.paypal.com';

		// read the post from PayPal system and add 'cmd'
		$req = 'cmd=_notify-validate';

		foreach ($_POST as $key => $value) {

		$value = urlencode(stripslashes($value));
		$req .= "&$key=$value";

		}

		
		// post back to PayPal system to validate
		$header = "POST /cgi-bin/webscr HTTP/1.1\r\n";
		$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
		$header .= "Host: ".$hostname."\r\n";
		$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";
		
		$fp = fsockopen ('ssl://' .$hostname, 443, $errno, $errstr, 30);

		// assign posted variables to local variables
		$invoice = $_POST['invoice'];
		$item_name = $_POST['item_name'];
		$item_number = $_POST['item_number'];
		$payment_status = $_POST['payment_status'];
		$payment_amount = round($_POST['mc_gross'], 2);
		$mc_amount3 = round($_POST['mc_amount3'], 2);
		$payment_currency = $_POST['mc_currency'];
		$txn_id = $_POST['txn_id'];
		$txn_type = $_POST['txn_type'];
		$receiver_email = $_POST['receiver_email'];
		$payer_email = $_POST['payer_email'];
		
	    
		
if(!$fp){
	
	error_log(JText::_('PAYPAL_SERVER_NOT_CONNECTED'));	
	jexit();
} 
else{
	
		$qv = "select * FROM `#__vquiz_plans_order` WHERE `order_key`=" . $db->quote($invoice);
		$db->setQuery($qv);
		$results = $db->loadObject();
        
		if(empty($results))	{
		error_log(JText::sprintf('NO_ORDER_WITH_INVOICE', $invoice));
		jexit();
		}

		$results->total = round($results->total, 2);

		fputs ($fp, $header . $req);
		while (!feof($fp)) {
			
				$res = fgets ($fp, 1024);
									
				if (stripos($res, "VERIFIED") !== false) {
					
					$now = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
					$user = JFactory::getUser($results->buyer_id);
					if($txn_type == "subscr_cancel"){
						
						$query = 'update #__vquiz_plans_order set status = "35" where order_id = '.$db->Quote($results->order_id);
						$db->setQuery( $query );
						$db->execute();
						$msg = JText::sprintf('SUBSCR_CANCEL_MSG', $invoice, $results->buyer_id);
						$subject = JText::sprintf('SUBSCANCELONYOURSITE', $sitename);
						//$this->notifyOwner($payer_email,$subject,$msg);
						//$this->notifyOwner($user->email,$subject,$msg);
						$this->notifyOwner($user->email,$subject,454);
						jexit();
					}

					elseif($payment_status == "Refunded"){
						
						$query = 'update #__vquiz_plans_order set status = "36" where order_id = '.$db->Quote($results->order_id);
						$db->setQuery( $query );
						$db->execute();
						$msg = JText::sprintf('SUBSCR_REFUND_MSG', $invoice, $results->buyer_id);
						$subject = JText::sprintf('SUBSREFUNDONYOURSITE', $sitename);
						//$this->notifyOwner($payer_email,$subject,$msg);
						//$this->notifyOwner($user->email,$subject,$msg);
						$this->notifyOwner($user->email,$subject,467);
						jexit();
					}
					elseif(($txn_type == "subscr_payment" or $txn_type == "web_accept") and $payment_status == "Completed")	{
						
						
							if($results->gateway_txn_id == $txn_id)	{
								
								$msg = JText::sprintf('TRANS_ALREADY_PROCESSED', $invoice, $results->id, $txn_id);
								$subject = JText::sprintf('TRANS_ALREADY_PROCESSED');
								//$this->notifyOwner($payer_email,$subject,$msg);
								//$this->notifyOwner($user->email,$subject,$msg);
								
								$this->notifyOwner($user->email,$subject,$msg);
								jexit();
							}


							if($receiver_email <> $paypal_email){
								
									$msg = JText::sprintf('SUBSCR_MODIFY_ERROR_DIFF_EMAIL', $invoice, $results->buyer_id, $paypal_email, $receiver_email);
									$subject = JText::sprintf('INVALIDTRANONYOURSITE', $sitename);
									//$this->notifyOwner($payer_email,$subject,$msg);
									//$this->notifyOwner($user->email,$subject,$msg);
									
									$this->notifyOwner($user->email,$subject,$msg);

									jexit();
							}





							if($payment_amount <> $results->total or "USD" <> $payment_currency)	{
								
								$msg = JText::sprintf('SUBSCR_MODIFY_ERROR_DIFF_AMOUNT', $invoice, $results->buyer_id, $results->total, $payment_amount);
								$subject = JText::sprintf('INVALIDTRANONYOURSITE', $sitename);
								//$this->notifyOwner($payer_email,$subject,$msg);
								//$this->notifyOwner($user->email,$subject,$msg);
                                $this->notifyOwner($user->email,$subject,$msg);
								jexit();
							}
							
							$query = 'update #__vquiz_plans_order set status = "31",gateway_txn_id="'.$txn_id.'" where order_id = '.$db->Quote($results->order_id);
							
							$db->setQuery( $query );
//update subscription table col status
							if(!$db->execute())	{
								$msg = JText::sprintf("DB_ERROR_MSG", $invoice, $results->buyer_id, $db->getErrorMsg());
								$subject = JText::sprintf('DERRORONUSITE', $sitename);
								//$this->notifytocustomer($payer_email,$subject,$msg);
								//$this->notifytocustomer($user->email,$subject,$msg);
								$this->notifyOwner($user->email,$subject,$msg);

								jexit();
							}
							
							$query1 = 'update #__vquiz_plans_subscription set status = "1" where id = '.$db->Quote($results->subscr_id);							
							$db->setQuery($query1);
							if(!$db->execute())	{
								$msg = JText::sprintf("DB_ERROR_MSG", $invoice, $results->buyer_id, $db->getErrorMsg());
								$subject = JText::sprintf('DERRORONUSITE', $sitename);
								//$this->notifytocustomer($payer_email,$subject,$msg);
								//$this->notifytocustomer($user->email,$subject,$msg);
								$this->notifyOwner($user->email,$subject,$msg);

								jexit();
							}
							$subject = JText::sprintf("PAYPALIPNTRANONUSITE", $sitename);
							$msg = JText::sprintf('PAYPAL_IPN_TRANSACTION', $payer_email, $results->order_key, $payment_status);
							//$order_detail_info=$this->getOrderDetailInfo($results->id);
							//$this->notifyOwner($payer_email,$subject,$msg);
							//$this->notifyOwner($result->email,$subject,$msg);
                            $this->notifyOwner($user->email,$subject,$msg);
							jexit();
					}			
				}
				else if (strcmp ($res, "INVALID") == 0) {
					$msg=JText::_("INVALID_REPONSE_FROM_PAYPAL");
					$subject=JText::_("INVALID_REPONSE_FROM_PAYPAL");
					error_log(JText::_("INVALID_REPONSE_FROM_PAYPAL"));
					//$this->notifyOwner($payer_email,$subject,$msg);
					//$this->notifyOwner($result->email,$subject,$msg);
                   $this->notifyOwner($user->email,$subject,$msg);  
					jexit();
				}
		}
		fclose ($fp);
		return true;
    }
		
}

	function notifyOwner($email,$subject, $msg )
	{
		$mainframe =  JFactory :: getApplication('site');
	
		$sitename = $mainframe->getCfg('sitename');
		$mailfrom = $mainframe->getCfg('mailfrom');
		$fromname = $mainframe->getCfg('fromname');
		
		//$subject='Testing';
		//$msg='Testing message';
		$mail = JFactory::getMailer();
		//$mailer->setBody($body);
		$mail->sendMail($mailfrom, $fromname, $email, $subject, $msg);
	}
	function getPaymentApp()
	{
		$db = JFactory::getDbo();
		$query=$db->getQuery(true);
		$query = 'select * from #__vquiz_payment_plugin where plugin_type = "paypal" ';
		$db->setQuery( $query );
		$result=$db->loadObject();
		
		return $result;
		
	}
   									
}