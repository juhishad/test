<?php
/*------------------------------------------------------------------------
# com_vquiz - vquiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
class VquizControllerUsersquizzes extends VquizController
{

	function __construct()
	{
		parent::__construct();
		
		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'unpublish',	'publish' );
		$this->registerTask( 'orderup', 		'reorder' );
		$this->registerTask( 'orderdown', 		'reorder' );
		$this->registerTask( 'unfeatured','featured' );	
	
	}
	
	function edit()
	{
		JRequest::setVar( 'view', 'usersquizzes' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);
		
		parent::display();
	}
	
	
 	function publish()
	{
		$model = $this->getModel('usersquizzes');
		$msg = $model->publish();
			

		$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes'), $msg );
	}

		function featured()
	{
 
		
		$model = $this->getModel('usersquizzes');
		$msg = $model->featured();
		
		$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes'), $msg );
		
	}
			
	function reorder()
	{
	
		$model = $this->getModel('usersquizzes');
		$msg = $model->reorder();

		$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes'), $msg );
	
	}
	
	function drawChart()
	{  
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('usersquizzes');
		$obj = $model->drawChart();	
		jexit(json_encode($obj));
	} 
	
 
	
 
	function saveOrder()
	{
	
		$model = $this->getModel('usersquizzes');
		$msg = $model->saveOrder();

	$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes'), $msg );
	
	}
	 
	function save()
	{
		  $model = $this->getModel('usersquizzes');

		if($model->store()) {
			$msg = JText::_('QUIZZES_SAVED_SUCCESS');
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes'), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes'));
		}
	
	}
	

	function apply()
	{
		$model = $this->getModel('usersquizzes');
		if($model->store()) {
			$msg = JText::_('QUIZZES_SAVED_SUCCESS');
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes&task=edit&cid[]='.JRequest::getInt('id', 0)), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes&task=edit&cid[]='.JRequest::getInt('id', 0)) );
		}

	}
	function save2copy()
	{
		
		$model = $this->getModel('usersquizzes');
		if($model->store()) {
			$msg = JText::_('QUIZZES_SAVED_SUCCESS');
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes&task=edit&cid[]='.JRequest::getInt('id', 0)), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes&task=edit&cid[]='.JRequest::getInt('id', 0)) );
		}
	}
	
	function save2new()
	{	
		$model = $this->getModel('usersquizzes');
		if($model->store()) {
			$msg = JText::_('QUIZZES_SAVED_SUCCESS');
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes&task=edit'), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes&task=edit&cid[]='.JRequest::getInt('id', 0)) );
		}
	}

 
	
				function remove()
				{
					$model = $this->getModel('usersquizzes');
					
					if(!$model->delete()) 
					{
						$msg = JText::_('QUIZ_COULD_NOT_DELETED');
					} 
					else 
					{
						$msg = JText::_('QUIZZES_DELETED');
					}
					
					$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=usersquizzes'), $msg );
				}
	
	
			function cancel()
			{
					$msg = JText::_('CANCEL');
					$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes'), $msg );
			}
					
	
			function copyquestion()
			{
				$model = $this->getModel('usersquizzes');
					if(!$model->copyquestion()) 
					$msg = JText::_('QUIZ_COULD_NOT_BE_COPY');
					else 	 
					$msg = JText::_('COPY_SUCCESSFUL');
					$this->setRedirect( 'index.php?option=com_vquiz&view=usersquizzes', $msg );
			}
							
		  function movequestion()
			{
				$model = $this->getModel('usersquizzes');
					if(!$model->movequestion()) 
					$msg = JText::_('QUIZ_COULD_NOT_BE_COPY');
					else 	 
					$msg = JText::_('MOVE_SUCCESSFUL');
					$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes'), $msg );
			}
 
		 
		 function trivia_message()
			{ 
				$model = $this->getModel('usersquizzes');
				if($model->trivia_messagestore()) {
					$quizid=JRequest::getInt('id');
					$msg = JText::_('MESSAGE_SAVE_SUCCESS');
					$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes&layout=trivia_messages&id='.$quizid.'&tmpl=component'), $msg );
				} else {
					jerror::raiseWarning('', $model->getError());
					$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=usersquizzes&layout=trivia_messages&tmpl=component'));
				}
			
			}

			 function personality_message()
			{ 
				$model = $this->getModel('usersquizzes');
				if($model->personality_messagestore()) {
					$quizid=JRequest::getInt('id');
					$msg = JText::_('MESSAGE_SAVE_SUCCESS');
					$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=usersquizzes&layout=personality_messages&id='.$quizid.'&tmpl=component'), $msg );
				} else {
					jerror::raiseWarning('', $model->getError());
					$this->setRedirect( JRoute::_('index.php?option=com_vquiz&view=usersquizzes&layout=personality_messages&tmpl=component'));
				}
			
			}
			
	function Question_options(){
	
		JRequest::checkToken() or jexit('{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('usersquizzes');
		$obj=$model->getQuestion_options();
		jexit(json_encode($obj));
		
	}
	function Question_weight(){
	
		JRequest::checkToken() or jexit('{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('usersquizzes');
		$obj=$model->getQuestion_weight();
		jexit(json_encode($obj));
		
	}
	
	function Question_weight_apply(){
	
		JRequest::checkToken() or jexit('{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('usersquizzes');
		$obj=$model->getQuestion_weight_apply();
		jexit(json_encode($obj));
		
	}

}