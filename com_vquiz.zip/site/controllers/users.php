<?php
/*------------------------------------------------------------------------
# com_vquiz - vquiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

class VquizControllerUsers extends VquizController
{
	
	function __construct()
	{
		parent::__construct();
		
		$this->model = $this->getModel('users');
		
		JRequest::setVar( 'view', 'users' );
	
		// Register Extra engineers
		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'unpublish',	'publish' );

	}

	/**
	 * display the edit form
	 * @return void
	 */
	function edit()
	{
		JRequest::setVar( 'view', 'users' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);
		
		parent::display();
	}

	/**
	 * save a record (and redirect to main page)
	 * @return void
	 */
	function save()
	{
	
		$mainframe = JFactory::getApplication();
		$lang = JFactory::getLanguage();
		$lang->load('com_users');
		jimport('joomla.user.helper');
		
		// Get required system objects
		$config		=  JFactory::getConfig();
		$params	= JComponentHelper::getParams('com_users');
		
		if($this->model->store()) {
			$msg = JText::_( 'Record Saved successfully' );
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=users'));
		} else {
			jerror::raiseWarning('', $this->model->getError());
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=users'));
		}

	}
	
	function apply()
	{
		
		if($this->model->store()) {
			$msg = JText::_('RECORD_SAVED');
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=users&task=edit&cid[]='.JRequest::getInt('id', 0)), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=users&task=edit&cid[]='.JRequest::getInt('id', 0)));
		}

	}
	
	/**
	 * Publish record(s)
	 * @return void
	 */
	function publish()
	{
		$task		= JRequest::getCmd( 'task' );
		$msg  	= $task == 'publish' ? JText::_('RECORD_PUBLISHED_SUCCESSFULLY') : JText::_( 'RECORD_UNPUBLISHED_SUCCESSFULLY' );
		if($this->model->publish()) {
			//$msg = JText::_( 'Record Published successfully' );
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=users'), $msg );
		} else {
			jerror::raiseWarning('', $this->model->getError());
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=users'));
		}

	}
	
	 

	/**
	 * remove record(s)
	 * @return void
	 */
	function remove()
	{
		
		if($this->model->delete()) {
			$msg = JText::_('RECORD_DELETED_SUCCESSFULLY' );
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=users'), $msg );
		} else {
			jerror::raiseWarning('', $this->model->getError());
			$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=users'));
		}
		
	}

	/**
	 * cancel editing a record
	 * @return void
	 */
	function cancel()
	{
		$msg = JText::_('CANCEL');
		$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=users'), $msg );
	}
 
			
	public function login()
	{
	 $app = JFactory::getApplication();
		// Populate the data array:
		$data = array();
		//$data['return'] = base64_decode($app->input->post->get('return', '', 'BASE64'));
		$data['return'] = base64_decode(JRequest::getVar('return', '', 'POST', 'BASE64'));
		$data['username'] = JRequest::getVar('username', '', 'method', 'username');
		$data['password'] = JRequest::getString('password', '', 'post', JREQUEST_ALLOWRAW);
		//$data['secretkey'] = JRequest::getString('secretkey', '');

		// Set the return URL if empty.
		if (empty($data['return']))
		{
			//$data['return'] = 'index.php?option=com_users&view=profile';
			$data['return'] ='index.php?option=com_vquiz&view=users&tmpl=component';
		}

		// Set the return URL in the user state to allow modification by plugins
		$app->setUserState('users.login.form.return', $data['return']);

		// Get the log in options.
		$options = array();
		$options['remember'] = $this->input->getBool('remember', false);
		$options['return'] = $data['return'];

		// Get the log in credentials.
		$credentials = array();
		$credentials['username']  = $data['username'];
		$credentials['password']  = $data['password'];
		//$credentials['secretkey'] = $data['secretkey'];

		// Perform the log in.
		if (true === $app->login($credentials, $options))
		{
			// Success
			if ($options['remember'] = true)
			{
				$app->setUserState('rememberLogin', true);
			}

			$app->setUserState('users.login.form.data', array());
			//$app->redirect(JRoute::_($app->getUserState('users.login.form.return'), false));	
		   //$app->redirect(JRoute::_('index.php?option=com_trademanager&view=trademanager&layout=registration&tmpl=component&login=1&Itemid=518', false));
			$msg= JText::_('YOUR_ARE_SUCCESSFULLY_LOGIN');	
			

		}
		else
		{
			// Login failed !
			$data['remember'] = (int) $options['remember'];
			$app->setUserState('users.login.form.data', $data);
			//$app->redirect(JRoute::_($app->getUserState('users.login.form.return'), false));		
			//$app->redirect(JRoute::_('index.php?option=com_trademanager&view=trademanager&layout=registration&tmpl=component&Itemid=518', false));
			$msg = JText::_('USERNAME_PASSWORD_DONOT_MATCH');
		}
		
		
		$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=users'), $msg );
		
	}
			
			
		 
}