<?php
/*------------------------------------------------------------------------
# com_vquiz - vquiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerQuizresult extends VquizController
{

	function __construct()
	{
		parent::__construct();
		$this->registerTask( 'add'  , 	'edit' );
	}
	
	function edit()
	{
		JRequest::setVar( 'view', 'quizresult' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);
		parent::display();
	}
	
	function apply()
	{
		$model = $this->getModel('quizresult');
		
		$self_result=JRequest::getVar('self_result', 0);
		if($self_result==1){
			$link=JRoute::_('index.php?option=com_vquiz&view=quizresult&layout=myresults');
		}else{
			$link=JRoute::_('index.php?option=com_vquiz&view=quizresult');
		}
	
		if($model->store()) {
			$msg = JText::_('GREETING_SAVE');
			$this->setRedirect($link, $msg );
		} else {
			jerror::raiseWarning('', $this->model->getError());
			$this->setRedirect($link);
		}
		
	}
	
	 function save_textarea_answer(){
		$id= JRequest::getInt('id',0);
		$model = $this->getModel('quizresult');
		$model->getUpdatetextarea_score();
		$msg = JText::_('TEXT_AREA_SCORE_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizresult&task=edit&cid[]='.$id, $msg );
	}
		
		
	function remove()
	{
		$model = $this->getModel('quizresult');
		if(!$model->delete()) 
		{
			$msg = JText::_('QUIZRESULT_COULD_NOT_DELETED');
		} 
		else 
		{
			$msg = JText::_('GREETING_DELETED');
		}
		
		$self_result=JRequest::getVar('self_result', 0);
		if($self_result==1){
			$link=JRoute::_('index.php?option=com_vquiz&view=quizresult&layout=myresults');
		}else{
			$link=JRoute::_('index.php?option=com_vquiz&view=quizresult');
		}
		
		$this->setRedirect($link, $msg );
	
	}
	
	function cancel()
	{
		$self_result=JRequest::getVar('self_result', 0);
		if($self_result==1){
			$link=JRoute::_('index.php?option=com_vquiz&view=quizresult&layout=myresults');
		}else{
			$link=JRoute::_('index.php?option=com_vquiz&view=quizresult');
		}
 
		$msg = JText::_('OPERATION_CANCELLED');
		$this->setRedirect($link, $msg );
	}	
	
	function export()
	{
		$model = $this->getModel('quizresult');
		$model->getCsv();	
		//JPluginHelper::importPlugin('hexdata', $profile->plugin);
		$dispatcher = JDispatcher::getInstance();
		
		$self_result=JRequest::getVar('self_result', 0);
		if($self_result==1){
			$link=JRoute::_('index.php?option=com_vquiz&view=quizresult&layout=myresults');
		}else{
			$link=JRoute::_('index.php?option=com_vquiz&view=quizresult');
		}
		
		try{
			$dispatcher->trigger('startExport');
			jexit(/*JText::_('INTERNAL_SERVER_ERROR')*/);
		}catch(Exception $e){
			jerror::raiseWarning('', $e->getMessage());
			$this->setRedirect($link, $msg );
		}
	
	}

}