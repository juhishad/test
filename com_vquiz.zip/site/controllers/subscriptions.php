<?php
/*------------------------------------------------------------------------
# com_vquiz - vquiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerSubscriptions extends VquizController
{

	function __construct()
	{
		parent::__construct();
		$this->registerTask( 'add'  , 	'edit' );
	}
	
	function edit()
	{
		JRequest::setVar( 'view', 'subscriptions' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);
		parent::display();
	}
	
	function apply()
	{
		$model = $this->getModel('subscriptions');		
		
		$link=JRoute::_('index.php?option=com_vquiz&view=subscriptions');
		
	
		if($model->store()) {
			$msg = JText::_('COM_VQUIZ_SUBSCRIPTIONS_SAVED');
			$this->setRedirect($link, $msg );
		} else {
			jerror::raiseWarning('', $this->model->getError());
			$this->setRedirect($link);
		}
		
	}
	
	 
		
	function remove()
	{
		$model = $this->getModel('subscriptions');
		if(!$model->delete()) 
		{
			$msg = JText::_('COM_VQUIZ_SUBSCRIPTIONS_NOT_DELETED');
		} 
		else 
		{
			$msg = JText::_('COM_VQUIZ_SUBSCRIPTIONS_DELETED');
		}
		
		
		$link=JRoute::_('index.php?option=com_vquiz&view=subscriptions');
		
		
		$this->setRedirect($link, $msg );
	
	}
	
	function cancel()
	{
		
		$link=JRoute::_('index.php?option=com_vquiz&view=subscriptions');
		
 
		$msg = JText::_('OPERATION_CANCELLED');
		$this->setRedirect($link, $msg );
	}

}