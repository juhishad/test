<?php
/*------------------------------------------------------------------------
# com_vquiz - vquiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerLearning extends VquizController
{
	
	function __construct()
	{
		parent::__construct();
		$this->registerTask('add','edit' );
	}
 function subscribe(){
		    $session = JFactory::getSession();
			
			$user = JFactory::getUser();
						
			if ($user->id!=0)
			{
				$model = $this->getModel('learning');	
				
				$config = $model->createUserOrderBeforePay();
				
				if($config){
                 $link = JRoute::_('index.php?option=com_vquiz&view=orders&order_key='.JRequest::getString('order_key', 0));					
                 $this->setRedirect( $link);
				}
				 else
				{
					
					JRequest::setVar( 'view', 'plans' );
					JRequest::setVar( 'layout', 'form'  );
					parent::display();	
				} 
            }
			else
			{
			
			JRequest::setVar( 'view', 'plans' );
			JRequest::setVar( 'layout', 'form'  );	
			parent::display();	
			}
			
	}
		function subscribes(){
			
		$jinput = JFactory::getApplication()->input;
			//print_r($jinput);
		    $model = $this->getModel('learning');
	        $ch = self::_doStartRegistration(); //exit;
			
			$config = $model->createUserOrderBeforePay();
			$link = JRoute::_('index.php?option=com_vquiz&view=orders&&order_key='.JRequest::getString('order_key', 0),false); 
			$this->setRedirect($link);	
	}
	protected function _doStartRegistration()
	{
		$jinput = JFactory::getApplication()->input;
		//print_r($jinput);exit;
		$app 				= JFactory::getApplication();
		$learning_id 		= $app->input->getString('learning_id', false);
		$email 				= $app->input->get('vquizRegisterAutoEmail', false, '@');
		$username 			= $app->input->get('vquizRegisterAutoUsername', false, '@');
		$password 			= $app->input->getString('vquizRegisterAutoPassword', false);
		$fullname			= $app->input->getString('vquizUserFullname', false);
		
		// if $username is not post then redirect to login page again
		if(!$username){
			$this->_app->redirect(JRoute::_('index.php?option=com_vquiz&view=learning&task=subscribe&learning_id='.$learning_id,false));
		}
		
		// if email is not post then redirect to login page again
		if(!$email){
			$this->_app->redirect(JRoute::_('index.php?option=com_vquiz&view=learning&task=subscribe&learning_id='.$learning_id));
		}
		
		// if password is not post then redirect to login page again
		if(!$password || JString::strlen(Jstring::trim($password)) === 0) {
			$this->_app->redirect(JRoute::_('index.php?option=com_vquiz&view=learning&task=subscribe&learning_id='.$learning_id));
		}

        
		$userId = self::_autoRegister($username, $email, $password,$fullname);
		if($userId){
			// registration is completed here so call afterRegistrationComplete
			$this->_setUser($userId);
			return $this->_doCompleteRegistration();
		}
		
		return true;
	}
	function _autoRegister($username, $email, $password, $fullname=null)
	{
		$app 				= JFactory::getApplication();
		require_once  JPATH_ROOT.DS.'components'.DS.'com_users'.DS.'models'.DS.'registration.php';
	    if( empty($fullname)){
        	$fullname=$username;
        }
		
		$model 	= new UsersModelRegistration();
		JFactory::getLanguage()->load('com_users');
		
		
		// load user helper
		jimport('joomla.user.helper');
		$temp 	= array(	'username'=>$username,'name'=>$fullname,'email1'=>$email,
						'password1'=>$password, 'password2'=>$password, 'block'=>0 );
				
		$config = JFactory::getConfig();
		$params = JComponentHelper::getParams('com_users');

		
		// Initialise the table with JUser.
		$user 	= new JUser;
		$data 	= (array)$model->getData();
		// Merge in the registration data.
		foreach ($temp as $k => $v) {
			$data[$k] = $v;
		}

		// Prepare the data for the user object.
		$data['email']		= $data['email1'];
		$data['password']	= $data['password1'];
		
		
		// Check if the user needs to activate their account.
		if (1) {
			jimport('joomla.user.helper');
			$data['activation'] = JApplication::getHash(JUserHelper::genRandomPassword());
			$data['block'] = 0;
		}

		// Bind the data.
		if (!$user->bind($data)) {
			$app->enqueueMessage(JText::sprintf('PLG_VQUIZSREGISTRATION_AUTO_BIND_FAILED', $user->getError()));
			return false;
		}

		// Load the users plugin group and Store the data
		JPluginHelper::importPlugin('user');
		if (!$user->save()) {
			$app->enqueueMessage(JText::sprintf('PLG_VQUIZREGISTRATION_AUTO_REGISTRATION_SAVE_FAILED', $user->getError()));
			return false;
		}
		

		// Compile the notification mail values.
		$data 				= $user->getProperties();
		$data['fromname']	= $config->get('fromname');
		$data['mailfrom']	= $config->get('mailfrom');
		$data['sitename']	= $config->get('sitename');
		$data['siteurl']	= JUri::base();
 
		return $user->id;
	}
	public function _doCompleteRegistration()
	{		
		$app = JFactory::getApplication();
		$session = JFactory::getSession();
		/* if(!self::_getPlan()){
			// if plan is not selected then do not create order
			// do not do anything 
			self::_setUser(0);
			return true;		
		} */
		$userId	= self::_getUser();
		
						
		// get user id in REGISTRATION_NEW_USER_ID to check it during session expiration checking	
		$session->set('REGISTRATION_NEW_USER_ID', $userId);				
		
		
		// now redirect to confirm action
		return true;
						
	}
	public function _setUser($userId)
	{
		$session = JFactory::getSession(); //print_r($session); exit;
		$session->set('REGISTRATION_USER_ID', $userId);
		return true;
	}
	
	public function _getUser($id = null)
	{
		$session = JFactory::getSession();
		return $session->get('REGISTRATION_USER_ID', 0);
	}
} 
  