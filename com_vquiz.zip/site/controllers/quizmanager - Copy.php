<?php
/*------------------------------------------------------------------------
# com_vquiz - vquiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
  jimport('joomla.filesystem.folder');
class VquizControllerQuizmanager extends VquizController
{
 
	function __construct()
	{
		parent::__construct();
		$this->registerTask( 'add'  , 	'edit' );
	}
	function subscribe(){
		    $session = JFactory::getSession();
			
			$user = JFactory::getUser();
			//echo $user->id;//$user_id = $session->get('user_id','');
			//exit;
			
			if ($user->id!=0)
			{
				$model = $this->getModel('quizmanager');	
				
				$config = $model->createUserOrderBeforePay();
				//print_r(JRequest::getString('order_key', 0));exit;
				if($config){
                 $link = JRoute::_('index.php?option=com_vquiz&view=orders&order_key='.JRequest::getString('order_key', 0));					
                 $this->setRedirect( $link);
				}
				 else
				{
					
					JRequest::setVar( 'view', 'plans' );
					JRequest::setVar( 'layout', 'form'  );
					parent::display();	
				} 
            }
			else
			{
			
			JRequest::setVar( 'view', 'plans' );
			JRequest::setVar( 'layout', 'form'  );	
			parent::display();	
			}
			
	}
		function subscribes(){
			
		$jinput = JFactory::getApplication()->input;
			//print_r($jinput);
		    $model = $this->getModel('quizmanager');
	        $ch = self::_doStartRegistration(); //exit;
			
			$config = $model->createUserOrderBeforePay();
			$link = JRoute::_('index.php?option=com_vquiz&view=orders&&order_key='.JRequest::getString('order_key', 0),false); 
			$this->setRedirect($link);	
	}
	protected function _doStartRegistration()
	{
		$jinput = JFactory::getApplication()->input;
		//print_r($jinput);exit;
		$app 				= JFactory::getApplication();
		$quizId 			= $app->input->getString('quiz_id', false);
		$email 				= $app->input->get('vquizRegisterAutoEmail', false, '@');
		$username 			= $app->input->get('vquizRegisterAutoUsername', false, '@');
		$password 			= $app->input->getString('vquizRegisterAutoPassword', false);
		$fullname			= $app->input->getString('vquizUserFullname', false);
		
		// if $username is not post then redirect to login page again
		if(!$username){
			$this->_app->redirect(JRoute::_('index.php?option=com_vquiz&view=quizmanager&task=subscribe&quiz_id='.$quizId,false));
		}
		
		// if email is not post then redirect to login page again
		if(!$email){
			$this->_app->redirect(JRoute::_('index.php?option=com_vquiz&view=quizmanager&task=subscribe&quiz_id='.$quizId));
		}
		
		// if password is not post then redirect to login page again
		if(!$password || JString::strlen(Jstring::trim($password)) === 0) {
			$this->_app->redirect(JRoute::_('index.php?option=com_vquiz&view=quizmanager&task=subscribe&quiz_id='.$quizId));
		}

        
		$userId = self::_autoRegister($username, $email, $password,$fullname);
		if($userId){
			// registration is completed here so call afterRegistrationComplete
			$this->_setUser($userId);
			return $this->_doCompleteRegistration();
		}
		
		return true;
	}
	function _autoRegister($username, $email, $password, $fullname=null)
	{
		$app 				= JFactory::getApplication();
		require_once  JPATH_ROOT.DS.'components'.DS.'com_users'.DS.'models'.DS.'registration.php';
	    if( empty($fullname)){
        	$fullname=$username;
        }
		
		$model 	= new UsersModelRegistration();
		JFactory::getLanguage()->load('com_users');
		
		
		// load user helper
		jimport('joomla.user.helper');
		$temp 	= array(	'username'=>$username,'name'=>$fullname,'email1'=>$email,
						'password1'=>$password, 'password2'=>$password, 'block'=>0 );
				
		$config = JFactory::getConfig();
		$params = JComponentHelper::getParams('com_users');

		
		// Initialise the table with JUser.
		$user 	= new JUser;
		$data 	= (array)$model->getData();
		// Merge in the registration data.
		foreach ($temp as $k => $v) {
			$data[$k] = $v;
		}

		// Prepare the data for the user object.
		$data['email']		= $data['email1'];
		$data['password']	= $data['password1'];
		
		
		// Check if the user needs to activate their account.
		if (1) {
			jimport('joomla.user.helper');
			$data['activation'] = JApplication::getHash(JUserHelper::genRandomPassword());
			$data['block'] = 0;
		}

		// Bind the data.
		if (!$user->bind($data)) {
			$app->enqueueMessage(JText::sprintf('PLG_VQUIZSREGISTRATION_AUTO_BIND_FAILED', $user->getError()));
			return false;
		}

		// Load the users plugin group and Store the data
		JPluginHelper::importPlugin('user');
		if (!$user->save()) {
			$app->enqueueMessage(JText::sprintf('PLG_VQUIZREGISTRATION_AUTO_REGISTRATION_SAVE_FAILED', $user->getError()));
			return false;
		}
		

		// Compile the notification mail values.
		$data 				= $user->getProperties();
		$data['fromname']	= $config->get('fromname');
		$data['mailfrom']	= $config->get('mailfrom');
		$data['sitename']	= $config->get('sitename');
		$data['siteurl']	= JUri::base();
 
		return $user->id;
	}
	public function _doCompleteRegistration()
	{		
		$app = JFactory::getApplication();
		$session = JFactory::getSession();
		/* if(!self::_getPlan()){
			// if plan is not selected then do not create order
			// do not do anything 
			self::_setUser(0);
			return true;		
		} */
		$userId	= self::_getUser();
		
						
		// get user id in REGISTRATION_NEW_USER_ID to check it during session expiration checking	
		$session->set('REGISTRATION_NEW_USER_ID', $userId);				
		
		
		// now redirect to confirm action
		return true;
						
	}
	public function _setUser($userId)
	{
		$session = JFactory::getSession(); //print_r($session); exit;
		$session->set('REGISTRATION_USER_ID', $userId);
		return true;
	}
	
	public function _getUser($id = null)
	{
		$session = JFactory::getSession();
		return $session->get('REGISTRATION_USER_ID', 0);
	}
	function edit()
	{
		JRequest::setVar( 'view', 'quizmanager' );
		JRequest::setVar( 'layout', 'quizzes'  );
		JRequest::setVar( 'layout', 'quizresult'  );
		JRequest::setVar( 'layout', 'description'  );
		JRequest::setVar('hidemainmenu', 1);
		parent::display();
	}

	function flagcount()
	{ 

		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->flagcount();		
		jexit(json_encode($obj));
	} 
		
	function penaltyexpiredtime()
	{ 
		
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->penaltyexpiredtime();		
		jexit(json_encode($obj));
	} 
		

	function quizzesdesc()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$itemid = JRequest::getInt('quizid',0); //echo $itemid; exit;
		$model = $this->getModel('quizmanager');
		$obj = $model->quizzesdesc($itemid);		
		jexit(json_encode($obj));
	} 

   	function later_play()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->later_play();		
		jexit(json_encode($obj));
	} 

  	function nextslide()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->nextslide();		
		jexit(json_encode($obj));
	} 

	function backslide()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->backslide();		
		jexit(json_encode($obj));

	}

	function showresult()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->showresult();		
		jexit(json_encode($obj));
	}

	function questionexplanation()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->questionexplanation();		
		jexit(json_encode($obj));
	}
	
	function questionhint()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->questionhint();		
		jexit(json_encode($obj));
	}
	
	function questiontranscript()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->questiontranscript();		
		jexit(json_encode($obj));
	}
	

	function share_snapshot()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->share_snapshot();		
		jexit(json_encode($obj));
	} 
 
	/*---Get Certificate congiguration---*/
 	function getcertificate_Confi($quizid,$uniqvariable,$certificate_name)
	{

		$user = JFactory::getUser();
		$session = JFactory::getSession();
		
		$datetime = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
		$db = JFactory::getDbo();
		$model = $this->getModel('quizmanager');
		
		if($session->has('checkresult_id'.$uniqvariable)){
			
			$checkresult_id =$session->get('checkresult_id'.$uniqvariable);
			
			$query = ' SELECT r.* ,q.title as quiztitle, q.answers_type as answers_type,q.correctans as  correctans,q.personality_type as personality_type,q.enable_questiongroup as enable_questiongroup,q.quiztype as quiztype FROM #__vquiz_quizresult as r left join  #__vquiz_quizzes as q on q.id=r.quizid WHERE r.id = '.$checkresult_id.' order by r.id desc';
			
		}else{
			
			$query = ' SELECT r.* ,q.title as quiztitle, q.answers_type as answers_type,q.correctans as  correctans,q.personality_type as personality_type,q.enable_questiongroup as enable_questiongroup,q.quiztype as quiztype FROM #__vquiz_quizresult as r left join  #__vquiz_quizzes as q on q.id=r.quizid WHERE r.userid = '.$db->quote($user->id).' order by r.id desc limit 0 1';
		}
		
		$db->setQuery( $query );
		$quizesult =$db->loadObject();
		
		$check_textarea_score = $model->getCheck_textarea_question($quizid);
		$quiztype=$quizesult->quiztype;
		$score=$quizesult->score;
		$maxscore=$quizesult->maxscore;
		$title=$quizesult->quiztitle;
		$startdatetime=$quizesult->starttime;
		$enddatetime=$quizesult->endtime;
		$play_date=$quizesult->created;
		$passed_score=$quizesult->passed_score;
		$enable_questiongroup=$quizesult->enable_questiongroup;
		//$flag=$quizesult->flag;
		$quizid=$quizesult->quizid;
		//$quizoptions=json_decode($quizesult->quiz_answers);
		
		$query = 'select a.text_answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$db->quote($checkresult_id).' order by qna_id asc';
		$db->setQuery( $query );
		$text_answer =$db->loadColumn();
		
		$query = 'select a.textarea_answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$db->quote($checkresult_id).' order by qna_id asc';
		$db->setQuery( $query );
		$textarea_answer =$db->loadColumn();
											
		$query=$db->getQuery(true);
		$query->select('sum(q.flagcount)');
		$query->from($db->quoteName('#__vquiz_question').' as q');
		$query->join('LEFT',$db->quoteName('#__vquiz_quiznques').' as a on a.questionid=q.id');
		$query->where('a.quizid ='.$db->quote($quizesult->quizid));
		$db->setQuery($query);
		$flag = $db->loadResult();
		
		$query = 'select a.answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$db->quote($quizesult->id).' order by qna_id asc';
		$db->setQuery( $query );
		$quiz_answers =$db->loadColumn();
		
		

		$message='';
		$personality_message='';
		$personality_message_result='';

		$stime=strtotime($quizesult->endtime)-strtotime($quizesult->starttime);
		$h=floor($stime/3600);
		$hr=$stime%3600;
		$m=floor($hr/60);
		$mr=$stime%60;
		$s=floor($mr); 
		$ht=$h>0?$h.'h':'';
		$mt=$m>0?$m.'m':'';
		$st=$s>0?$s.'s':'';
		$spenttime=$ht.'  ' .$mt.'  '.$st;
		
		
		$query = 'select * from #__vquiz_quizzes where id='.$db->quote($quizid);
		$db->setQuery( $query );
		$quizzes =$db->loadObject();	
		
		
		$query = 'select * from #__vquiz_configuration';
		$db->setQuery( $query );
		$confiresult =$db->loadObject();
		
		if(!empty($quizzes->certificate)){
		
			$text = $quizzes->certificate;
			$cet_digits =$quizzes->cet_digits;
			$certificate_number =$quizzes->start_with;
			
		}else{
		
			if($quizzes->quiztype==2 OR $quizzes->quiztype==22){
				$text = $confiresult->mailformat2;
			}
			else{
				$text = $confiresult->mailformat;
			}
			$cet_digits =$confiresult->cet_digits;
			$certificate_number =$confiresult->start_with;
		}
		

		function generateRandomAlphanumericString($cet_digits) {
			return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $cet_digits);
		}
		function generateRandomAlphabeticString($cet_digits) {
			return substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $cet_digits);
		}
		function generateRandomnumericString($cet_digits) {
			return substr(str_shuffle("0123456789"), 0, $cet_digits);
		}

		if($quizzes->quiztype==2 OR $quizzes->quiztype==2){
			if(!empty($quizzes->personality_certificate)){
				$cet_type = $quizzes->cet_type;
				$cet_format = $quizzes->cet_format;
			}else{
				$cet_type = $confiresult->cet_type;
				$cet_format = $confiresult->cet_format;
			}
		}
		else{
		
			if(!empty($quizzes->trivia_certificate)){
				$cet_type = $quizzes->cet_type;
				$cet_format = $quizzes->cet_format;
			}else{
				$cet_type = $confiresult->cet_type;
				$cet_format = $confiresult->cet_format;
			}
			
		}
		
		if($cet_type==1){
			if($cet_format==1){
				$certificate_number .=generateRandomAlphanumericString($cet_digits);
			}elseif($cet_format==2){
				$certificate_number .=generateRandomAlphabeticString($cet_digits);
			}else{
				$certificate_number .=generateRandomnumericString($cet_digits);
			}
			
		}else{
		
			$query = ' SELECT count( * ) FROM #__vquiz_quizresult ';
			$db->setQuery( $query );
			$input_sequnce =$db->loadResult();
			$certificate_number .=str_pad($input_sequnce, $cet_digits, 0, STR_PAD_LEFT);
		}
		
		if($quizzes->quiztype==2 OR $quizzes->quiztype==22){
			if(!empty($quizzes->personality_certificate)){
				$certificate_number .= $quizzes->end_with;
			}else{
				$certificate_number .= $confiresult->end_with;
			}
		}
		else{
		
			if(!empty($quizzes->trivia_certificate)){
				$certificate_number .= $quizzes->end_with;
			}else{
				$certificate_number .= $confiresult->end_with;
			}
			
		}
		if($enable_questiongroup==1)
		{
			$html_qgroup_score  ='<table border="1" width="100%" cellspacing="0" cellpadding="5"><tr><th>'.JText::_('CATE_SCORE_TITLE').'</th><th>'.JText::_('CATE_SCORE_SCORE').'</th><th>'.JText::_('GROUP_SCORE_RATING').'</th><th>'.JText::_('GROUP_SCORE_MESSAGE').'</th></tr>';
			$query = 'select  guestiongroup, score from #__vquiz_quizresult_questiongroup where resultid='.$db->quote($checkresult_id);
			$db->setQuery( $query );
			$question_grp_result =$db->loadObjectList();
			//print_r($question_grp_result);exit;
			if(!empty($question_grp_result))
			{
			for($i=0;$i<count($question_grp_result);$i++)
			{
				$query='select * from #__vquiz_quizzes_questiongroup_message where score >= ' .(int)$question_grp_result[$i]->score.' and groupid ='.$question_grp_result[$i]->guestiongroup.' order by id asc  ';
				
				$db->setQuery( $query );
				$grp_msg_result =$db->loadObject();
				if(!empty($grp_msg_result)){
						$qgroup_message=$grp_msg_result->message;
						$qgroup_rating=$grp_msg_result->rating;
						$qgroup_description=$grp_msg_result->description;
				}
				else{
					
					$qgroup_message='';
					$qgroup_rating='';
					
				}
				 $query='select title from #__vquiz_quizzes_questiongroup where qorder = ' .$question_grp_result[$i]->guestiongroup ;
				// print_r($query);exit;
				$db->setQuery( $query );
				$res =$db->loadResult();
				$title = !empty($res)?$res:'---'; 
						$qgroup_title=$title;
						$qgroup_score=$question_grp_result[$i]->score;
						if($check_textarea_score==1)
					{
						$qgroup_score='--';
						$qgroup_rating='--';
						$qgroup_message='--';
					}
						
						
				$html_qgroup_score  .='<tr><td>'.$qgroup_title.'</td><td>'.$qgroup_score.'</td>';
				$html_qgroup_score  .='<td>'.$qgroup_rating.'</td>';
			$html_qgroup_score  .='<td>'.$qgroup_message.'</td></tr>';
			}
				$html_qgroup_score .='</table>';
			}
			else
			{
				$html_qgroup_score='---';
			}
			
		}
		if($quizzes->quiztype==1 OR $quizzes->quiztype==11){

			$query='select id,message as message from #__vquiz_trivia_message where quizid='.$db->quote($quizid).' and score>='.$score.' order by score asc';
			$db->setQuery($query);
			$trivia_result = $db->loadObject();
			
			if(empty($trivia_result)){
			
				$query='select id,message as message from #__vquiz_trivia_message where quizid='.$db->quote($quizid).' order by score desc';
				$db->setQuery($query);
				$trivia_result = $db->loadObject();
			}

			if($trivia_result!=''){
				$trivia_message = $trivia_result->message;
			}else{
				$trivia_message ='';
			}
			
		}else if($quizzes->quiztype==2 OR $quizzes->quiztype==22){
			
			$all_optionid=array();
			for($op=0;$op<count($quiz_answers);$op++){
				if(!empty($quiz_answers[$op])){
					array_push($all_optionid,$quiz_answers[$op]);
				}else
					array_push($all_optionid,0);
			}

			$query = "select personality_optionid from #__vquiz_option Where id IN (".implode(',',$all_optionid).")";
			$db->setQuery($query);	
			$result=$db->loadColumn();	

			$count=array_count_values($result);
			$match_value_pc='';
			
			
			if($quizzes->personality_type==2){
			
				$resulted_value=json_encode($result);
				$match_value_pc=$model->check_pcategory($quizid,$resulted_value);
				
				if($match_value_pc!=''){
					$query ='select id,answer as personality_answer,article_id,description as personality_desc,quizid from #__vquiz_personality_message where category_combination='.$db->quote($match_value_pc);
				}else{
					$query ='select id,answer as personality_answer,article_id ,description as personality_desc,quizid from #__vquiz_personality_message order by id desc limit 1';
				}
						
				
			}else{
				arsort($count);
				$keys=array_keys($count);

				$remove = array(0);
				$keys = array_values(array_diff($keys, $remove));   
				$most_selected_id = $keys[0];

				if($most_selected_id){
					$query ='select id,answer as personality_answer,description as personality_desc,quizid from #__vquiz_personality_message where id='.$most_selected_id;
				}else{
					$query ='select id,answer as personality_answer,description as personality_desc,quizid from #__vquiz_personality_message order by id desc limit 1';
				}
			}

			$db->setQuery( $query );
			$personality_result=$db->loadObject();

			$personality_message_result=$personality_result->personality_answer;
			$personality_message=$personality_result->personality_desc;
			
		}
			

			if($maxscore>0){
				$persentagescore=round($score/$maxscore*100,2)>100?100:round($score/$maxscore*100,2);
			}	
			else{
				$persentagescore=$score;
			}

			if($persentagescore>=$passed_score){
				$passed_text='<span style="color:green">'.JText::_('PASSED').'</span>';	
			}
			else{
				$passed_text='<span style="color:red">'.JText::_('FAILED').'</span>';
			}

			if(!empty($certificate_name)){
				$username=$certificate_name;
			}elseif(!$user->get('guest')){
				$username=$user->username;
			}else{
				$username=JText::_('COM_VQUIZ_GUEST');
			}
				
				
				
			if(strpos($text, '{username}')!== false)
			{
				$text = str_replace('{username}', $username, $text);
			}
				
			if(strpos($text, '{quizname}')!== false)
			{
				$text = str_replace('{quizname}', $title, $text);
			}
				
			if(strpos($text, '{userscore}')!== false)
			{
				if($check_textarea_score==1){
					$text = str_replace('{userscore}', '--', $text);
				}else{
					$text = str_replace('{userscore}', $score, $text);
				}
			}

			if(strpos($text, '{maxscore}')!== false)
			{
				if($check_textarea_score==1){
				$text = str_replace('{maxscore}', '--', $text);
				}else{
				$text = str_replace('{maxscore}', $maxscore, $text);
		}
			}
				
			if(strpos($text, '{starttime}')!== false)
			{
				$text = str_replace('{starttime}', $startdatetime, $text);
			}
				
			if(strpos($text, '{endtime}')!== false)
			{
				$text = str_replace('{endtime}', $enddatetime, $text);
			}
				
			if(strpos($text, '{spenttime}')!== false)
			{
				$text = str_replace('{spenttime}', $spenttime, $text);
			}
				
			if(strpos($text, '{passedscore}')!== false)
			{
						if($check_textarea_score==1){
						$text = str_replace('{passedscore}', '--', $text);
						}else{
						$text = str_replace('{passedscore}', $passed_score, $text);
		}
			}
				
			if(strpos($text, '{percentscore}')!== false)
			{
				if($check_textarea_score==1){
					$text = str_replace('{percentscore}', '--', $text);
				}else{
					$text = str_replace('{percentscore}', $persentagescore, $text);
		}
			}
				
			if(strpos($text, '{passed}')!== false)
			{
				if($check_textarea_score==1){
					$text = str_replace('{passed}', '--', $text);
				}else{
				$text = str_replace('{passed}', $passed_text, $text);
		}
			}
			
			if(strpos($text, '{flag}')!== false)
			{
				$text = str_replace('{flag}', $flag, $text);
			}
				
			if(strpos($text, '{trivia_message}')!== false )
			{
				$text = str_replace('{trivia_message}', $trivia_message, $text);
			}
			if(strpos($text, '{questiongroup_score}')!== false)
			{
				$text = str_replace('{questiongroup_score}', $html_qgroup_score, $text);
			}	
			if(strpos($text, '{personality_message}')!== false)
			{
				$text = str_replace('{personality_message}', $personality_message, $text);
			}
				
			if($quizzes->personality_type==1 and $quizzes->quiztype==2){
				
				$multi_w_personality=json_decode($quizesult->multi_w_personality);
				$multi_w_persentage=json_decode($quizesult->multi_w_persentage);
				$array_p_result=json_decode($multi_w_personality[0]);
				$array_p_color=json_decode($multi_w_personality[1]);

				$txt_p='<div class="p_answer_row">';

				for($r=0;$r<count($multi_w_persentage);$r++){
				

					$txt_p .='<p><span style="color:'.$array_p_color[$r].'!important;float:left">'.$array_p_result[$r].'</span>';
					$txt_p .='<span class="answer_percentage_span" style="color:'.$array_p_color[$r].';float:left;">'.$multi_w_persentage[$r].'%</span></p>';
					
				}

				$txt_p .='</div>';

			}else{
				 $txt_p=$personality_message_result;						
			}	
						
				if(strpos($text, '{personality_score}')!== false)
				{
					$text = str_replace('{personality_score}', $txt_p, $text);
				}

				if(strpos($text, '{certificate_number}')!== false)
				{
					$text = str_replace('{certificate_number}', $certificate_number, $text);
				}
				
				
				//$quiz_answers=json_decode($quizesult->quiz_answers);
				//$quiz_questions=json_decode($quizesult->quiz_questions);
				
				$query = 'select a.qid from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$db->quote($quizesult->id).' order by qna_id asc';
				$db->setQuery( $query );
				$quiz_questions =$db->loadColumn();

				
				$remove = array(0);
				$givenanswers = array_values(array_diff($quiz_answers, $remove));  
				
				if(strpos($text, '{total_questions}')!== false)
				{
					$text = str_replace('{total_questions}', count($quiz_questions), $text);
				}
				
				if(strpos($text, '{given_answers}')!== false)
				{
					$text = str_replace('{given_answers}', count($givenanswers), $text);
					
				}
				if(strpos($text, '{date}')!== false)
				{
					$text = str_replace('{date}', JFactory::getDate('now', JFactory::getConfig()->get('offset'))->format("j F, Y"), $text);
				}
				
				if(strpos($text, '{play_date}')!== false)
				{
					$text = str_replace('{play_date}', $play_date, $text);
				}

				/*---count corrct answers---*/
				$model = $this->getModel('quizmanager');
				$correct_answers_count=$model->getCorrect_answers($quiz_questions,$quiz_answers,$text_answer,$textarea_answer);

				if(strpos($text, '{correct_answers}')!== false)
				{
					if($quizzes->quiztype==1 and $quizzes->answers_type==0){
						$text = str_replace('{correct_answers}', $correct_answers_count, $text);
					}else{
						$text = str_replace('{correct_answers}','--', $text);
					}
				}
				//print_r($text);exit;
				return $text;
		
		}
	
		/*--- Get Learning PathCertificate ---*/
		function getLearningPathcertificate_Confi($quizid,$uniqvariable,$certificate_name){

			$user = JFactory::getUser();
			$session = JFactory::getSession();
			
			$datetime = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
			$db = JFactory::getDbo();
			$model = $this->getModel('quizmanager');
			
			$learningId = JRequest::getInt('learningId',0);
			
			$query=$db->getQuery(true);
			$query->select('id,certificate,certificate_multi_item,title,article_id');
			$query->from($db->quoteName('#__vquiz_learning'));
			$query->where('id='.$db->quote($learningId));
			$db->setQuery($query);
			$learningPathcertificate=$db->loadObject();
			$text = $learningPathcertificate->certificate;
			//return $text;
			
			if(!empty($learningPathcertificate)){
				
				$query  ='  select quizid from #__vquiz_learning_lnq';
				$query .= ' where learningid ='.$learningPathcertificate->id;
				$query .= ' ORDER BY id asc';
				$db->setQuery( $query);		//echo $query; print_r($learningPathcertificate);exit;
				$quizes_order = $db->loadColumn(); 
				
				$text = $learningPathcertificate->certificate;
				$learningtitle=$learningPathcertificate->title;
				$arIds=$learningPathcertificate->article_id;
				$articleid=JRoute::_('index.php?option=com_content&view=article&id='.$arIds);
				$total_questions=count($quizes_order);
				
				$query  ='  select r.id,r.video_seen,l.title as lesson_title from #__vquiz_learning_result r left join #__vquiz_lessons l ON r.lession_id=l.id';
				$query .= ' where r.learning_id ='.$learningPathcertificate->id;
				$query .= ' AND r.userid ='.$user->id;
				$query .= ' AND r.lession_id<>0 AND r.completed = 1';
				$query .= ' ORDER BY r.id asc';
				$db->setQuery( $query);		
				$lessons_list = $db->loadObjectList(); //echo $query; print_r($lessons_list);exit;
				
				$query="SELECT date_format(date(created),'%m/%d/%Y') as quiz_passed_date FROM #__vquiz_quizresult WHERE userid = ". $user->id." And quizid = ".$quizid." Order by id desc limit 1"; 	 		
				$db->setQuery( $query);		
				$qresult_detail = $db->loadObject(); 
				
				$quiz_passed_date = $qresult_detail->quiz_passed_date;
				
				$query="SELECT * FROM #__comprofiler WHERE user_id = ". $user->id; 			
				$db->setQuery( $query);		
				$cbuilder_list = $db->loadObject();				
				
				$firstname = isset($cbuilder_list->firstname)?$cbuilder_list->firstname:'';
				$lastname = isset($cbuilder_list->lastname)?$cbuilder_list->lastname:'';
				$middlename = isset($cbuilder_list->middlename)?$cbuilder_list->middlename:'';
				
				//$username = isset($cbuilder_list->username)?$cbuilder_list->username:'';
				//$email = isset($cbuilder_list->email)?$cbuilder_list->email:'';
				
				$driving_license_number = isset($cbuilder_list->cb_license_number)?$cbuilder_list->cb_license_number:'';
				$driving_license_issuing_state = isset($cbuilder_list->cb_state)?$cbuilder_list->cb_state:'';
				$id_number = isset($cbuilder_list->cb_license_number)?$cbuilder_list->cb_license_number:'';
				$id_issuing_state = isset($cbuilder_list->cb_state)?$cbuilder_list->cb_state:'';
				
				$identity_type = isset($cbuilder_list->cb_id_type)?$cbuilder_list->cb_id_type:'';
				
				// show license or id fields based on identity type
				if($identity_type=="ID"){
					$driving_license_number = '';
					$driving_license_issuing_state = '';
				}else{
					$id_number = '';
					$id_issuing_state = '';
				}
				//echo $query; print_r($cbuilder_list); exit;	
				 
			}else{
				$text = ''; 
			}

			/* if(!empty($certificate_name)){
				$username=$certificate_name;
			}elseif(!$user->get('guest')){
				$username=$user->username;
			}else{
				$username=JText::_('GUEST');
			}	
			
			if(!$user->get('guest')){
				$email=$user->email;
			}else{
				$email='';
			} */
			
			if(!$user->get('guest')){
				$username=$user->username;
			}else{
				$username=JText::_('GUEST');
			}	
			
			if(!$user->get('guest')){
				$email=$user->email;
			}else{
				$email='';
			}
			
			$name = $user->name;
			
			if(strpos($text, '{firstname}')!== false)
			{
				$text = str_replace('{firstname}', $firstname, $text);
			}
			
			if(strpos($text, '{lastname}')!== false)
			{
				$text = str_replace('{lastname}', $lastname, $text);
			}
			
			if(strpos($text, '{middlename}')!== false)
			{
				$text = str_replace('{middlename}', $middlename, $text);
			}
			
			if(strpos($text, '{name}')!== false)
			{
				$text = str_replace('{name}', $name, $text);
			}
			
			if(strpos($text, '{driving_license_number}')!== false)
			{
				$text = str_replace('{driving_license_number}', $driving_license_number, $text);
			}
			
			if(strpos($text, '{driving_license_issuing_state}')!== false)
			{
				$text = str_replace('{driving_license_issuing_state}', $driving_license_issuing_state, $text);
			}
			
			if(strpos($text, '{id_number}')!== false)
			{
				$text = str_replace('{id_number}', $id_number, $text);
			}
			
			if(strpos($text, '{id_issuing_state}')!== false)
			{
				$text = str_replace('{id_issuing_state}', $id_issuing_state, $text);
			}
			
			if(strpos($text, '{passed_date}')!== false)
			{
				$text = str_replace('{passed_date}', $quiz_passed_date, $text);
			}
			
			
			if(strpos($text, '{username}')!== false)
			{
				$text = str_replace('{username}', $username, $text);
			}
			
			if(strpos($text, '{email}')!== false)
			{
				$text = str_replace('{email}', $email, $text);
			}
			
			if(strpos($text, '{learningtitle}')!== false)
			{
				$text = str_replace('{learningtitle}', $learningtitle, $text);
			}

			if(strpos($text, '{current_date}')!== false)
			{
				$text = str_replace('{current_date}', JFactory::getDate('now', JFactory::getConfig()->get('offset'))->format("j F, Y"), $text);
			}
			
			if(strpos($text, '{total_questions}')!== false)
			{
				$text = str_replace('{total_questions}', $total_questions, $text);
			}	
			
			if(strpos($text, '{articleid}')!== false)
			{
				$text = str_replace('{articleid}', $articleid, $text);
			}
			
			
			//get multi-item listing
			$multi_lessons = $learningPathcertificate->certificate_multi_item;
			$multi_item=array();
			$lesson_total_hour = $lesson_total_minute = 0;
			
			for($i=0;$i<count($lessons_list);$i++) {
			
				$lesson_title = $lessons_list[$i]->lesson_title;
				$lesson_hour = floor($lessons_list[$i]->video_seen / 3600);
				$lesson_minute = floor(($lessons_list[$i]->video_seen / 60) % 60);			
				
				$multi_item_name_new = $multi_lessons;					
				 
				
				if(strpos($multi_item_name_new, '{lesson_title}')!== false)	{
					$multi_item_name_new = str_replace('{lesson_title}', $lesson_title, $multi_item_name_new);
				}

				if(strpos($multi_item_name_new, '{lesson_hour}')!== false)	{
					$multi_item_name_new = str_replace('{lesson_hour}', str_pad($lesson_hour,2,"0",STR_PAD_LEFT), $multi_item_name_new);
				}
				
				if(strpos($multi_item_name_new, '{lesson_minute}')!== false)	{
					$multi_item_name_new = str_replace('{lesson_minute}', str_pad($lesson_minute,2,"0",STR_PAD_LEFT), $multi_item_name_new);
				}
				
				$multi_item[$i] =  $multi_item_name_new;
				
				$lesson_total_hour += $lesson_hour;
				$lesson_total_minute += $lesson_minute;
						
			}
			
			//if total minute exceeds 60 min, add to total hour
			if($lesson_total_minute>=60){
				$new_hour = floor($lesson_total_minute / 60);
				$lesson_total_hour += $new_hour;
				$lesson_total_minute = floor($lesson_total_minute % 60);
			}
			
			$mitem = implode('',$multi_item);
			
			if(strpos($text, '{multi_item}')!== false)	{
				$text = str_replace('{multi_item}', $mitem, $text);
			}
			
			if(strpos($text, '{lesson_total_hour}')!== false)
			{
				$text = str_replace('{lesson_total_hour}', str_pad($lesson_total_hour,2,"0",STR_PAD_LEFT), $text);
			}
			
			if(strpos($text, '{lesson_total_minute}')!== false)
			{
				$text = str_replace('{lesson_total_minute}', str_pad($lesson_total_minute,2,"0",STR_PAD_LEFT), $text);
			}
 
			return $text;
		
		}

	function invite()
	{
		$user = JFactory::getUser();
		$session = JFactory::getSession();
		$uniqvariable=JRequest::getVar('uniqvariable','');
		$sender_name=JRequest::getVar('s_name','');
		$email =  JRequest::getVar('semail',''); 
		$sender = array( 
						$email,
						$sender_name 
						);
					
		$remail =  JRequest::getVar('rremail',''); 
		$emails = explode(';', $remail);
		//$reciver_result_id 	=array();
		$quizid=JRequest::getInt('quizid',0);
		
		$datetime = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
		$db = JFactory::getDbo();
		$mailer = JFactory::getMailer();
		$config = JFactory::getConfig();
		$obj = new stdClass();
		$obj->result = "error";
	
		if($session->has('checkresult_id'.$uniqvariable)){
			
			$checkresult_id =$session->get('checkresult_id'.$uniqvariable);
			
			$query = ' SELECT r.* ,q.title as quiztitle, q.answers_type as answers_type,q.correctans as  correctans,q.personality_type as personality_type,q.enable_questiongroup as enable_questiongroup,q.quiztype as quiztype FROM #__vquiz_quizresult as r left join  #__vquiz_quizzes as q on q.id=r.quizid WHERE r.id = '.$checkresult_id.' order by r.id desc';
			
		}else{
			
			$query = ' SELECT r.* ,q.title as quiztitle, q.answers_type as answers_type,q.correctans as  correctans,q.personality_type as personality_type,q.enable_questiongroup as enable_questiongroup,q.quiztype as quiztype FROM #__vquiz_quizresult as r left join  #__vquiz_quizzes as q on q.id=r.quizid WHERE r.userid = '.$db->quote($user->id).' order by r.id desc limit 0 1';
		}
		
		$db->setQuery( $query );
		$quizesult =$db->loadObject();
		$score=$quizesult->score;
		$maxscore=$quizesult->maxscore;
		$title=$quizesult->quiztitle;
		$quiztype=$quizesult->quiztype;
		$result_id=$quizesult->id;
		
		$query = 'select a.answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$db->quote($quizesult->id).' order by qna_id asc';
		$db->setQuery( $query );
		$quiz_answers =$db->loadColumn();
		
		$personality_message_result='';
		$query = 'select * from #__vquiz_quizzes where id='.$db->quote($quizid);
		$db->setQuery( $query );
		$quizzes =$db->loadObject();
		
		if($quizzes->quiztype==2 OR $quizzes->quiztype==22){
			
			$all_optionid=array();
			for($op=0;$op<count($quiz_answers);$op++){
				if(!empty($quiz_answers[$op])){
					array_push($all_optionid,$quiz_answers[$op]);
				}else
					array_push($all_optionid,0);
			}
			
			$query = "select personality_optionid from #__vquiz_option Where id IN (".implode(',',$all_optionid).")";
			$db->setQuery($query);	
			$result=$db->loadColumn();	

			$count=array_count_values($result);
			$match_value_pc='';
			
			if($quizzes->personality_type==2){
			
				$resulted_value=json_encode($result);
				$match_value_pc=$model->check_pcategory($quizid,$resulted_value);
				
				if($match_value_pc!=''){
					$query ='select id,answer as personality_answer,article_id,description as personality_desc,quizid from #__vquiz_personality_message where category_combination='.$db->quote($match_value_pc);
				}else{
					$query ='select id,answer as personality_answer,article_id ,description as personality_desc,quizid from #__vquiz_personality_message order by id desc limit 1';
				}
						
				
			}else{
				arsort($count);
				$keys=array_keys($count);

				$remove = array(0);
				$keys = array_values(array_diff($keys, $remove));   
				$most_selected_id = $keys[0];

				if($most_selected_id){
					$query ='select id,answer as personality_answer,description as personality_desc,quizid from #__vquiz_personality_message where id='.$most_selected_id;
				}else{
					$query ='select id,answer as personality_answer,description as personality_desc,quizid from #__vquiz_personality_message order by id desc limit 1';
				}
			}

			$db->setQuery( $query );
			$personality_result=$db->loadObject();

			$personality_message_result=$personality_result->personality_answer;
		//print_r($personality_message_result);
		}
		 /*if($user->id!=0)
		{
			compare score 
		}
		  */
		if($user->id==0){
				$quiz_link=JURI::root().'index.php?option=com_vquiz&view=quizmanager&id='.$quizid;
				
				if($quiztype==1 OR $quiztype==11){
				$mailsubject =JText::_('INVITATION_SEND_SUBJECT_TRIVIA');
				
				$body =JText::sprintf('INVITATION_SEND_BODY_TRIVIA',$sender_name,$quiz_link,$title,$score);
				}
				
				elseif($quiztype==2 OR $quiztype==22){
				$mailsubject =JText::_('INVITATION_SEND_SUBJECT_PERSONALITY');
				$body =JText::sprintf('INVITATION_SEND_BODY_PERSONALITY',$sender_name,$quiz_link,$title,$personality_message_result);
				}
				elseif($quiztype==3){
				$mailsubject =JText::_('INVITATION_SEND_SUBJECT_SURVEY');
				$body =JText::sprintf('INVITATION_SEND_BODY_SURVEY',$sender_name,$quiz_link,$title);
				}
					$mailer->setSender($sender);
					$mailer->setSubject($mailsubject);
					$mailer->setBody($body);
					for ($z=0;$z<count($emails);$z++) {
						if(!empty($emails[$z])){
						   $mailer->addRecipient( $emails[$z] );
							}
						} 
					$mailer->IsHTML(true);
					$send = $mailer->send();
					
					if($send==true){
						$obj->result =1;
						
					}
					else 
					{
						$obj->result =0;
					}
		}
		else{
			for ($z=0;$z<count($emails);$z++) {
				$reciver_result_id[$z]=hash('md4', $emails[$z]);
				//$reciver_result_id[$z]=$link_unqiquevar;
				$quiz_link=JURI::root().'index.php?option=com_vquiz&view=quizmanager&id='.$quizid.'&r_id='.$result_id.'&link='.$reciver_result_id[$z];
				
				if($quiztype==1 OR $quiztype==11){
				$mailsubject =JText::_('INVITATION_SEND_SUBJECT_TRIVIA');
				
				$body =JText::sprintf('INVITATION_SEND_BODY_TRIVIA',$sender_name,$quiz_link,$title,$score);
				}
				
				elseif($quiztype==2 OR $quiztype==22){
				$mailsubject =JText::_('INVITATION_SEND_SUBJECT_PERSONALITY');
				$body =JText::sprintf('INVITATION_SEND_BODY_PERSONALITY',$sender_name,$quiz_link,$title,$personality_message_result);
				}
				elseif($quiztype==3){
				$quiz_link=JURI::root().'index.php?option=com_vquiz&view=quizmanager&id='.$quizid;
				$mailsubject =JText::_('INVITATION_SEND_SUBJECT_SURVEY');
				$body =JText::sprintf('INVITATION_SEND_BODY_SURVEY',$sender_name,$quiz_link,$title);
				}
				$mailer->setSender($sender);
					$mailer->setSubject($mailsubject);
					$mailer->setBody($body);
				
						if(!empty($emails[$z])){
						   $mailer->addRecipient( $emails[$z] );
							}
						
					$mailer->IsHTML(true);
					$send = $mailer->send();
					
					if($send==true){
						$obj->result =1;
						$insert_r = new stdClass();
						$insert_r->id = null;
						$insert_r->user_id = $user->id;
						$insert_r->result_id = $result_id;
						$insert_r->emails = $emails[$z];
						$insert_r->reciver_result_id = $reciver_result_id[$z];
						
						
						$ins_data = $db->insertObject('#__vquiz_quizuser_invitation', $insert_r);
						
					}
					else 
					{
						$obj->result =0;
					}
			}
			// send notification on sending quiz invitation
			if($db->insertid()){ 
					
				$data_arr = array();
				$data_arr['itemid'] = $db->insertid();
				$data_arr['notification_type'] = 11;
					
				if(QuizHelper::checkNotification($data_arr['notification_type'])){
					$data_arr['notify_users'] = QuizHelper::findUsersToNotify('notify_send_invitation');
					$data_arr['enotify_users'] = QuizHelper::findUsersToEnotify('enotify_send_invitation');
					//print_r($data_arr); exit;
					QuizHelper::sendNotification($data_arr);
				}
				
			}
			
		}
		
		//print_r($reciver_result_id);exit;
		
		jexit(json_encode($obj));
	}
	
	 function sendmail()
	 {
		$user = JFactory::getUser();
		$session = JFactory::getSession();
		$certificate_name= JRequest::getVar('certificate_name','');
		$uniqvariable=JRequest::getVar('uniqvariable','');
		$email =  JRequest::getVar('email',''); 
		$quizid=JRequest::getInt('quizid',0);
		$learningId=JRequest::getInt('learningId',0);
		
		$datetime = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
		$db = JFactory::getDbo();
		$mailer = JFactory::getMailer();
		$config = JFactory::getConfig();
		
		$obj = new stdClass();
		$obj->result = "error";
		
		$query = 'select * from #__vquiz_configuration';
		$db->setQuery( $query );
		$confiresult =$db->loadObject();
		
		//$text=$this->getcertificate_Confi($quizid,$uniqvariable,$certificate_name);
		
		if($learningId!=0){		// get Learning Paths certificate
			$text=$this->getLearningPathcertificate_Confi($quizid,$uniqvariable,$certificate_name);
									
			//$username = $user->username;				
			//$pdfname=$username.$cet_number->cet_number.'.pdf'; //'certificate.pdf';
			
		}else{
			$text=$this->getcertificate_Confi($quizid,$uniqvariable,$certificate_name);
		}

		
		/*------Save Certificte to  pdf formate-------*/
		
		require_once( JPATH_COMPONENT.'/assets/dompdf_library/dompdf_config.inc.php');

		$foldername=JPATH_SITE.'/components/com_vquiz/assets/certificate';
		
		if (!JFolder::exists($foldername)){
			JFolder::create($foldername);
		}
		
		$pdfname='Cerificate.pdf';
		$pdf_name=$foldername.'/'.$pdfname;
		
		unlink($pdf_name);
		
		if (get_magic_quotes_gpc()){
			$text = stripslashes($text);
		}
		
		
		$dompdf = new DOMPDF();
		$dompdf->load_html($text);
		$dompdf->set_paper('a4', 'portrait');
		$dompdf->render();
		file_put_contents($pdf_name, $dompdf->output()); 
		
		/*--end ----*/
		$mailsubject =JText::_('CERTIFICATE_SEND_SUBJECT');
		
		$body =JText::sprintf('CERTIFICATE_SEND_BODY',$email);
		
		$mailer->setSender($config->get('mailfrom'));
		$mailer->setSubject($mailsubject);
		$mailer->setBody($body);
		$mailer->addAttachment($pdf_name);
		$recievermail = $email;
		$mailer->addRecipient($recievermail);
		$mailer->IsHTML(true);
		$send = $mailer->send();

		if($send==true)
			$obj->result =1;
		else 
			$obj->result =0;

		jexit(json_encode($obj)); 
		
	}
	
function certificate_text()
	{
		$user = JFactory::getUser();
		$session = JFactory::getSession();
		$certificate_name= JRequest::getVar('certificate_name','');
		$uniqvariable=JRequest::getVar('uniqvariable','');
		$quizid=JRequest::getInt('quizid',0);
		$LearningPaths=JRequest::getInt('LearningPaths',0);
		$learningId=JRequest::getInt('learningId',0);
		$db = JFactory::getDbo();
		$checkresult_id =$session->get('checkresult_id'.$uniqvariable);
		$query = 'select cet_name,save_certificate,certificate from #__vquiz_quizzes where id='.$quizid ;
		$db->setQuery( $query );
		$result =$db->loadObject();
		
		$query = 'select cet_name,save_certificate from #__vquiz_configuration';
				$db->setQuery( $query );
				$confiresult =$db->loadObject();
					
		$query = 'select cet_number from #__vquiz_quizresult where id='.$checkresult_id ;
				$db->setQuery( $query );
				$cet_number =$db->loadObject();
				
		if(!empty($result->certificate))
		{
			$pdfname=$result->cet_name.$cet_number->cet_number.'.pdf';	
			$save_certificate=$result->save_certificate;
		}
		else
		{
			$pdfname=$confiresult->cet_name.$cet_number->cet_number.'.pdf';	
			$save_certificate=$confiresult->save_certificate;
		}
		$foldername=JPATH_SITE.'/components/com_vquiz/assets/certificate';
	 if (!JFolder::exists($foldername)){
			JFolder::create($foldername);
		} 
		
		$filename=$foldername.'/'.$pdfname;
		$obj = new stdClass();
		$obj->result = "error";
		if (file_exists($filename))
		{
			$obj->result = "success";
			$obj->save_certificate=$save_certificate;
			$obj->pdf_name=$pdfname;
			jexit(json_encode($obj)); 	
		}
	else 
	{
		
		if($learningId!=0){		// get Learning Paths certificate
			$text=$this->getLearningPathcertificate_Confi($quizid,$uniqvariable,$certificate_name);
									
			$username = $user->username;				
			$pdfname=$username.$cet_number->cet_number.'.pdf';		//'certificate.pdf';
			
		}else{
			$text=$this->getcertificate_Confi($quizid,$uniqvariable,$certificate_name);
		}
		require_once( JPATH_COMPONENT.'/assets/dompdf_library/dompdf_config.inc.php');

		if (!JFolder::exists($foldername)){
			JFolder::create($foldername);
		}
		
		$pdf_name=$foldername.'/'.$pdfname; //echo $text;exit;
	
		if (get_magic_quotes_gpc()){
			$text = stripslashes($text);
		}
		$dompdf = new DOMPDF();
		$dompdf->load_html($text);
		$dompdf->set_paper('a4', 'portrait');
		$dompdf->render();
		file_put_contents($pdf_name, $dompdf->output()); 
		$obj->result = $text;	//$session->clear('lead_user_name'.$quizid)	;
			$obj->save_certificate=$save_certificate;
		$obj->pdf_name=$pdfname;
		jexit(json_encode($obj)); 
	}
	}
	
	function SaveLeadUserInfo()
	{
		$user = JFactory::getUser();
		$user_name= JRequest::getVar('user_name','');
		$user_email=JRequest::getVar('user_email','');
		$user_mobile=JRequest::getVar('user_mobile','');
		$quizid=JRequest::getInt('quizid',0);
		
		$obj = new stdClass();
		$obj->result = "error";
		$model = $this->getModel('quizmanager');
		$text = $model->SaveLeadUserInfo($quizid,$user_name,$user_email,$user_mobile);
		if($text==true){
			$obj->result =1;	
		}else{
			$obj->result = 0;	
		}
			
		jexit(json_encode($obj)); 

	}
	
		
	function CheckRedudancyLeadUser()
	{	
		$user = JFactory::getUser();
		$user_email=JRequest::getVar('user_email','');
		$quizid=JRequest::getInt('quizid',0);

		$obj = new stdClass();
		$obj->result = "error";
		$model = $this->getModel('quizmanager');
		$text = $model->CheckRedudancyLeadUser($quizid,$user_email);

		$obj->result =$text->allowresult;
		$obj->lead_mendatory =$text->lead_mendatory;
		
		if($text->allowresult==1){
			$obj->msg =JText::_('COM_VQUIZ_ALREADY_PLAYED');
		}else{
			$obj->msg ='';
		}
			
		jexit(json_encode($obj)); 

	}
	function delete_certificate()
	{
		$filename=JRequest::getVar('filename','');
		$obj = new stdClass();
		$obj->result = "error";
		$foldername=JPATH_SITE.'/components/com_vquiz/assets/certificate';
		$filename=$foldername.'/'.$filename;
		unlink($filename);
		$obj->result = "sucess";
		jexit(json_encode($obj)); 
	}
	function lead_input()
	{		$obj = new stdClass();
		$obj->result = "error";
		$quizid=JRequest::getInt('quizid',0);
		$session = JFactory::getSession();
		if($session->has('lead_user_name'.$quizid))
		{
				$username =$session->get('lead_user_name'.$quizid);
		}
		else
		{
			$username ="";
		}
		$obj->username =$username;
		$obj->result = "sucess";
		jexit(json_encode($obj)); 
	
	}
	function grp_paging()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->grp_paging();		
		jexit(json_encode($obj));
	}
	
	function verify_answer()
	{ 
		//JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->verify_answer();		
		jexit(json_encode($obj));
	}
	
	function submit_slide()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj = $model->submit_slide();		
		jexit(json_encode($obj));
	} 
	
	

}