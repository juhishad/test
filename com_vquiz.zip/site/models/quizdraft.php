<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.modellist');
 
class VquizModelQuizdraft extends JModelList
{
		function __construct()
		{
			parent::__construct();

			$mainframe = JFactory::getApplication();
		  	$context	= 'com_vquiz.darft.list.';
			
			// Get pagination request variables
			$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
			$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );

			// In case limit has been changed, adjust it
			$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
			$this->setState('limit', $limit);
			$this->setState('limitstart', $limitstart);				 
			$array = JRequest::getVar('cid',  0, '', 'array');
			$this->setId((int)$array[0]);
		}

		
				
		 function &getItem(){
			 
			if (empty( $this->_data )) {
				$query='SELECT i.*,q.personality_type as personality_type,q.quiztype as quiztype,q.title as quiztitle, u.username as username';
				$query .=' FROM #__vquiz_quizdraft as i LEFT JOIN #__users as u ON i.userid = u.id  LEFT JOIN #__vquiz_quizzes as q ON i.quizid = q.id WHERE i.id = '.$this->_db->quote($this->_id);	
				
				$this->_db->setQuery( $query );
				$this->_data = $this->_db->loadObject();
			}



			if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->title = null;
			$this->_data->userid = null;
			$this->_data->startdatetime = null;
			$this->_data->enddatetime = null;
			$this->_data->score = null;
			$this->_data->passed_score = null;
			$this->_data->maxscore = null;
			$this->_data->quiz_spentdtime = null;
	 
			}
			return $this->_data;
		}
	
	
		function _buildQuery()
		{
			$db =JFactory::getDBO();
			$user = JFactory::getUser();

			$query="SELECT i.*,q.id as quiz_id,q.title as quiztitle ,q.quiztype as quiztype , u.username as username FROM #__vquiz_quizdraft as i LEFT JOIN #__users as u ON i.userid = u.id LEFT JOIN #__vquiz_quizzes as q on q.id=i.quizid";			
			return $query;
		}

		function setId($id)	
		{
			$this->_id		= $id;
			$this->_data	= null;
 		}


		 function &getItems(){
		 
			// Lets load the data if it doesn't already exist
			if (empty( $this->_data ))
			{
				 $query = $this->_buildQuery();
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();
				 
				 $query .= $filter;
				 $query .= $orderby;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			}
	
			return $this->_data;
		}
	 

		function getTotal(){
				
			if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$query .= $this->_buildContentFilter();
			$this->_total = $this->_getListCount($query);    
			}
			return $this->_total;
 		}


		function _buildItemOrderBy(){
	
	
			$mainframe = JFactory::getApplication();
			$context	= 'com_vquiz.draft.list.';
			$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
			$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
			$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
			return $orderby;
		}

		function getPagination(){
		
			// Load the content if it doesn't already exist
			if (empty($this->_pagination)) {
				jimport('joomla.html.pagination');
				$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
			}
			return $this->_pagination;
		}
 
 
	  function _buildContentFilter(){
	  
			$mainframe =JFactory::getApplication();
			$user=JFactory::getUser();
			$context	= 'com_vquiz.draft.list.';
			$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
			
			$startdatesearch = $mainframe->getUserStateFromRequest( $context.'startdatesearch', 'startdatesearch',	'',	'string' );
			$enddatesearch = $mainframe->getUserStateFromRequest( $context.'enddatesearch', 'enddatesearch',	'',	'string' );
			
			$quiz_id		= $mainframe->getUserStateFromRequest( $context.'quiz_id', 'userid',	'',	'string' );
			
			$self_result = JRequest::getInt('self_result',0);
			
			if(empty($quiz_id))
			$quiz_id = JRequest::getInt('quiz_id', 0);
			
			$search		= JString::strtolower( $search );
	 
			$where = array();
			
			
			 
			if($search)
			{	
				if (is_numeric($search)) 
				{		 
					$where[] = 'LOWER(  i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				}
				else
				{
				 $where[] = 'i.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
				}
			}
			
			if($quiz_id)
			{		
				$where[] = 'LOWER(  i.quizid ) ='.$this->_db->Quote( $this->_db->escape( $quiz_id, true ), false );
			}
			
			//if (!$user->authorise('core.admin', 'com_vquiz')){
				if($self_result==1){
					$where[] = 'i.userid='.$this->_db->Quote($user->id);
				}else{
					$where[] = 'q.created_by ='.$this->_db->Quote( $this->_db->escape($user->id, true ), false ); 
					
				}
				
			//}
			
			$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
				
			return $filter;
		}
			
		function getAllQuizinresult(){

			$query='SELECT  i.quizid as quizid , q.title as title';
			$query .=' FROM #__vquiz_quizdraft as i LEFT JOIN #__vquiz_quizzes as q ON i.quizid = q.id group by quizid order by quizid asc ';	
			$this->_db->setQuery( $query );
			$resultdata = $this->_db->loadObjectList();

			return $resultdata;
		}	
 
		function store(){
		
			$time = time();
			$row =& $this->getTable();
			$data = JRequest::get( 'post' );
					
			if (!$row->bind($data)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
			}

			if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
			}
	 
			if (!$row->store()) {
			$this->setError( $row->getErrorMsg() );
			return false; 
			}
			return true;
		}
 

		function delete()
		{
			$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
			$row =& $this->getTable();
			if (count( $cids )) {
			foreach($cids as $cid) {
				if (!$row->delete( $cid )) {
					$this->setError( $row->getErrorMsg() );
					return false;
					}
				}
			}
			return true;
		}


		function getShowresult(){

			$user = JFactory::getUser();	
			$query = ' SELECT * FROM #__vquiz_quizdraft  WHERE id = '.$this->_db->quote($this->_id);
			$this->_db->setQuery( $query );
			$result = $this->_db->loadObject();

			$session_data=json_decode($result->session_data);

			$query = ' SELECT * FROM #__vquiz_quizzes  WHERE id = '.$this->_db->quote($result->quizid);
			$this->_db->setQuery( $query );
			$quiz_result = $this->_db->loadObject();	

			//$query = 'select count(id) from #__vquiz_question where quizid = '.$this->_db->quote($this->_db->quote($quiz_result->id));
			$query = 'select count(questionid) from #__vquiz_quiznques where quizid = '.$this->_db->quote($this->_db->quote($quiz_result->id));
			$this->_db->setQuery( $query );
			$total_question = $this->_db->loadResult();
 
 
			
			$optiontypescore=$quiz_result->quiztype;
			$question=$session_data->qids;
			$answers=$session_data->aids;
			$user_comment=$session_data->user_comment_value;
			$text_answer=$session_data->text_value;
			$textarea_answer=$session_data->textarea_value;
			
			$correct_answers_count=$this->getCorrect_answers($question,$answers);
			
			/*---Quizzes---*/
			$query1= ' SELECT answers_type,correctans,personality_type FROM #__vquiz_quizzes  WHERE id = '.$this->_db->quote($result->quizid);
			$this->_db->setQuery( $query1);
			$display_quizzes = $this->_db->loadObject();
			$correctans = $display_quizzes->correctans;
			$answers_type = $display_quizzes->answers_type;
			$personality_type = $display_quizzes->personality_type;
			
			/*Category Score Result*/
				$quiz_answers=$answers;
				$given_answers=array();
				for($c=0;$c<count($quiz_answers);$c++){
					$given_answer=explode(',',$quiz_answers[$c]);
					$given_answers=array_merge($given_answers,$given_answer);
				}
				
				$query = 'select category_score,qid  from #__vquiz_option where id IN ('.implode(',',$this->_db->quote($given_answers)).')';
				$this->_db->setQuery( $query );
				$category_score_result =$this->_db->loadObjectList(); 
				
				$array_cat=array();	
					
				for($c=0;$c<count($category_score_result);$c++){
					
					$query = 'select score from #__vquiz_question where id = '.$this->_db->quote($category_score_result[$c]->qid);
					$this->_db->setQuery( $query );
					$question_score = $this->_db->loadResult();
					$category_score=json_decode($category_score_result[$c]->category_score);
 

					if($c==0){
						for($s=0;$s<count($category_score);$s++){
							array_push($array_cat,0);
						}
					}
					
					if(!empty($array_cat)){
					
						for($s=0;$s<count($category_score);$s++){
							$array_cat[$s] += $category_score[$s]*$question_score;
						}
					}

				}
				
				$query = 'select category from #__vquiz_quiz_score_category  where quizid = '.$this->_db->quote($result->quizid);
				$this->_db->setQuery( $query );
				$category_title =$this->_db->loadColumn();
				
				if($answers_type==2 and !empty($category_title)){
					$html_cat_score  ='<table border="1" width="100%" cellspacing="0" cellpadding="5"><tr><th>'.JText::_('CATEGORY_SCORE_TITLE').'</th><th>'.JText::_('CATEGORY_SCORE').'</th></tr>';
					for($t=0;$t<count($array_cat);$t++){
						$html_cat_score  .='<tr><td>'.$category_title[$t].'</td><td>'.$array_cat[$t].'</td></tr>';
					}
					$html_cat_score .='</table>';
				}else{
					$html_cat_score=0;
				}
				

			$qusetion_item = new stdClass();

			for($j=0;$j<count($question);$j++){

				$query = 'select qtitle,score,optiontype from #__vquiz_question where id = '.$this->_db->quote($question[$j]);
				$this->_db->setQuery( $query );
				$qusetion_item->question[$j] = $this->_db->loadObject();

				$query = 'select i.*,p.answer as personality_answer from #__vquiz_option as i left join #__vquiz_personality_message as p on i.personality_optionid=p.id where i.qid = '.$this->_db->quote($question[$j]).' order by id asc';
				$this->_db->setQuery( $query );
				$qusetion_item->options[$j] = $this->_db->loadObjectList(); 

			}
			
			 
			$qusetion_item->givenanswer =$answers;
			$qusetion_item->question_array = $question;
			$qusetion_item->optiontypescore = $optiontypescore;	
			$qusetion_item->user_comment = $user_comment;
			$qusetion_item->correctans = $correctans;	
			$qusetion_item->text_answer = $text_answer;	
			$qusetion_item->textarea_answer = $textarea_answer;	
			$qusetion_item->answers_type = $answers_type;	
			$qusetion_item->category_answer = $html_cat_score;	
			$qusetion_item->personality_type = $personality_type;	
			$qusetion_item->correct_answers_count = $correct_answers_count;	
			$qusetion_item->total_question = $total_question;	


			return $qusetion_item;
		} 

		
		  /*--Get Correct answers--*/
		   function getCorrect_answers($quizoptions_qids,$quizoptions_aids){
		   
				$total_correct_answer=0;
				$quizoptions['qids']=$quizoptions_qids;
				$quizoptions['aids']=$quizoptions_aids;
				for($i=0;$i<count($quizoptions['qids']);$i++){	

					$countoption=false;
					$c=0;
					
					$query = 'select id from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]).' and correct_ans = 1';
					$this->_db->setQuery( $query );
					$answers = $this->_db->loadColumn();
		
					$xx=explode(',',$quizoptions['aids'][$i]);

					for($k=0;$k<count($xx);$k++){
						if(in_array($xx[$k],$answers) and count($xx)==count($answers)){
							$countoption=true;
							$c=$c+1;
						}
						else{
							$countoption=false;
						}
					}
					
					if($countoption==true and $c==count($answers)) { 
						$total_correct_answer=$total_correct_answer+1;
					}
					else {
						$total_correct_answer=$total_correct_answer+0;
					}
				}

				return $total_correct_answer;
				
			}
			
			function getConfiguration(){

				$query='select * from #__vquiz_configuration';
				$this->_db->setQuery($query);
				$result = $this->_db->loadObject();
				return $result;
			}

				
}