<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.modellist');
 
class VquizModelQuizresult extends JModelList
{
		 function __construct()
			{
				parent::__construct();

				$mainframe = JFactory::getApplication();
				$context	= 'com_vquiz.result.list.';
				// Get pagination request variables
				$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
				$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );

				// In case limit has been changed, adjust it
				$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
				$this->setState('limit', $limit);
				$this->setState('limitstart', $limitstart);				 
				$array = JRequest::getVar('cid',  0, '', 'array');
				$this->setId((int)$array[0]);
			}

		function _buildQuery()
		{
			$db =JFactory::getDBO();

			$query ="SELECT i.*,sum(qes.flagcount) as flagcount, q.title as quiztitle,q.quiztype as quiztype ,l.user_fname as lead_name, u.username as username FROM #__vquiz_quizresult as i LEFT JOIN #__users as u ON i.userid = u.id";
			$query .=" LEFT JOIN #__vquiz_leads as l ON l.resultid = i.id";
			$query .=" LEFT JOIN #__vquiz_quizzes as q ON q.id = i.quizid";
			$query .=" LEFT JOIN #__vquiz_quiznques as qq ON qq.quizid = q.id";
			$query .=" LEFT JOIN #__vquiz_question as qes ON qq.questionid = qes.id";
			
			return $query;
		}

		function setId($id)	
		{
			$this->_id		= $id;
			$this->_data	= null;
 		}

		
		function &getItem()
		{
			if (empty( $this->_data )) {
			
				/* $query='SELECT i.*, u.username as username';
				$query .= ',(SELECT description from #__vquiz_personality_message where id=i.personality_id) as desc ';
				$query .= ',(SELECT answer from #__vquiz_personality_message where id=i.personality_id) as answer ';
				$query .=' FROM #__vquiz_quizresult as i LEFT JOIN #__users as u ON i.userid = u.id WHERE i.id = '.$this->_id;	
				 */
				//$query .=' LEFT JOIN #__vquiz_users as qu ON i.userid = qu.userid WHERE i.id = '.$this->_id;	
				
				$query ="SELECT i.*,sum(qes.flagcount) as flagcount, q.title as quiztitle,q.quiztype as quiztype ,l.user_fname as lead_name,l.user_email as lead_email,l.user_mobile as lead_mobile, u.username as username";
				//$query .= ',(SELECT description from #__vquiz_personality_message where id=q.personality_id) as desc ';
				//$query .= ',(SELECT answer from #__vquiz_personality_message where id=q.personality_id) as personality_answer ';
				$query .=" FROM #__vquiz_quizresult as i LEFT JOIN #__users as u ON i.userid = u.id ";
				$query .=" LEFT JOIN #__vquiz_leads as l ON l.resultid = i.id";
				$query .=" LEFT JOIN #__vquiz_quizzes as q ON q.id = i.quizid";
				$query .=" LEFT JOIN #__vquiz_quiznques as qq ON qq.quizid = q.id";
				$query .=" LEFT JOIN #__vquiz_question as qes ON qq.questionid = qes.id";
				$query .=" where i.id = ".$this->_id;
				
				$this->_db->setQuery( $query );
				$this->_data = $this->_db->loadObject();
			
			}



			if (!$this->_data) {
				$this->_data = new stdClass();
				$this->_data->id = 0;
				$this->_data->title = null;
				$this->_data->userid = null;
				$this->_data->startdatetime = null;
				$this->_data->enddatetime = null;
				$this->_data->score = null;
				$this->_data->passed_score = null;
				$this->_data->maxscore = null;
				$this->_data->quiz_spentdtime = null;
			}
			
			return $this->_data;
		}




		 function &getItems(){
		 
			// Lets load the data if it doesn't already exist
			if (empty( $this->_data ))
			{
				 $query = $this->_buildQuery();
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();
				 
				 $query .= $filter;
				 $query .= $orderby;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			}
	
			return $this->_data;
		}
	 


	
		function getTotal()
		{
				
			if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$query .= $this->_buildContentFilter();
			$this->_total = $this->_getListCount($query);    
			}
			return $this->_total;
 		}



		function _buildItemOrderBy(){
		
			$mainframe = JFactory::getApplication();
			$context	= 'com_vquiz.result.list.';
			$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
			$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
			$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
			return $orderby;
		}



		function getPagination(){
			// Load the content if it doesn't already exist
			if (empty($this->_pagination)) {
				jimport('joomla.html.pagination');
				$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
			}
			return $this->_pagination;
		}
 

		  function _buildContentFilter(){
		  
				$mainframe =JFactory::getApplication();
				$user = JFactory::getUser();
				$context	= 'com_vquiz.result.list.';
				$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
				
				$self_result = JRequest::getInt('self_result',0);
				
				$startdatesearch = $mainframe->getUserStateFromRequest( $context.'startdatesearch', 'startdatesearch',	'',	'string' );
				
				$enddatesearch = $mainframe->getUserStateFromRequest( $context.'enddatesearch', 'enddatesearch',	'',	'string' );
				
				$search		= JString::strtolower( $search );
		 
				$where = array();
				$OR = array();
				
 
				if($startdatesearch){
					$where[] = 'i.created >='.$this->_db->Quote( $this->_db->escape( $startdatesearch, true ), false );
				}
				if($enddatesearch){
					$where[] = 'i.created <='.$this->_db->Quote( $this->_db->escape( $enddatesearch, true ), false );
				}
 

				if($search)
				{	
					if (is_numeric($search)) 
					{		 
						$where[] = 'LOWER(  i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
					}
					else
					{
					 $where[] = 'i.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
					}
				}
				
				$query='SELECT id FROM #__vquiz_quizzes where created_by='.$user->id;
				$this->_db->setQuery( $query );
				$resultqid= $this->_db->loadColumn();
				$resultedqid=!empty($resultqid)?$resultqid:array(0);
				
				/* $query='SELECT monitor_user_id,monitor_quiz,monitor_category FROM #__vquiz_users where userid='.$user->id;
				$this->_db->setQuery( $query );
				$monitor_results= $this->_db->loadObject();
				//$monitor_user_id=json_decode(@$monitor_results->monitor_user_id);
				//$monitor_quiz=json_decode(@$monitor_results->monitor_quiz);				
				//$monitor_category=json_decode(@$monitor_results->monitor_category);	 */
				
				$query='SELECT quizid FROM #__vquiz_monitor_quiz where userid='.$user->id;
				$this->_db->setQuery( $query );
				$monitor_quiz= $this->_db->loadColumn();
				
				$query='SELECT muserid FROM #__vquiz_monitor_user where userid='.$user->id;
				$this->_db->setQuery( $query );
				$monitor_user_id= $this->_db->loadColumn();
				
				$userid=JFactory::getUser()->id;
				$query='SELECT catid FROM #__vquiz_monitor_category where userid='.$user->id;
				$this->_db->setQuery( $query );
				$monitor_category= $this->_db->loadColumn();
				
				if($self_result==1){
					$where[] = 'i.userid='.$this->_db->Quote($user->id);
					
				}else{
				
					if(!empty($monitor_quiz[0])){
						$resultedqid=array_merge($resultedqid,$monitor_quiz);
					}
					
					$where[] = 'i.quizid IN ('.implode(',', $resultedqid).')';
					
					if(!empty($monitor_category[0])){
						$OR[] = 'i.categoryid IN ('.implode(',', $monitor_category).')';
					}

					if(!empty($monitor_user_id[0])){
						$OR[] = 'i.userid IN ('.implode(',', $monitor_user_id).')';
					} 
				}

				$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
				
				if(empty($filter)){
					$filter = count($OR) ? ' WHERE ' . implode(' OR  ', $OR) : '';
				}else{
					$filter .= count($OR) ? ' OR ' . implode(' OR  ', $OR) : '';
				}
				 
				return $filter;
			}
		
 
	function store()
 	{	
		$time = time();
		$row =& $this->getTable();
		$data = JRequest::get( 'post' );
		
 		if (!$row->bind($data)) {
 		$this->setError($this->_db->getErrorMsg());
 		return false;
 		}

  		if (!$row->check()) {
 		$this->setError($this->_db->getErrorMsg());
 		return false;
 		}
 
		if (!$row->store()) {
 		$this->setError( $row->getErrorMsg() );
 		return false; 
 		}
 		return true;

	}
 

	function delete()
	{
 		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
 		$row =& $this->getTable();
 		if (count( $cids )) {
 		foreach($cids as $cid) {
 			if (!$row->delete( $cid )) {
 				$this->setError( $row->getErrorMsg() );
 				return false;
 				}
 			}
 		}
 		return true;
 	}

 		   /*--Get Correct answers--*/
		   function getCorrect_answers($quizoptions_qids,$quizoptions_aids,$quiz_text_value,$quiz_textarea_value){
	   
			$total_correct_answer=0;
			$quizoptions['qids']=$quizoptions_qids;
			$quizoptions['aids']=$quizoptions_aids;
			$quizoptions['text_value']=$quiz_text_value;
			$quizoptions['textarea_value']=$quiz_textarea_value;
			
			for($i=0;$i<count($quizoptions['qids']);$i++){	

				$countoption=false;
				$c=0;
				
				$query = 'select id from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]).' and correct_ans = 1';
				$this->_db->setQuery( $query );
				$answers = $this->_db->loadColumn();
	
				$xx=explode(',',$quizoptions['aids'][$i]);

				for($k=0;$k<count($xx);$k++){
					if(in_array($xx[$k],$answers) and count($xx)==count($answers)){
						$countoption=true;
						$c=$c+1;
					}
					else{
						$countoption=false;
					}
				}
				
				if($countoption==true and $c==count($answers)) { 
					$total_correct_answer=$total_correct_answer+1;
				}
				else {
					$total_correct_answer=$total_correct_answer+0;
				}
				
				$query = 'select text_field_ans,case_sensitive from #__vquiz_question where id = '.$this->_db->quote($quizoptions['qids'][$i]);
				$this->_db->setQuery( $query );
				$question_option = $this->_db->loadObject();
				
				if($quizoptions['text_value'][$i]!=''){
				
					$text_field_ans = trim($question_option->text_field_ans);
					if($question_option->case_sensitive==1){
					
						if($text_field_ans === trim($quizoptions['text_value'][$i])){ 
							$total_correct_answer=$total_correct_answer+1;
						}
						
					}else{
						if(ucwords($text_field_ans) === ucwords(trim($quizoptions['text_value'][$i]))){ 
							$total_correct_answer=$total_correct_answer+1;
						}
					}

				} 
				
			}

			return $total_correct_answer;
			
		}
			 
		/* function getShowresult(){

			$user = JFactory::getUser();	
			$query = ' SELECT * FROM #__vquiz_quizresult  WHERE id = '.$this->_id.' order by id desc';
			$this->_db->setQuery( $query );
			$result = $this->_db->loadObject();
			$quiz_questions=$result->quiz_questions;
			$quiz_answers=$result->quiz_answers;
			$user_comments=$result->user_comment;
			$text_value_json=$result->text_answer;
			$textarea_value_json=$result->textarea_answer;
			$textarea_given_score=$result->textarea_given_score;
			
			$optiontypescore=$result->optiontypescore;
			$question=json_decode($quiz_questions);
			$answers=json_decode($quiz_answers);
			$user_comment=json_decode($user_comments);
			$text_answer=json_decode($text_value_json);
			$textarea_answer=json_decode($textarea_value_json);
			$textarea_admin_score=json_decode($textarea_given_score);
			$correct_answers_count=$this->getCorrect_answers($question,$answers,$text_answer,$textarea_answer);
			
			//---Quizzes--
			$query1= ' SELECT answers_type,correctans,personality_type FROM #__vquiz_quizzes  WHERE id = '.$result->quizid;
			$this->_db->setQuery( $query1);
			$display_quizzes = $this->_db->loadObject();
			$correctans = $display_quizzes->correctans;
			$answers_type = $display_quizzes->answers_type;
			$personality_type = $display_quizzes->personality_type;
			
			//Category Score Result
				$quiz_answers=json_decode($result->quiz_answers);
				$given_answers=array();
				for($c=0;$c<count($quiz_answers);$c++){
					$given_answer=explode(',',$quiz_answers[$c]);
					$given_answers=array_merge($given_answers,$given_answer);
				}
				
				$query = 'select category_score,qid  from #__vquiz_option where id IN ('.implode(',',$given_answers).')';
				$this->_db->setQuery( $query );
				$category_score_result =$this->_db->loadObjectList(); 
				
				$array_cat=array();	
					
				for($c=0;$c<count($category_score_result);$c++){
					
					$query = 'select score from #__vquiz_question where id = '.$this->_db->quote($category_score_result[$c]->qid);
					$this->_db->setQuery( $query );
					$question_score = $this->_db->loadResult();
					$category_score=json_decode($category_score_result[$c]->category_score);
					

					if($c==0){
						for($s=0;$s<count($category_score);$s++)
						array_push($array_cat,0);
					}
					
					
					if(!empty($array_cat)){
					
						for($s=0;$s<count($category_score);$s++){
							$array_cat[$s] += $category_score[$s]*$question_score;
						}
					}

				}
				
				$query = 'select category from #__vquiz_quiz_score_category  where quizid = '.$this->_db->quote($result->quizid);
				$this->_db->setQuery( $query );
				$category_title =$this->_db->loadColumn();
				
				if($answers_type==2 and !empty($category_title)){
					$html_cat_score  ='<table border="1" width="100%" cellspacing="0" cellpadding="5"><tr><th>'.JText::_('CATEGORY_SCORE_TITLE').'</th><th>'.JText::_('CATEGORY_SCORE').'</th></tr>';
					for($t=0;$t<count($array_cat);$t++){
						$html_cat_score  .='<tr><td>'.$category_title[$t].'</td><td>'.$array_cat[$t].'</td></tr>';
					}
					$html_cat_score .='</table>';
				}else{
					$html_cat_score=0;
				}
				

			$qusetion_item = new stdClass();

			for($j=0;$j<count($question);$j++){

				$query = 'select qtitle,score,optiontype from #__vquiz_question where id = '.$this->_db->quote($question[$j]);
				$this->_db->setQuery( $query );
				$qusetion_item->question[$j] = $this->_db->loadObject();

				$query = 'select i.*,p.answer as personality_answer from #__vquiz_option as i left join #__vquiz_personality_message as p on i.personality_optionid=p.id where i.qid = '.$this->_db->quote($question[$j]).' order by id asc';
				$this->_db->setQuery( $query );
				$qusetion_item->options[$j] = $this->_db->loadObjectList(); 

			}
			
			 
			$qusetion_item->givenanswer =$answers;
			$qusetion_item->question_array = $question;
			$qusetion_item->optiontypescore = $optiontypescore;	
			$qusetion_item->user_comment = $user_comment;
			$qusetion_item->correctans = $correctans;	
			$qusetion_item->text_answer = $text_answer;	
			$qusetion_item->textarea_answer = $textarea_answer;	
			$qusetion_item->textarea_admin_score = $textarea_admin_score;	
			$qusetion_item->answers_type = $answers_type;	
			$qusetion_item->category_answer = $html_cat_score;	
			$qusetion_item->personality_type = $personality_type;	
			$qusetion_item->correct_answers_count = $correct_answers_count;	


			return $qusetion_item;
		}  */

		
		
		function getShowresult(){

			$user = JFactory::getUser();	
			$query = ' SELECT r.* ,q.title as quiztitle,q.description as quizdescription, q.answers_type as answers_type,q.correctans as  correctans,q.personality_type as personality_type,q.enable_questiongroup as enable_questiongroup,q.quiztype as quiztype FROM #__vquiz_quizresult as r left join  #__vquiz_quizzes as q on q.id=r.quizid WHERE r.id = '.$this->_id.' order by r.id desc';
			$this->_db->setQuery( $query );
			$result = $this->_db->loadObject();

			$quiztype=$result->quiztype;			$quiztitle=$result->quiztitle;			$quizdescription=$result->quizdescription;
			
			$query = 'select a.qid from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
			$this->_db->setQuery( $query );
			$question =$this->_db->loadColumn();
			

			$query = 'select a.answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
			$this->_db->setQuery( $query );
			$quiz_answers =$this->_db->loadColumn();

			$query = 'select a.text_answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
			$this->_db->setQuery( $query );
			$text_answer =$this->_db->loadColumn();
			
			$query = 'select a.textarea_score from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
			$this->_db->setQuery( $query );
			$textarea_answer =$this->_db->loadColumn();
			
			$query = 'select a.textarea_answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
			$this->_db->setQuery( $query );
			$textarea_given_answer =$this->_db->loadColumn();
			
			$query = 'select a.comment from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
			$this->_db->setQuery( $query );
			$user_comment =$this->_db->loadColumn();
			
			$correct_answers_count=$this->getCorrect_answers($question,$quiz_answers,$text_answer,$textarea_answer);
			
			$correctans = $result->correctans;
			$answers_type = $result->answers_type;
			$personality_type = $result->personality_type;

				$given_answers=array();
				for($c=0;$c<count($quiz_answers);$c++){
					$given_answer=explode(',',$quiz_answers[$c]);
					$given_answers=array_merge($given_answers,$given_answer);
				}
				
				if(!empty($given_answers)){
					$query = 'select category_score,qid  from #__vquiz_option where id IN ('.implode(',',$given_answers).')';
					$this->_db->setQuery( $query );
					$category_score_result =$this->_db->loadObjectList(); 
				}else{
					$category_score_result=array();
				}
				
				$array_cat=array();	
					
				for($c=0;$c<count($category_score_result);$c++){
					
					$query = 'select score from #__vquiz_question where id = '.$this->_db->quote($category_score_result[$c]->qid);
					$this->_db->setQuery( $query );
					$question_score = $this->_db->loadResult();
					$category_score=json_decode($category_score_result[$c]->category_score);
 

					if($c==0){
						for($s=0;$s<count($category_score);$s++){
							array_push($array_cat,0);
						}
					}
					
					if(!empty($array_cat)){
					
						for($s=0;$s<count($category_score);$s++){
							$array_cat[$s] += $category_score[$s]*$question_score;
						}
					}

				}
				
				$query = 'select category from #__vquiz_quiz_score_category  where quizid = '.$this->_db->quote($result->quizid);
				$this->_db->setQuery( $query );
				$category_title =$this->_db->loadColumn();
				
				if($answers_type==2 and !empty($category_title)){
					$html_cat_score  ='<table border="1" width="100%" cellspacing="0" cellpadding="5"><tr><th>'.JText::_('CATEGORY_SCORE_TITLE').'</th><th>'.JText::_('CATEGORY_SCORE').'</th></tr>';
					for($t=0;$t<count($array_cat);$t++){
						$html_cat_score  .='<tr><td>'.$category_title[$t].'</td><td>'.$array_cat[$t].'</td></tr>';
					}
					$html_cat_score .='</table>';
				}else{
					$html_cat_score='';
				}
				
				$query = 'select score from  #__vquiz_quizresult_questiongroup where resultid='.$this->_db->quote($result->id);
				$this->_db->setQuery( $query );
				$question_group_result =$this->_db->loadColumn();
				
				if(!empty($question_group_result) and $display_quizzes->enable_questiongroup==1){
					
					$html_qgroup_score  ='<table border="1" width="100%" cellspacing="0" cellpadding="5"><tr><th>'.JText::_('QUESTION_GROUP_SCORE_TITLE').'</th><th>'.JText::_('QUESTION_GROUP_SCORE').'</th><th>'.JText::_('GROUP_SCORE_MESSAGE').'</th></tr>';
					
					foreach($question_group_result as $key=>$val){
														
							$query=$this->_db->getQuery(true);
							$query->select('*');
							$query->from($this->_db->quoteName('#__vquiz_quizzes_questiongroup_message'));
							$query->where('score >= ' .(int)$val);
							$query->where('groupid ='.$this->_db->quote($key));
							$query->order('id asc');
							$query->setlimit(1);
							$this->_db->setQuery($query);
							$result = $this->_db->loadObject();
							
							if(isset($result->qgroup_article_id) and (!empty($result) OR  $result->qgroup_article_id!=0)){
								
								$qgroup_message=$result->qgroup_message;

								$query = $this->_db->getQuery(true);
								$query->select('link');
								$query->from($this->_db->quoteName('#__menu'));
								$query->where('id='.$this->_db->quote($result->qgroup_article_id));
								$this->_db->setQuery($query);
								$menu_link = $this->_db->loadResult();
					
								if($menu_link!=''){
									
									$articlelink_group=JRoute::_($menu_link.'&Itemid='.$result->qgroup_article_id);

									$group_message_weblink ='<a href="'.$articlelink_group.'" target="_blank">'.$qgroup_message.'</a>';
				
								}else{
									$group_message_weblink ='<a href="javascript:void(0);" target="_blank">'.substr($qgroup_message,0,15).'</a>';
				
								}
								
								
							}else{
								$group_message_weblink='';
								$qgroup_message='';
							}
							
		
						$query = $this->_db->getQuery(true);
						$query->select('title');
						$query->from($this->_db->quoteName('#__vquiz_quizzes_questiongroup'));
						$query->where(' qorder ='.$this->_db->quote($key));
						$this->_db->setQuery($query);
						$title = $this->_db->loadResult(); 
						
						if($title ==''){
							$title ='----';
						}
						
						$html_qgroup_score  .='<tr><td>'.$title.'</td><td>'.$val.'</td>';
						$html_qgroup_score  .='<td><p class="hasTip" title="'.$qgroup_message.'">'.$group_message_weblink.'</p></td></tr>';
					
					}
					$html_qgroup_score .='</table>';
				}else{
					$html_qgroup_score='---';
				}

			$qusetion_item = new stdClass();
			
			for($j=0;$j<count($question);$j++){

				$query = 'select qtitle,score,optiontype from #__vquiz_question where id = '.$this->_db->quote($question[$j]);
				$this->_db->setQuery( $query );
				$qusetion_item->question[$j] = $this->_db->loadObject();

				$query = 'select i.*,p.answer as personality_answer from #__vquiz_option as i left join #__vquiz_personality_message as p on i.personality_optionid=p.id where i.qid = '.$this->_db->quote($question[$j]).' order by id asc';
				$this->_db->setQuery( $query );
				$qusetion_item->options[$j] = $this->_db->loadObjectList(); 

			}
			
			 
			$qusetion_item->givenanswer =$quiz_answers;
			$qusetion_item->question_array = $question;
			$qusetion_item->quiztype = $quiztype;							$qusetion_item->quiztitle = $quiztitle;			$qusetion_item->quizdescription = $quizdescription;	
			$qusetion_item->user_comment = $user_comment;
			$qusetion_item->correctans = $correctans;	
			$qusetion_item->text_answer = $text_answer;	
			$qusetion_item->textarea_answer = $textarea_given_answer;	
			$qusetion_item->textarea_admin_score = $textarea_answer;//$textarea_given_score;	
			$qusetion_item->answers_type = $answers_type;	
			$qusetion_item->category_answer = $html_cat_score;	
			$qusetion_item->question_group_answer = $html_qgroup_score;	
			$qusetion_item->personality_type = $personality_type;	
			$qusetion_item->correct_answers_count = $correct_answers_count;	
			$qusetion_item->check_textarea_question = $this->getCheck_textarea_question($result->quizid);	


			return $qusetion_item;
		} 

 		function getCsv()
		{
				$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
				
				$db = JFactory::getDbo();		
				$columnhead =array("Username","Quiztitle","Quiztype","Quizcategory","StartTime","EndTime","Score","SpendTime","Comment","Date","Passed Score","Total Questions","Total Given Answers","Total Correct answer","Status","Questions","Your Answer",);
					
				$query='SELECT u.username as username,i.title as quiztitle, case i.optiontypescore when 1 then "'.JText::_('TRIVIA').'" when 2 then "'.JText::_('PERSONALITY').'" else "'.JText::_('SURVEY').'" end as quiztype';
				
				$query .= ',(SELECT title from #__vquiz_category where id=i.categoryid) as quizcategory';
				
				$query .= ',i.startdatetime as startdatetime,i.enddatetime as enddatetime';
				
				$query .= ',case i.optiontypescore when 1 then i.score when 2 then';
				
				$query .= '(SELECT personality_answer from #__vquiz_personality_message where id=i.personality_id) else  "survey" end  as score ';
				
				$query .= ',CONCAT(i.quiz_spentdtime,"  Second") as quiz_spentdtime,i.user_comment as user_comment,i.start_datetime as start_datetime,CONCAT(i.passed_score," %")';
					
				$query .=' FROM #__vquiz_quizresult as i LEFT JOIN #__users as u ON i.userid = u.id WHERE i.id IN ('.implode(',',$cids).')';
				
				$this->_db->setQuery( $query );
				$data = $db->loadRowList();
				
				$max_quetion=0;

				$query = 'select score,maxscore,passed_score,quiz_questions,quiz_answers,text_answer,textarea_answer,optiontypescore from #__vquiz_quizresult where id IN ('.implode(',',$cids).')';
				$this->_db->setQuery( $query );
				$qusetion_id= $this->_db->loadObjectList();	

				 
				$Questions_array=array();
				$Useranswer_array=array();
				$total_questions=array();
				$total_givenans=array();
				$total_correctanswer=array();
				$result_status=array();
 
				for($i=0;$i<count($qusetion_id);$i++){
				
					$answer=array();

					$score=$qusetion_id[$i]->score;
					$maxscore=$qusetion_id[$i]->maxscore;
					$passed_score=$qusetion_id[$i]->passed_score;

					if($maxscore==0)
						$persentagescore=100;	
					else
						$persentagescore=round($score/$maxscore*100,2)>100?100:round($score/$maxscore*100,2);

					$persentagescore=$persentagescore>0?$persentagescore:0;
					
					if($persentagescore>=$passed_score){
						$status="Passed";
					}else{
						$status="Failed";
					}
					
					$ques=json_decode($qusetion_id[$i]->quiz_questions);
					$ans=json_decode($qusetion_id[$i]->quiz_answers);
					
					$qusetion_id[$i]->quiz_answers;
					$text_answer=json_decode($qusetion_id[$i]->text_answer);
					$textarea_answer=json_decode($qusetion_id[$i]->textarea_answer);
					
					$query = 'select qtitle from #__vquiz_question WHERE id IN ('.implode(',',$ques).')';
					$this->_db->setQuery( $query );
					$result_ques=$db->loadColumn();
					array_push($Questions_array,json_encode($result_ques));
					
					$max_quetion = count($result_ques)>$max_quetion?count($result_ques):$max_quetion;
					
					
					for($d=0;$d<count($ans);$d++){
					
						if($ans[$d]==0){
							if($text_answer[$d]!=''){
								array_push($answer,$text_answer[$d]);
							}elseif($textarea_answer[$d]!=''){
								array_push($answer,$textarea_answer[$d]);
							}	
						}else{
							$query = 'select qoption from #__vquiz_option WHERE id IN ('.$ans[$d].')';
							$this->_db->setQuery( $query );
							$result_option=$db->loadColumn();
							array_push($answer,implode(',',$result_option));
						}
					}
					
						array_push($Useranswer_array,json_encode($answer)); 
						array_push($total_questions,count($ques)); 
						array_push($total_givenans,count($answer)); 
						
						if($qusetion_id[$i]->optiontypescore==1){
							$correct_answers_count=$this->getCorrect_answers($ques,$ans,$text_answer,$textarea_answer);
						}else{
							$correct_answers_count='';
							$status='';
						}

						array_push($total_correctanswer,$correct_answers_count); 
						array_push($result_status,$status); 
				}
				

				   for($j=0;$j<count($data);$j++){
				   
						array_push($data[$j],$total_questions[$j]);
						array_push($data[$j],$total_givenans[$j]);
						array_push($data[$j],$total_correctanswer[$j]);
						array_push($data[$j],$result_status[$j]);
						
						//array_push($data[$j],$Questions_array[$j]);
						//array_push($data[$j],$Useranswer_array[$j]);
						
						$questions=json_decode($Questions_array[$j]);
						$useranswer=json_decode($Useranswer_array[$j]);
						
						for($m=0;$m<count($questions);$m++)	{
							array_push($data[$j],$questions[$m]);
							if(isset($useranswer[$m]))
							array_push($data[$j],$useranswer[$m]);
						}
				   }

					for($n=0;$n<$max_quetion;$n++){
						array_push($columnhead,"Questions");
						array_push($columnhead,"Your Answer");
					} 

					//push the heading row at the top
					array_unshift($data, $columnhead);
					
					// output headers so that the file is downloaded rather than displayed
					header('Content-Type: text/csv; charset=utf-8');
					header('Content-Disposition: attachment; filename=Quiz-Result.csv');
					
					// create a file pointer connected to the output stream
					$output = fopen('php://output', 'w');
					
					foreach ($data as $fields) {
						/*
						$f=array();
						foreach($fields as $v)
						array_push($f, mb_convert_encoding($v, 'UTF-16LE', 'utf-8'));
						*/
						fputcsv($output, $fields, ',', '"');
					}
					fclose($output);
					return true;
					
		}
		
	
		function getConfiguration(){

			$query='select * from #__vquiz_configuration';
			$this->_db->setQuery($query);
			$result = $this->_db->loadObject();
			return $result;
		}
				
		function getUpdatetextarea_score(){
		
			$text_area_score= JRequest::getVar('text_area_score','', '', 'array');
			$id= JRequest::getInt('id',0);
			
			$query = ' SELECT qid FROM #__vquiz_quizresult_qna  WHERE resultid = '.$this->_db->quote($id).' order by qna_id asc';
			$this->_db->setQuery( $query );
			$qids = $this->_db->loadColumn();
			
			for($i=0;$i<count($qids);$i++){
				$query = 'update #__vquiz_quizresult_qna set textarea_score='.$this->_db->quote($text_area_score[$i]).'where resultid='.$this->_db->quote($id).' and qid='.$qids[$i];
				$this->_db->setQuery( $query );
				$this->_db->execute();	
			}
			return true;
		}
		
				/*---Check_textarea_question---*/

		function getCheck_textarea_question($itemid){
			$query =$this->_db->getQuery(true);
			$query->select('q.*');
			$query->from($this->_db->quoteName('#__vquiz_question').' as q');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as qq on qq.questionid=q.id');
			$query->where('qq.quizid ='.$this->_db->quote($itemid));
			$query->where('q.published = 1');
			
			$this->_db->setQuery( $query );
			$data_all_question = $this->_db->loadObjectList();
			$check_textarea_score=0;
			for($p=0;$p<count($data_all_question);$p++){

				if($data_all_question[$p]->optiontype==5){
					if($data_all_question[$p]->score!=0){
						$check_textarea_score=1;
					} else{
						$check_textarea_score=0;
					}
				}
				
			}

			return $check_textarea_score; 
		  
		}	
}