 <?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
class VquizModelPlans extends JModelList
{
	var $_total = null;
	var $_pagination = null;
	
	function __construct()
	{
		parent::__construct();
        $mainframe = JFactory::getApplication();
		
		$context	= 'com_vquiz.plans.list.';
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		$filter_language		= $mainframe->getUserStateFromRequest( $context.'filter_language',	'filter_language',	'' );
		//$akey			= $mainframe->getUserStateFromRequest( $context.'akey', 'akey', '',	'string' );
		//$akey			= JString::strtolower( $this->_akey );
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
		
		$plan_id = JRequest::getVar('plan_id',  0);
		$this->setId((int)$plan_id);
	}

 
 	function _buildQuery()
 	{
		$db =JFactory::getDBO();
		$user = JFactory::getUser();
		
 		 $query="SELECT i.* FROM #__vquiz_plans as `i`";
		 
   
		 return $query; 
	}
 
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}
    

	function &getItem()
	{ 
		// Load the data
		if (empty( $this->_data )) {
		$query = ' SELECT * FROM #__vquiz_plans'.
					'  WHERE id = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}

		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->title = null;
			$this->_data->alias = null;
			$this->_data->published= null;
			$this->_data->expiration= '000000000000';
			$this->_data->expirationtype= null;
			$this->_data->price= null;
			$this->_data->applyall= null;
			$this->_data->applyallquizss= null;
			$this->_data->ordering= null;
			$this->_data->created_date= null;
			$this->_data->description= null;
			$this->_data->quizcategory= '';
			$this->_data->quizid= array();
			$this->_data->created_by= null;
		}

		return $this->_data; 

	}

		function &getItems()
			
		{
			// Lets load the data if it doesn't already exist
			
				 $query = $this->_buildQuery();
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();
				 
				 $query .= $filter;
				 $query .= $orderby;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			    
			return $this->_data;
		}
	 
	 
 
			function getTotal()
			{
		
			 if (empty($this->_total)) {
				$query = $this->_buildQuery();
				$query .= $this->_buildContentFilter();
				$query  .= $this->_buildItemOrderBy();
				$this->_total = $this->_getListCount($query);    
		 
				}
			   return $this->_total;
			}
		 
		 
			function _buildItemOrderBy()
			{
				$mainframe = JFactory::getApplication();
				
				$context	= 'com_vquiz.plans.list.';
		 
				$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'i.id', 'cmd' );
				$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );substr(strrchr($filter_order, "."), 1);
				
		        if (!array_key_exists((string)substr(strrchr($filter_order, "."), 1), $this->getTable('Plans', 'Table')->getFields()))
			        $filter_order = 'i.id';
		 		//$orderby = ' order by '.$filter_order.' '.$filter_order_Dir . ' ';
				$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
		 
				return $orderby;
			}

	function _buildContentFilter()
	{

				$mainframe =JFactory::getApplication();
		 
				$context	= 'com_vquiz.plans.list.';
				$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
				$publish_item		= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );
				$search		= JString::strtolower( $search );
		 
				$where = array();
				
				if($publish_item)
				{  

					if ( $publish_item == 'p' )
					$where[] = 'i.published= 1';
					
					else if($publish_item =='u')
					$where[] = 'i.published = 0';
			
				}
				 
				if($search)
				{	
					if (is_numeric($search)) 
					{		 
						$where[] = 'LOWER( i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
					}
					else
					{
		 
					 $where[] = 'i.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
		
					
					}
				}
				  
					$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
		 
				return $filter;
			}
		
		 function checkout($pk = null)
		{
			$table = $this->getTable('Plans', 'Table');
			$pk = (!empty($pk)) ? $pk : (int) $this->getState($this->getName() . '.id');
	
			return $table->checkout($pk);
	}
		
	
	function createUserOrderBeforePay()
 	{	
		$time = time();
		$config = QuizHelper::getConfiguration();
		
		$time = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
		$session=JFactory::getSession();
		$user = JFactory::getUser();
		if ($user->guest)
		{
		$userid = $session->get('REGISTRATION_USER_ID', 0);
		}
		else
		$userid = $user->id;
		echo $plan_id = JRequest::getVar('plan_id','');
		$subscription_id = JRequest::getVar('subid','');
		$plan = QuizHelper::planDetail($plan_id);
		$total = $config->tax_enable==1?QuizHelper::pricewithtax($plan->price):$plan->price;
		$subscriptions = $this->getTable('subscriptions', 'Table');
		$subscriptions->load($subscription_id);
		$subscriptions->status = QuizHelper::SUBSCRIPTION_NONE;
		$subscriptions->total =  $total;
		$subscriptions->subscription_date = $time;
		$subscriptions->plan_id = $plan_id;
		$subscriptions->user_id = $userid;
		$param = new stdClass();
		$param->expirationtype = $plan->expirationtype;
		$param->expiration = $plan->expiration;
		$param->price = $total;
		$param->title = $plan->title;
		$subscriptions->params  = json_encode($param);
		if (!$subscriptions->store())
		{
		$this->setError( $subscriptions->getError() );
		return false; 
        }

		   
		    JRequest::setVar('subid', $subscriptions->id);
			
			$order_id = JRequest::getVar('order_id','');
	        $order =  $this->getTable('Orders', 'Table');
			$order->load($order_id);
		    $order->subscr_id = $subscriptions->id;
			$order->app_id = 1;
			$order->tax = $config->tax_enable==1?$total-$plan->price:'0.00000';
			$order->currency = $config->currencyname;
			$session = JFactory::getSession();
			$coupon = $session->get('coupon_data', '');
			$coupon_value = 0;
			$coupon_str = "";
			if( !empty($coupon) ) {

			$coupon_str = $coupon['code'] . ";;" . $coupon['value'] . ";;" . $coupon['percentot'];

			if( $coupon['percentot'] == 2 ) { // TOTAL
			$coupon_value = $coupon['value'];
			}
            if( $coupon['percentot'] == 1 ) { // TOTAL
			$coupon_value = ($coupon['value']*$subscriptions->total)/100;
			}
			$session->set('coupon_data', '');
			}
			$order->total = $total;
			$order->subtotal = $coupon_value!=0?$total-$coupon_value:$total; 
			$order->status = QuizHelper::ORDER_NONE;
			$order->coupon_code = $coupon_str;
			$order->buyer_id = $userid;
			$order->created_date = $time;
			$order->modified_date = $time;
			$order->modified_date = $time; 
			$order->order_key = QuizHelper::generateSerialCode(12);
			
			$param = new stdClass();
			$param->expirationtype = $plan->expirationtype;
			$param->expiration = $plan->expiration;
			$param->price = $total;
			$param->title = $plan->title;
			$order->params = json_encode($param); 
			
			if (!$order->store()) {
				$this->setError( $order->getErrorMsg() );
				return false;
			}
			JRequest::setVar('order_key', $order->order_key);
			
			$subscription =  $this->getTable('subscriptions', 'Table');
			$subscription->load($subscriptions->id);
			$subscription->total = $order->subtotal; 
			$param = new stdClass();
			$param->expirationtype = $plan->expirationtype;
			$param->expiration = $plan->expiration;
			$param->title = $plan->title;
			$param->order_id = $order->order_id;
			$param->order_key = $order->order_key;
			$param->price = $order->subtotal;
			$subscription->params = json_encode($param);
			$subscription->store();
           
		return true;

		}
 
		 
 

			function delete()
			{
			$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
			$row =& $this->getTable();
			if (count( $cids )) {
				foreach($cids as $cid) {
						
						$query = ' SELECT photopath from #__vquiz_category WHERE id = '.$cid;
						$this->_db->setQuery( $query );
						$oldimage_path = $this->_db->loadResult();
						if(!empty($oldimage_path)){
						unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/'.$oldimage_path);
						unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/thumbs/'.'thumb_'.$oldimage_path);
						}	
						
						 
					
						$query = ' SELECT id FROM #__vquiz_quizzes WHERE quiz_categoryid = '.$cid;
						$this->_db->setQuery( $query );
						$quizzes_id = $this->_db->loadColumn();
						
						if(!empty($quizzes_id)){
						$query = ' SELECT id FROM #__vquiz_question WHERE quizzesid IN ('.implode(',',$quizzes_id).')';
						$this->_db->setQuery( $query );
						$question_id = $this->_db->loadColumn();
						}
						
						
						
						$q1 ='delete FROM #__vquiz_quizzes WHERE quiz_categoryid = '.$cid;
						$this->_db->setQuery( $q1 );
						$this->_db->execute();
						
						if(!empty($quizzes_id)){
						$q2 ='delete FROM #__vquiz_question WHERE quizzesid IN ('.implode(',',$quizzes_id).')';
						$this->_db->setQuery( $q2 );
						$this->_db->execute();
						}
						
						if(!empty($question_id)){
						$q3 ='delete FROM #__vquiz_option WHERE qid IN ('.implode(',',$question_id).')';
						$this->_db->setQuery( $q3 );
						$this->_db->execute();
							
						}
							
  					 
					
					if (!$row->delete( $cid )) {
						$this->setError( $row->getErrorMsg() );
						return false;
						}
						

					}
		 
				}
			return true;
		 
			}
			
			
	function getCsv()
	{
		$db = JFactory::getDbo();

		/*
		$query = 'select columns from #__vquiz_category';
		$db->setQuery( $query );
		$columnhead = $db->loadColumn();*/
		
		$columnhead=array('id','Quiztitle','Published','PhotoPath','Parentid','level','left','right','Language','Access','Meta Desc','Mata Key','Created_by');
		
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		
		$query = 'select id,quiztitle,published,photopath,parent_id,level,lft,rgt,language,access,meta_desc,meta_keyword,created_by from #__vquiz_category WHERE id IN ('.implode(',',$cids).')';
		$db->setQuery( $query );
		$data = $db->loadRowList();
		
		//push the heading row at the top
		array_unshift($data, $columnhead);
		
		// output headers so that the file is downloaded m than displayed
		
		header('Content-Type: text/csv; charset=UTF-8');
		header('Content-Disposition: attachment; filename=Category.csv');
		
		// create a file pointer connected to the output stream
		$output = fopen('php://output', 'w');
		
		foreach ($data as $fields) {
			$f=array();
			//foreach($fields as $v)						
			//array_push($f, mb_convert_encoding($v,"UTF-8"));
			//fputcsv($output, $f, ',', '"');
			fputcsv($output, $fields, ',', '"');
		}
		fclose($output);
		return true;
	}
				
					
	function publish()
	{
		$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$task		= JRequest::getCmd( 'task' );
		$publish	= ($task == 'publish')?1:0;
		$n = count( $cid );
		if (empty( $cid )) 
		{
			return 'No item selected';
		}
		$cids = implode( ',', $cid );
		//implode() convert array into string
		$query = 'UPDATE #__vquiz_plans SET published = ' . (int) $publish . ' WHERE id IN ( ' . $cids . ' )';
		$this->_db->setQuery( $query );
		if (!$this->_db->query())
			return $this->_db->getErrorMsg();
		else
			return ucwords($task).'ed successfully.';
	}
							
	function getParentcategory()
	{
		$query='select parent_id from #__vquiz_category';
		$this->_db->setQuery($query);
		$parentid=$this->_db->loadResult();
		
		$query ='select a.id , a.quiztitle , a.level , a.parent_id ';
		$query .=' from #__vquiz_category As a ';
		$query .=' LEFT join #__vquiz_category AS b ON a.lft > b.lft AND a.rgt < b.rgt';
				 
		$where = array();
		
		$where[] = 'a.id !=1';
		$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
		$query .= $filter;
		$query .=' group by a.id, a.quiztitle, a.level, a.lft, a.rgt, a.parent_id order by a.lft ASC';

		$this->_db->setQuery($query); 
		$result=$this->_db->loadAssocList();
		return $result;
	}
	function updatequiz()
	{   
	    $quizss = array();
		$catid = JRequest::getVar('cateid',0);
		$query='select `q`.`id` as `value`, `q`.`quizzes_title` as `text` from #__vquiz_quizzes as `q` where `q`.`quiz_categoryid`='.$this->_db->quote($catid);
		$query .=' order by `q`.`quizzes_title` ASC';
		$this->_db->setQuery($query);
		$this->_db->Query($query);
		$quizss = $this->_db->loadAssocList(); 
        return $quizss; 		
		
	}	
 
 }