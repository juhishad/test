<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 www.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die();

jimport('joomla.application.component.modellist');

class VquizModelConfig extends JModelList
{
    
	function __construct()
	{
		parent::__construct();			
        $mainframe = JFactory::getApplication();
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
		
	}

 	function _buildQuery()
	{
		
		$user = JFactory::getUser();
		 
		 $query = ' SELECT * FROM #__vquiz_config ';
		 
		 if (!$user->authorise('core.admin','com_vquiz')){
			$groups = implode(',', $user->getAuthorisedViewLevels());
			$query .= ' and i.access IN (' . $groups . ')';
		}
		   
		 return $query;
	}
 
 
 
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}

	/**
	 * Method to get a wproperty
	 * @return object with data
	 */
	function &getItem()
	{
		$user = JFactory::getUser();
		
		// Load the data
		if (empty( $this->_data )) {
			$query = 'SELECT * FROM #__vquiz_config WHERE user_id='.$user->id;
					
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}
		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->notfify_add_quizcategory= null;			
			$this->_data->notfify_add_quiz= null;			
			$this->_data->notify_add_lpath= null;
			$this->_data->notify_add_lesson= null;
			$this->_data->notify_add_skill= null;
			$this->_data->notify_send_certificate= null;
			$this->_data->notify_complete_quiz= null;
			$this->_data->notify_incomplete_quiz= null;
			$this->_data->notify_complete_lpath= null;
			$this->_data->notify_send_invitation= null;
			$this->_data->notify_complete_invitation= null;			
						
			$this->_data->enotfify_add_quiz= null;
			$this->_data->enotfify_add_quizcategory= null;
			$this->_data->enotify_add_lpath= null;
			$this->_data->enotify_add_lesson= null;
			$this->_data->enotify_add_skill= null;
			$this->_data->enotify_send_certificate= null;
			$this->_data->enotify_complete_quiz= null;
			$this->_data->enotify_incomplete_quiz= null;
			$this->_data->enotify_complete_lpath= null;
			$this->_data->enotify_send_invitation= null;
			$this->_data->enotify_complete_invitation= null;			
			

		} 
		return $this->_data;
	}

     
	 function &getItems()
	 	
	 {
		// Lets load the data if it doesn't already exist
		if (empty( $this->_data ))
		{
			 $query = $this->_buildQuery();
			 $this->_data = $this->_getList($query);
		}

		return $this->_data;
	}

 	function getTotal()
  	{
        // Load the content if it doesn't already exist
        if (empty($this->_total)) {
            $query = $this->_buildQuery();
            $this->_total = $this->_getListCount($query);    
        }
        return $this->_total;
  	}

	/**
	 * Method to store a record
	 *
	 * @access	public
	 * @return	boolean	True on success
	 */
  
	 
	function store()
	{	
		JTable::addIncludePath(JPATH_COMPONENT.DS.'tables');	
		$row =& $this->getTable(); 		
		$user = JFactory::getUser();
		//print_r($row); exit;

		$data = JRequest::get( 'post' ); 
		
		$data['user_id'] = $user->id; //print_r($data); exit;
		
		//$data['notfify_add_quizcategory'] = isset($data['notfify_add_quizcategory'])?$data['notfify_add_quizcategory']:0;
		
		  
		// Bind the form fields to the wproperty table
		if (!$row->bind($data)) {
		 
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Make sure the wproperty record is valid
		if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
		}

		// Store the web link table to the database
		if (!$row->store()) {
			$this->setError( $row->getErrorMsg() );
			return false; 
		}
 

		return true;
	}

	/**
	 * Method to delete record(s)
	 *
	 * @access	public
	 * @return	boolean	True on success
	 */
	function delete()
	{
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );

		$row =& $this->getTable();

		if (count( $cids )) {
			foreach($cids as $cid) {
				if (!$row->delete( $cid )) {
					$this->setError( $row->getErrorMsg() );
					return false;
				}
			}
		}
		return true;
	}
	
	function getQuizCount()
	{
		$user = JFactory::getUser();		
		
		$query = 'SELECT count(id) as quiz_count FROM #__vquiz_quizzes WHERE created_by='.$user->id;
				
		$this->_db->setQuery( $query );
		$quizcount_result = $this->_db->loadColumn();
		
		$quizcount = $quizcount_result[0];		
		return $quizcount;
	}
	
 
	
	 
	
 

}