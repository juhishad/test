<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.modellist');
class VquizModelLearning extends JModelList
{
    var $_total = null;
	var $_pagination = null;
	
	function __construct()
	{
		parent::__construct();		
        $mainframe = JFactory::getApplication();
 
 		$app = JFactory::getApplication('site');
		$params = $app->getParams();
		$this->setState('params', $params);
		
		$context	= 'com_vquiz.vquiz.list.';
		// Get pagination request variables
		$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		//$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
	
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
	}
	
	function _buildQuery()
	{
		
		$user = JFactory::getUser();
		
		$query = ' SELECT i.* FROM #__vquiz_learning as i ';
		//$query .= ' left join #__vquiz_learning_restrict_ip as l on l.learning_id=i.id';

		return $query;
	}
	
	
	function _buildFilter()
	{
		$user = JFactory::getUser();
		$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
		$app = JFactory::getApplication();
		$lang = JFactory::getLanguage();
		$parant = JRequest::getvar('parant',0);
		$ipAdress=$_SERVER['REMOTE_ADDR'];
		
		$where = array();
		$OR = array();
		
		$where[] = ' i.published =1';

		$where[] = ' i.access in ('.implode(',', $user->getAuthorisedViewLevels()).')';

		$where[] = ' i.startpublish_date <= '.$this->_db->quote($date->format('Y-m-d')).' and (i.endpublish_date >= '.$this->_db->quote($date->format('Y-m-d')).' or endpublish_date='.$this->_db->quote(('0000-00-00')).')';
		
		if($app->getLanguageFilter())	{
			$where[] = ' i.language in ('.$this->_db->quote($lang->getTag()).', '.$this->_db->Quote('*').')';
		}
		
		if(!empty($ipAdress)){
			//$where[] = ' i.ipaddress_allow !='.$this->_db->quote($ipAdress);
			$where[] = ' (i.ipaddress_allow="" or i.ipaddress_allow REGEXP "('.$ipAdress.')")';
		} 
		
		$filter = ' where ' . implode(' and ', $where); //echo $filter;

		return $filter;
		
	}
	
	function _buildOrderBy()
	{
		$orderby ='	group by i.id order by ordering asc';
		return $orderby;
	}
	
  function getTotal(){
	 
		if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$query .= $this->_buildFilter();
			$query .= $this->_buildOrderBy();
			
			$this->_total = $this->_getListCount($query);       
		}
		return $this->_total;
	}
	
	
  function getPagination(){
	  
		// Load the content if it doesn't already exist
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
		}
		return $this->_pagination;
		
	}
	
	function getItems()
	{
			if (empty($this->_data)) {
			$query = $this->_buildQuery();
			$query .= $this->_buildFilter();
			$query .= $this->_buildOrderBy(); //echo $query; //exit;
			$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));    
		}
		return $this->_data;
		
	}
		
	/* public function getSelectedQuizzes(){
		
		$id = JRequest::getInt('id',0);
		
		if($this->getDescription()->id){
			
			$query  ='  select quizid from #__vquiz_learning_lnq';
			$query .= ' where learningid ='.$this->getDescription()->id;
			$query .= ' ORDER BY id asc';
			$this->_db->setQuery( $query);		
			$select_id = $this->_db->loadColumn();
			if($select_id){
				$query=$this->_db->getQuery(true);
				$query->select('id,title,image');
				$query->from($this->_db->quoteName('#__vquiz_quizzes'));
				$query->where('id IN ('.implode(',',$select_id).')');
				$query->where(' published=1 ');
				$query->order('FIELD(id,'.implode(',',$select_id).')');
				$this->_db->setQuery($query);
				$result=$this->_db->loadObjectList();
				return $result;
			}
		}
		
	} 
	public function getSelectedLessons(){	
			
		$id = JRequest::getInt('id',0);
		
		if($this->getDescription()->id){
			
			$query  ='  select lessionid from #__vquiz_learning_lnq';
			$query .= ' where learningid ='.$this->getDescription()->id;
			$query .= ' ORDER BY id asc';
			$this->_db->setQuery( $query);		
			$select_id = $this->_db->loadColumn();
			if($select_id){
				$query=$this->_db->getQuery(true);
				$query->select('id,title,thumbnail');
				$query->from($this->_db->quoteName('#__vquiz_lessons'));
				$query->where('id IN ('.implode(',',$select_id).')');
				$query->where(' published=1 ');
				$query->order('FIELD(id,'.implode(',',$select_id).')');
				$this->_db->setQuery($query);
				$result=$this->_db->loadObjectList();
				return $result;
			}
		}
	} */
 	public function getLearningPath(){	
			
		$id = JRequest::getInt('id',0);
		
		if($this->getDescription()->id)
		{
			$query=$this->_db->getQuery(true);
			$query->select('l.* , q.title as quiztitle, q.image as quizimage, a.title as lessontitle, a.thumbnail as lessonimage ');
			$query->from($this->_db->quoteName('#__vquiz_learning_lnq').' as l');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes').' as q on q.id=l.quizid ');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_lessons').' as a on a.id=l.lessionid');
			$query->where(' learningid= '.$id);
			$query->order('ordering asc');
			$this->_db->setQuery($query);
			$result=$this->_db->loadObjectList();
			
			return $result;
			
		}
	}		
	function getConfiguration()
	{
		$query='select * from #__vquiz_configuration';
		$this->_db->setQuery($query);
		$result = $this->_db->loadObject();
		return $result;
	}
		
		
	function getDescription(){
	
		$user = JFactory::getUser();
		$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
		$app = JFactory::getApplication();
		$lang = JFactory::getLanguage();
		$id = JRequest::getInt('id',0);
		
		$result=new stdClass();
		$result->description='';
		$result->id='';
		$result->title='';
		$result->image='';
		
		if($this->CheckAccess($id)!=1){ 
			//UNAUTH_ACCESS
			$error=jerror::raiseWarning('403', JText::_('NOT_AUTHORISED'));	
			$this->setError($error);
			return $result;
		}
		
		if($id){
			try{
				$query ='select * from #__vquiz_learning';
				$where = array();
				$where[] =  ' id ='.$this->_db->quote($id);
				$where[] =  ' access in ('.implode(',', $user->getAuthorisedViewLevels()).')';
				if($app->getLanguageFilter()){
					$where[] = 'language in ('.$this->_db->quote($lang->getTag()).', '.$this->_db->Quote('*').')';
				}
				$query .= ' where ' . implode(' and ', $where);	
				$query .= ' and  published =1';
				$this->_db->setQuery($query);
				$result_learning = $this->_db->loadObject();
				if(empty($result_learning)){
					$result_learning=$result;
				}
				return $result_learning;
				
			}catch (Exception $e){
				throw new Exception($e->getMessage());
			}
		}

	}
				
	/*---Check Learning Path Access--*/
	
	function CheckAccess($learningId){ 
		
		$user = JFactory::getUser();	
		$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
		$lang = JFactory::getLanguage();
		$app = JFactory::getApplication();
		$session = JFactory::getSession();
		
		$UniqLearningPath='onThePlayvQuizLearningPath'.$learningId;
		
		$query = ' SELECT i.access,i.attempt_count,i.set_price,i.attempt_delay,i.attempt_delay_param,i.ipaddress_allow as ipaddress FROM #__vquiz_learning as i ';
 
		$where = array();
		
		$where[] = ' i.id = '.$this->_db->quote($learningId);
		$where[] = ' i.published = 1';
		$where[] = ' i.access in ('.implode(',', $user->getAuthorisedViewLevels()).')';
		if($app->getLanguageFilter())	{
			$where[] = ' i.language in ('.$this->_db->quote($lang->getTag()).', '.$this->_db->Quote('*').')';
		}
		$query .= ' where ' . implode(' and ', $where);
		$query .=' order by i.id asc';
		$this->_db->setQuery($query);
		$result = $this->_db->loadObject();
		
		if(!empty($result)){
			$set_price = $result->set_price;
			$accessuser = $result->access;
			$attempt_count = $result->attempt_count;
			$attempt_delay = $result->attempt_delay;
			$delay_periods = $result->attempt_delay_param;
			$ipaddress_allow = explode(',',$result->ipaddress);
		}else{
			$set_price = 0;
			$accessuser = '';
			$attempt_count = 0;
			$attempt_delay = 0;
			$delay_periods ='';
			$ipaddress_allow = '';
			return false;
		}
 
		switch ($delay_periods) {
			case 'days':
			$days=1;
			break;
			case 'week':
			$days=7;
			break;
			case 'month':
			$days=30;
			break;
			case 'hour':
			$days=1/24;
			break;
			default:
			$days=0;
		}
		
		$attemptdate=$attempt_delay * $days;
		$attemptdate_tounix=$attemptdate * 24*60*60;

		$query=$this->_db->getQuery(true);
		$query->select('created');
		$query->from('#__vquiz_learning_playedquizzes');
		if($user->id!=0) {
			$query->where('userid='.$this->_db->quote($user->id));
		}else if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
			$cookieId = $_COOKIE['vQuizLearningPath'.$UniqLearningPath];
			$query->where('cookieId='.$this->_db->quote($cookieId));
		}
		$query->where('learning_id ='.$this->_db->quote($learningId));
		$query->where('played = 1');
		$query->order('id asc');
		$query->setLimit(1);
		
		$this->_db->setQuery($query);
		$first_start_date=$this->_db->loadResult();

		$curent_date=strtotime(JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString());
		$next_attempt_date=strtotime($first_start_date)+$attemptdate_tounix;
		
 
		
		$query=$this->_db->getQuery(true);
		$query->select('count(learning_id )');
		$query->from('#__vquiz_learning_playedquizzes'); //vquiz_learning_result
		if($user->id!=0) {
			$query->where('userid='.$this->_db->quote($user->id));
		}else if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
			$cookieId = $_COOKIE['vQuizLearningPath'.$UniqLearningPath];
			$query->where('cookieId='.$this->_db->quote($cookieId));
		}
		$query->where('learning_id ='.$this->_db->quote($learningId));
		//$query->where(' lession_id=0');
		$this->_db->setQuery($query);
		$attemptresult=$this->_db->loadResult();
 

					if($attempt_count>0)
					{	
						if($attemptresult<$attempt_count){
							$access_path =1;							
						}
						else{
							$access_path =0;
						} 
						
						if($attempt_delay>0){
						
							if($curent_date>$next_attempt_date){
								$access_path =1;							
							}
							else{
								$access_path =0;
							} 
						}   
					}
					else{
						$access_path =1;
					} 

 
			//---Check Server ip addrss---//
 
			if(!empty($ipaddress_allow) and $access_path==1 ){
				if(in_array($_SERVER['REMOTE_ADDR'],$ipaddress_allow)){
					$access_path =0;
				}else{
					$access_path =1;
				}
			}  	
			/*  if($set_price){
				
					$checkaccess = QuizHelper::learningaccess($learningId,$user->id);
					//print_r($set_price);
					if(!$checkaccess){
						$access_path =0;
					}else{
								$access_path =1;
					}
			  }
  */
			return $access_path;
		} 
		function createUserOrderBeforePay()
			{	
				$time = time();
				$config = QuizHelper::getConfiguration();
				//print_r($config);exit;
				//$date = new DateTime();
				$time = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
				$session=JFactory::getSession();
				$user = JFactory::getUser();
				if ($user->id==0)
				{
				$userid = $session->get('REGISTRATION_USER_ID', 0);
				}
				else{
				$userid = $user->id;
				}
			    $learning_id=JRequest::getVar('learning_id','');
				$query ='select title,price from #__vquiz_learning where id = '.$learning_id;
				$this->_db->setQuery( $query );
				$learning_detail = $this->_db->loadrow();
				//print_r($learning_detail);exit;
				//$title=JRequest::getVar('title','');print_r($title);exit;
				//$plan_id = JRequest::getVar('plan_id','');
				$subscription_id = JRequest::getVar('subid','');
				//$plan = QuizHelper::planDetail($plan_id);
				$total = $config->tax_enable==1?QuizHelper::pricewithtax($learning_detail[1]):$learning_detail[1];
				$subscriptions = $this->getTable('subscriptions', 'Table');
				$subscriptions->load($subscription_id);
				$subscriptions->status = QuizHelper::SUBSCRIPTION_NONE;
				$subscriptions->total =  $total;
				$subscriptions->subscription_date = $time;
				$subscriptions->plan_id = 0; //$plan_id
				$subscriptions->quiz_id = 0;
				$subscriptions->learning_id = $learning_id;
				$subscriptions->user_id = $userid;
				$param = new stdClass();
				$param->expirationtype = 'forever';
				$param->expiration = '000000000000';
				$param->price = $learning_detail[1];  //$total 
				
				$param->title = $learning_detail[0];
				$subscriptions->params  = json_encode($param);
				//print_r($subscriptions);
				if (!$subscriptions->store())
				{
				$this->setError( $subscriptions->getError() );
				return false; 
				}

				   
					JRequest::setVar('subid', $subscriptions->id);
					
					$order_id = JRequest::getVar('order_id','');
					$order =  $this->getTable('Orders', 'Table');
					$order->load($order_id);
					//print_r($order);exit;
					$order->subscr_id = $subscriptions->id;
					$order->app_id = 1;  
					$order->tax = $config->tax_enable==1?$total-$learning_detail[1]:'0.00000';
					$order->currency = $config->currencyname;
					
					
					
					$order->total = $total;
					$order->subtotal = $learning_detail[1]; 
					$order->status = QuizHelper::ORDER_NONE;
					$order->coupon_code = "";
					$order->buyer_id = $userid;
					$order->created_date = $time;
					$order->modified_date = $time;
					 
					$order->order_key = QuizHelper::generateSerialCode(12);
					
					$param = new stdClass();
					$param->expirationtype = 'forever';
					$param->expiration = '000000000000';
					$param->price = $learning_detail[1]; // $total
					$param->title = $learning_detail[0];
					$order->params = json_encode($param); 
					//print_r($order);exit;
					if (!$order->store()) {
						$this->setError( $order->getErrorMsg() );
						return false;
					}
					JRequest::setVar('order_key', $order->order_key);
					
					$subscription =  $this->getTable('subscriptions', 'Table');
					$subscription->load($subscriptions->id);
					$subscription->total = $order->total; 
					$param = new stdClass();
					$param->expirationtype = 'forever';
					$param->expiration = '000000000000';
					$param->title = $learning_detail[0];
					$param->order_id = $order->order_id;
					$param->order_key = $order->order_key;
					$param->price = $learning_detail[1]; //  $order->total; 
					$subscription->params = json_encode($param);
					$subscription->store();
				   
				return true;

				}
function getLessonViewedStatus(){		
	
		$user = JFactory::getUser();				
		$app=JFactory::getApplication();		
		$learningId = JRequest::getInt('id',0);
		//$learningId = $app->input->get('learningId',0);	
		
		$query  ='  select count(id) as lesson_viewed from #__vquiz_learning_result';		
		$query .= ' where learning_id ='.$learningId.' AND lession_id <> 0 AND completed=1 AND userid='.$user->id;	$this->_db->setQuery( $query);				
		
		$result = $this->_db->loadObject();
		$lesson_viewed = $result->lesson_viewed;
		
		$query  ='  select count(id) as total_lessons from #__vquiz_learning_lnq';		
		$query .= ' where learningid ='.$learningId.' AND lessionid <> 0 ';
		$this->_db->setQuery( $query);				
		
		$result = $this->_db->loadObject(); //var_dump($result);
		$total_lessons = $result->total_lessons;
		
		if($lesson_viewed==$total_lessons){
			return 1;
		}else{
		return 0;	
		}
	}				
}