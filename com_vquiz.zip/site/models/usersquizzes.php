<?php
/*------------------------------------------------------------------------
# com_vquiz - vquiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
 
class VquizModelUsersquizzes extends JModelList
{
 
	function __construct()
	{
		parent::__construct();
        $mainframe = JFactory::getApplication();
		
		JTable::addIncludePath(JPATH_SITE.'/components/com_vquiz/tables');
		$row=JTable::getInstance('Quizzes', 'VquizTable', array());
	 
		
		$context	= 'com_vquiz.usersquizzes.list.';
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		
		$filter_language = $mainframe->getUserStateFromRequest( $context.'filter_language',	'filter_language',	'' );
		
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
		
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);

	}

 	function _buildQuery()
	{
		$db =JFactory::getDBO();
		$user = JFactory::getUser();

		//$query='SELECT i.*, count(u.quizid) as totalquestion , x.title as categoryname FROM #__vquiz_quizzes as i left join #__vquiz_question as u ON i.id = u.quizid left join #__vquiz_category as x ON x.id = i.catid';
		
		 $query =$this->_db->getQuery(true);
		 $query->select('i.*,count(q.questionid) as totalquestion , x.title as categoryname ');
		 $query->from($this->_db->quoteName('#__vquiz_quizzes').' as i');
		 $query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').'as q on i.id = q.quizid ');
		// $query->join('LEFT',$this->_db->quoteName('#__vquiz_question').'as qu on qu.id = q.questionid ');
		 $query->join('LEFT',$this->_db->quoteName('#__vquiz_category').'as x ON x.id = i.catid');
		
		if (!$user->authorise('core.admin','com_vquiz')){
			$groups = implode(',', $user->getAuthorisedViewLevels());
			$query .= ' and i.access IN (' . $groups . ')';
		}
		
		 return $query;

	}

	function setId($id)
	{
		$this->_id		= $id;
		$this->_data	= null;
	}

	function &getItem()

	{

		if (empty( $this->_data )) {
			$query = ' SELECT * FROM #__vquiz_quizzes '.
					'  WHERE id = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();


		}

		if (!$this->_data) {
				
				$this->_data = new stdClass();
				$this->_data->id = 0;
 				$this->_data->title = null;
 				$this->_data->catid= null; 
 			    $this->_data->startpublish_date= JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString(); 
 				$this->_data->endpublish_date= null;
 				$this->_data->question_categoryid= null; 
 				$this->_data->description= null;
 				$this->_data->published= 1;
				$this->_data->set_price= null;
				$this->_data->price= 0;
				$this->_data->featured= null;
 				$this->_data->total_timelimit= null;
				$this->_data->totaltime_parameter= null;
 				$this->_data->question_timelimit= null;
 				$this->_data->passed_score= null;
 				$this->_data->random_question= null;
 				$this->_data->prev_button= null;
 				$this->_data->skip_button= null;
				$this->_data->question_number= null;
 				$this->_data->show_correctans= null;
 				$this->_data->explanation= null;
 				$this->_data->penalty= null;
  				$this->_data->paging= null;
				$this->_data->paging_limit= null;
				
 				$this->_data->accessuser= null;
 				$this->_data->attempt_count = null;
				$this->_data->count_ipaddress = null;
 				$this->_data->attempt_delay= null;
 				$this->_data->delay_periods= null;
 				$this->_data->quiz_categoryname= null;
 				$this->_data->graph_type= null;
				$this->_data->flag= null;
				$this->_data->livescore= null;
				$this->_data->quiztype= null;
				$this->_data->question_limit= null;
				$this->_data->meta_keyword= null;
				$this->_data->meta_desc= null;
				$this->_data->userscore= null;
				$this->_data->ordering= null;
				$this->_data->access= null;
				$this->_data->language= null;
				$this->_data->slider_bar= null;
				$this->_data->correctans= null;
				$this->_data->question_options_display= null;
				$this->_data->show_graph= null;
				$this->_data->answers_type= null;
				$this->_data->personality_type= null;
				$this->_data->multi_p_percentage= null;
				$this->_data->completion_level= null;
				$this->_data->multi_p_score= null;
				$this->_data->ipaddress_allow= null;
				$this->_data->random_option =null;
				$this->_data->answer_sheet_option =1;
				$this->_data->prev_answer =0;
				$this->_data->answer_sheet =1;
				$this->_data->category_combination =null;
				$this->_data->certificate =null;
				$this->_data->cet_digits =10;
				$this->_data->end_with ='vQuiz';
				$this->_data->cet_format =0;
				$this->_data->cet_type =1;
				$this->_data->start_with ='CET';
				$this->_data->input_first_name =0;
				$this->_data->input_last_name =0;
				$this->_data->input_company =0;
				$this->_data->input_title =0;
				$this->_data->input_email =0;
				$this->_data->input_mobile =0;
				$this->_data->display_result =0;
				$this->_data->answersheet_explanation =0;
				$this->_data->lead_generate =0;
				$this->_data->lead_generate_mandatory =0;
				$this->_data->play_user_name =0;
				$this->_data->play_user_ids =null;
				$this->_data->enable_questiongroup =0;
				$this->_data->access_token =null;
				$this->_data->questionreview=0;
				$this->_data->questionreview_answer=0;
				$this->_data->questionreview_qlink=0;
				$this->_data->questionreview_option=0;
				$this->_data->questionreview_question=0;
				$this->_data->questionreview_box=0;
				$this->_data->textformat=null;
				
				$this->_data->next_quiz= null;
				$this->_data->prev_quiz= null;
				$this->_data->result_snapshot= null;
				$this->_data->content_prep_event_quiz= null;
				$this->_data->content_prep_event_ques= null;
				$this->_data->circulate_skipped_ques= null;
				$this->_data->quiz_draft= null;
				$this->_data->send_invitation= null;
				$this->_data->disable_print_copy= null;
				$this->_data->share_button= null;
				$this->_data->share_btn_choosed= null;
				$this->_data->quiz_review_panel= null;
				$this->_data->quiz_certificate= null;
				$this->_data->save_certificate= 0;
				$this->_data->cet_name= null;
				$this->_data->show_qgroup_description=0;
				$this->_data->show_qgroup_title=0;
				$this->_data->hint=0;
				$this->_data->transcript=0;
				$this->_data->article_link_id=0;
				
				$this->_data->continuous_question= 0;
				$this->_data->later_play= 0;
				$this->_data->invite= 0;
				$this->_data->disable_print_copy_result= 0;
				
				
		}
		return $this->_data;

	}

		function &getItems(){
		
			// Lets load the data if it doesn't already exist
			if (empty( $this->_data ))
			{
				 $query = $this->_buildQuery();
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();
				 
				 $query .= $filter;
				 $query .= $orderby;
			 
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			}

			return $this->_data;
		}
	 


function getTotal()
		
			{
		
				if (empty($this->_total)) {
					$query = $this->_buildQuery();
					$query .= $this->_buildContentFilter();
					$query  .= $this->_buildItemOrderBy();  
					$this->_total = $this->_getListCount($query);    
				}
				return $this->_total;
			}
			
			
			

			 function _buildItemOrderBy()
				{
					$mainframe = JFactory::getApplication();
					
					$context	= 'com_vquiz.usersquizzes.list.';
			 
					$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
					$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
			 
					$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
			 
					return $orderby;
				}



			function getPagination()
			{
				// Load the content if it doesn't already exist
				if (empty($this->_pagination)) {
					jimport('joomla.html.pagination');
					$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
				}
				return $this->_pagination;
			}
 
 
 
		  function _buildContentFilter()
		  {
				
				//$qcategoryid = JRequest::getVar('qcategoryid');
				$requestcategoryid = JRequest::getVar('qcategoryid');
				$quiztype = JRequest::getInt('qtype',0);
				
				$mainframe =JFactory::getApplication();
		        $user=JFactory::getUser();
				$context	= 'com_vquiz.usersquizzes.list.';
				$qcategoryid		= $mainframe->getUserStateFromRequest( $context.'qcategoryid', 'qcategoryid',	'',	'string' );
				$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
				$categorysearch		= $mainframe->getUserStateFromRequest( $context.'categorysearch', 'categorysearch',	'',	'integer' );
				$publish_item		= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );
				$assign_quiz		= $mainframe->getUserStateFromRequest( $context.'assign_quiz', 'assign_quiz',	'',	'string' );
				
				$search		= JString::strtolower( $search );
				
				$where = array();
				$OR = array();
				
				if($publish_item)
				{  

					if ( $publish_item == 'p' )
					$where[] = 'i.published= 1';
					
					else if($publish_item =='u')
					$where[] = 'i.published = 0';
			
				}
								
				if($qcategoryid and $requestcategoryid ){
				
					$where[] = 'i.catid LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $qcategoryid, true ).'%', false );
				
				}else if($categorysearch){ 
					 $where[] = 'i.catid='.$this->_db->Quote( $this->_db->escape( $categorysearch, true ), false );
				}
				 
				if($search){	
					if (is_numeric($search)){		 
						$where[] = 'LOWER( i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
					}else {
					 $where[] = 'i.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
					}
				}
				
				if($qcategoryid) {
					$where[] = 'i.catid LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $qcategoryid, true ).'%', false );
				}
					  
					$where[] = 'i.catid !=1';
					  
				if($quiztype){
					$where[] = ' i.quiztype ='.$this->_db->quote($quiztype);
				}
 						
				$query='SELECT quizid FROM #__vquiz_monitor_quiz where userid='.JFactory::getUser()->id;
				$this->_db->setQuery( $query );
				$monitor_quiz= $this->_db->loadColumn();
				
				$query='SELECT catid FROM #__vquiz_monitor_category where userid='.JFactory::getUser()->id;
				$this->_db->setQuery( $query );
				$monitor_category= $this->_db->loadColumn();
				
				if($assign_quiz){
				
					if ( $assign_quiz ==1){
						$where[] = 'i.created_by ='.$this->_db->Quote( $this->_db->escape($user->id, true ), false );
					}elseif($assign_quiz ==2 and !empty($monitor_quiz[0])){
						$where[] = 'i.id IN ('.implode(',', $monitor_quiz).')';
						if(!empty($monitor_category[0])){
						$OR[] = 'i.catid IN ('.implode(',', $monitor_category).')';
						}
					}else{
						$where[] = 'i.created_by ='.$this->_db->Quote( $this->_db->escape($user->id, true ), false );
					}
					
				}else{
				 
					$where[] = 'i.created_by ='.$this->_db->Quote( $this->_db->escape($user->id, true ), false );
					
					if(!empty($monitor_quiz[0])){
						$OR[] = 'i.id IN ('.implode(',', $monitor_quiz).')';
					}
					if(!empty($monitor_category[0])){
						$OR[] = 'i.catid IN ('.implode(',', $monitor_category).')';
					}
				}
				 
				$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
				
				if(empty($filter)){
					$filter = count($OR) ? ' WHERE ' . implode(' OR  ', $OR) : '';
				}else{
					$filter .= count($OR) ? ' OR ' . implode(' OR  ', $OR) : '';
				}
		
			return $filter;
		}
			
			
	
	function reorder()
		{
			 $mainframe =& JFactory::getApplication();
			// Check for request forgeries
			//JRequest::checkToken() or jexit( 'Invalid Token' );
			$cid 	= JRequest::getVar( 'cid', array(), 'post', 'array' );
			JArrayHelper::toInteger($cid);
			$task	= JRequest::getCmd('task', '');
			$inc	= ($task == 'orderup' ? -1 : 1);
			if (empty( $cid )) {
				return JError::raiseWarning( 500, 'No items selected' );
			}
			//$row =& $this->getTable();
			$row=& JTable::getInstance('Quizzes', 'VquizTable', array());
			$row->load( (int) $cid[0] );
			$row->move( $inc  );
			return 'reordered successfully!';
		}
	
		function saveOrder()
				
			{
				// Check for request forgeries
				//JRequest::checkToken() or jexit( 'Invalid Token' );
				$cid 	= JRequest::getVar( 'cid', array(), 'post', 'array' );
				JArrayHelper::toInteger($cid);
				if (empty( $cid )) {
					return JError::raiseWarning( 500, 'No items selected' );
				}
				$total		= count( $cid );
				//$row =& $this->getTable();
				$row=& JTable::getInstance('Quizzes', 'VquizTable', array());
				$groupings = array();
				$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
				JArrayHelper::toInteger($order);
				// update ordering values
				for ($i = 0; $i < $total; $i++)
				{
					$row->load( (int) $cid[$i] );
					// track postions
					$groupings[] = $row->position;
					if ($row->ordering != $order[$i])
					{
						$row->ordering = $order[$i];
						if (!$row->store()) {
							return JError::raiseWarning( 500, $this->_db->getErrorMsg() );
						}
					}
				}
		
				// execute updateOrder for each parent group
				$groupings = array_unique( $groupings );
				foreach ($groupings as $group){
					$row->reorder();
				}
				return 'New ordering saved';
			}
			
			

	function store()
	{	
		
		
		$time = time();
		$session =JFactory::getSession();
	   $row=JTable::getInstance('Quizzes', 'VquizTable', array());
		 //$row =$this->getTable();
		$user = JFactory::getUser();
 
		$data = JRequest::get( 'post' ); 
		if($data['quiztype']!=11)
		{
			$data['answers_type']=0;
		}
		if($data['quiztype']==22)
		{
			$data['personality_type']=2;
		}
		$data['description'] = JRequest::getVar('description', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$data['certificate'] = JRequest::getVar('certificate', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$data['textformat'] = JRequest::getVar('textformat', '', 'post', 'string', JREQUEST_ALLOWRAW);
  		$data['quiz_categoryname'] =JRequest::getVar('quiz_categoryname','', 'post');
  		$data['ipaddress_allow'] =json_encode(JRequest::getVar('ipaddress_allow','', 'post'));
		
		
		$data['access'] =!empty($data["access"])?$data["access"]:1;
					
		$data["alias"] = JFilterOutput::stringURLSafe(empty($data["alias"])?$data["title"]:$data["alias"]);
		
		$data['share_btn_choosed'] =implode(',',JRequest::getVar('share_btn_choosed','', 'post','array'));
		
		
		$query = 'select users_moderation from #__vquiz_configuration';
		$this->_db->setQuery( $query );
		$moderation =$this->_db->loadResult();
		if($moderation==1){
			$data["published"]=0;
		}

		
		if($data["id"]==0)
		{
			
			$data['created'] = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
			$data['created_by'] = $user->id;
 
			$query='select MAX(ordering) from #__vquiz_quizzes';
			$this->_db->setQuery($query);
			$highest_ordering=$this->_db->loadResult();

			$data['ordering'] = $highest_ordering+1;
			
			

			
		}
		
		if($data["id"]){
			
			$query = ' SELECT image from #__vquiz_quizzes WHERE id = '.$data["id"];
			$this->_db->setQuery( $query );
			$oldimage_path = $this->_db->loadResult();
			
					if(JRequest::getVar('task','')=='save2copy'){
			
			$origTable = clone $row;
			$origTable->load($data['id']);
			//$origTable = $row->load($data['id']);

				if($data['title'] == $origTable->title){
					$data['id'] = 0;
				
					while ($row->load(array('alias' => $data['alias'], 'catid' => $data['catid'])))
					{
						$data['title'] = JString::increment($data['title']);
						$data['alias'] = JString::increment($data['alias'], 'dash');
					}
				}else{
					$data['id'] = 0;
				
					while ($row->load(array('alias' => $data['alias'], 'catid' => $data['catid'])))
					{ 
						$data['title'] = JString::increment($data['title']);
						$data['alias'] =  str_replace(' ', '-', strtolower($data['title']));
					} 
				}

			}
			else
			{
				if ($data['alias'] == $origTable->alias)
				{
					$data['alias'] = '';
				}
			}	
		}
 
		$image = JRequest::getVar('image', null, 'FILES', 'array');
 		$allowed = array('.jpg', '.jpeg', '.gif', '.png');
 
	        	$dirpath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/';
    			$thumbPath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/thumbs/'; 
				 
        	jimport('joomla.filesystem.file');
     	   $image_name = str_replace(' ', '', JFile::makeSafe($image['name']));
   			$image_tmp = $image['tmp_name'];
			$time = time();

 
			if($image_name <> "" )
			{
				$ext = strrchr($image_name, '.');
 			     if(!in_array($ext, $allowed)){
					$msg_error=JText::_('THIS_IMAGE_TYPE_NOT_ALLOWED');
					$this->setError($msg_error);
					return false;
				}
				//=============================//			

 				$size = getimagesize($image_tmp);
 				$src_w = $size[0];
 				$src_h = $size[1];
 				//set the height and width in proportions
 					if($src_w > $src_h )
 				{
 						$width = 125; //New width of image    
 						$height = $size[1]/$size[0]*$width; //This maintains proportions
 						$width1 = 300; //New width of image    
 						$height1 = $size[1]/$size[0]*$width; //This maintains proportions


					}else


					{
 						$height = 125;
 						$width = $size[0]/$size[1]*$height; //This maintains proportions
 						$height1 = 360;
 						$width1 = $size[0]/$size[1]*$height; //This maintains proportions


					}


						// set image new width and height 
 						$width1 = 265; //New width of image    
 						$height1 = $size[1]/$size[0]*$width; //This maintains proportions
 
						$new_image = imagecreatetruecolor($width, $height);
 						$new_image1 = imagecreatetruecolor($width1, $height1);
						
 						if($size['mime'] == "image/jpeg")
 						$tmp = imagecreatefromjpeg($image_tmp);
 						elseif($size['mime'] == "image/gif")
 						$tmp = imagecreatefromgif($image_tmp);
 						else

 						$tmp = imagecreatefrompng($image_tmp);
 						imagecopyresampled($new_image, $tmp,0,0,0,0, $width, $height, $src_w, $src_h);


						if($size['mime'] == "image/jpeg")


							imagejpeg($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);

 							elseif($size['mime'] == "image/gif")


							imagegif($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);

 
						else


							imagepng($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);

 							imagecopyresampled($new_image1, $tmp,0,0,0,0, $width1, $height1, $src_w, $src_h);


						if($size['mime'] == "image/jpeg")


							imagejpeg($new_image1, $dirpath.$time.'_'.$image_name);

 							elseif($size['mime'] == "image/gif")


							imagegif($new_image1, $dirpath.$time.'_'.$image_name);
 							else


							imagepng($new_image1, $dirpath.$time.'_'.$image_name);
							
 						//======= end of thumbail code========//
 					if(move_uploaded_file($image_tmp, $dirpath.$time.'_'.$image_name))


					$data['image'] = $time.'_'.$image_name;
	 
 	
					}
 
				if($data['image'] and $oldimage_path)
				{
					unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/'.$oldimage_path);
					unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/thumbs/'.'thumb_'.$oldimage_path);  
				}
		 

		if (!$row->bind($data)) {
 
			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		// Make sure the vquiz record is valid
		if (!$row->check()) {
 
			$this->setError($this->_db->getErrorMsg());

			return false;

		}
		// Store the web link table to the database
		if (!$row->store()) { 
			$this->setError( $row->getErrorMsg() );
			return false; 
		}

		if(!$data['id']){
			JRequest::setVar('id', $row->id);
			
			// On Create Quiz Trigger Jomsocial Stream Plugin.
			$plugin = JPluginHelper::getPlugin('community', 'vquiz_stream');
			
			if($plugin){
				
				JPluginHelper::importPlugin('community','vquiz_stream');
				$dispatcher = JDispatcher::getInstance();
				try{
					$dispatcher->trigger('onCreateQuizStream',array($user,$row->id));
				}catch(Exception $e){
					jexit('{"result":"error", "error":"'.$e->getMessage().'"}');
				}
			}  
			
		}
			
		if($session->has('personality_message_session')){
			$tm=$session->get('personality_message_session');
			JRequest::setVar('answer', $tm['answer']);
			JRequest::setVar('desc', $tm['desc']);
			JRequest::setVar('article_id', $tm['article_id']);
			JRequest::setVar('article_link_title', $tm['article_link_title']);
			JRequest::setVar('concate_desc', $tm['concate_desc']);
			JRequest::setVar('color', $tm['color']);
			JRequest::setVar('quizid',$row->id);
			$this->personality_messagestore();
			
		}elseif($session->has('trivia_message_session')){
		
			$tm=$session->get('trivia_message_session');
			JRequest::setVar('score', $tm['score']);
			JRequest::setVar('trivia_message', $tm['trivia_message']);
			JRequest::setVar('article_link_id', $tm['article_link_id']);
			JRequest::setVar('article_link_title', $tm['article_link_title']);
			JRequest::setVar('quizid',$row->id);
			$this->trivia_messagestore();
 
		}
		
		
		//save notification on adding quiz
						
		if(!$data['id']){ 
					
			$data_arr = array();
			$data_arr['itemid'] = $row->id;
			$data_arr['notification_type'] = 6;
				
			if(QuizHelper::checkNotification($data_arr['notification_type'])){
				$data_arr['notify_users'] = QuizHelper::findUsersToNotify('notfify_add_quiz');
				$data_arr['enotify_users'] = QuizHelper::findUsersToEnotify('enotfify_add_quiz');
				//print_r($data_arr); exit;
				QuizHelper::sendNotification($data_arr);
			}
		
		}
	  		
		return true;
	}

	function trivia_messagestore()
		{	
 
		$session=JFactory::getSession();
		$data = JRequest::get( 'post' );
		$quizid=JRequest::getInt('quizid');
		$data['score']	= JRequest::getVar('score', array(), 'post', 'array');
		$data['trivia_message'] = JRequest::getVar('message', array(), 'post', 'array'); 
		$data['article_link_id'] = JRequest::getVar('article_link_id', array(), 'post', 'array');	
		$data['article_link_title'] = JRequest::getVar('article_link_title', array(), 'post', 'array');	

		$query='select id from #__vquiz_trivia_message where quizid='.$quizid.' order by id asc';
		$this->_db->setQuery($query);
		$exid = $this->_db->loadColumn(); 
 
 
		for($i=0;$i<count($data['score']);$i++)
		{
		    if($quizid and !empty($data['score'])){
				
				if(count($exid)>0)	{
				$id = array_shift($exid);
					$query = 'update #__vquiz_trivia_message set message = '.$this->_db->quote($data['message'][$i]).', score = '.$this->_db->quote($data['score'][$i]).' ,article_link_id = '.$this->_db->quote($data['article_link_id'][$i]).' where id = '.$this->_db->quote($id);
					
				}
				
				else{
				 $query = 'insert into #__vquiz_trivia_message(quizid,message,score,article_link_id) values('.$this->_db->quote($quizid).','.$this->_db->quote($data['message'][$i]).','.$this->_db->quote($data['score'][$i]).','.$this->_db->quote($data['article_link_id'][$i]).')';
			  }
				$this->_db->setQuery($query);
										
				if(!$this->_db->execute())	
				{
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
				
				JRequest::setVar('id', $quizid);
				$session->clear('trivia_message_session');
			}
			else{
				 
				$session->set('trivia_message_session',$data);
			}
		 }
		 
		if(count($exid)>0 and !empty($data['score']))	{
			
			$query = 'delete from #__vquiz_trivia_message where id in ('.implode(', ', $exid).')';
			$this->_db->setQuery( $query );
						
			if(!$this->_db->execute())	
			{
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		
		} 
	 
		return true;
 
		
	}
		
		
	function personality_messagestore()
		{	
           
		$session=JFactory::getSession();
		$data = JRequest::get('post');
	    $quizid=JRequest::getInt('quizid');
		$data['answer']	= JRequest::getVar('answer', array(), 'post', 'array');
		$data['desc'] = JRequest::getVar('desc', array(), 'post', 'array'); 
 
		$query='select id from #__vquiz_personality_message where quizid='.$quizid.' order by id asc';
		$this->_db->setQuery($query);
		$exid = $this->_db->loadColumn(); 
 
 
		for($i=0;$i<count($data['answer']);$i++)
		{ 
			if($quizid and !empty($data['answer'][$i])){ 
				if(count($exid)>0)	{
				$id = array_shift($exid);
					$query = 'update #__vquiz_personality_message set description = '.$this->_db->quote($data['desc'][$i]).', answer = '.$this->_db->quote($data['answer'][$i]).' where id = '.$this->_db->quote($id);
					
				}
				
				else{
				 

				 $query = 'insert into #__vquiz_personality_message(quizid,description,answer) values('.$this->_db->quote($quizid).','.$this->_db->quote($data['desc'][$i]).','.$this->_db->quote($data['answer'][$i]).')';
			  }
				$this->_db->setQuery($query);
										
				if(!$this->_db->execute())	
				{
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
				
				JRequest::setVar('id', $quizid);
				$session->clear('personality_message_session');
			}
			else{
				 
				$session->set('personality_message_session',$data);
			}
		 }
		 
		if(count($exid)>0 and !empty($data['answer']))	{
			
			$query = 'delete from #__vquiz_personality_message where id in ('.implode(', ', $exid).')';
			$this->_db->setQuery( $query );
						
			if(!$this->_db->execute())	
			{
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		
		} 

		return true;
 
		
	}
		
	function getTrivia_messages()
	{
		$quizid=JRequest::getInt('id',0);
		$db=JFactory::getDbo();
		$query=$db->getQuery(true);
		$query->select('i.*,a.title as article_title');
		$query->from($db->quoteName('#__vquiz_trivia_message').' as i');
		$query->join('LEFT',$db->quoteName('#__content').' as a on i.article_link_id=a.id');
		$query->where('i.quizid = ' .(int)$quizid);
		$this->_db->setQuery($query);
		$result = $this->_db->loadObjectList();
		return $result;
	}
	
	function getPersonality_messages()
	{
		$quizid=JRequest::getInt('id',0);
		$db=JFactory::getDbo();
		$query=$db->getQuery(true);
		$query->select('i.*,a.title as article_title');
		$query->from($db->quoteName('#__vquiz_personality_message').' as i');
		$query->join('LEFT',$db->quoteName('#__content').' as a on i.article_id=a.id');
		$query->where('i.quizid = ' .(int)$quizid);
		$this->_db->setQuery($query);
		$result = $this->_db->loadObjectList();

		return $result;
	}

		 function publish()
			{
				$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
				$task		= JRequest::getCmd( 'task' );
				$publish	= ($task == 'publish')?1:0;
				$n = count( $cid );
				if (empty( $cid )) 
				{
					return 'No item selected';
				}
				$getModeration=$this->getModeration();
				
				if($getModeration==0){
				
					$cids = implode( ',', $cid );
					//implode() convert array into string		
					$query = 'UPDATE #__vquiz_quizzes SET published = ' . (int) $publish . ' WHERE id IN ( ' . $cids . ' )';
					$this->_db->setQuery( $query );

					if (!$this->_db->query())
						return $this->_db->getErrorMsg();
					else
						return ucwords($task).'ed successfully.';
						
				}
				else{
					return JText::_("MODERATION_MESSAGE");
				}

			}
	
	
	function featured()
			{
		 
				$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
				$task		= JRequest::getCmd( 'task' );
				$featured	= ($task == 'featured')?1:0;
				$n = count( $cid );
				
				
				if (empty( $cid )) 
				{
				return 'No item selected';
				}
				
				$cids = implode( ',', $cid );
				$query = 'UPDATE #__vquiz_quizzes SET featured = ' . (int) $featured . ' WHERE id IN ( ' . $cids . ' )';
				$this->_db->setQuery( $query );
				
				if (!$this->_db->query())
				return $this->_db->getErrorMsg();
				else
				return ucwords($task).'ed successfully.';
			
			}

				
			function getCategory()

			{
				$query ='select a.id , a.title , a.level ';
				$query .=' from #__vquiz_category As a ';
				$query .=' LEFT join #__vquiz_category AS b ON a.lft > b.lft AND a.rgt < b.rgt';
				
				$where = array();								
				$where[] = 'a.id !=1';
				$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
				$query .= $filter;
				$query .=' group by a.id, a.title, a.level, a.lft, a.rgt, a.parent_id order by a.lft ASC';
				
				$this->_db->setQuery($query);
				$result=$this->_db->loadObjectList();
				return $result;
				
			}

		
		function delete()
				{
		
				$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		
				//$row =& $this->getTable();
				$row=& JTable::getInstance('Quizzes', 'VquizTable', array());
		
				if (count( $cids )) {
		
					foreach($cids as $cid) {
								
								$query = ' SELECT image from #__vquiz_quizzes WHERE id = '.$cid;
								$this->_db->setQuery($query);
								$oldimage_path = $this->_db->loadResult();
					 
								if(!empty($oldimage_path)){
								unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/'.$oldimage_path);
								unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/thumbs/'.'thumb_'.$oldimage_path);
								}
		
						if (!$row->delete( $cid )) {
		
							$this->setError( $row->getErrorMsg() );
		
							return false;
		
						}
						
						if($row->delete( $cid )){
						
								$q ='delete FROM #__vquiz_personality_message WHERE quizid = '.$cid;
								$this->_db->setQuery( $q );
								$this->_db->execute();

								$q ='delete FROM #__vquiz_trivia_message WHERE quizid = '.$cid;
								$this->_db->setQuery( $q );
								$this->_db->execute();
						
								$query = ' SELECT id FROM #__vquiz_question WHERE quizid = '.$cid;
								$this->_db->setQuery( $query );
								$question_id = $this->_db->loadColumn();
							
								$q ='delete FROM #__vquiz_question WHERE quizid = '.$cid;
								$this->_db->setQuery( $q );
		 
								if ($this->_db->execute() and !empty($question_id)) {
									
								$q ='delete FROM #__vquiz_option WHERE qid IN ('.implode(',',$question_id).')';
								$this->_db->setQuery( $q );
								$this->_db->execute();
								
								}
								
		
						}
		
						
		
		
					}
					
					
				}
		 
				return true;
		
			}
	
	

				function getAccess()
			{
				$query='select * from #__usergroups order by id asc';
				$this->_db->setQuery($query);
				$result = $this->_db->loadObjectList();
				
				return $result;
		
			}

				
			function movequestion()
				{
				
				$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
				$categoryid = JRequest::getInt('quizcategoryidmove');
				
				if (count( $cids )) {
					foreach($cids as $cid) {
					
					$query = 'UPDATE #__vquiz_quizzes SET catid = '.$categoryid.' WHERE id = '.$cid;
					$this->_db->setQuery( $query );

					if (!$this->_db->query()){
					$msg = $this->setError($this->_db->stderr());
					$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=usersquizzes'), $msg );
					return false;
					}
					
					}
				}
					return true;
                 
				}
				
				
				function copyquestion()
				{
				
				$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
				$categoryid = JRequest::getInt('quizcategoryidcopy');

				if (count( $cids )) {
					foreach($cids as $cid) {
						
					$query = ' SELECT * FROM #__vquiz_quizzes WHERE id = '.$cid;
					$this->_db->setQuery( $query );
					$result= $this->_db->loadObject();
							
						$insert = new stdClass();
						$insert->id = null;
						$insert->catid =$categoryid;
						//$insert->quiz_categoryname = $result->quiz_categoryname;
						$insert->startpublish_date = $result->startpublish_date;
						$insert->endpublish_date = $result->endpublish_date;
						$insert->title = $result->title;
						$insert->alias = $result->alias;
						$insert->image = $result->image;
						$insert->passed_score = $result->passed_score;
						$insert->total_timelimit = $result->total_timelimit;
						$insert->totaltime_parameter = $result->totaltime_parameter;
						$insert->random_question = $result->random_question;
						$insert->prev_button = $result->prev_button;
						$insert->skip_button = $result->skip_button;
						$insert->flag = $result->flag;
						
						$insert->livescore =$result->livescore;
						$insert->show_correctans = $result->show_correctans;
						$insert->explanation = $result->explanation;
						$insert->penalty = $result->penalty;
						$insert->display_userscore = $result->display_userscore;
						$insert->graph_type = $result->graph_type;
						$insert->paging = $result->paging;
						$insert->paging_limit = $result->paging_limit;
						$insert->accessuser = $result->accessuser;
						//$insert->attempt_count = $result->attempt_count;
						//$insert->attempt_delay = $result->attempt_delay;
						//$insert->delay_periods = $result->delay_periods;
						$insert->description = $result->description;
						$insert->created = $result->created;
						$insert->created_by = $result->created_by;
	
						//$insert->published = $result->published;
						$insert->featured = $result->featured;
						$insert->ordering = $result->ordering;
						$insert->language = $result->language;
						$insert->access = $result->access;
						$insert->question_limit = $result->question_limit;
						//$insert->meta_keyword = $result->meta_keyword;
						//$insert->meta_desc = $result->meta_desc;
						$insert->quiztype = $result->quiztype;
						$insert->slider_bar = $result->slider_bar;
						
						$insert->share_button = $result->share_button;
			$insert->share_btn_choosed = $result->share_btn_choosed;
						
											
						if(!$this->_db->insertObject('#__vquiz_quizzes', $insert, 'id'))	{
						$msg = $this->setError($this->_db->stderr());
						$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=quizmanager'), $msg );
						return false;
						}
						$queszid = $this->_db->insertid();
 			
					    $query = ' SELECT * FROM #__vquiz_question WHERE quizid = '.$cid;
						$this->_db->setQuery( $query );
						$question=$this->_db->loadObjectList();
 
				
							for($i=0;$i<count($question);$i++)	{
								
								$insertquestion = new stdClass();
        						$insertquestion->id = null;
							    $insertquestion->quizid =$queszid;
								$insertquestion->questiontime_parameter = $question[$i]->questiontime_parameter;
								$insertquestion->question_timelimit = $question[$i]->question_timelimit;
								$insertquestion->optiontype = $question[$i]->optiontype;
								$insertquestion->qtitle = $question[$i]->qtitle;
								$insertquestion->explanation = $question[$i]->explanation;
								$insertquestion->scoretype = $question[$i]->scoretype;
								$insertquestion->score = $question[$i]->score;
								$insertquestion->expire_timescore = $question[$i]->expire_timescore;
								$insertquestion->penalty = $question[$i]->penalty;
								$insertquestion->created = $question[$i]->created;
								$insertquestion->modified_date = $question[$i]->modified_date;
								$insertquestion->published = $question[$i]->published;
								$insertquestion->featured = $question[$i]->featured;
								
														
								if(!$this->_db->insertObject('#__vquiz_question', $insertquestion, 'id'))	{
								
								$msg = $this->setError($this->_db->stderr());
								$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=quizmanager'), $msg );
								return false;
								}
						 
							    $qid = $this->_db->insertid();
								
								$query = ' SELECT * FROM #__vquiz_option WHERE qid = '.$question[$i]->id;
								$this->_db->setQuery( $query );
								$option = $this->_db->loadObjectList();
								
 
								 for($j=0;$j<count($option);$j++)	{
									 
										$insertoption = new stdClass();
										$insertoption->id = null;
										$insertoption->qid =$qid;
										$insertoption->image =$option[$j]->image;
										$insertoption->qoption =$option[$j]->qoption;
										$insertoption->correct_ans = $option[$j]->correct_ans;
										$insertoption->options_score =$option[$j]->options_score;
										$insertoption->personality_optionid =$option[$j]->personality_optionid;
										
										
										if(!$this->_db->insertObject('#__vquiz_option', $insertoption, 'id'))	{
										
											$msg = $this->setError($this->_db->stderr());
											$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=quizmanager'), $msg );
											
											return false;
										}
										
										
									}
								
						
							}
							
							$query = ' SELECT * FROM #__vquiz_personality_message WHERE quizid = '.$cid;
							$this->_db->setQuery( $query );
							$personality_messages=$this->_db->loadObjectList();
							
							for($i=0;$i<count($personality_messages);$i++)	{
								
								$insertpersonality = new stdClass();
        						$insertpersonality->id = null;
							    $insertpersonality->quizid =$queszid;
								$insertpersonality->answer = $personality_messages[$i]->answer;
								$insertpersonality->description = $personality_messages[$i]->desc;
								 						
								if(!$this->_db->insertObject('#__vquiz_personality_message', $insertpersonality, 'id'))	{
								
								$msg = $this->setError($this->_db->stderr());
								$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=quizmanager'), $msg );
								return false;
								}
							}
							
							
							$query = ' SELECT * FROM #__vquiz_trivia_message WHERE quizid = '.$cid;
							$this->_db->setQuery( $query );
							$trivia_messages=$this->_db->loadObjectList();
							
							for($i=0;$i<count($trivia_messages);$i++)	{
								
								$inserttrivia = new stdClass();
        						$inserttrivia->id = null;
							    $inserttrivia->quizid =$queszid;
								$inserttrivia->message = $trivia_messages[$i]->message;
								$inserttrivia->score = $trivia_messages[$i]->score;
								 						
								if(!$this->_db->insertObject('#__vquiz_trivia_message', $inserttrivia, 'id'))	{
								
								$msg = $this->setError($this->_db->stderr());
								$this->setRedirect(JRoute::_('index.php?option=com_vquiz&view=quizmanager'), $msg );
								return false;
								}
							
								
						}			
			
					}
				}	
					return true;
                 
				}
				
				
			function drawChart(){
	
 				$quizid = JRequest::getInt('quizid',0);
				$charttype = JRequest::getInt('charttype',0);
										
				$obj = new stdClass();
				$obj->result = "error";
				$obj->charttype=$charttype;
				
				
				/*---Most Choosed user---*/
				if($charttype==1){
					$query = 'SELECT score,count(userid) as totaluser from #__vquiz_quizresult WHERE quizid ='.$this->_db->quote($quizid).' group by score order by score asc';
					$this->_db->setQuery( $query );	
					$result_score=$this->_db->loadRowList(); 
					$obj->responce1=$result_score;
						
				}else{
					
					$countoption_p=array();
					$p_result_array=array();
					
					$q =' SELECT personality_result_id from #__vquiz_quizresult WHERE quizid ='.$quizid.' AND  personality_result_id IS NOT NULL ';
					$this->_db->setQuery( $q );	
					$result_pr=$this->_db->loadColumn(); 
					
					for($i=0;$i<count($result_pr);$i++)	
					{
						$xx=json_decode($result_pr[$i]);

						for($j=0;$j<count($xx);$j++){

							$given_answer=explode(',',$xx[$j]);
							for($k=0;$k<count($given_answer);$k++){
								if($given_answer[$k]!='')
								array_push($countoption_p,$given_answer[$k]);
							}  
						}
					} 

					$chosen_personality_count=array_count_values($countoption_p);
					$personality_keyvalue=array_keys($chosen_personality_count);
					$chosen_pcount=array_values($chosen_personality_count);

					for($i=0;$i<count($personality_keyvalue);$i++){
					
						$p_result=array();
						
						$query = 'select answer from #__vquiz_personality_message where id = '.$this->_db->quote($personality_keyvalue[$i]);
						$this->_db->setQuery( $query );
						$rs=$this->_db->loadResult();
						array_push($p_result,$rs);
						array_push($p_result,$chosen_pcount[$i]);
						array_push($p_result_array,$p_result); 
						
					}
					$obj->responce1=$p_result_array;
					
				}
				
				
				
				/*---Most Choosed Option---*/
				
				$q = 'SELECT quiz_answers from #__vquiz_quizresult WHERE quizid ='.$this->_db->quote($quizid);
				$this->_db->setQuery( $q );	
				$result_quiz_answer=$this->_db->loadRowList(); 
 
			    $options=array();
				$countoption=array();
				$array=array();
				$maxoption=0;
				
				for($i=0;$i<count($result_quiz_answer);$i++)	
				{
					$xx=json_decode($result_quiz_answer[$i][0]);
					
					for($j=0;$j<count($xx);$j++){
					
						$given_answer=explode(',',$xx[$j]);
						
						for($k=0;$k<count($given_answer);$k++){
							if($given_answer[$k]!=0)
							array_push($countoption,$given_answer[$k]);
						} 
					}
					
				} 

				$choosedoption=array_count_values($countoption);
				$keyvalue=array_keys($choosedoption);


				$query = 'select id from #__vquiz_question where  quizid = '.$this->_db->quote($quizid); 
				$this->_db->setQuery( $query );
				$loadcolumn = $this->_db->loadColumn();
				
				$query = 'select count(qid) from #__vquiz_option where qid in ('.implode(',', $loadcolumn).') group by qid' ;
				$this->_db->setQuery( $query );
				$maxid = $this->_db->loadColumn();	
				
				for($ck=0;$ck<count($maxid);$ck++){
					$xx=$maxid[$ck];
					$maxoption=$xx>$maxoption?$xx:$maxoption;
				}
    
				$query = 'select id,qtitle from #__vquiz_question where  quizid = '.$this->_db->quote($quizid).' order by id asc'; 
				$this->_db->setQuery( $query );
				$questions = $this->_db->loadObjectList();

				$arr = array();
				$qu=array('Question');
				$xx=array();
				for($h=0;$h<$maxoption;$h++){
					array_push($xx,chr(65+$h));	
				}
						
				$merg=array_merge($qu,$xx);
				array_push($arr,$merg);
			
							
			   for($k=0;$k<count($questions);$k++){
					
				$query = 'select id from #__vquiz_option where qid = '.$this->_db->quote($questions[$k]->id).' order by id asc';
				$this->_db->setQuery( $query );
				$options= $this->_db->loadColumn();
				 					
				$oo=array();
					
					for($q=0;$q<$maxoption;$q++){
		
						if (@in_array($options[$q],$keyvalue)) {
							foreach ($choosedoption as $key => $value){
							if($key==$options[$q])	
							array_push($oo,$value);
							}
						}
						else{
							array_push($oo,0);
						}
					}
					
				$ques=array(strip_tags($questions[$k]->qtitle));
				$x[$k]=array_merge($ques,$oo);
				array_push($arr,$x[$k]);
								
				}
 
				$obj->responce2=$arr;	
				$obj->result = "success";

			return $obj;
		} 
				
			function getModeration(){

				$query = 'select users_moderation from #__vquiz_configuration';
				$this->_db->setQuery( $query );
				$moderation =$this->_db->loadResult();

				return $moderation;
				
			}		
			
			function getConfiguration()
			{
				$query='select * from #__vquiz_configuration';
				$this->_db->setQuery($query);
				$result = $this->_db->loadObject();
				return $result;
			}	
			
			function getScore_category(){
				$query='select * from #__vquiz_quiz_score_category where quizid='.$this->_id;
				$this->_db->setQuery($query);
				$result = $this->_db->loadObjectList();
				return $result;
			}
			
			function getpersonality_category(){
			$query='select * from #__vquiz_quiz_personality_category where quizid='.$this->_id;
			$this->_db->setQuery($query);
			$result = $this->_db->loadObject();
			return $result;
			}
			
			function getp_c_personality_view(){
				$quizid=JRequest::getInt('id',0);
				$query='select * from #__vquiz_quiz_personality_category where quizid='.$quizid;
				$this->_db->setQuery($query);
				$result = $this->_db->loadObject();
				return $result;
			}	
		
		
		function getMenuItems(){
		
			$db = $this->getDbo();
			$query = $db->getQuery(true);
			$user = JFactory::getUser();
			$app = JFactory::getApplication();
		
			$query->select('id,menutype,title');
			$query->from($db->quoteName('#__menu'));
			$query->where('id > 1')
			->where('client_id = 0');
			$query->where('(published IN (1))');
			
			$parentId = $this->getState('filter.parent_id');

			if (!empty($parentId))
			{
				$query->where('id = ' . (int) $parentId);
			}

			// Filter the items over the menu id if set.
			$menuType = $this->getState('filter.menutype');

			if (!empty($menuType))
			{
				$query->where('menutype = ' . $db->quote($menuType));
			}

			// Filter on the access level.
			if ($access = $this->getState('filter.access'))
			{
				$query->where('access = ' . (int) $access);
			}

			// Implement View Level Access
			if (!$user->authorise('core.admin'))
			{
				$groups = implode(',', $user->getAuthorisedViewLevels());
				$query->where('access IN (' . $groups . ')');
			}

			// Filter on the level.
			if ($level = $this->getState('filter.level'))
			{
				$query->where('level <= ' . (int) $level);
			}

			// Filter on the language.
			if ($language = $this->getState('filter.language'))
			{
				$query->where('language = ' . $db->quote($language));
			}
		
			$db->setQuery($query);
			$result = $db->loadObjectList();			
			return $result;
		}	
		
		function getQuestion_options(){
		
			$question_id=JRequest::getInt('question_id',0);
			$ruleid=JRequest::getInt('ruleid',0);
			$obj = new stdClass();
			$obj->result = "error";	
			
			if($question_id){
			
				$query ='select id,qoption from #__vquiz_option where qid='.$this->_db->quote($question_id);
				$this->_db->setQuery( $query );
				$question_option=$this->_db->loadObjectList();
 
				
				$query=$this->_db->getQuery(true);
				$query->select('rule_optionid');
				$query->from('#__vquiz_quizzes_branching');
				$query->where('rule_questionid='.$this->_db->quote($question_id));
				$query->where('ruleid='.$this->_db->quote($ruleid));
				$query->order(' id desc ');
				$this->_db->setQuery($query);
				$rule_optionid=$this->_db->loadResult();
 
				$html   = '<select name="option_select_rule" id="option_select_rule">';
				for($i=0;$i<count($question_option);$i++){
					if($rule_optionid==$question_option[$i]->id)
						$selected='selected="selected"';
					else
						$selected='';
					$html   .= '<option value="'.$question_option[$i]->id.'" '.$selected.'>'.$question_option[$i]->qoption.'</option>';
					
				}
				$html   .= '</select>';
								
				$obj->question_id=$html;
				$obj->result = "success";

			}
			
			return $obj;
			
		}
		
		function getQuestion_weight(){
		
			$quizid=JRequest::getInt('quizid',0);
			$ruleid=JRequest::getInt('ruleid',0);
			
			$obj = new stdClass();
			$obj->result = "error";	
			
			if($quizid){
			
				$query ='select DISTINCT(score) from #__vquiz_question where quizid='.$this->_db->quote($quizid).' order by score desc';
				$this->_db->setQuery( $query );
				$question_weight=$this->_db->loadObjectList();
				
				$query=$this->_db->getQuery(true);
				$query->select('rule_scorepercentile');
				$query->from('#__vquiz_quizzes_branching');
				$query->where('ruleid='.$this->_db->quote($ruleid));
				$this->_db->setQuery($query);
				$rule_scorepercentile=$this->_db->loadResult();
				 
				$html   = '<select name="score_percentile" id="score_percentile">';
				$html   .= '<option value="0">'.JText::_('COM_VQUIZ_ALL_QUESTION').'</option>';
				for($i=0;$i<count($question_weight);$i++){
					if($rule_scorepercentile==$question_weight[$i]->score)
						$selected='selected="selected"';
					else
						$selected='';
					
					$html   .= '<option value="'.$question_weight[$i]->score.'" '.$selected.'>with '.$question_weight[$i]->score.' weight Upto Question</option>';
					
				}
				$html   .= '</select>';
				
				$obj->question_weights =$html;
				
				$obj->result = "success";

			}
			
			return $obj;
			
		}
		
		  function getQuestion_weight_apply(){
		
			$quizid=JRequest::getInt('quizid',0);
			$applyid=JRequest::getInt('applyid',0);
			$apply_weight=JRequest::getInt('apply_weight',0);
			
			$obj = new stdClass();
			$obj->result = "error";	
			
			if($quizid){
			
				$query ='select DISTINCT(score) from #__vquiz_question where quizid='.$this->_db->quote($quizid).' order by score desc';
				$this->_db->setQuery( $query );
				$question_weight=$this->_db->loadObjectList();
				
				$html   = '<select name="apply_weight" id="apply_weight" style="width:120px;">';
				$html   .= '<option value="0">'.JText::_('COM_VQUIZ_SELECT').'</option>';
				for($i=0;$i<count($question_weight);$i++){
					if($apply_weight==$question_weight[$i]->score)
						$selected='selected="selected"';
					else
						$selected='';
					
					$html   .= '<option value="'.$question_weight[$i]->score.'" '.$selected.'>Weight '.$question_weight[$i]->score.'</option>';
					
				}
				$html   .= '</select>';
				
				$obj->question_weights =$html;
				
				$obj->result = "success";

			}
			
			return $obj;
			
		}
		
		function getBranching_rule(){

			$query ='select * from #__vquiz_quizzes_branching where quizid='.$this->_db->quote($this->_id);
			$this->_db->setQuery( $query );
			$branching_result=$this->_db->loadObjectList();
			return $branching_result;
			
		}
		
		function getMonitorquizzes(){
			
			$userid=JFactory::getUser()->id;
			$query='SELECT quizid FROM #__vquiz_monitor_quiz where userid='.$userid;
			$this->_db->setQuery( $query );
			$monitor_quiz= $this->_db->loadColumn();
			return $monitor_quiz;
		}
		function getMonitorcategory(){
			
			$userid=JFactory::getUser()->id;
			$query='SELECT catid FROM #__vquiz_monitor_category where userid='.$userid;
			$this->_db->setQuery( $query );
			$monitor_category= $this->_db->loadColumn();
			return $monitor_category;
		}
		
		function getQuestiongroup(){
			
			$query=$this->_db->getQuery(true);
			$query->select('*');
			$query->from('#__vquiz_quizzes_questiongroup');
			$query->where('quizid='.$this->_db->quote($this->_id));
			$query->order('id asc');
			$this->_db->setQuery($query);
			$result=$this->_db->loadObjectList();

			return $result;
		}
			
		function getCountQuestion(){
		if($this->_id!=0){		
		
			//$query=" select count(quizzesid)  FROM #__vquiz_question WHERE quizzesid = ".$this->_id;
			
			$query = $this->_db->getQuery(true);
			$query->select('count(questionid)');
			$query->from($this->_db->quoteName('#__vquiz_quiznques'));
			$query->where('quizid ='.$this->_db->quote($this->_id));
			$this->_db->setQuery( $query );
			$total_Question = $this->_db->loadResult();
			
		}else{
			$total_Question=0;
		}
		return $total_Question;
	}
	
		function getSkills(){
		
			$obj = new stdClass();
			if($this->_id){
				$query=$this->_db->getQuery(true);
				$query->select('skillid');
				$query->from($this->_db->quoteName('#__vquiz_quizns'));
				$query->where('quizid ='.$this->_db->quote($this->_id));
				$this->_db->setQuery($query);
				$selectedid=$this->_db->loadColumn();
			}else{
				$selectedid=array();
			}
			$obj->selectedid=$selectedid;
			
			$query=$this->_db->getQuery(true);
			$query->select('id,title');
			$query->from($this->_db->quoteName('#__vquiz_skills'));
			$query->where('published = 1');
			$this->_db->setQuery($query);
			$obj->skillid=$this->_db->loadObjectList();
			return $obj;
		} 
			
 }