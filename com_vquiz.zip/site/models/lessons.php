<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');

class VquizModelLessons extends JModelList
{

		function __construct()
		{
			parent::__construct();
			$mainframe = JFactory::getApplication();
			
			$context	= 'com_vquiz.lessons.list.';
			// Get pagination request variables
			$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
			$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
			
			// In case limit has been changed, adjust it
			$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
			
			$this->setState('limit', $limit);
			$this->setState('limitstart', $limitstart);
			
			$array = JRequest::getVar('cid',  0, '', 'array');
			$this->setId((int)$array[0]);
		}

		function _buildQuery()
		{
		 
		 $query="SELECT i.* FROM #__vquiz_lessons as i";
		 return $query;
	 
		}
 
		function setId($id)
		{
			$this->_id		= $id;
			$this->_data	= null;
		}

 
		function &getItem()
		{
			
			$mainframe =JFactory::getApplication();
			$id = JRequest::getVar( 'id' );	
			$query = 'select i.* FROM #__vquiz_lessons as i where i.id ='. $id;
			$this->_db->setQuery( $query );
			$item = $this->_db->loadObject();
		
			if(empty($item)) {
				$item = new stdClass();
				$item->id = 0;
				$item->title = null;
				$item->catid= null; 
				$item->desc = null;
				$item->type = null;
				$item->files = null;
				$item->access =null ;
				$item->published =null ;
				$item->language =null;
				$item->ordering =null;
			}
			return $item;
		}

 
		function &getItems()
		{
			// Lets load the data if it doesn't already exist
			if (empty( $this->_data ))
			{
				 $query = $this->_buildQuery();
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();
				 
				  $query .= $filter;
				 $query .= $orderby;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			}
	
			return $this->_data;
		}

		function getTotal()
		{

		  if (empty($this->_total)) {

			$query = $this->_buildQuery();
			$query .= $this->_buildContentFilter();
			$this->_total = $this->_getListCount($query);    
			}
		   return $this->_total;
		}
 

	 function _buildItemOrderBy(){
		$mainframe = JFactory::getApplication();
		
		$context	= 'com_vquiz.lessons.list.';
 
		$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
		$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
 
		$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
 
		return $orderby;
	}



	function getPagination()
	{

		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit'));
		}
		return $this->_pagination;
	}
 
    function _buildContentFilter()
	{
		
		$app = JFactory::getApplication();
		$lessiontype=$app->input->get('lessiontype',0);
		$context='com_vquiz.lessons.list.';
		$where = array();
		
		if($lessiontype){
			$where[]='i.catid='.$this->_db->quote($lessiontype);	
		}
		
		$where[]='i.published=1';
		$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
		return $filter;
	}
 
	function getConfiguration()
	{
		$query='select * from #__vquiz_configuration';
		$this->_db->setQuery($query);
		$result = $this->_db->loadObject();
		return $result;
	}
	
	function getLearningnextlevel()
	{
		$app=JFactory::getApplication();
		$learningId = $app->input->get('learningId',0);
		$id = $app->input->get('id',0);
	
		$query  ='  select quizid from #__vquiz_learning_lnq';
		$query .= ' where learningid ='.$learningId;
		$query .= ' ORDER BY id asc';
		$this->_db->setQuery( $query);		
		$quizzes_order = $this->_db->loadColumn();
		
		$query  ='  select lessionid from #__vquiz_learning_lnq';
		$query .= ' where learningid ='.$learningId;
		$query .= ' ORDER BY id asc';
		$this->_db->setQuery( $query);		
		$lessons_order = $this->_db->loadColumn();
		
		$lessonId=0;
		$learningquizId=0;
		$lessonIndex=array_search($id,$lessons_order);
		$lessoncheckId = isset($lessons_order[$lessonIndex+1])?$lessons_order[$lessonIndex+1]:-1;
		if($lessoncheckId == 0){
			$learningquizId=$quizzes_order[$lessonIndex+1];
		}else if($lessoncheckId !=-1){
			$lessonId=$lessons_order[$lessonIndex+1];
		}
		$obj=new stdClass();
		$obj->lessonId=$lessonId;
		$obj->learningquizId=$learningquizId;
		$obj->learningId=$learningId;

		return $obj;

	}		
	function getVideoDetail(){		
	
	$user = JFactory::getUser();				
	$app=JFactory::getApplication();		
	$learningId = $app->input->get('learningId',0);		
	$lession_id = $app->input->get('id',0);		
	//print_r($app->input);exit;
	$query  ='  select * from #__vquiz_learning_result';		
	$query .= ' where learning_id ='.$learningId.' AND lession_id='.$lession_id.' AND userid='.$user->id;		
	
	$this->_db->setQuery( $query);				
	$result = $this->_db->loadObject();
			
	return $result;	
	}
	
	function setvideoinfo()	{ 			
		$user = JFactory::getUser();			
			
		$app = JFactory::getApplication();		
		
		$time = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();				
		$obj = new stdClass();		
		//$obj->result = "error";				
		$learning_rs_id = $app->input->get('learning_rs_id',0); 		
		$learning_id = $app->input->get('learning_id',0);		
		$lession_id = $app->input->get('lession_id',0);				
		$userid = $user->id;				
		$curpos = $app->input->get('curpos',0);				
		$viewedpos = $app->input->get('viewedpos',0);		
		$completed = $app->input->get('completed',0); 				
		
		if($curpos>$viewedpos){						
			$max_viewed = $curpos;						
			if(($learning_id!=0) && ($lession_id!=0) && ($userid!=0)){
				
				if($learning_rs_id!=0){													
					$query = 'update #__vquiz_learning_result set video_seen='.$this->_db->quote($max_viewed).', completed='.$this->_db->quote($completed).' where id='.$this->_db->quote($learning_rs_id);				
					$this->_db->setQuery( $query);				
					$this->_db->execute();												
				}else{
					$query  =" Insert into #__vquiz_learning_result set learning_id = $learning_id, lession_id = $lession_id, userid = $userid, created='$time', video_seen='$max_viewed', completed=$completed";					
					$this->_db->setQuery($query);					
					$this->_db->execute();					
					$last_id=$this->_db->insertid(); 										
					$obj->learning_rs_id = $last_id;				
				}
			
			}				
		}else{			
		$max_viewed = $viewedpos;		
		}				
					
		$obj->video_seen = $max_viewed;				
		jexit(json_encode($obj));					
	}
		
	function getLessonViewedStatus(){		
	
		$user = JFactory::getUser();				
		$app=JFactory::getApplication();		
		$learningId = JRequest::getInt('learningId',0); 
			
		
		$query  ='  select count(id) as lesson_viewed from #__vquiz_learning_result';		
		$query .= ' where learning_id ='.$learningId.' AND lession_id <> 0 AND completed=1 AND userid='.$user->id;	$this->_db->setQuery( $query);				
		
		$result = $this->_db->loadObject();
		$lesson_viewed = $result->lesson_viewed;
		
		$query  ='  select count(id) as total_lessons from #__vquiz_learning_lnq';		
		$query .= ' where learningid ='.$learningId.' AND lessionid <> 0 ';
		$this->_db->setQuery( $query);				
		
		$result = $this->_db->loadObject(); //var_dump($result);
		$total_lessons = $result->total_lessons;
		
		if($lesson_viewed==$total_lessons){
			return 1;
		}else{
		return 0;	
		}
	}

						
 }