<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

//jimport( 'joomla.application.component.model' );


class VquizModelWidget extends JModelLegacy
{
	function _data($query)
	{
		try{
				$this->_db->setQuery($query);//alwas use $this->_db in model
				$data= $this->_db->loadObject();
				
		}
		catch (Exception $e)
		{
			throw new Exception($e->getMessage());
		}
		return $data;
	}
	
    function getQuizuser()
	{ 		
			jimport('joomla.application.module.helper');
			//$data= new stdclass();
			$moduleHtml=array();
			$app = JFactory::getApplication();
			$currentMenuId = @JSite::getMenu()->getActive()->id;
			$menuitem   = $app->getMenu()->getItem($currentMenuId);			//print_r($menuitem);exit;
			$params = $menuitem->params;
			$layout=$params['layout'];
			//$data->layout=$layout;
			$modules = &JModuleHelper::getModules($layout);
			
			$parameter=array();
			foreach($modules as $mod)
			{				
				
				$params=json_decode($mod->params,true);
				foreach($params as $key=>$value)
				{	
					array_push($parameter,$key."=".$value);
				}
				$module = JModuleHelper::getModule($mod->module,$mod->title);
				$module->params = implode("\n", $parameter);
				 $html = JModuleHelper::renderModule($module);
				 array_push($moduleHtml, $html);
			}
			
			return $moduleHtml;
				}
				
}
?>





	<?php			
				/* if($module=='mod_vquiz_user')
				{
						
						$module = JModuleHelper::getModule($module,$title);
						
						$mP = array();
						if(empty($params['numberofuser']))
							{
								$params['numberofuser']=5;
							} 
						$mP[] = "quizzesid=".$params['quizzesid'];
						$mP[] = "autodetect=".$params['autodetect'];
						$mP[] = "ordering=".$params['ordering'];
						$mP[] = "score=".$params['score'];
						$mP[] = "quizname=".$params['quizname'];
						$mP[] = "showlink=".$params['showlink'];
						$mP[] = "completedtime=".$params['completedtime'];
						$mP[] = "limit=".$params['numberofuser'];       correct in module   done
						$mP[] = "userpic=".$params['userpic'];
						$mP[] = "mostactive=".$params['mostactive'];
						$mP[] = "cid=".$params['cid'];
						$mP[] = "sid=".$params['sid'];
						$mP[] = "timeopts=".$params['timeopts'];
							 print_r ($mP);
						$module->params = implode("\n", $mP);
						
				}
				if($module=='mod_vquiz_users_slider')
				{
						$module = JModuleHelper::getModule($module,$title);
						//print_r ($module);exit;
						$mP = array();
						if(empty($params['numberofuser']))
							{
								$params['numberofuser']=5;
							} 
						$mP[] = "score=".$params['score'];
						$mP[] = "quizname=".$params['quizname'];
						$mP[] = "showlink=".$params['showlink'];
						$mP[] = "completedtime=".$params['completedtime'];
						
						$mP[] = "limit=".$params['numberofuser'];          correct in module  done
						$mP[] = "ordering=".$params['ordering'];
						
						$mP[] = "autodetect=".$params['autodetect'];
						$mP[] = "readmore=".$params['readmore'];
						$mP[] = "slidewidth=".$params['width'];     		correct in module
						$mP[] = "adaptiveheight=".$params['adaptiveheight'];
						$mP[] = "responsive=".$params['responsive'];
						$mP[] = "keyboard=".$params['keyboard'];
						$mP[] = "num_carousel_slide=".$params['num_carousel'];		correct in module
						$mP[] = "slides_move=".$params['moveslides'];				correct in module
						$mP[] = "controls=".$params['controls'];  
						
						$mP[] = "autodirection=".$params['autodirection'];
						
						$mP[] = "auto=".$params['auto'];
						$mP[] = "mode=".$params['mode'];
						$mP[] = "speed=".$params['speed'];
						$mP[] = "pause=".$params['pause'];
						$mP[] = "slide_margin=".$params['slidemargin'];   correct in module
						$mP[] = "randomstart=".$params['randomstart'];
						$mP[] = "infiniteloop=".$params['infiniteloop'];
						$mP[] = "hidecontrolonend=".$params['hidecontrolonend'];
						$mP[] = "touchenabled=".$params['touchenabled'];
						$mP[] = "loadjquery=".$params['loadjquery'];
						$mP[] = "pager=".$params['pager'];
						$mP[] = "pagertype=".$params['pagertype'];
						print_r ($mP);
						$module->params = implode("\n", $mP);
						//$moduleHtml = JModuleHelper::renderModule($module); 
						//print_r ($moduleHtml);exit;
				}
				$moduleHtml .= JModuleHelper::renderModule($module);  
				 
			}
			//print_r ($moduleHtml);exit;
			return $moduleHtml; */
	

?>