<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );

class VquizModelUseradmin extends JModelLegacy
{
    
    var $_total = null;
	var $_pagination = null;
	
	function __construct()
	{
		parent::__construct();
 
        $mainframe = JFactory::getApplication();
		
		$context			= 'com_vquiz.users.list.'; 
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);

		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}
	
	function _buildQuery()
	{
		$query = 'select i.* FROM #__users as i';

		return $query;
	}
	
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}
	
	function getItem()
    {
		$uid = JFactory::getUser()->id;
		
		$query = ' SELECT c.*, i.id, i.name, i.email, i.username,  i.block FROM #__vquiz_users as c right join #__users as i on c.userid = i.id WHERE i.id = '.$uid;
		
		$this->_db->setQuery( $query );
		$item = $this->_db->loadObject();
		echo $this->_db->getErrorMsg();
		
		if(empty($item))	{
			 
			$item->id = 0;
			$item->profile_pic = null;
			$item->email = null;
			$item->username = null;
			$item->name = null;
			$item->block = null;
		}
				
		return $item;
    }
	
	function getItems()
    {
        if(empty($this->_data))	{
		
			$query = $this->_buildQuery();
 
			
			$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
		
		}
		echo $this->_db->getErrorMsg();
        return $this->_data;
    }
	
	function getTotal()
  	{
        // Load the content if it doesn't already exist
        if (empty($this->_total)) {
            $query = $this->_buildQuery();
            $this->_total = $this->_getListCount($query);     
        }
        return $this->_total;
  	}
	
	
	function getCategory()
				{
					$db = JFactory::getDbo();		
					$query = 'select id,title from #__vquiz_category WHERE published=1';
					$db->setQuery( $query );
					$result = $db->loadObjectList();
					
					return $result;
				}
				
				
				function getLinechart()
				{
					
				    $db = JFactory::getDbo();
					$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
					$type = JRequest::getVar('type', 'day');
					$category = JRequest::getInt('category', 0);
					$formate = JRequest::getVar('formate', '');
					 $user = JFactory::getUser();
                    
					$obj = new stdClass();
					$obj->result = "error";
                    $where=array();
 
					
					switch($type)
					{
					case 'day':
					$query = 'SELECT date_format(r.start_datetime, "%e, %b"),date_format(r.start_datetime, "%e, %b") as day';
 
					break;
					case 'week':
					$query = 'SELECT date_format(r.start_datetime, "%U, %Y"),date_format(r.start_datetime, "%U, %Y") as week';
					break;
					
					case 'month':
					$query = 'SELECT date_format(r.start_datetime, "%b"),date_format(r.start_datetime, "%b") as month';
					break;
					}
					
					
					$query .= ' ,count(r.userid) as users from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id ';
					
                    
                    
                   // $query .=' where q.created_by='.$user->id;
                   // if (!$user->authorise('core.edit', 'com_vquiz'))
	                 $where[] = ' q.created_by ='.$this->_db->Quote( $this->_db->escape($user->id, true ), false );
                    
                    
					if($category)
					{
					$where[]=' r.categoryid='.$category.'';
					}
                    
                    $filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
                    $query .=$filter;
					
					$query .= ' group by '.$type.' order by r.id asc';
					
					$this->_db->setQuery( $query );	
					$result=$this->_db->loadRowList(); 	
                    if($formate == 'listing_formate'){
						$this->_db->setQuery( $query );	
					    $result=$this->_db->loadObjectList(); 	
						$html = '';
						for($r=0;$r<count($result);$r++){
							if($r==0){
							$html .= '<thead><tr>';
							$h = 0;
							foreach($result[$r] as $key => $value)
							{
								if($h == 0){$h=1; continue;}
								$html .= '<td>'.$key.'</td>';
							}
							$html .= '</tr></thead>';	
							}
							else{
							$html .= '<tr>';
							$html .= '<td>'.$result[$r]->$type.'</td>';	
							$html .= '<td>'.$result[$r]->users.'</td>';
							$html .= '</tr>';
							}
							
						}
					$result	= $html;
					}
					$obj->playedquiz=$result;
 
					
					$obj->result = "success";
 
					return $obj;
				}
							
							
			function getpiechart()
				{
					
				    $db = JFactory::getDbo();
					$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
					$category = JRequest::getVar('category', 0);
					$quiz_type = JRequest::getVar('quiz_type', 0);
					$formate = JRequest::getVar('formate', '');
                    $user = JFactory::getUser();
					
					$obj = new stdClass();
					$obj->result = "error";
 					
                    $arr2=array();
                    $where = array();	

					
					$query = ' SELECT q.title as qtitle,q.id as quizid ,count(r.userid) as totaluser from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id ';
                
                    $where[] = 'q.created_by='.$user->id;
                    if (!$user->authorise('core.edit', 'com_content'))
	                  $where[] = ' q.created_by ='.$this->_db->Quote( $this->_db->escape($user->id, true ), false );
					 
					if($category)
					{
                         
                          $where[] = ' r.categoryid='.$category;
					}
					if($quiz_type)
					{
                       
                        $where[] = ' q.quiztype='.$quiz_type;
					}
    
                    //$filter = ' WHERE ' . implode(' AND ', $where);
                    $filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
                
                    $query .= $filter;
                 
					$query .= ' group by r.quizid order by r.id desc LIMIT 10';
					
					$this->_db->setQuery( $query );	
										
					$resulted=$this->_db->loadObjectList(); 
					
 
					for($i=0;$i<count($resulted);$i++){
						$arr=array();
						$x=$resulted[$i]->qtitle;
						$y=$resulted[$i]->totaluser;
						 
						$link=$resulted[$i]->quizid;
						array_push($arr,$x);
						array_push($arr,$link);
						array_push($arr,$y);
						array_push($arr2,$arr);
					}
					if($formate=='listing_formate'){
							
						$html = '';
						for($r=0;$r<count($resulted);$r++){
							if($r==0){
							$html .= '<thead><tr>';
						
							foreach($resulted[$r] as $key => $value)
							{
								
								$html .= '<td>'.$key.'</td>';
							}
							$html .= '</tr></thead>';	
							}
							else{
							$html .= '<tr>';
							$html .= '<td>'.$resulted[$r]->$type.'</td>';	
							$html .= '<td>'.$resulted[$r]->users.'</td>';
							$html .= '</tr>';
							}
							
						}
					$arr2	= $html;
					}
  								
					$obj->playedquiz=$arr2;				
					$obj->result = "success";
 
					return $obj;
				} 
				
				
				function getgeochart()
				{
					
                    $db = JFactory::getDbo();
                    $date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
                    $agegroup = JRequest::getInt('agegroup');
                 
                    $obj = new stdClass();
                    $obj->result = "error";
					
					$query = ' SELECT i.country,count(u.id) from #__vquiz_users as i left join #__users as u on i.userid=u.id ';
 					
					if($agegroup)
					{	
					$age=$agegroup+10;
					
					if($agegroup==60)
					$query .=' where TIMESTAMPDIFF(YEAR ,i.dob, NOW()) >='.$agegroup.'';
					else
					$query .=' where TIMESTAMPDIFF(YEAR ,i.dob, NOW()) >='.$agegroup.' and TIMESTAMPDIFF(YEAR ,i.dob, NOW()) <='.$age.'';
					
					}
					
					$query .= ' group by i.country order by  i.id desc ';
					
					$this->_db->setQuery( $query );	
					$result=$this->_db->loadRowList(); 					
					$obj->userinfo=$result;
 
					
					$obj->result = "success";
 
					return $obj;
				} 
				
				
				
			function getflagpiechart()
			{
				$db = JFactory::getDbo();
				$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));	
				$category = JRequest::getInt('category', 0);
                $user = JFactory::getUser();
				
				$obj = new stdClass();
				$obj->result = "error";
 
				

 				$arr2=array();
				//$query = ' SELECT quizid,qtitle,id,flagcount from #__vquiz_question where flagcount!=0  order by id asc LIMIT 10';				
                
                
                					
					$query = ' SELECT q.created_by, qu.quizid,qu.qtitle,qu.id,qu.flagcount from #__vquiz_question as qu left join #__vquiz_quizzes as q on q.id=qu.quizid';
                
                    $where[] = ' qu.flagcount!=0';

                if (!$user->authorise('core.edit', 'com_content'))
                    $where[] = ' q.created_by ='.$this->_db->Quote( $this->_db->escape($user->id, true ), false );

                $filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
                
                $query .=$filter;
                
                $query .=' order by qu.id asc LIMIT 10';
                                
                
				$this->_db->setQuery( $query );	
				$result=$this->_db->loadObjectList(); 
					
				
					for($i=0;$i<count($result);$i++){
					$arr=array();
					$x=strip_tags($result[$i]->qtitle);
					$id=$result[$i]->id;
					$y=$result[$i]->flagcount;
					$quizid=$result[$i]->quizid;
					array_push($arr,substr($x,0,100));
					array_push($arr,$id);
					array_push($arr,$y);
					array_push($arr,$quizid);
					array_push($arr2,$arr);
					}

				$obj->flagquestion=$arr2;

				
				$obj->result = "success";

				return $obj;
			}
	
		function getConfiguration()
		{
			$query='select * from #__vquiz_configuration';
			$this->_db->setQuery($query);
			$result = $this->_db->loadObject();
			return $result;
		}
	    function getProfile($profile_id){
		$data = array();
		if($profile_id!='')
		{
			$query = 'select * from #__vquiz_widget where id="'.$profile_id.'" order by ordering';
			$this->_db->setQuery($query);
			$data = $this->_db->loadObject();
		}
		return $data;
	}
	function getProfiles()
	{ 
		
		$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
		$user = JFactory::getUser();
		
		$query='select * from `#__vquiz_widget` where site in (1,2) order by ordering';
		$this->_db->setQuery($query);
		$widget = $this->_db->loadObjectList(); 
 		return $widget;
	}
	function getTotalQuiz()
	{
		
		$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
		$user = JFactory::getUser();
		if($user->id>0)
		{
		$query='select * from `#__vquiz_quizzes` as `q` where `q`.`created_by`='.$user->id;
		$this->_db->setQuery($query);
		$total_quiz = $this->_db->loadObjectList();
		if(count($this->_db->loadObjectList())>0)
			 return count($this->_db->loadObjectList());	
		   else
			 return 0;	  
		}
        else
         return 0;			
		
	}
}

?>