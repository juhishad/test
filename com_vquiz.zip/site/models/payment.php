<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
class VquizModelPayment extends JModelList
{   
	var $_list;
    var $_data = null;
	var $_total = null;
	var $_pagination = null;
	function __construct()
	{
		parent::__construct();
        $mainframe = JFactory::getApplication();

		
		$context	= 'com_vquiz.payment.list.';
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart); 
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);

	}
    function paymentDetail($payment_id = null){
		 $payment_row =  $this->getTable('Payment', 'VquizTable');
		
		if($payment_id){
			     $payment_row->load($payment_id);
				 $payment_row->main_params= json_decode( $payment_row->main_params); 
				 $payment_row->extra_params= json_decode( $payment_row->extra_params);  
		}
			  
		
		 return $payment_row;
	}
 	function _buildQuery()
	{
	    
		 $query="SELECT i.* from `#__vquiz_payment_plugin` as `i`";
		
		 return $query;

	}

	function setId($id)
	{
		$this->_id		= $id;
		$this->_data	= null;
	}

	function &getItem()

	{

		if (empty( $this->_data )) {
			$query = 'SELECT i.* from `#__vquiz_payment_plugin` as `i`'.
					'  WHERE `i`.`id` = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();


		}

		if (!$this->_data) {
			    $this->_data = new stdClass();
			    $this->_data->id = 0;
				$this->_data->plugin_extension_id = null;
 				$this->_data->title= null; 
 			    $this->_data->name= null; 
 				$this->_data->alias= null;
				$this->_data->type= null; 
				$this->_data->description= null; 
 				$this->_data->main_params= null; 
				$this->_data->extra_params= null; 
 				$this->_data->plan_id= null; 
 				$this->_data->ordering= null;
				$this->_data->published= null;
 				
				}
				
				if(!empty($this->_data)){
				 $this->_data->main_params= json_decode( $this->_data->main_params); 
				 $this->_data->extra_params= json_decode( $this->_data->extra_params);   
				}
 
		return $this->_data;

	}	
 }