<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.modellist');
class VquizModelVquiz extends JModelList
{
    var $_total = null;
	var $_pagination = null;
	protected $params = null;
	
	function __construct()
	{
		parent::__construct();		
		$db =JFactory::getDBO();
        $mainframe = JFactory::getApplication();
 
 		$app = JFactory::getApplication('site');
		$this->params = $app->getParams();
		$this->setState('params', $this->params);
		
		$context	= 'com_vquiz.vquiz.list.';
		// Get pagination request variables
		$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		//$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
	
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
	}
	
	function _buildQuery()
	{		

		$app = JFactory::getApplication();
		//$modulorder = JRequest::getInt('modulorder',0);	
		$modulorder=$this->params->get('modulorder');
		$listtype=$app->input->get('listtype',0);
		$parent_id=$app->input->get('id',0);
 
		$query ='select i.*,count(q.catid) as totalquizzes';
		/*-- most Played quizzes-- */
		if($modulorder==2)	
			$query .= ', count(r.id) as items';
	 
		$query .= ' from #__vquiz_category as i left join #__vquiz_quizzes as q on i.id=q.catid';
		
		if($listtype==1){	
			$query .= ' right join #__vquiz_lessons as l on l.catid=i.id';
		}
		

		
		if($modulorder==2)	{
			$query .=' left join #__vquiz_quizresult as r ON r.quizid=q.id';	
		}
		/*-- recent Played quizzes --*/
		elseif($modulorder==3)	{
			$query .=' left join ( select max(id) as id, quizid from #__vquiz_quizresult group by quizid) as r ON r.quizid=q.id';
		}
			
		return $query;	
	}
	
	function _buildFilter()
	{
			$user = JFactory::getUser();
			$app = JFactory::getApplication();
			$lang = JFactory::getLanguage();
			$parent_id=$app->input->get('id',0);
			$listtype=$app->input->get('listtype',0);
			$lessons_type=$this->params->get('lessons_type');
			$quiz_type=$this->params->get('qtype');
			$modulorder=$this->params->get('modulorder');
			$subcategory_lavel=$this->params->get('subcategory_lavel');
			$lesson_subcategory_lavel=$this->params->get('lesson_subcategory_lavel');
 
		    $where = array();
			
			$where[] = ' i.published =1';
			if($parent_id){
				$parent_id_array=array($parent_id);
				$Children=$this->GetCategoriesWithChildren($parent_id_array);

				if($listtype==1 and $lesson_subcategory_lavel){
					if(count($Children)>$lesson_subcategory_lavel)
					$Children=array_slice($Children,0,$lesson_subcategory_lavel);
				}else{
					if(count($Children)>$subcategory_lavel)
					$Children=array_slice($Children,0,$subcategory_lavel);
				}

				$where[] = ' i.id in ('.implode(',',$Children).')';
				
			}else{
				 //$where[] = ' i.parent_id=1';
			}
			 			
			$where[] = ' i.access in ('.implode(',', $user->getAuthorisedViewLevels()).')';
			if($app->getLanguageFilter())	{
				$where[] = ' i.language in ('.$this->_db->quote($lang->getTag()).', '.$this->_db->Quote('*').')';
			}
			
			if($quiz_type)
			{
				$where[] ='q.quiztype='.$quiz_type;
			}
	
			if($listtype==1 and $lessons_type!='all'){	
				$where[] = ' l.type = '.$this->_db->quote($lessons_type);
			}
			
			$filter = ' where ' . implode(' and ', $where);
			
			return $filter;
		
	}
	
	function _buildOrderBy()
	{
		//$modulorder = JRequest::getInt('modulorder',0);
		$modulorder=$this->params->get('modulorder');
 
		//latest playes Quizzes
		if($modulorder==1)	{
			$orderby = ' group by q.catid order by q.created desc';
		}
		//most Played quizzes
		elseif($modulorder==2)	{
			$orderby = ' group by q.catid order by items desc';
		}
		//recent Played quizzes
		elseif($modulorder==3)	{
			$orderby = ' group by q.catid order by r.id desc';
		}
		//random played quizzes
		elseif($modulorder==4)	{
			$orderby = ' group by q.catid ORDER BY RAND()';
		}
		else
		{
			$orderby = ' group by q.catid order by i.ordering desc';
		}

			//$orderby ='	group by q.catid order by ordering asc';
		return $orderby;
	}
	
	  function getTotal(){
		 
			if (empty($this->_total)) {
				$query = $this->_buildQuery();
				$query .= $this->_buildFilter();
				$query .= $this->_buildOrderBy();
				
				$this->_total = $this->_getListCount($query);       
			}
			return $this->_total;
		}
	
		  function getPagination(){
				// Load the content if it doesn't already exist
				if (empty($this->_pagination)) {
					jimport('joomla.html.pagination');
					$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
				}
				return $this->_pagination;
			}
	
		function getQuizcategory()
		{
			if (empty($this->_data)) {
				$query = $this->_buildQuery();
				$query .= $this->_buildFilter();
				$query .= $this->_buildOrderBy();
				$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));    
			}
			return $this->_data;
			
		}
		
 		
		function getConfiguration()
		{
			$query='select * from #__vquiz_configuration';
			$this->_db->setQuery($query);
			$result = $this->_db->loadObject();
			return $result;
		}
					
						
		function child_category()
		{
				
			$parentid = JRequest::getInt('parentid');
			$itemid = JRequest::getInt('itemid',0);
			$parent_id_array=array($itemid);
			$Children=$this->GetCategoriesWithChildren($parent_id_array);
			
			$query ='select a.id , a.title, a.level ';
			$query .=' from #__vquiz_category As a ';
			$query .=' LEFT join #__vquiz_category AS b ON a.lft > b.lft AND a.rgt < b.rgt';
			
			$where = array();
			$where[] = 'a.id !=1';
			$where[] = 'a.id in ('.implode(',',$Children).')';
			$where[] = 'a.id !='.$itemid;
			$where[] = 'a.published=1';
			$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
			$query .= $filter;
			$query .=' group by a.id, a.title, a.level, a.lft, a.rgt, a.parent_id order by a.lft ASC';
	 

			$this->_db->setQuery($query);
			$result=$this->_db->loadObjectList();
			
			return $result;
		}
		
		public function GetCategoriesWithChildren($categories) {
		   $results = array();
		   foreach ($categories as $baseCategory)
		   {
			  $query = $this->_db->getQuery(true);
			  $query->select('c.path');
			  $query->from('#__vquiz_category AS c');
			  $query->where('c.published > 0');
			  $query->where('c.id = ' . $baseCategory);
			  $this->_db->setQuery($query);
			  $fathersList = $this->_db->loadObjectList();
			
			  foreach ($fathersList as $father)
			  {
				 $results[] = $baseCategory; // This adds the father only if it is published
				 $query = $this->_db->getQuery(true);
				 $query->select('c.id');
				 $query->from('#__vquiz_category AS c');
				 $query->where('c.published > 0');
				 $query->where('c.path LIKE \'' . $father->path . '/%\'');
				 $this->_db->setQuery($query);
				 $children = $this->_db->loadObjectList();
				 foreach ($children as $category)
				 {
					$results[] = $category->id;
				 }
			  }
		   }
		   return $results;
		}
			
		
	
}
 