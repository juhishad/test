<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
class VquizModelOrders extends JModelList
{   
		protected $coupon_code;
		protected $buyer_id;
		protected $app_id;
		protected $currency;
		protected $status;
		protected $subtotal;
		protected $total;
		protected $gateway_txn_id;
		protected $gatewaway_parent_txn;
		protected $subscr_id;
		protected $created_date;
		protected $modified_date;
		protected $params;
	static $instance = array();
	function __construct()
	{
		parent::__construct();
        $mainframe = JFactory::getApplication();

		
		$context	= 'com_vquiz.orders.list.';
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		
		$filter_language = $mainframe->getUserStateFromRequest( $context.'filter_language',	'filter_language',	'' );
		$this->subscr_id = $mainframe->getUserStateFromRequest( $context.'subscr_id', 'subscr_id', 0, 'int' ); 
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart); 
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);

	}
    function updateOrders($order_id = null){
		 $orders_row =  $this->getTable('Orders', 'Table');
		
		if($order_id)
			 $orders_row->load($order_id); 
		
		 return $orders_row;
	}
 	function _buildQuery()
	{
	    
		 $query="SELECT i.*, `s`.`id` as `sid`  from `#__vquiz_plans_order` as `i` left join `#__vquiz_plans_subscription` as `s` on `i`.`subscr_id`=`s`.`id` left join `#__vquiz_plans` as `p` on `p`.`id`= `s`.`plan_id`";
		
		 return $query;

	}

	function setId($id)
	{
		$this->_order_id		= $id;
		$this->_data	= null;
	}

	function &getItem()

	{

		if (empty( $this->_data )) {
			$query = 'SELECT i.* from `#__vquiz_plans_order` as `i`'.
					'  WHERE `i`.`order_id` = '.$this->_order_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();


		}

		if (!$this->_data) {
			$this->_data = new stdClass();
			    $this->_data->order_id = 0;
 				$this->_data->app_id = 1;
				$this->_data->buyer_id = null;
 				$this->_data->coupon_code= null; 
 			    $this->_data->status= null; 
 				$this->_data->currency= null;
				$this->_data->subtotal= null; 
				$this->_data->tax= null; 
 				$this->_data->total= null; 
				$this->_data->gateway_txn_id= null; 
 				$this->_data->gatewaway_parent_txn= null; 
 				$this->_data->subscr_id= null;
				$this->_data->created_date= null;
 				$this->_data->modified_date= null;
				$this->_data->paid_date= '0000-00-00 00:00:00';
 				$this->_data->params= null;
				}
				
				if(!empty($this->subscr_id)){
				   $query = 'SELECT s.*, p.*, s.params as sub_params from `#__vquiz_plans_subscription` as `s` left join `#__vquiz_plans` as `p` on `p`.`id`= `s`.`plan_id`'.
					'  WHERE `s`.`id` = '.$this->subscr_id;
					$this->_db->setQuery( $query );
					$subscription_data = $this->_db->loadObject();
					$this->_data->title = $subscription_data->title;
					$this->_data->price = $subscription_data->total;
					$this->_data->expirationtype = $subscription_data->expirationtype;
					$this->_data->expiration = $subscription_data->expiration;
					$params = json_decode($subscription_data->sub_params);
					if(isset($params->order_id) && !empty($params->order_id)){
					$query = 'select * from `#__vquiz_plans_order` where `order_id`=(select (order_id) from `#__vquiz_plans_order` where `subscr_id`='.$this->_db->quote($this->subscr_id).' AND `order_id`='.$this->_db->quote($params->order_id).')';
					$this->_db->setQuery($query);
					$this->_db->Query($query);
		            if( $this->_db->getNumRows() > 0 ) { 
					$lastorder = $this->_db->loadObject(); 
					$this->_data->params = $lastorder->params;
					$this->_data->subtotal = $this->_data->subtotal;
					$this->_data->total = $this->_data->total;
					}
					else{
						$this->_data->params = $subscription_data->sub_params;
					$this->_data->subtotal = $subscription_data->total;
					$this->_data->total = $subscription_data->total;
					}
					}
					else
					{
					$this->_data->params = $subscription_data->sub_params;
					$this->_data->subtotal = $subscription_data->total;
					$this->_data->total = $subscription_data->total;
					} 
				}
 
		return $this->_data;

	}
		

		function &getItems()
					
				{
					// Lets load the data if it doesn't already exist
					if (empty( $this->_data ))
					{
						 $query = $this->_buildQuery();
						 $filter = $this->_buildContentFilter();
						 $orderby = $this->_buildItemOrderBy();
						 
						 $query .= $filter;
						 $query .= $orderby;
						 //$this->_data = $this->_getList( $query );
						 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
					}
					
					
			
					return $this->_data;
				}
			 


			function getTotal()
		
			{
		
				if (empty($this->_total)) {
					$query = $this->_buildQuery();
					$query .= $this->_buildContentFilter();
					$query  .= $this->_buildItemOrderBy();
					$this->_total = $this->_getListCount($query);    
				}
				return $this->_total;
			}
			
			
			

			 function _buildItemOrderBy()
				{
					$mainframe = JFactory::getApplication();
					
					$context	= 'com_vquiz.subscriptions.list.';
			 
					$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'order_id', 'cmd' );
					$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
					if (!array_key_exists((string)substr(strrchr($filter_order, "."), 1), $this->getTable('Orders', 'Table')->getFields()))
			        $filter_order = 'i.order_id'; 
			        
					$orderby = ' group by i.order_id order by '.$filter_order.' '.$filter_order_Dir . ' ';
			 
					return $orderby;
				}



			function getPagination()
			{
				// Load the content if it doesn't already exist
				if (empty($this->_pagination)) {
					jimport('joomla.html.pagination');
					$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
				}
				return $this->_pagination;
			}
 
 
 
		  function _buildContentFilter()
 			{
 
				$requestcategoryid = JRequest::getVar('qcategoryid');
				$quiztype = JRequest::getInt('qtype',0);
 
				
				$mainframe =JFactory::getApplication();
		 
				$context	= 'com_vquiz.subscriptions.list.';
				$usernaem		= $mainframe->getUserStateFromRequest( $context.'usernaem', 'usernaem',	'',	'string' );
				$status		= $mainframe->getUserStateFromRequest( $context.'status', 'status',	'',	'INT' );
				$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
				$planid		= $mainframe->getUserStateFromRequest( $context.'planid', 'planid',	'',	'int' );
				$pade_date= $mainframe->getUserStateFromRequest( $context.'pade_date', 'pade_date',	array(),	'ARRAY' );
			   $subscription_date= $mainframe->getUserStateFromRequest( $context.'subscription_date', 'subscription_date',	array(),	'ARRAY' );
				$search		= JString::strtolower( $search );
				
				$where = array();
				if(count($pade_date)>0){
					if(isset($pade_date[0]) && !empty($pade_date[0]))
						$where[] = 'i.pade_date >= '.$this->_db->quote($pade_date[0]);
					if(isset($pade_date[1]) && !empty($pade_date[1]))
						$where[] = 'i.pade_date <= '.$this->_db->quote($pade_date[1]);
				}
				
				if($planid)
				{ 
                $where[] = 'p.id='.$this->_db->quote($planid);
				}
  				if($status!=''){
				$where[] = 'i.status='.$this->_db->quote($status);	
				}
				if($usernaem)
				{
				$where[] = 'u.usernaem LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $qcategoryid, true ).'%', false );
				
				}
				
				 
				if($search)
				{	
					if (is_numeric($search)) 
					{		 
						$where[] = 'LOWER( i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
					}
                   
					else 
					{
		 
					 $where[] = 'p.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
		
					}
					
					
				}	
				$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
		 
				return $filter;
			}
			
		
			
			
   
	public function reset(Array $option=array())
	{
		
		$this->order_id 	         = 0;
		$this->buyer_id 	         = 0;
		$this->status 			     = QuizHelper::NONE;
		$this->total 			     = 0.0000;
		$this->subtotal 	         = 0.0000;
		$this->currency 	         = 0;
		$this->gateway_txn_id 	     = 0;
		$this->gatewaway_parent_txn  = 0.0000;
		$this->subscr_id			 = 0;
		$this->created_date          = new DateTime('0000:00:00 00:00:00');
		$this->modified_date	     = new DateTime('0000:00:00 00:00:00');
		$this->params			     = array();

		return $this;
	}
	function UpdateCouponValue($coupon_key,$subscription_id,$order_id){ 
	
			
		    $session = JFactory::getSession();
			$config = QuizHelper::getConfiguration();
			$coupon = $session->get('coupon_data', '');
			$coupon_value = 0;
			
			$row =  $this->getTable('Orders', 'Table');
			$row->load($order_id);
			
			
			if( !empty($coupon_key) && !empty($coupon)) {

				$coupon_str = $coupon['codes'] . ";;" . $coupon['offer'] . ";;" . $coupon['type_offer'];
				
				$params = json_decode($row->params);			
				

				if( $coupon['type_offer'] == 1 ) { // amount
				$coupon_value = $coupon['offer'];
				}
				if( $coupon['type_offer'] == 0 ) { // percecntage
				$coupon_value = ($coupon['offer']*$params->price)/100;
				}
				
				$row->coupon_code = $coupon_str;
				
				$row->discount_amount  = $coupon_value;
				
				$subtotal = $params->price-$coupon_value; // tax will be calculated after discount
				
				$row->subtotal = $subtotal;  // with discounted amount
				
				$total = $config->tax_enable==1?QuizHelper::pricewithtax($subtotal):$subtotal; 
				
				$row->total = $total;
				
				$row->tax = $config->tax_enable==1?$total-$subtotal:'0.00000';
				
				/* $params = json_decode($row->params);
				
				$params->price = $row->subtotal;
				
				$row->params = json_encode($params); */
				
				
				if (!$row->store()) {
				$this->setError( $row->getErrorMsg() );
				return false; 

				}
				
				$subscriptions = $this->getTable('subscriptions', 'Table');
				$subscriptions->load($subscription_id);
				
				$subscriptions->total =  $total;
				
				/* $subs_params = json_decode($subscriptions->params);				
				$subs_params->price = $row->subtotal;				
				$subscriptions->params  = json_encode($subs_params); */
				
																//print_r($subscriptions);
				if (!$subscriptions->store())
				{
				$this->setError( $subscriptions->getError() );
				return false; 
				}

				}
					
		    
			return true; 
	}
	function store()
		{	
		$time = time();
		//$datee =JFactory::getDate();
		$config = QuizHelper::getConfiguration();
		$session=JFactory::getSession();
		$user = JFactory::getUser();
	    $row =  $this->getTable('Orders', 'Table');
		$row->reset(true);
		$data = JRequest::get( 'post' ); 
		if(!isset($data['subscr_id']) || empty($data['subscr_id'])){
			return false;
		}
		    $config = QuizHelper::getConfiguration();
			$subscription = QuizHelper::subscriptionDetail($data['subscr_id']);
			$plan = QuizHelper::planDetail($subscription->plan_id);
			$data['currency'] = $config->currencyname;
			$data['created_date'] = date("Y-m-d H:m:s");
			
			$session = JFactory::getSession();
			$coupon = $session->get('coupon_data', '');
			$coupon_value = 0;
			if($data['order_id']){
			$data['subtotal'] = $config->tax_enable==1?QuizHelper::pricewithtax($plan->price):$plan->price;
			$data['total'] = $config->tax_enable==1?QuizHelper::pricewithtax($plan->price):$plan->price;
			}
			$order_detail = '';
			if($data['order_id']){
				$data['modified_date'] = date("Y-m-d H:m:s");
				$order_detail = QuizHelper::orderDetail($data['order_id']);
				$data['subtotal'] = $order_detail->subtotal;
			}
			$update_subscription = false;
			
			if($data['status'] == QuizHelper::ORDER_PAID && (empty($order_detail) || $order_detail->paid_date=='0000-00-00 00:00:00')){ 
				$data['paid_date'] = date("Y-m-d H:m:s");
				$update_subscription = true;
			}
			$total = $config->tax_enable==1?QuizHelper::pricewithtax($plan->price):$plan->price; 
			$data['tax'] = $config->tax_enable==1?$total-$plan->price:'0.00000';
			$coupon_str = "";
			
			if( !empty($coupon) ) {

			$coupon_str = $coupon['codes'] . ";;" . $coupon['offer'] . ";;" . $coupon['type_offer'];

			if( $coupon['type_offer'] == 1 ) { // TOTAL
			$coupon_value = $coupon['offer'];
			}
            if( $coupon['type_offer'] == 2 ) { // TOTAL
			$coupon_value = ($coupon['offer']*$total)/100;
			}
			$session->set('coupon_data', '');
			$data['coupon_code'] = $coupon_str;
			$data['subtotal'] = $coupon_value!=0?$total-$coupon_value:$total;
			}
			
			$params = JRequest::getVar('params', array()); 
			$params['expiration'] = $data['expiration'];
			$data['params'] = json_encode($params) ;
			
			
			$data['app_id'] = 1;
			
			$data['buyer_id'] = $subscription->user_id;
           //print_r($data); jexit();
		if (!$row->bind($data)) {

			$this->setError($this->_db->getErrorMsg());
			return false;
		}
		// Make sure the wproperty record is valid
		if (!$row->check()) {

			$this->setError($this->_db->getErrorMsg());

			return false;

		}
		// Store the web link table to the database
		if (!$row->store()) {
			$this->setError( $row->getErrorMsg() );
			return false; 

		}
		
		 JRequest::setVar('id', $row->order_id);
		/* if($update_subscription){
			$subscription =  $this->getTable('subscriptions', 'VquizTable');
			$subscription->load($data['subscr_id']);
			if($subscription->status == QuizHelper::SUBSCRIPTION_ACTIVE && $config->extend_subscription){
			$seconds = strtotime($subscription->expiration_date) - time();
			$subscription->expiration_date = date("Y-m-d H:i:s", strtotime(QuizHelper::addExpiration($data['expiration']))+$seconds);	
			$subscription->total = $subscription->total+$row->subtotal;	
			}
			else
			{
			$subscription->expiration_date = QuizHelper::addExpiration($data['expiration']);
            $subscription->total = $row->subtotal;	
			}
			
			$subscription->status = QuizHelper::SUBSCRIPTION_ACTIVE;
			$subscription->total = $row->subtotal;
			$params['order_id'] = $row->order_id;
			$params['price'] = $row->subtotal;
			$subscription->params = json_encode($params);
			$subscription->store();
		} */
     	 
		return $row;
	}

	
		function delete()
 		{

		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );

		$row =& $this->getTable('Orders', 'Table');

			if (count( $cids )) {

				foreach($cids as $cid) {
							
					if (!$row->delete( $cid )) {

						$this->setError( $row->getErrorMsg() );

						return false;

					}
					
					
				}
				
				
			}
 
		  return true;
	    }
	function subsriptionstatus($subid, $current_status)
	{
		$query = "select `status` from `#__vquiz_plans_subscription`  where `id`=".$this->_db->quote($subid);
		$this->_db->setQuery($query);
		$previous_status = $this->_db->loadResult();
		
		if($previous_status!=$current_status){
		 $query = "update `#__vquiz_plans_subscription` set `status`=".$this->_db->quote($current_status)." where `id`=".$this->_db->quote($subid);
		$this->_db->setQuery($query);
		$this->_db->execute();
		return true;
		}
	}	
	function getPlans(){
		$query = 'select `id`, `title` from `#__vquiz_plans` where `published`=1;';
		$this->_db->setQuery($query);
		return $this->_db->loadObjectList();
	}				function getPayment_integration(){                        $input=JFactory::getApplication()->input;                        $query=$this->_db->getQuery(true);            $query->select('*');            $query->from($this->_db->quoteName('#__vquiz_payment_plugin'));            $query->where('published=1');            $this->_db->setQuery($query);            $result=$this->_db->loadObjectList();            return $result;        }	
 }