<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
jimport('joomla.filesystem.file');
jimport('joomla.filesystem.folder' );

class VquizModelQuizmanager extends JModelList
{		
	var $_total = null;
	var $_pagination = null;
	var $_score_depend_index = null;
		
	protected $params = null;
		
	function __construct()
	{
		parent::__construct();	
		
		$db =JFactory::getDBO();		
		$mainframe = JFactory::getApplication();
		$app = JFactory::getApplication('site');
		$this->params = $app->getParams();
		$this->setState('params', $this->params);
		$itemid = JRequest::getInt('id', 0);
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
		$context	= 'com_vquiz.quizmanager.list.';
		$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		
		$query ='select score_depend from #__vquiz_quiz_score_category where quizid = '.$itemid.' order by id asc';
		$this->_db->setQuery( $query );
		$score_depend = $this->_db->loadColumn();
		$index=array_search(1,$score_depend);

		if($index!==false){
			$this->_score_depend_index=$index;
		}
		
	}


	function setId($id){
		$this->_id		= $id;
		$this->_data	= null;
	}


	function getTotal(){
		
		if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$query .= $this->_buildFilter();
			$query .= $this->_buildOrderBy();
			$this->_total = $this->_getListCount($query);       
		}
		return $this->_total;
	}

	function getPagination(){

		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
		}
		return $this->_pagination;
		
	}

	protected function getListQuery()
	{
		$itemid = JRequest::getInt('id', 0);	
		$db = JFactory::getDBO();
		$query = $db->getQuery(true);
		
		$query->select('*');
		if(!empty($itemid)){
			$query->from('#__vquiz_quizzes where Where published = 1 AND id = '.$this->_db->quote($itemid).'');
		}else{
			$query->from('#__vquiz_quizzes Where published = 1');
		}

		return $query;

	}
 
	function _buildQuery(){

		$modulorder=$this->params->get('modulorder',0);
		
		$query =$this->_db->getQuery(true);
		$query->select('i.*,count(q.questionid) as allquestion');
		
		if($modulorder==2){	//most Played quizzes
			$query->select('count(r.id) as items');
		}
		
		$query->from($this->_db->quoteName('#__vquiz_quizzes').'as i');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').'as q on q.quizid = i.id');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_category').'as c on c.id = i.catid');
		
		if($modulorder==2)	{//most Played quizzes
		
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizresult').'as r ON r.quizid=i.id');
			
		}elseif($modulorder==3)	{//recent Played quizzes
			$query->join('LEFT','(select max(id) as id, quizid from #__vquiz_quizresult group by quizid) as r ON r.quizid=i.id');
		}
		//$query->join('LEFT',$this->_db->quoteName('#__vquiz_question').'as que ON que.quizzesid=i.id');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizns').'as s ON s.quizid=i.id');

		return $query;		

	}

	public function GetCategoriesWithChildren($categories) {
	   $results = array();
	   foreach ($categories as $baseCategory)
	   {
		  $query = $this->_db->getQuery(true);
		  $query->select('c.path');
		  $query->from('#__vquiz_category AS c');
		  $query->where('c.published > 0');
		  $query->where('c.id = ' . $baseCategory);
		  $this->_db->setQuery($query);
		  $fathersList = $this->_db->loadObjectList();
		
		  foreach ($fathersList as $father)
		  {
			 $results[] = $baseCategory; // This adds the father only if it is published
			 $query = $this->_db->getQuery(true);
			 $query->select('c.id');
			 $query->from('#__vquiz_category AS c');
			 $query->where('c.published > 0');
			 $query->where('c.path LIKE \'' . $father->path . '/%\'');
			 $this->_db->setQuery($query);
			 $children = $this->_db->loadObjectList();
			 foreach ($children as $category)
			 {
				$results[] = $category->id;
			 }
		  }
	   }
	   return $results;
	}
		
	function _buildFilter(){
		
		$user = JFactory::getUser();
		$date = JFactory::getDate('now', JFactory::getConfig()->get('offset')); 
		$app = JFactory::getApplication();
		$lang = JFactory::getLanguage();
		$featured = JRequest::getInt('featured',0);
		$quiztype=$this->params->get('qtype',0);
		$modulorder=$this->params->get('modulorder',0);
		$skills=$this->params->get('skills',0);
 
		$categoryid = JRequest::getInt('id',0);
		
		if($categoryid == 0){
			$categoryid=$this->params->get('catid',0);	
		}
		
		$where = array();		
		$where[] = 'i.published =1';
		$where[] = 'i.access_token =""';
		
		if($featured==1){
			 $where[] = ' i.featured =1';
		}
		
		if($quiztype){
			if($quiztype ==4){
				$where[] = ' i.quiztype = 3';
			}else{
				$where[] = ' i.quiztype ='.$this->_db->quote($quiztype);
			}
		}

		$subcategory_list_layout=$this->getConfiguration()->subcategory_list_layout;
		
		if($subcategory_list_layout==0){
			$parent_id_array=array($categoryid);
			$child_result=$this->GetCategoriesWithChildren($parent_id_array);
		}else{
			$child_result=array();
		}
		
		if(!empty($child_result) and !empty($categoryid)){
			
			$where[] = ' i.catid IN (' . implode(',', $this->_db->quote($child_result)).')';
			
		}elseif($categoryid){
			
			$where[] = ' i.catid ='.$this->_db->quote($categoryid);
		}
		
		$where[] = ' i.access in ('.implode(',', $user->getAuthorisedViewLevels()).')';
		
		
		
		$where[] = ' i.startpublish_date <= '.$this->_db->quote($date->format('Y-m-d H:i:s')).' and (i.endpublish_date >= '.$this->_db->quote($date->format('Y-m-d H:i:s')).' or i.endpublish_date='.('0000-00-00').')'; 
		
		if($app->getLanguageFilter())	{
			$where[] = 'i.language in ('.$this->_db->quote($lang->getTag()).', '.$this->_db->Quote('*').')';
		}
		
		/* Learning Path Restricted url quizzes*/
		
		$restrcited_quizzes=$this->LearningPathRestrictedUrlQuizzes();
		if(!empty($restrcited_quizzes)){
			$where[]=' i.id not in ('.implode(',', $restrcited_quizzes).')';
		}
		 
		if($skills){
			$where[]=' s.skillid in ('.implode(',', $skills).')';
		}  
		
		$filter = ' where ' . implode(' and ', $where); //echo $filter; print_r($date);exit;
		return $filter;
		
	}



function _buildOrderBy(){

	//$modulorder = JRequest::getInt('modulorder',0);
	//$publish_order = JRequest::getInt('publish_order',0);
	$modulorder=$this->params->get('modulorder',0);
	$publish_order=$this->params->get('publish_order',0);
	
	
	if($publish_order==1){
		$order_by_publish_date=',i.startpublish_date desc';
	}else{
		$order_by_publish_date=',i.startpublish_date asc';
	}

	/*--latest playes Quizzes--*/
	if($modulorder==1)	{
		$orderby = ' group by i.id order by i.created desc';
	}
	/*--most Played quizzes--*/
	elseif($modulorder==2)	{
		$orderby = ' group by i.id order by items desc';
	}
	/*--recent Played quizzes--*/
	elseif($modulorder==3)	{
		$orderby = ' order by r.id desc';
	}
	/*--random played quizzes--*/
	elseif($modulorder==4)	{
		$orderby = ' group by i.id ORDER BY RAND()';
	}
	else{
		$orderby = ' group by i.id order by i.ordering desc';
	}

	return $orderby.$order_by_publish_date;
}



function getQuizzes(){

	if (empty($this->_data)) {
		$query = $this->_buildQuery();
		$query .= $this->_buildFilter();
		$query .= $this->_buildOrderBy(); //echo $query; exit;
		$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));    
	}

	return $this->_data;
}	
	
	
/*------------QUIMANAGER-------*/

	function flagcount(){

		$obj = new stdClass();
		$obj->result = "error";	
		$session = JFactory::getSession();
		$flagqid=JRequest::getVar('flagqid',0);
		$uniqvariable = JRequest::getVar('uniqvariable','');
		
						
		if($flagqid){
		
			$query ='select flagcount from #__vquiz_question where id='.$this->_db->quote($flagqid);
			$this->_db->setQuery( $query );
			$t=$this->_db->loadResult();
			$totalflag=$t+1;
			
			$query_new = 'update #__vquiz_question set flagcount='.$this->_db->quote($totalflag).' where id='.$this->_db->quote($flagqid);
			$this->_db->setQuery( $query_new );
			$this->_db->execute();	
			
		}

		if($session->has('fqid'.$uniqvariable)){
			$fqid =$session->get('fqid'.$uniqvariable);
			}
		else{
			$fqid=array();
		}
		
		if($flagqid){
			array_push($fqid, $flagqid);
			$session->set('fqid'.$uniqvariable, $fqid);	
			$obj->flaged_questions =$session->get('fqid'.$uniqvariable);
			$obj->result = "success";
		}
		
		return $obj;	

	}

		/*---Check_textarea_question---*/

		function getCheck_textarea_question($itemid){
			$query =$this->_db->getQuery(true);
			$query->select('q.*');
			$query->from($this->_db->quoteName('#__vquiz_question').' as q');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as qq on qq.questionid=q.id');
			$query->where('qq.quizid ='.$this->_db->quote($itemid));
			$query->where('q.published = 1');
			
			$this->_db->setQuery( $query );
			$data_all_question = $this->_db->loadObjectList();
			$check_textarea_score=0;
			for($p=0;$p<count($data_all_question);$p++){

				if($data_all_question[$p]->optiontype==5){
					if($data_all_question[$p]->score!=0){
						$check_textarea_score=1;
					} else{
						$check_textarea_score=0;
					}
				}
				
			}

			return $check_textarea_score; 
		  
		}

	/*----- get Branching Include Quesion  ------*/
	
	function getBranch_incldequestion($quizid){
		
		$query=$this->_db->getQuery(true);
		$query->select('MAX(apply_weight)');
		$query->from($this->_db->quoteName('#__vquiz_quizzes_branching'));
		$query->where('applyid =1');
 		$this->_db->setQuery($query);
		$maxweight = $this->_db->loadResult();
		
		if(!empty($maxweight)){
			
			$query=$this->_db->getQuery(true);
			$query->select('q.questionid');
			$query->from($this->_db->quoteName('#__vquiz_quiznques','q'));
			$query->join('left',$this->_db->quoteName('#__vquiz_question', 'que') . ' ON (' . $this->_db->quoteName('que.id') . ' = ' . $this->_db->quoteName('q.questionid') . ')');
			$query->join('left',$this->_db->quoteName('#__vquiz_quizzes_branching', 'b') . ' ON (' . $this->_db->quoteName('q.quizid') . ' = ' . $this->_db->quoteName('b.quizid') . ')');
			$query->where('que.score <='.$maxweight);
			$query->where('b.applyid = 1 ');
			$query->where('q.quizid = '.$quizid);
			$query->group('que.id');
			$this->_db->setQuery($query);
			$b_qid = $this->_db->loadColumn();
			
		}else{
			$b_qid=array();
		}
		return $b_qid;
		
	}

	/*---First Slide---*/
	 
	function getFitem()
	{	
		
		$app = JFactory::getApplication();
		$lang = JFactory::getLanguage(); 		
		$user = JFactory::getUser();
		$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));	
		//echo $date;exit;
		//$unix_time=JFactory::getDate()->toUnix();
		
		//$unix_time=strtotime(JFactory::getDate()->toSql());
		
			$unix_time =strtotime(JFactory::getDate('now', JFactory::getConfig()->get('offset')));
			//echo $unix_time;exit;
		$session_id=JFactory::getSession()->getId();
		$itemid=JRequest::getInt('id', 0);
		$session = JFactory::getSession();
		$this->_data = new stdClass();
					
		if($session->has('uniqvariable_store')){
			$uniqvariable_store= $session->get('uniqvariable_store');
		}
		else{ 
			$uniqvariable_store=array();
		}
		
		$uniqvariable=$session_id.$itemid.$unix_time;
		
		 if($uniqvariable){

			array_push($uniqvariable_store,$uniqvariable);
			$session->set('uniqvariable_store', $uniqvariable_store);
			
		 }
					
		$query =$this->_db->getQuery(true);
		$query->select('*');
		$query->from($this->_db->quoteName('#__vquiz_quizzes'));
		$query->where('id ='.$this->_db->quote($itemid));
		$query->where('published = 1');
		$query->order('id asc');

		$this->_db->setQuery( $query );
		$all = $this->_db->loadObject();
		
		
		/*---Check for Session quiz---*/
		
		$query=$this->_db->getQuery(true);
		$query->select('session_data');
		$query->from('#__vquiz_quizdraft');
		$query->where('userid='.$this->_db->quote($user->id).' and quizid='.$this->_db->quote($itemid));
		$this->_db->setQuery($query);
		$later_play_data=$this->_db->loadResult();
		if(!empty($later_play_data)){
		
			$quizoption_later=(array)json_decode($later_play_data);
			$session->set('quizoptions'.$uniqvariable, $quizoption_later);
			JRequest::setVar('uniqvariable', $uniqvariable);
			$livescore=$this->score();
			$this->_data->livescore = $livescore->score;
			$this->_data->maxscore = $livescore->maxscore; 
			$this->_data->quiztype = $livescore->quiztype;
			$quizoption_later_lastid=array_pop($quizoption_later['qids']);
			$quizoption_later_lastoption=array_pop($quizoption_later['aids']);

			if($all->paging_limit==1){
				$end_quiz_forcely=$this->BranchingCondition($uniqvariable,$itemid,$quizoption_later_lastid,$quizoption_later_lastoption,'skip',count($quizoption_later['qids']));
			}

		}else{
		
			$quizoption_later=null;
			$this->_data->livescore =0;
			$this->_data->maxscore = 0; 
			$this->_data->quiztype = null;
		}	 
		
		$where = array();
		
		$query='select access from #__vquiz_quizzes';
		
		$where[] = ' id = '.$this->_db->quote($itemid);
		$where[] = ' published = 1';
		//$where[] = ' access in ('.implode(',', $user->getAuthorisedViewLevels()).')';
		$where[] = ' startpublish_date <= '.$this->_db->quote($date->format('Y-m-d')).' and (endpublish_date >= '.$date->format('Y-m-d').' or endpublish_date='.('0000-00-00').')';

		if($app->getLanguageFilter())	{
			$where[] = ' language in ('.$this->_db->quote($lang->getTag()).', '.$this->_db->Quote('*').')';
		}
		
		/* Learning Path Restricted url quizzes*/
	
		$restrcited_quizzes=$this->LearningPathRestrictedUrlQuizzes();
		if(!empty($restrcited_quizzes)){
			$where[]=' id not in ('.implode(',', $restrcited_quizzes).')';
		} 
		

		$query .= ' where ' . implode(' and ', $where);
		$query .=' order by id asc';
		
		$this->_db->setQuery($query);
		$accescheck = $this->_db->loadResult();

		$starttime=strtotime(JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString());
	//echo $starttime; exit;
		$session->set('starttime'.$uniqvariable, $starttime); 
 		
		if(empty($all)){
			$all = new stdClass();
			$all->question_limit=0;
			$all->total_timelimit=0;
			$all->paging_limit=1;
			$all->paging=1;
			$all->random_question=0;
			$all->enable_questiongroup=0;
			$all->random_option=0;
			$all->totaltime_parameter='seconds';
		}

		$query =$this->_db->getQuery(true);
		$query->select('count(q.id),q.published');
		$query->from($this->_db->quoteName('#__vquiz_quiznques').' as qe');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_question').' as q on q.id=qe.questionid');
		$query->where('qe.quizid ='.$this->_db->quote($itemid));
		$query->where('q.published = 1');

		$this->_db->setQuery( $query );
		$totalq_count= $this->_db->loadResult();


		if($all->question_limit>0 and $all->question_limit<$totalq_count){
			$totalq=$all->question_limit;
		}
		else{
			$totalq=$totalq_count;	
		}
		
 
	
		/*----Later Quiz Play enable in configuration-----*/
		
		$later_play=$this->getConfiguration()->later_play;

		if($later_play==1){
			$totime=0;
		}else{
			$totime=$all->total_timelimit;
		}
		$totimeformate=$all->totaltime_parameter;

		switch ($totimeformate) {
			case 'seconds':
			$seconds=1;
			break;
			case 'minutes':
			$seconds=60;
			break;
			default:
			$seconds=0;
		}
		$totalquiz_times=$seconds*$totime;
		$this->_data->totalquiz_times = $totalquiz_times; 
		
		$this->_data->nextvariable = 0; 

		$this->_data->check_textarea_score = $this->getCheck_textarea_question($itemid); 
		 
		
		if(!empty($accescheck)){
			
			//$query_question_group = ' SELECT qorder FROM #__vquiz_quizzes_questiongroup where quizid = '.$this->_db->quote($itemid);
			
			$query =$this->_db->getQuery(true);
			$query->select('qorder');
			$query->from($this->_db->quoteName('#__vquiz_quizzes_questiongroup'));
			$query->where('quizid ='.$this->_db->quote($itemid));
			$this->_db->setQuery($query);
			$question_groupsId=$this->_db->loadColumn();
			
 			$query =$this->_db->getQuery(true);
			$query->select('DISTINCT i.questiongroup as questiongroup ');
			$query->from($this->_db->quoteName('#__vquiz_question').' as i');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as j on j.questionid=i.id');
			$query->where('j.quizid ='.$this->_db->quote($itemid));
			$query->order('questiongroup asc ');
			$this->_db->setQuery($query);
			$groupsId=$this->_db->loadColumn();
			
			$firstgroupid=!empty($groupsId)?array_shift($groupsId):0;
			
			$query =$this->_db->getQuery(true);
			$query->select('i.*,g.title as question_group_title,g.description as question_group_description');
			$query->select('(select count(id) from #__vquiz_question where questiongroup=g.qorder) as questiongroupids');
			$query->from($this->_db->quoteName('#__vquiz_question').' as i');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as j on j.questionid=i.id');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes_questiongroup').' as g on g.qorder=i.questiongroup');
			$query->where('j.quizid ='.$this->_db->quote($itemid));
			$query->where('i.published = 1');
			

			if($all->paging_limit>1  ){

					$limit=$all->paging_limit>0?$all->paging_limit:1;	
					$limit=$totalq>=$limit?$limit:$totalq;
					
					if(!empty($quizoption_later)){
						$query .=' and i.id not in ('.implode(',', $quizoption_later['qids']).')';
						$this->_data->nextvariable = count($quizoption_later['qids']); 
					}
					if($all->random_question==1 and $all->enable_questiongroup==0){
						
						$query .=' order by RAND() asc limit  '.$limit;
						
					}else{
						
						if(!empty($question_groupsId) and $all->enable_questiongroup==1){
							$query .=' order BY FIELD(i.questiongroup,'.implode(',',$question_groupsId).'),i.ordering asc limit '.$limit;	
						}else{
							$query .=' order by i.ordering asc limit '.$limit;	
						}
					}
					
			}else if($all->paging==3 and $all->enable_questiongroup==1){
						
					if(!empty($groupsId)){
						$query->where('i.questiongroup ='.$firstgroupid);
						$query .=' order BY i.questiongroup,i.ordering asc' ;	
					}else{
						$query .=' order by i.ordering asc limit 1';	
					}
					//$this->_data->qgroup_paging_limit = count($firstgroupqid); 
			}else{
		
				if(!empty($quizoption_later['qids'])){
					$query .=' and i.id not in ('.implode(',', $this->_db->quote($quizoption_later['qids'])).')';
					$this->_data->nextvariable = count($quizoption_later['qids']); 
				}
			
				/* $b_qid=$this->getBranch_incldequestion($itemid);				
				if(!empty($b_qid)){
					$query .=' and i.id not in ('.implode(',', $this->_db->quote($b_qid)).')';
				} */
					
				if(!$session->has('include_question'.$uniqvariable)){ 
					$b_qid=$this->getBranch_incldequestion($itemid);
					if(!empty($b_qid)){
						$query .=' and id not in ('.implode(',', $this->_db->quote($b_qid)).')';
					}	
				}
				
				if($session->has('exculde_question'.$uniqvariable)){
					
					$exculde_question=$session->get('exculde_question'.$uniqvariable);
					$query .=' and id not in ('.implode(',',$this->_db->quote($exculde_question)).')';
					
				}elseif($session->has('bran_skipedquestion'.$uniqvariable)){
						
					$bran_skipedquestion=$session->get('bran_skipedquestion'.$uniqvariable);
					$query .=' and id not in ('.implode(',', $this->_db->quote($bran_skipedquestion)).')';
					
				}elseif($session->has('bran_jumpquestion'.$uniqvariable)){
					
					$bran_jumpquestion = $session->get('bran_jumpquestion'.$uniqvariable);
					if(!empty($bran_jumpquestion)){
						$query .=' and id='.implode(',',$this->_db->quote($bran_jumpquestion));
					}
				}

				
				if(!empty($question_groupsId) and $all->enable_questiongroup==1){
					$query .=' order BY FIELD(i.questiongroup,'.implode(',',$question_groupsId).') ,i.ordering asc limit 1';
					 
				}else if($all->random_question==1 and $all->enable_questiongroup==0){
					$query .=' order by RAND() asc limit 1';
				}else{
					$query .=' order by i.ordering asc limit 1';
				}

			}
 
			$this->_db->setQuery( $query );
			$this->_data->ques = $this->_db->loadObjectList();
 
			
		}
		else{
			$this->_data->ques =null;	
		}
		
		/*---Question Times ---*/
		
		if($totime<=0){
			$qetime=0;
		}	
		else{
			if(!empty($this->_data->ques)){
				$qetime=$all->paging_limit>1?0:$this->_data->ques[0]->question_timelimit;
			}else{
				$qetime=0;
			}
		}
		
		$q_timeformate=!empty($this->_data->ques)?$this->_data->ques[0]->questiontime_parameter:''; 
		
		switch ($q_timeformate) {
			case 'seconds':
				$qsecond=1;
			break;
			case 'minutes':
				$qsecond=60;
			break;
			default:
				$qsecond=0;
		}
		$question_times=$qsecond*$qetime;
		$this->_data->question_times = $question_times; 


		/*---Attempted Check---*/
		
		$quizzesdesc_get=$this->quizzesdesc($itemid);
		$access_result_check=$quizzesdesc_get->access;

		if($access_result_check==1){
			$this->_data->access_attemp_check=1;	
			return $this->_data;	
		}else{
			$this->_data->access_attemp_check=0;
		}
										
		/*----end----*/
		
		 /*-Random answers-*/
		 $ques_random_option=$all->random_option;
		
		 for($j=0;$j<count($this->_data->ques);$j++){
		 
			$qustionid=$this->_data->ques[$j]->id;
			if(!empty($accescheck) and !empty($qustionid)){
			
				$query='select * from #__vquiz_option where qid ='.$this->_db->quote($qustionid);
				
				if($ques_random_option==1){
						$query .=' order by RAND()';
					}else{
						$query .=' order by id asc';
				}
				
				$this->_db->setQuery($query);
				$this->_data->option[$j] = $this->_db->loadObjectList();
				
			}
			else{
				$this->_data->option=null;	
			}
			
		 }

		$this->_data->quizzes = $all;
		$this->_data->totalq = $totalq;
		$this->_data->uniqvariable = $uniqvariable;
		$this->_data->qgroupid = $firstgroupid;
		
		if($session->has('bran_jumpquestion'.$uniqvariable)){
			
			$bran_jumpquestion = $session->get('bran_jumpquestion'.$uniqvariable);
			
			if(!empty($bran_jumpquestion)){

				$query=$this->_db->getQuery(true);
				$query->select('id');
				$query->from($this->_db->quoteName('#__vquiz_question'));
				$query->where('quizid = '.$this->_db->quote($itemid));
				$query->where('published = 1');
				$query->order('id asc');
				$this->_db->setQuery( $query );
				$all_questionid=$this->_db->loadColumn();
				$last_ques=array_pop($bran_jumpquestion);
				$this->_data->nextvariable = array_search($last_ques,$all_questionid);
				unset($last_ques);
				$session->set('bran_jumpquestion'.$uniqvariable, $bran_jumpquestion);

			}							
	   } 

		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->qtitle = null;
			$this->_data->quiztype = null;
		}

		return $this->_data;
	}

	
		/*--For later Play Quiz--*/
				
		function later_play(){
			
			$session = JFactory::getSession();
			$itemid = JRequest::getInt('id', 0);
			$uniqvariable = JRequest::getVar('uniqvariable','');
			$user = JFactory::getUser();	
			$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
			$obj = new stdClass();
			$obj->result = "error";	
			
			if($session->has('quizoptions'.$uniqvariable)){
			
				$quizoptions = $session->get('quizoptions'.$uniqvariable);
				
				$query=$this->_db->getQuery(true);
				$query->select('id');
				$query->from('#__vquiz_quizdraft');
				$query->where('userid='.$this->_db->quote($user->id).' and quizid='.$this->_db->quote($itemid));
				$this->_db->setQuery($query);
				$prvious_id=$this->_db->loadResult();

				
				$insert = new stdClass();
				$insert->id = $prvious_id;
				$insert->quizid = $itemid;
				$insert->userid = $user->id;
				$insert->session_data = json_encode($quizoptions);
				$insert->created = $date->toSQL();
		 
				
				if($prvious_id==0){
					
					$result =$this->_db->insertObject('#__vquiz_quizdraft', $insert);
					
				}else{
					$result =$this->_db->updateObject('#__vquiz_quizdraft', $insert, 'id');
				}
				
			}
			else{
					$obj->error = JText::_('INVALID_TOKEN'); 
					return $obj;
			}
			$obj->result = "success";
			return $obj;
		}
		
		/*---  Get branching Rule ---*/
		
		function getBranching($id){
			
			$obj=new stdClass();
			
			$query=$this->_db->getQuery(true);
			$query->select('*');
			$query->from('#__vquiz_quizzes_branching');
			$query->where('quizid='.$this->_db->quote($id));
			$this->_db->setQuery($query);
			$obj->branching=$this->_db->loadObjectList();
			
			$query=$this->_db->getQuery(true);
			$query->select('ruleid');
			$query->from('#__vquiz_quizzes_branching');
			$query->where('quizid='.$this->_db->quote($id));
			$this->_db->setQuery($query);
			$obj->ruleid=$this->_db->loadcolumn();
			
			$query=$this->_db->getQuery(true);
			$query->select('applyid');
			$query->from('#__vquiz_quizzes_branching');
			$query->where('quizid='.$this->_db->quote($id));
			$this->_db->setQuery($query);
			$obj->applyid=$this->_db->loadcolumn();
 
			
			return $obj;
			
		}
		
		/*--- Branching Conditions ---*/		
		
		function BranchingCondition($uniqvariable,$itemid,$qid,$aid,$buttontype,$limit){
			
			$session = JFactory::getSession();
			$branching_fnc=$this->getBranching($itemid);
			$all_branching=$branching_fnc->branching;
			$ruleid_array=$branching_fnc->ruleid;
			$apply_array=$branching_fnc->applyid;
			$limit=$limit;
			$end_quiz_forcely=false;
			
			if($session->has('exculde_question'.$uniqvariable))	{
					$exculde_question = $session->get('exculde_question'.$uniqvariable);
				}else{
					$exculde_question = array();
				}
				
				if($session->has('include_question'.$uniqvariable))	{
					$include_question = $session->get('include_question'.$uniqvariable);
				}else{
					$include_question = array();
				}
				
				if($session->has('bran_jumpquestion'.$uniqvariable))	{
					$bran_jumpquestion = $session->get('bran_jumpquestion'.$uniqvariable);
				}else{
					$bran_jumpquestion = array();
				}
				
				if($session->has('bran_skipedquestion'.$uniqvariable))	{
					$bran_skipedquestion = $session->get('bran_skipedquestion'.$uniqvariable);
				}else{
					$bran_skipedquestion = array();
				}
			
			for($b=0;$b<count($all_branching);$b++){

				$apply_id=$all_branching[$b]->applyid;
				$rule_id=$all_branching[$b]->ruleid;

				$apply_questionid=$all_branching[$b]->apply_questionid;
				$apply_weight_check=$all_branching[$b]->apply_weight_check;
				$apply_weight=$all_branching[$b]->apply_weight;
				
				$quizoptions = $session->get('quizoptions'.$uniqvariable);
				
				
				if(!empty($quizoptions['qids'])){
					$livescore=$this->score();
					$score = $livescore->score;
					$maxscore = $livescore->maxscore; 
				}else{
					$maxscore=0;
				}

				if($maxscore==0){
					$persentagescore=100;	
				}else{
					$persentagescore=round($score/$maxscore*100,2)>100?100:round($score/$maxscore*100,2);
				}

				
				
				$query=$this->_db->getQuery(true);
				$query->select('id');
				$query->from($this->_db->quotename('#__vquiz_question'));
				if($apply_weight_check==1){
					$query->where('score > '.$apply_weight);
				}else{
					$query->where('score <='.$apply_weight);
				}
				$query->order('id asc');
				$this->_db->setQuery($query);
				$qid_with_apply_weight=$this->_db->loadColumn();
 	
				if($all_branching[$b]->rule_questionid!=0){
					
					if($all_branching[$b]->rule_questionid==$qid){
						
						 if($rule_id==1){
							 
							 if($apply_id==1){ 
								 if($buttontype=='next'){
									 $include_question=$this->getBranch_incldequestion($itemid);
			
									 continue;
								 }
							 }elseif($apply_id==2){
								 if($buttontype=='next'){
									 $exculde_question=$qid_with_apply_weight;
									 continue;
								 }
								 
							 }elseif($apply_id==3){
								 
								 if($buttontype=='next'){
									array_push($bran_jumpquestion,$apply_questionid);
									continue;
								 }
								 
							 }elseif($apply_id==4){
								 
								 if($buttontype=='next'){
									array_push($bran_skipedquestion,$apply_questionid);
									continue;
								 }
								 
							 }else{ 
								if($buttontype=='next'){
									$end_quiz_forcely=true;
									continue;
								} 
							 }
							 
						 }elseif($rule_id==2){
							  
							 if($apply_id==1){
								 if($buttontype=='skip'){
									 $include_question=$this->getBranch_incldequestion($itemid);
									 continue;
								 }
							 }elseif($apply_id==2){
								 if($buttontype=='skip'){
									 $exculde_question=$qid_with_apply_weight;
									 continue;
								 }
							 }elseif($apply_id==3){
								 
								 if($buttontype=='skip'){
									array_push($bran_jumpquestion,$apply_questionid);
									continue;
								 }
								 
							 }elseif($apply_id==4){
								
								 if($buttontype=='skip'){
									array_push($bran_skipedquestion,$apply_questionid);
									continue;
								 }
								 
							 }else{
								if($buttontype=='skip'){
									$end_quiz_forcely=true;
									continue;
								} 
							 }
						 }elseif($rule_id==3){
							 
							 if($apply_id==1){
								 if($all_branching[$b]->rule_optionid==$aid){
									 $include_question=$this->getBranch_incldequestion($itemid);
									 continue;
								 }
							 }elseif($apply_id==2){
								 if($all_branching[$b]->rule_optionid==$aid){
									 $exculde_question=$qid_with_apply_weight;
									 continue;
								 }
							 }elseif($apply_id==3){
								 
								if($all_branching[$b]->rule_optionid==$aid){
									array_push($bran_jumpquestion,$apply_questionid);
									continue;
								}
							 }elseif($apply_id==4){

								 if($all_branching[$b]->rule_optionid==$aid){
									array_push($bran_skipedquestion,$apply_questionid);
									continue;
								}
								
							 }else{
								
								if($all_branching[$b]->rule_optionid==$aid){
									$end_quiz_forcely=true;
									continue;
								}

							 }
							 
						 }elseif($rule_id==4){

							  
							 if($apply_id==1){
								 if($all_branching[$b]->rule_optionid!=$aid){
									$include_question_question=$qid_with_apply_weight;
									continue;
								 } 
							 }elseif($apply_id==2){
								 if($all_branching[$b]->rule_optionid!=$aid){
									$exculde_question=$qid_with_apply_weight;
									continue;
								} 
							 }elseif($apply_id==3){
								 
								if($all_branching[$b]->rule_optionid!=$aid){
									array_push($bran_jumpquestion,$apply_questionid);
									continue;
								} 

							 }elseif($apply_id==4){
								 
								if($all_branching[$b]->rule_optionid!=$aid){
									array_push($bran_skipedquestion,$apply_questionid);
									continue;
								} 

							 }else{
								 
								if($all_branching[$b]->rule_optionid==$aid){
									$end_quiz_forcely=false;
								}else{
									$end_quiz_forcely=true;
									continue;
								}
							 }
							 
						 }else{
							
							 if($apply_id==1){
								 
								 if($all_branching[$b]->rule_weight_check==0){
									if($persentagescore<=$all_branching[$b]->rule_weight){
										$include_question=$this->getBranch_incldequestion($itemid);
										continue;
									}
									
								}elseif($all_branching[$b]->rule_weight_check==1){
									if($persentagescore>$all_branching[$b]->rule_weight){
										$include_question=$this->getBranch_incldequestion($itemid);
										continue;
									}
								} 
								
							 }elseif($apply_id==2){
								 
								 if($all_branching[$b]->rule_weight_check==0){
									if($persentagescore<=$all_branching[$b]->rule_weight){
										$exculde_question=$qid_with_apply_weight;
										continue;
									}
									
								}elseif($all_branching[$b]->rule_weight_check==1){
									if($persentagescore>$all_branching[$b]->rule_weight){
										$exculde_question=$qid_with_apply_weight;
										continue;
									}
								} 
								
							 }elseif($apply_id==3){
								 
								 if($all_branching[$b]->rule_weight_check==0){
									if($persentagescore<=$all_branching[$b]->rule_weight){
										array_push($bran_jumpquestion,$apply_questionid);
										continue;
									}
									
								}elseif($all_branching[$b]->rule_weight_check==1){
									if($persentagescore>$all_branching[$b]->rule_weight){
										array_push($bran_jumpquestion,$apply_questionid);
										continue;
									}
								} 
								
							 }elseif($apply_id==4){
								 
								if($all_branching[$b]->rule_weight_check==0){
									if($persentagescore<=$all_branching[$b]->rule_weight){
										array_push($bran_skipedquestion,$apply_questionid);
										continue;
									}
									
								}elseif($all_branching[$b]->rule_weight_check==1){
									if($persentagescore>$all_branching[$b]->rule_weight){
										array_push($bran_skipedquestion,$apply_questionid);
										continue;
									}
								} 
								 
							 }else{
								 
								if($all_branching[$b]->rule_weight_check==0){
									if($persentagescore<=$all_branching[$b]->rule_weight){
										$end_quiz_forcely=true;
										continue;
									}
									
								}elseif($all_branching[$b]->rule_weight_check==1){
									if($persentagescore>$all_branching[$b]->rule_weight){
										$end_quiz_forcely=true;
										continue;
									}
								}
								
							 }
						 }
						 
					}else{
						
					}
				}else{
					
					if($rule_id==5){
						if($apply_id==1){
								
							if($all_branching[$b]->rule_wno_question==$limit){
								if($all_branching[$b]->rule_weight_check==0){
									if($persentagescore<=$all_branching[$b]->rule_weight){
										$include_question=$this->getBranch_incldequestion($itemid);
										continue;
									}
									
								}elseif($all_branching[$b]->rule_weight_check==1){
									if($persentagescore>$all_branching[$b]->rule_weight){
										$include_question=$this->getBranch_incldequestion($itemid);
										continue;
									}
								}
							}
							
						 }elseif($apply_id==2){

							 
							 if($all_branching[$b]->rule_wno_question==$limit){
								if($all_branching[$b]->rule_weight_check==0){
									if($persentagescore<=$all_branching[$b]->rule_weight){
										$exculde_question=$qid_with_apply_weight;
										continue;
									}
									
								}elseif($all_branching[$b]->rule_weight_check==1){
									if($persentagescore>$all_branching[$b]->rule_weight){
										$exculde_question=$qid_with_apply_weight;
										continue;
									}
								}

							}
							
						 }elseif($apply_id==3){
							 
							 if($all_branching[$b]->rule_wno_question==$limit){
								if($all_branching[$b]->rule_weight_check==0){
									if($persentagescore<=$all_branching[$b]->rule_weight){
										array_push($bran_jumpquestion,$apply_questionid);
										continue;
									}
									
								}elseif($all_branching[$b]->rule_weight_check==1){
									if($persentagescore>$all_branching[$b]->rule_weight){
										array_push($bran_jumpquestion,$apply_questionid);
										continue;
									}
								}
							}
							
						 }elseif($apply_id==4){
							 if($all_branching[$b]->rule_wno_question==$limit){
								if($all_branching[$b]->rule_weight_check==0){
									if($persentagescore<=$all_branching[$b]->rule_weight){
										array_push($bran_skipedquestion,$apply_questionid);
										continue;
									}
									
								}elseif($all_branching[$b]->rule_weight_check==1){
									if($persentagescore>$all_branching[$b]->rule_weight){
										array_push($bran_skipedquestion,$apply_questionid);
										continue;
									}
								}
							}
						 }else{
							if($all_branching[$b]->rule_wno_question==$limit){
								if($all_branching[$b]->rule_weight_check==0){
									if($persentagescore<=$all_branching[$b]->rule_weight){
										$end_quiz_forcely=true;
										continue;
									}
									
								}elseif($all_branching[$b]->rule_weight_check==1){
									if($persentagescore>$all_branching[$b]->rule_weight){
										$end_quiz_forcely=true;
										continue;
									}
								}
							}
						 }	
					}
				}
			}

			if(!empty($exculde_question))
				$session->set('exculde_question'.$uniqvariable, $exculde_question);	
			if(!empty($include_question))
				$session->set('include_question'.$uniqvariable, $include_question);
			if(!empty($bran_skipedquestion))
				$session->set('bran_skipedquestion'.$uniqvariable, $bran_skipedquestion);
			if(!empty($bran_jumpquestion))
				$session->set('bran_jumpquestion'.$uniqvariable, $bran_jumpquestion);
			//print_r($end_quiz_forcely);exit;
			return $end_quiz_forcely;
			
		}
		
			
		/*---Next question Slide ---*/
		function nextslide()
		{
			$uri=JRequest::getVar('uri','');
			
			$session = JFactory::getSession();
			$itemid = JRequest::getInt('id', 0);
			$buttontype = JRequest::getVar('buttontype','skip');
			$limit=JRequest::getInt('limit_nextvariable', 0);
			$total_time_running=JRequest::getInt('total_time_running', 0);
			$expiredtime = JRequest::getInt('expiredtime',0);
			$qspenttime = JRequest::getInt('qspenttime',0);
			$qgroupid = JRequest::getInt('qgroupid',0);
			$end_quiz_forcely=false;
			$user =JFactory::getUser();
			$grp_clink=JRequest::getInt('grp_clink',0);
			
			/*--continuous Question Option--*/
			$continuous_enable=$this->getConfiguration()->continuous_question;

			$uniqvariable = JRequest::getVar('uniqvariable','');
			$ajex_continous_quiz = JRequest::getInt('ajex_continous_quiz',0);
			$questions_id= stripslashes(html_entity_decode(JRequest::getVar('qid','')));
			$qid=json_decode($questions_id,true);

			$user_comment_value= JRequest::getVar('user_comment_value',0, '', 'array');
			$aid= JRequest::getVar('aid',0, '', 'array');
			$text_value= JRequest::getVar('text_value','', '', 'array');
			$textarea_value= JRequest::getVar('textarea_value','', '', 'array');
			
			$drag_ans= JRequest::getVar('drag_ans','', '', 'array');
			$hotspotAns= JRequest::getVar('hotspotAns','', '', 'array');
 
			$obj = new stdClass();
			$obj->result = "error";	

			//$query = ' SELECT count(*) FROM #__vquiz_question where quizzesid = '.$this->_db->quote($itemid).' and  published = 1';

			
			$query =$this->_db->getQuery(true);
			$query->select('count(id)');
			$query->from($this->_db->quoteName('#__vquiz_question').' as q');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as qq on qq.questionid=q.id');
			$query->where('qq.quizid ='.$this->_db->quote($itemid));
			$query->where('q.published = 1');
			
			$this->_db->setQuery( $query );
			$totalq_count= $this->_db->loadResult();
			
			$query = ' SELECT * FROM #__vquiz_quizzes where id = '.$this->_db->quote($itemid).' order by id asc';
			$this->_db->setQuery( $query );
			$quizzesresult = $this->_db->loadObject();
			$catid = $quizzesresult->catid;
			$answers_type = $quizzesresult->answers_type;
			$quizzestitle = $quizzesresult->title;
			$passed_score = $quizzesresult->passed_score;
			$total_questionlimit = $quizzesresult->question_limit;
			$paging = $quizzesresult->paging;	
 
			
			/*----Later Quiz Play enable in configuration-----*/
			$later_play=$this->getConfiguration()->later_play;
			if($later_play==1){
				$total_time=0;
			}else{
				 $total_time=$quizzesresult->total_timelimit;
			}
			
			$totimeformate=$quizzesresult->totaltime_parameter;
					
			$question_limit=$quizzesresult->paging_limit>1?$quizzesresult->paging_limit:1;	
			
			if($total_questionlimit>0){
				
				$question_limit=$total_questionlimit>=$question_limit?$question_limit:$total_questionlimit;
				$limit=$total_questionlimit>=$limit?$limit:$total_questionlimit;
				
			}else{
				
				$total_questionlimit=$totalq_count;
			}
			
			$obj->question_limit = $question_limit;
 
			
			$query = 'select question_timelimit,score,penalty,expire_timescore,optiontype from #__vquiz_question ';
			$query .=' where  published=1 and id IN ('.implode(',',$this->_db->quote($qid)).') ORDER BY FIELD(ID,'.implode(',',$this->_db->quote($qid)).')';
			$this->_db->setQuery( $query );
			$result= $this->_db->loadObjectList();
            
            
            if( $session->has('uniqvariable_store')){

				$uniqvariable_store = $session->get('uniqvariable_store');
				$uniqvariable_exist=array_search($uniqvariable,$uniqvariable_store);
                
                if($uniqvariable_exist ===false){
                    $obj->error = JText::_('INVALID_TOKEN');
                    return $obj;   
                }
                    
			}else{ 
				$obj->error = JText::_('INVALID_TOKEN');
				return $obj;  
			}
         		 
			if($session->has('quizoptions'.$uniqvariable))	{
			
				$quizoptions = $session->get('quizoptions'.$uniqvariable);
				 
				if(empty($aid[0]) and empty($text_value[0]) and empty($textarea_value[0]) and empty($drag_ans[0]) and empty($hotspotAns[0]) and empty($user_comment_value) and $buttontype!='skip'){
					$obj->error = JText::_('CHOOSE_ANSWER_FIRST'); 
					return $obj;
				} 

			}
			else{
			
				$quizoptions = array('qids'=>array(), 'aids'=>array(),'text_value'=>array(),'textarea_value'=>array(),'drag_ans'=>array(),'hotspotAns'=>array(),'score'=>array(),'penalty'=>array(),'expire_timescore'=>array(),'qspenttime'=>array(),'user_comment_value'=>array(),'qgroupids'=>array());		
			}


		for($j=0;$j<count($qid);$j++){

		
				/*--- Branching ---*/
				if($quizzesresult->paging_limit==1){
					
					$end_quiz_forcely=$this->BranchingCondition($uniqvariable,$itemid,$qid[$j],$aid[$j],$buttontype,$limit);
					
				}

				$chkqtime[$j]=$result[$j]->question_timelimit;
				$qscore[$j]=$result[$j]->score;
				$optiontype[$j]=$result[$j]->optiontype;
				$qpenalty[$j]=$result[$j]->penalty;
				$expire_timescore[$j]=$result[$j]->expire_timescore;
				$ansid = array_search($qid[$j], $quizoptions['qids']);
				
				
				if($ansid !== false){
				
						if($buttontype=='skip'){
							$quizoptions['aids'][$ansid]=0;
							$quizoptions['expire_timescore'][$ansid]=0;
							$quizoptions['textarea_value'][$ansid]='';
							$quizoptions['text_value'][$ansid]='';
							$quizoptions['drag_ans'][$ansid]='';
							$quizoptions['hotspotAns'][$ansid]='';
							$quizoptions['user_comment_value'][$ansid]='';	
						}
						else{
						
							$quizoptions['user_comment_value'][$ansid]=$user_comment_value[$j];	
							//$quizoptions['aids'][$ansid]=$aid[$j];

								if($aid[$j]=='' and $text_value[$j]!=''){
									$quizoptions['text_value'][$ansid]=$text_value[$j];
								}elseif($aid[$j]=='' and $textarea_value[$j]!=''){
									$quizoptions['textarea_value'][$ansid]=$textarea_value[$j];
								}elseif($aid[$j]=='' and $drag_ans[$j]!=''){
									$quizoptions['drag_ans'][$ansid]=$drag_ans[$j];
								}elseif($aid[$j]=='' and $hotspotAns[$j]!=''){
									$quizoptions['hotspotAns'][$ansid]=$hotspotAns[$j];
								}else{
									$aid[$j]=$aid[$j]!=''?$aid[$j]:0;
									$quizoptions['aids'][$ansid]=$aid[$j];
								} 

							if($expiredtime==1 and $chkqtime[$j]>0 and $question_limit==1)
								$quizoptions['expire_timescore'][$ansid]=$expire_timescore[$j];
							else
								$quizoptions['expire_timescore'][$ansid]=0;

						}

						if($chkqtime[$j]==0 or $question_limit>1 or $total_time==0){
						
							$quizoptions['qspenttime'][$ansid]=-1;
							
						}else{
							$quizoptions['qspenttime'][$ansid]=$qspenttime;
						}

						$obj->idexist =1;
						$obj->ansid= $ansid;
						$obj->lastitem=key( array_slice( $quizoptions['qids'], -1, 1, TRUE ) )+1;
					
				}else{
				
						array_push($quizoptions['qids'], $qid[$j]);
						

						if($buttontype=='skip'){
						
							array_push($quizoptions['aids'], 0);
							array_push($quizoptions['penalty'], 0);
							array_push($quizoptions['expire_timescore'], 0);
							array_push($quizoptions['text_value'],'');
							array_push($quizoptions['textarea_value'], '');
							array_push($quizoptions['drag_ans'], '');
							array_push($quizoptions['hotspotAns'], '');
							array_push($quizoptions['user_comment_value'],'');
						}
						else{
							 array_push($quizoptions['user_comment_value'], $user_comment_value[$j]);

							if(empty($aid[$j]) and !empty($text_value[$j])){
								array_push($quizoptions['text_value'], $text_value[$j]);
								array_push($quizoptions['aids'],0);
								array_push($quizoptions['textarea_value'], '');
								array_push($quizoptions['drag_ans'], '');
								array_push($quizoptions['hotspotAns'], '');
							}elseif(empty($aid[$j]) and !empty($textarea_value[$j])){
								array_push($quizoptions['textarea_value'], $textarea_value[$j]);
								array_push($quizoptions['text_value'],'');
								array_push($quizoptions['aids'],0);
							array_push($quizoptions['drag_ans'], '');
								array_push($quizoptions['hotspotAns'], '');
							}elseif(empty($aid[$j]) and !empty($drag_ans[$j])){
								array_push($quizoptions['drag_ans'], $drag_ans[$j]);
								array_push($quizoptions['text_value'],'');
								array_push($quizoptions['aids'],0);
								array_push($quizoptions['textarea_value'], '');
								array_push($quizoptions['hotspotAns'], '');
							}elseif(empty($aid[$j]) and !empty($hotspotAns[$j])){
								array_push($quizoptions['hotspotAns'], $hotspotAns[$j]);
								array_push($quizoptions['text_value'],'');
								array_push($quizoptions['aids'],0);
								array_push($quizoptions['textarea_value'], '');
								array_push($quizoptions['drag_ans'], '');
							}else{
								$aid[$j]=$aid[$j]!=''?$aid[$j]:0;
								array_push($quizoptions['aids'], $aid[$j]);
								array_push($quizoptions['text_value'],'');
								array_push($quizoptions['textarea_value'], '');
								array_push($quizoptions['drag_ans'], '');
								array_push($quizoptions['hotspotAns'], '');
							}
							
							array_push($quizoptions['penalty'], $qpenalty[$j]);
							
							if($expiredtime==1 and $chkqtime[$j]>0 and $question_limit==1){
								array_push($quizoptions['expire_timescore'], $expire_timescore[$j]);
							}else{
								array_push($quizoptions['expire_timescore'], 0);
							}
						}

						array_push($quizoptions['score'], $qscore[$j]);

						if($chkqtime[$j]==0 or $question_limit>1 or $total_time==0){
							array_push($quizoptions['qspenttime'], -1);
						}
						else{
							array_push($quizoptions['qspenttime'], $qspenttime);
						}
						
						array_push($quizoptions['qgroupids'], $qgroupid);

						$obj->idexist =0;	
				}
			}
		$total_question =$this->getFitem()->totalq;
			
			
			if(!$limit==0){
				$obj->first = 0;
			}else{
				$obj->first = 1;
			}
			
			$circular_completed_question=0;
			
			/*---main Session Set all Quiz information--- */
			$session->set('quizoptions'.$uniqvariable, $quizoptions);
			
			$question_limit=$quizzesresult->paging_limit>1?$quizzesresult->paging_limit:1;	
			$quizoptions = $session->get('quizoptions'.$uniqvariable);
			
			
			/*---if Session has Random Quiz Option when question go through backslide---*/
			
			if($session->has('random_quizoption'.$uniqvariable)){
			
				$random_quizoption=$session->get('random_quizoption'.$uniqvariable);
			
				for($s=0;$s<count($qid);$s++){
		
					$id_check = in_array($qid[$s], $random_quizoption);
					if($id_check === false){ 
						array_push($random_quizoption, $qid[$s]);
					}
				}
				
				$session->set('random_quizoption'.$uniqvariable, $random_quizoption); 
			}
			
			/* --get Quiz Question-group -- */
			
			$query_question_group = ' SELECT qorder FROM #__vquiz_quizzes_questiongroup where quizid = '.$this->_db->quote($itemid);
			$this->_db->setQuery($query_question_group);
			$question_groupsId=$this->_db->loadColumn();

			$query =$this->_db->getQuery(true);
			$query->select('DISTINCT i.questiongroup as questiongroup ');
			$query->from($this->_db->quoteName('#__vquiz_question').' as i');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as j on j.questionid=i.id');
			$query->where('j.quizid ='.$this->_db->quote($itemid));
			$query->where('i.questiongroup not in ('.implode(',',$this->_db->quote(array_unique($quizoptions['qgroupids']))).')');
			$query->order('questiongroup asc ');

			$this->_db->setQuery($query);
			$groupsId=$this->_db->loadColumn();
			$obj->SSSSSSSSSS=json_encode($groupsId);
			$firstgroupid=!empty($groupsId)?array_shift($groupsId):0;
			$obj->qgroupid = $firstgroupid;
			
			/* $query =$this->_db->getQuery(true);
			$query->select('i.id');
			$query->from($this->_db->quoteName('#__vquiz_question').' as i');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as j on j.questionid=i.id');
			$query->where('j.quizid ='.$this->_db->quote($itemid));
			$query->where('i.questiongroup ='.$this->_db->quote($firstgroupid));
			$query->order('questiongroup asc ');
			$this->_db->setQuery($query);
			$firstgroupqid=$this->_db->loadColumn(); */
			 
			
			$query = ' SELECT i.*,g.qorder as qgid,g.title as question_group_title,g.description as question_group_description FROM #__vquiz_question as i left join #__vquiz_quiznques as j on j.questionid=i.id left join #__vquiz_quizzes_questiongroup as g on g.qorder=i.questiongroup where j.quizid = '.$this->_db->quote($itemid).' and  i.published = 1';
			
			if($quizzesresult->random_question==1 and $quizzesresult->enable_questiongroup==0){

				if($session->has('random_quizoption'.$uniqvariable))	{
 
					if($total_questionlimit>0 and count($quizoptions['qids'])>=$total_questionlimit)
					$query .=' and i.id in ('.implode(',', $this->_db->quote($quizoptions['qids'])).')';
				
					$query .=' and i.id not in ('.implode(',',$this->_db->quote($random_quizoption)).')';
					

				}else{ 
				    
					$query .=' and i.id not in ('.implode(',', $this->_db->quote($quizoptions['qids'])).')';

				}
				
				if(!$session->has('include_question'.$uniqvariable) and $quizzesresult->paging_limit==1){ 
					$b_qid=$this->getBranch_incldequestion($itemid);
					if(!empty($b_qid)){
						$query .=' and i.id not in ('.implode(',', $this->_db->quote($b_qid)).')';
					}	
				}
				
				if($session->has('exculde_question'.$uniqvariable)){
					
					$exculde_question=$session->get('exculde_question'.$uniqvariable);
					$query .=' and i.id not in ('.implode(',',$this->_db->quote($exculde_question)).')';
					
				}elseif($session->has('bran_skipedquestion'.$uniqvariable)){
						
					$bran_skipedquestion=$session->get('bran_skipedquestion'.$uniqvariable);
					$query .=' and i.id not in ('.implode(',', $this->_db->quote($bran_skipedquestion)).')';
					
				}elseif($session->has('bran_jumpquestion'.$uniqvariable)){
					
					$bran_jumpquestion=$session->get('bran_jumpquestion'.$uniqvariable);
					if(!empty($bran_jumpquestion)){
						$query .=' and i.id='.implode(',',$this->_db->quote($bran_jumpquestion));
					}
				}
				
				$query .=' group by i.id order by RAND() asc limit  '.$question_limit;
				
			}else{
				
				
				if(!$session->has('include_question'.$uniqvariable) and $quizzesresult->paging_limit==1){ 
					$b_qid=$this->getBranch_incldequestion($itemid);
					if(!empty($b_qid)){
						$query .=' and i.id not in ('.implode(',', $this->_db->quote($b_qid)).')';
					}	
				}
				
				if($session->has('exculde_question'.$uniqvariable)){
					
					$exculde_question=$session->get('exculde_question'.$uniqvariable);
					$query .=' and i.id not in ('.implode(',',$this->_db->quote($exculde_question)).')';
					
					if(!empty($question_groupsId) and $quizzesresult->enable_questiongroup==1){
						$query .=' group by i.id  order BY FIELD(i.questiongroup,'.implode(',',$question_groupsId).') ,i.ordering asc limit '.$limit.','.$question_limit;
					}else{
						$query .=' group by i.id  order by i.ordering asc limit '.$limit.','.$question_limit;
					}
				
				}elseif($session->has('bran_skipedquestion'.$uniqvariable)){
					
					$bran_skipedquestion=$session->get('bran_skipedquestion'.$uniqvariable);
					$query .=' and i.id not in ('.implode(',',$this->_db->quote($bran_skipedquestion)).')';
					
					if(!empty($question_groupsId) and $quizzesresult->enable_questiongroup==1){
						$query .=' group by i.id  order BY FIELD(i.questiongroup,'.implode(',',$question_groupsId).') ,i.ordering asc limit '.$limit.','.$question_limit;
					}else{
						$query .=' group by i.id  order by i.ordering asc limit '.$limit.','.$question_limit;
					}
					
				}elseif($session->has('bran_jumpquestion'.$uniqvariable)){
					
					$bran_jumpquestion=$session->get('bran_jumpquestion'.$uniqvariable);
					if(!empty($bran_jumpquestion)){
						$query .=' and i.id='.implode(',',$this->_db->quote($bran_jumpquestion));
					}else{
						$query .=' order by ordering asc limit '.$limit.','.$question_limit;
					}
										
				}else{
					
					if($quizzesresult->paging ==3 ){
						if($grp_clink==1){
						$res_grp_id=array_unique($quizoptions['qgroupids']);
						if($qgroupid==end($res_grp_id))
						{
							$firstgroupid=0;
						}
						else{
							/* $res_grp_id=array_values($res_grp_id);
							$index=array_search($qgroupid,$res_grp_id);
							if($index!=-1){

								$firstgroupid=$res_grp_id[$index+1];

							} */
							 for($i=0;$i<count($quizoptions['qgroupids']);$i++) {
								if($qgroupid==$quizoptions['qgroupids'][$i])
								{
									for($j=$i+1;$j<count($quizoptions['qgroupids']);$j++) {
										if($qgroupid!=$quizoptions['qgroupids'][$j])
										{
											$firstgroupid=$quizoptions['qgroupids'][$j];
											$obj->qgroupid =$firstgroupid;
											break;
										}
									}
								}
									
								} 
						}
						//print_r($res_grp_id);
							}
							$query .=' and i.questiongroup ='.$firstgroupid;
							$query .=' order BY i.questiongroup,i.ordering asc' ;	
							$limit =count($quizoptions['qgroupids']); 
		
							/* if($firstgroupid){  $obj->LLLL1603='LLLL1607';
								$query .=' and i.questiongroup ='.$firstgroupid;
								$query .=' order BY i.questiongroup,i.ordering asc' ;	
							}else{      $obj->LLLL1603='LLLL1609';
								$query .=' group by i.id  order by i.ordering asc limit '.$limit.','.$question_limit;
							}
							$limit =count($quizoptions['qgroupids']); */
						
					}elseif(!empty($question_groupsId) and $quizzesresult->enable_questiongroup==1){
						$query .=' group by i.id  order BY FIELD(i.questiongroup,'.implode(',',$question_groupsId).') ,i.ordering asc limit '.$limit.','.$question_limit;
					}else{
						$query .=' group by i.id  order by i.ordering asc limit '.$limit.','.$question_limit;
					}
 
				}
				 
			}
			$this->_db->setQuery( $query );
			$obj->item = $this->_db->loadObjectList();			
			$this->_db->setQuery( $query );
			$qide=$this->_db->loadColumn();
			$obj->continuous_circle=0;
			$obj->continuousenable=$continuous_enable;
			$check_id_use_in_countionus=false;

			if($session->has('bran_jumpquestion'.$uniqvariable)){
				
				$bran_jumpquestion = $session->get('bran_jumpquestion'.$uniqvariable);
				
				if(!empty($bran_jumpquestion)){
					
					$query=$this->_db->getQuery(true);
					$query->select('i.id as id');
					$query->from($this->_db->quoteName('#__vquiz_question').' as i');
					$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as j on j.questionid=i.id');
					$query->where('quizid = '.$this->_db->quote($itemid));
					$query->where('published = 1');
					$query->order('id asc');

						
//select q.id  from pre_vquiz_question as q join pre_vquiz_quiznques as qq on q.id=qq.questionid where quizid=5 and published = 1 order by id asc
					$this->_db->setQuery( $query );
					$all_questionid=$this->_db->loadColumn();
					
					if (($key = array_search($qide[0], $bran_jumpquestion)) !== false) {
						$limit = array_search($qide[0],$all_questionid);	
						unset($bran_jumpquestion[$key]);
						$session->set('bran_jumpquestion'.$uniqvariable, $bran_jumpquestion);
					}
					$limit = array_search($qide[0],$all_questionid);	
					$session->clear('bran_jumpquestion',$uniqvariable);
				}				
		   }

			if($continuous_enable==1 and empty($qide)){
			
					$reset_ids=array();
					$zero_answer_keys = array_keys(array_filter($quizoptions['aids'], function($item){return $item == 0;}));
					$zero_answer_textvalue_keys = array_keys(array_filter($quizoptions['text_value'], function($item){return $item =='';}));
					$zero_answer_textareavalue_keys = array_keys(array_filter($quizoptions['textarea_value'], function($item){return $item =='';}));
					
					$zero_answer_dragans_keys = array_keys(array_filter($quizoptions['drag_ans'], function($item){return $item =='';}));
					$zero_answer_hotspotAns_keys = array_keys(array_filter($quizoptions['hotspotAns'], function($item){return $item =='';}));
		 
 
					for($i=0;$i<count($zero_answer_keys);$i++){
					
						$qid=$quizoptions['qids'][$zero_answer_keys[$i]];
						array_push($reset_ids,$qid);
					}

					
					for($i=0;$i<count($zero_answer_textvalue_keys);$i++){
					
						$qid=$quizoptions['qids'][$zero_answer_textvalue_keys[$i]];
						
						if(!in_array($qid,$reset_ids)){
							array_push($reset_ids,$qid);
						}else{
							unset($reset_ids[array_search($qid,$reset_ids)]);
							$reset_ids=array_values($reset_ids);
						}
					}

					
					for($i=0;$i<count($zero_answer_textareavalue_keys);$i++){
					
						$qid=$quizoptions['qids'][$zero_answer_textareavalue_keys[$i]];
						
						if(!in_array($qid,$reset_ids)){
							array_push($reset_ids,$qid);
						}else{
							unset($reset_ids[array_search($qid,$reset_ids)]);
							$reset_ids=array_values($reset_ids);
						}
					}
					
					for($i=0;$i<count($zero_answer_dragans_keys);$i++){
					
						$qid=$quizoptions['qids'][$zero_answer_dragans_keys[$i]];
						
						if(!in_array($qid,$reset_ids)){
							array_push($reset_ids,$qid);
						}else{
							unset($reset_ids[array_search($qid,$reset_ids)]);
							$reset_ids=array_values($reset_ids);
						}
					}
					
					for($i=0;$i<count($zero_answer_hotspotAns_keys);$i++){
					
						$qid=$quizoptions['qids'][$zero_answer_hotspotAns_keys[$i]];
						
						if(!in_array($qid,$reset_ids)){
							array_push($reset_ids,$qid);
						}else{
							unset($reset_ids[array_search($qid,$reset_ids)]);
							$reset_ids=array_values($reset_ids);
						}
					}

				  
                  if($total_time>0){
                        
                         $zero_questime_keys = array_keys(array_filter($quizoptions['qspenttime'], function($item){return $item ==0;}));
                        
                        for($i=0;$i<count($zero_questime_keys);$i++){
					
                            $qid=$quizoptions['qids'][$zero_questime_keys[$i]];
                            
                            if(!in_array($qid,$reset_ids)){
								
                                array_push($reset_ids,$qid);
								
                            }else{
								
								unset($reset_ids[array_search($qid,$reset_ids)]);
								$reset_ids=array_values($reset_ids);
							}
					   }    
                        
                    }
                
					$qide=$reset_ids;
					$check_id_use_in_countionus=true;
					
			}else{
			
					$reset_ids=array();
					$zero_answer_keys = array_keys(array_filter($quizoptions['aids'], function($item){return $item != 0;}));
					$zero_answer_textvalue_keys = array_keys(array_filter($quizoptions['text_value'], function($item){return $item !='';}));
					$zero_answer_textareavalue_keys = array_keys(array_filter($quizoptions['textarea_value'], function($item){return $item !='';}));
					
					$zero_answer_dragans_keys = array_keys(array_filter($quizoptions['drag_ans'], function($item){return $item !='';}));
					$zero_answer_hotspotAns_keys = array_keys(array_filter($quizoptions['hotspotAns'], function($item){return $item !='';}));
       
					
					for($i=0;$i<count($zero_answer_keys);$i++){
					
						$qid=$quizoptions['qids'][$zero_answer_keys[$i]];
						array_push($reset_ids,$qid);

					}
					
					for($i=0;$i<count($zero_answer_textvalue_keys);$i++){
					
						$qid=$quizoptions['qids'][$zero_answer_textvalue_keys[$i]];
						if(!in_array($qid,$reset_ids)){
							array_push($reset_ids,$qid);
						}
					}
					
					for($i=0;$i<count($zero_answer_textareavalue_keys);$i++){
					
						$qid=$quizoptions['qids'][$zero_answer_textareavalue_keys[$i]];
						if(!in_array($qid,$reset_ids)){
							array_push($reset_ids,$qid);
						}
					}
					
					
					for($i=0;$i<count($zero_answer_dragans_keys);$i++){
					
						$qid=$quizoptions['qids'][$zero_answer_dragans_keys[$i]];
						if(!in_array($qid,$reset_ids)){
							array_push($reset_ids,$qid);
						}
					}
					
					for($i=0;$i<count($zero_answer_hotspotAns_keys);$i++){
					
						$qid=$quizoptions['qids'][$zero_answer_hotspotAns_keys[$i]];
						if(!in_array($qid,$reset_ids)){
							array_push($reset_ids,$qid);
						}
					}
                
                    if($total_time>0){
                        
                         $zero_questime_keys = array_keys(array_filter($quizoptions['qspenttime'], function($item){return $item ==0;}));
                        
                        for($i=0;$i<count($zero_questime_keys);$i++){
					
                            $qid=$quizoptions['qids'][$zero_questime_keys[$i]];
                            
                            if(!in_array($qid,$reset_ids)){
                                array_push($reset_ids,$qid);
                            }
                            
					   }    
                        
                    }


			}
			
			
			 /*------Skipped Question Enable Given Annswers Questions------*/
				if($continuous_enable==1 ){
                    
					$completed_count=array();
					$zero_answer_keys = array_keys(array_filter($quizoptions['aids'], function($item){return $item != 0;}));
					$zero_answer_textvalue_keys = array_keys(array_filter($quizoptions['text_value'], function($item){return $item !='';}));
					$zero_answer_textareavalue_keys = array_keys(array_filter($quizoptions['textarea_value'], function($item){return $item !='';}));
					
					$zero_answer_dragans_keys = array_keys(array_filter($quizoptions['drag_ans'], function($item){return $item !='';}));
					$zero_answer_hotspotAns_keys = array_keys(array_filter($quizoptions['hotspotAns'], function($item){return $item !='';}));
					
					for($i=0;$i<count($zero_answer_keys);$i++){
						$qid=$quizoptions['qids'][$zero_answer_keys[$i]];
						array_push($completed_count,$qid);
					}
					
					for($i=0;$i<count($zero_answer_textvalue_keys);$i++){
						$qid=$quizoptions['qids'][$zero_answer_textvalue_keys[$i]];
						if(array_search($qid,$completed_count)!==true){
							array_push($completed_count,$qid);
						}
					}
					
					for($i=0;$i<count($zero_answer_textareavalue_keys);$i++){
						$qid=$quizoptions['qids'][$zero_answer_textareavalue_keys[$i]];
						if(array_search($qid,$completed_count)!==true){
							array_push($completed_count,$qid);
						}
					}
					
					
					for($i=0;$i<count($zero_answer_dragans_keys);$i++){
						$qid=$quizoptions['qids'][$zero_answer_dragans_keys[$i]];
						if(array_search($qid,$completed_count)!==true){
							array_push($completed_count,$qid);
						}
					}
					
					for($i=0;$i<count($zero_answer_hotspotAns_keys);$i++){
						$qid=$quizoptions['qids'][$zero_answer_hotspotAns_keys[$i]];
						if(array_search($qid,$completed_count)!==true){
							array_push($completed_count,$qid);
						}
					}
                    
                    if($total_time>0){
                        
                         $zero_questime_keys = array_keys(array_filter($quizoptions['qspenttime'], function($item){return $item ==0;}));
                        
                        for($i=0;$i<count($zero_questime_keys);$i++){
					
                            $qid=$quizoptions['qids'][$zero_questime_keys[$i]];
                            if(array_search($qid,$completed_count)!==true){
                                array_push($completed_count,$qid);
                            }
                            
					   }    
                        
                    }
                    
					$obj->skipped_en=$circular_completed_question;
					$circular_completed_question=count($completed_count);
					
			}
 
			$obj->circular_completed_question=$circular_completed_question;
			
			if($question_limit==1 ){
			
				$qides=count($qide)>0?$qide[0]:0; 
				$index = array_search($qides,$quizoptions['qids']);

                if($check_id_use_in_countionus==false and $continuous_enable==1){

                    if(in_array($qide[0],$reset_ids)!==false){

                        $index_old = array_search($qide[0],$quizoptions['qids']);

                        $qide_all = array_diff($quizoptions['qids'], $reset_ids); 

                        foreach( $qide_all as $key => $value ){
                              if( $key > $index_old ){
                                $index= $key;
                                break;
                              }
                        }

                        if (array_key_exists($index, $qide_all)!==true) {
                            foreach( $qide_all as $key => $value ){
                              if( $key < $index_old ){
                                $index= $key;
                                break;
                              }
                            }	
                        }

                        if(!empty($qide_all)){
                            $qides=$qide_all[$index]; 
                        }else{
                            $qides=0;
                        }

                    }

                }

				
				if($index !==false and $total_time>0){
				 
						$obj->skip_slide=1;
						$obj->idexist =1;

						for($j=$index;$j<count($quizoptions['qspenttime']);$j++){
							
						  if($quizoptions['qspenttime'][$j]>0 or $quizoptions['qspenttime'][$j]==-1 ){
							break;
						  }
						  
						}		
						
						if($j==count($quizoptions['qspenttime']) or $quizoptions['qspenttime'][$j]==-1){
						
							$limit=$j;
 							
							if($j==count($quizoptions['qspenttime'])){	
								$j= $limit-1;
							}
							$obj->ansid= $j;
							
							//$query = 'select * from #__vquiz_question where quizzesid = '.$this->_db->quote($itemid).'  and published = 1';
							
							//$query = ' SELECT i.*,g.title as question_group_title,g.description as question_group_description FROM #__vquiz_question as i left join #__vquiz_quizzes_questiongroup as g on g.qorder=i.question_group where i.quizzesid = '.$this->_db->quote($itemid).' and  i.published = 1';

							$query =$this->_db->getQuery(true);
							$query->select('i.*,g.title as question_group_title,g.description as question_group_description');
							$query->from($this->_db->quoteName('#__vquiz_question').' as i');
							$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as j on j.questionid=i.id');
							$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes_questiongroup').' as g on g.qorder=i.questiongroup');
							$query->where('j.quizid ='.$this->_db->quote($itemid));
							$query->where('i.published = 1');
					
							if(!empty($question_groupsId) and $quizzesresult->enable_questiongroup==1){
								$query .=' group by i.id  order BY FIELD(i.questiongroup,'.implode(',',$question_groupsId).'),i.ordering asc limit '.$limit.', 1';
							}else if($quizzesresult->random_question==1 and $quizzesresult->enable_questiongroup==0){
								$qid=$quizoptions['qids'][$j];
								$query .=' and i.id ='.$this->_db->quote($qid);
							}else{
								$query .=' group by i.id  order by i.ordering asc limit '.$limit.', 1';
							}
							
							$this->_db->setQuery( $query );
							$obj->item = $this->_db->loadObjectList();
							$this->_db->setQuery( $query );
							$qide=$this->_db->loadColumn();	
							$quespenttime=$quizoptions['qspenttime'][$j]; 
							$obj->quespenttime= $quespenttime;

	
						}else{	
                            
                            $qid=$quizoptions['qids'][$j];                           
                            $quespenttime=$quizoptions['qspenttime'][$j]; 
                            $obj->quespenttime= $quespenttime;	
							
							//$query = ' SELECT i.*,g.title as question_group_title,g.description as question_group_description FROM #__vquiz_question as i left join #__vquiz_quizzes_questiongroup as g on g.qorder=i.questiongroup where i.id = '.$this->_db->quote($qid).' and  i.published = 1';
							
							$query =$this->_db->getQuery(true);
							$query->select('i.*,g.title as question_group_title,g.description as question_group_description');
							$query->from($this->_db->quoteName('#__vquiz_question').' as i');
							$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes_questiongroup').' as g on g.qorder=i.questiongroup');
							if($quizzesresult->paging !=3){
								$query->where('i.id ='.$this->_db->quote($qid));
							}else{
								$query->where('i.questiongroup ='.$this->_db->quote($firstgroupid));
							}
							$query->where('i.published = 1');

                            $this->_db->setQuery( $query );
                            $obj->item = $this->_db->loadObjectList();
							$this->_db->setQuery( $query );
                            $qide=$this->_db->loadColumn();	
							
							
                            $limit=$j;
                            $obj->ansid= $limit;
                               
						}
							
					
				}else if($index !==false and $total_time<=0){
			
						$obj->skip_slide=1;
						$obj->idexist =1;
						
						//$query = ' SELECT i.*,g.title as question_group_title,g.description as question_group_description FROM #__vquiz_question as i left join #__vquiz_quizzes_questiongroup as g on g.qorder=i.question_group where i.id = '.$this->_db->quote($qides).' and  i.published = 1';

						$query =$this->_db->getQuery(true);
						$query->select('i.*,g.title as question_group_title,g.description as question_group_description');
						$query->from($this->_db->quoteName('#__vquiz_question').' as i');
						$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes_questiongroup').' as g on g.qorder=i.questiongroup');
						$query->where('i.id ='.$this->_db->quote($qides));
						$query->where('i.published = 1');
						
						$this->_db->setQuery( $query );
						$obj->item = $this->_db->loadObjectList();
						$this->_db->setQuery( $query );
						$qide=$this->_db->loadColumn();	
						$limit=$index;
						$obj->ansid= $limit;
						
				}else{
				
					$obj->idexist =0;
				}

			}else{
				
					$index_muntiquestion=false;
					for($j=0;$j<count($qide);$j++){
						$index_muntiquestion_id = array_search($qide[$j],$quizoptions['qids']);
						if($index_muntiquestion_id !==false){
							$index_muntiquestion=true;
						}else{
							$index_muntiquestion=false;
						}
					}
					
					if($index_muntiquestion !==false){
					
						$obj->skip_slide=1;
						$obj->idexist =1;
						$qids_old=$qide;
						
						if($check_id_use_in_countionus==true){
							$limit=abs($limit-count($qids_old));
						} 
						
						
						$query =$this->_db->getQuery(true);
						$query->select('i.*,g.title as question_group_title,g.description as question_group_description');
						$query->from($this->_db->quoteName('#__vquiz_question').' as i');
						$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as j on j.questionid=i.id');
						$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes_questiongroup').' as g on g.qorder=i.questiongroup');
						$query->where('j.quizid ='.$this->_db->quote($itemid));
						$query->where('i.published = 1');
						
						if($check_id_use_in_countionus==true){
						
							$query .=' and i.id in ('.implode(',',$this->_db->quote($qide)).')'; 
							
							if(!empty($question_groupsId) and $quizzesresult->enable_questiongroup==1){
								
								$query .=' group by i.id  order BY FIELD(i.questiongroup,'.implode(',',$question_groupsId).'),i.ordering asc limit '.$question_limit;
								
								$query .=' group by i.id  order by RAND() asc limit '.$question_limit;
							}else if($quizzesresult->random_question==1 and $quizzesresult->enable_questiongroup==0){
							}else{
								$query .=' group by i.id  order by i.ordering asc limit '.$question_limit;
							}
 
							
						}else{
							$query .=' group by i.id  order by i.ordering asc limit '.$limit.','.$question_limit; 
						}
												
						$this->_db->setQuery( $query );
						$obj->item = $this->_db->loadObjectList();
						$this->_db->setQuery( $query );
						$qide=$this->_db->loadColumn();	
						$obj->ansid= $limit;

					}  
			
			}
			
            
			$obj->limit=$limit;

            if($continuous_enable==1){
				
				$limit=$circular_completed_question;
				if($total_time_running==0 and $total_time>0 ){
					$limit=$total_questionlimit;
				}
            }
			
			if($end_quiz_forcely==true){
					$obj->item=NULL;	
			}elseif($total_questionlimit>0 and $limit==$total_questionlimit){

				if($quizzesresult->random_question==1 and $session->has('random_quizoption'.$uniqvariable)){

					if($obj->limit==count($random_quizoption)){
						$obj->item=NULL;
					}	
					
				}else{
					$obj->item=NULL;	
				}

			}else{
			
			}
 
			
			$checked_answer=array();
			$text_anwser=array();
			$drag_anwser=array();
			$hotspotAns=array();

			for($j=0;$j<count($qide);$j++){

				$index = array_search($qide[$j],$quizoptions['qids']);
				$quespenttime=$quizoptions['qspenttime'][$index];
				
				if($index!==false) {
				
					$ans_explode=$quizoptions['aids'][$index];
					$anscheck_array=explode(',',$ans_explode);										 
					$txtans_array=explode(',',$quizoptions['text_value'][$index]);
					$dragans_array=explode(',',$quizoptions['drag_ans'][$index]);
					$hotspotAns_array=explode(',',$quizoptions['hotspotAns'][$index]);
					
					for($x=0;$x<count($txtans_array);$x++){
						array_push($text_anwser,$txtans_array[$x]);
					}
					for($x=0;$x<count($anscheck_array);$x++){
						array_push($checked_answer,$anscheck_array[$x]);
					}
					for($x=0;$x<count($dragans_array);$x++){
						array_push($drag_anwser,$dragans_array[$x]);
					}
					for($x=0;$x<count($hotspotAns_array);$x++){
							array_push($hotspotAns,$hotspotAns_array[$x]);
						}
					 
					if($question_limit>1){  
						$obj->quespenttime ='empty';
						
					}else{ 
						$obj->quespenttime = count($qide)>0?$quespenttime:0;
					}
					$obj->idexist =1;
					
				}else {
					$anscheck_array=0;
					$obj->idexist =0;
					array_push($checked_answer,$anscheck_array);
					array_push($text_anwser,'');
					array_push($drag_anwser,'');
					array_push($hotspotAns,'');
				}
				 
			}
			
			$prepare_question_title=array();
			for($c=0;$c<count($obj->item);$c++){
				$p_title=JHtml::_('content.prepare', $obj->item[$c]->qtitle);
				array_push($prepare_question_title,$p_title);
			}
			$obj->prepare_question_title = $prepare_question_title;
			
			$obj->checked = $checked_answer;
			$obj->txtAns = $text_anwser;
			$obj->dragOrd = implode(',',$drag_anwser);
			$obj->hotspotAnswer = $hotspotAns;
			$livescore=$this->score();
			$obj->livescore = $livescore->score;
			$obj->quiztype = $livescore->quiztype;
			$maxscore = ($livescore->quiztype==1 || $livescore->quiztype==11)?$livescore->maxscore:1;
			$obj->maxscore = $maxscore; 
			
			/*-- Dyamic add Styel and Script in header --*/
			
			if($this->getConfiguration()->question_prepare_content==1){
				$document = JFactory::getDocument();
	 
				$dynamic_script=$dynamic_style='';
				
				if($session->has('DynamicAddScript'.$uniqvariable)){
					
					$DynamicAddScript=$session->get('DynamicAddScript'.$uniqvariable);

					foreach($document->_scripts as $key=>$v){
						if (in_array($key, $DynamicAddScript)!=true) {
							$dynamic_script .='<script src="'.$key.'" type="text/javascript"></script>';
						}
					}
				}
				
				if($session->has('DynamicAddStyle'.$uniqvariable)){
					
					$DynamicAddStyle=$session->get('DynamicAddStyle'.$uniqvariable);

					foreach($document->_styleSheets as $key=>$v){
						if (in_array($key, $DynamicAddStyle)!=true) {
							$dynamic_style .='<link rel="stylesheet" type="text/css" href="'.$key.'" />';
						}
					}
				}
				
				
				$dynamic_scriptdeclaration ='<script>';
				
				foreach($document->_script as $key=>$v){
					$dynamic_scriptdeclaration .=$v;
				} 
				
				$dynamic_scriptdeclaration .='</script>';
				
				$obj->dynamic_headerAdd=$dynamic_style.$dynamic_script.$dynamic_scriptdeclaration;
			}else{
				$obj->dynamic_headerAdd=null;
			}

		/*---Empty Question Result Dashboard----*/
		
		if(empty($obj->item) or $buttontype=="submit_review")
 		{
			
			$obj->google_adds=$this->getConfiguration()->g_ads;
			$obj->ads_setting=$this->getConfiguration()->ads_shows;
			$obj->lead_generate=$quizzesresult->lead_generate;
		
			$quizzesdesc_get=$this->quizzesdesc($itemid);
			
			$access_result_check=$quizzesdesc_get->access;
			
			if($access_result_check==1){
				$obj->access_result_check=$access_result_check;
				return $obj;
			}

			$obj->continuous_circle=0;
			$obj->limit=count($quizoptions['qids']);
			$livescore=$this->score();
			$obj->livescore = $livescore->score;		
			$obj->quiztype = $livescore->quiztype;
			$obj->answers_type = $answers_type;
			$score = $livescore->score;	
			$quiztype = $livescore->quiztype;
			$maxscore =($quiztype==1 || $quiztype==11)?$livescore->maxscore:1;
			$obj->score=$score;	
			$obj->maxscore = $maxscore;		
			
			$triviaquiz_id=0;
			$personalityquiz_id=0;
			$trivia_menu_link=null;
			$trivia_message=null;
			$personality_message=null;
			$personality_message_result=null;
			$personality_article_link_id=0;
			$article_link_id_trivia=0;
			$personality_result=array();
			$persentage_array=array();
			$match_value_pc='';											
			$all_optionid=array();
			$array_p_result=array();
			$array_p_article_link=array();
			$array_p_menu_link=array();
			$array_p_color=array();
			$array_p_description=array();
			$array_p_ids=array();
			$personality_menu_link='';
						 
			if($quizzesresult->quiztype==1 || $quizzesresult->quiztype==11 )
			{//Trivia type Quiz
			
				$query='select id, message, rating, description, article_link_id from #__vquiz_trivia_message where quizid='.$this->_db->quote($itemid).' and score>='.$this->_db->quote($score).' order by score asc limit 1';
				$this->_db->setQuery($query);
				$trivia_result = $this->_db->loadObject();

				if(empty($trivia_result)){
					
					$query='select id, message, rating, description, article_link_id from #__vquiz_trivia_message where quizid='.$this->_db->quote($itemid).'  order by score desc limit 1';
					$this->_db->setQuery($query);
					$trivia_result = $this->_db->loadObject();
				} 
			
				if(!empty($trivia_result)){
				
					$trivia_message = $trivia_result->message;
					$trivia_rating = $trivia_result->rating;
					$trivia_description = $trivia_result->description;
					$triviaquiz_id = $trivia_result->id;
					$article_link_id_trivia = $trivia_result->article_link_id;
				}
				else{
					$trivia_message ='';
					$trivia_rating = '';
					$trivia_description = '';
					$triviaquiz_id = '';
					$article_link_id_trivia = '';
				}
				
				$query = $this->_db->getQuery(true);
				$query->select('link');
				$query->from($this->_db->quoteName('#__menu'));
				$query->where('id='.$this->_db->quote($article_link_id_trivia));
				$this->_db->setQuery($query);
				$trivia_menu_link = $this->_db->loadResult();


			 }elseif($quizzesresult->quiztype==2){//Personality Type Quiz
				
				
				$multi_p_percentage=$quizzesresult->multi_p_percentage;
				$multi_p_score=$quizzesresult->multi_p_score;
				$personality_type=$quizzesresult->personality_type;

				for($j=0;$j<count($quizoptions['aids']);$j++){
				
					if(!empty($quizoptions['aids'][$j])){
						array_push($all_optionid,$quizoptions['aids'][$j]);
					}else{
						array_push($all_optionid,0);
					}
				}
				
				$query = "select personality_optionid from #__vquiz_option Where id IN (".implode(',',$this->_db->quote($all_optionid)).") order by personality_optionid ASC ";
				$this->_db->setQuery($query);	
				$result=$this->_db->loadColumn();
				
				$result = array_filter($result, function($item){return $item !=0;});
			
				$tota_count_p=count($result);
				$count=array_count_values($result);
				arsort($count);
				$p_answer_keys=array_keys($count);	

				if($multi_p_score==1 && $personality_type==1){
				
					$query = "select multi_p_options_score from #__vquiz_option Where id IN (".implode(',',$this->_db->quote($all_optionid)).")";
					$this->_db->setQuery($query);	
					$count_total_score=array_sum($this->_db->loadColumn());
					$count_total_score=$count_total_score>0?$count_total_score:1;

					for($w=0;$w<count($p_answer_keys);$w++){
						
						$query = "select multi_p_options_score from #__vquiz_option Where personality_optionid=".$p_answer_keys[$w].' and id IN ('.implode(',',$this->_db->quote($all_optionid)).')';
						$this->_db->setQuery($query);	
						$result_multiscore=array_sum($this->_db->loadColumn());
						$result_multiscore=$result_multiscore>0?$result_multiscore:1;
		
						$p1=($result_multiscore*100)/$count_total_score;
						
						if($multi_p_percentage>0){
							if($p1>=$multi_p_percentage){
								array_push($persentage_array,round($p1,1));
							}else{
								array_push($persentage_array,0);
							}
						}else{
							array_push($persentage_array,round($p1,1));
						}
						

					}
												
				}elseif($personality_type==2){
				
					$resulted_value=json_encode($result);
					$match_value_pc=$this->check_pcategory($itemid,$resulted_value);

				
				}else{
				
					$value_p=array_values($count);
				
					for($f=0;$f<count($value_p);$f++){
					
						$p1=($value_p[$f]*100)/$tota_count_p;
						
						if($multi_p_percentage>0){
							if($p1>=$multi_p_percentage){
								array_push($persentage_array,round($p1,1));
							}else{
								array_push($persentage_array,0);
							}
						}else{
							array_push($persentage_array,round($p1,1));
						}
					}

			}
			
			arsort($persentage_array);
			$pkeys=array_keys($persentage_array);

				
			if($personality_type==2){
				
				if($match_value_pc!=''){
					$query ='select id,answer as personality_answer,article_id,description as  personality_desc,quizid from #__vquiz_personality_message where category_combination='.$this->_db->quote($match_value_pc);
				}else{
					$query ='select id,answer as personality_answer,article_id ,description as  personality_desc,quizid from #__vquiz_personality_message order by id desc limit 1';
				}
				
				$this->_db->setQuery( $query );
				$personality_result_single=$this->_db->loadObject();
			
				$personality_message_result=$personality_result_single->personality_answer;
				$personality_message=$personality_result_single->personality_desc;
				$personality_article_link_id=$personality_result_single->article_id;
				
				$query = $this->_db->getQuery(true);
				$query->select('link');
				$query->from($this->_db->quoteName('#__menu'));
				$query->where('id='.$this->_db->quote($personality_article_link_id));
				$this->_db->setQuery($query);
				$personality_menu_link = $this->_db->loadResult();
			
			}else{
			
				for($d=0;$d<count($p_answer_keys);$d++){
					$ms_is=$p_answer_keys[$pkeys[$d]];
					$query ='select id,answer as personality_answer,article_id,description as  personality_desc,color as p_color, 	concate_desc as concate_desc from #__vquiz_personality_message where id='.$this->_db->quote($ms_is);
					$this->_db->setQuery( $query );
					$result_each=$this->_db->loadObject();
					
					if(!empty($result_each)){
					
						$query = $this->_db->getQuery(true);
						$query->select('link');
						$query->from($this->_db->quoteName('#__menu'));
						$query->where('id='.$this->_db->quote($result_each->article_id));
						$this->_db->setQuery($query);
						$personality_menu_link = $this->_db->loadResult();
						
						array_push($array_p_result,$result_each->personality_answer);
						array_push($array_p_article_link,$result_each->article_id);
						array_push($array_p_menu_link,$personality_menu_link);
						array_push($array_p_color,$result_each->p_color);
						array_push($array_p_description,$result_each->personality_desc);
						array_push($array_p_ids,$result_each->id);
					}
					
				}
				
				
				array_push($personality_result,json_encode($array_p_result));
				array_push($personality_result,json_encode($array_p_color));
				 
				$persentage_array=array_values($persentage_array);	
				$remove = array(0);
				$p_answer_keys = array_values(array_diff($p_answer_keys, $remove));   

				if(!empty($p_answer_keys))
					$most_selected_id=$p_answer_keys[$pkeys[0]];
				else 
					$most_selected_id=0;

				
				for($i=0;$i<count($pkeys);$i++){
					
					if(!empty($p_answer_keys)){
						if($p_answer_keys[$pkeys[$i]]!=0){
							$most_selected_id=$p_answer_keys[$pkeys[$i]];
							break;
						}
					} 
				}

				if($most_selected_id!=0){
					$query ='select id,answer as personality_answer,article_id,description as personality_desc,quizid from #__vquiz_personality_message where id='.$this->_db->quote($most_selected_id);
				}else{
					$query ='select id,answer as personality_answer,article_id,description as personality_desc,quizid from #__vquiz_personality_message order by id desc limit 1';
				}
				
				$this->_db->setQuery( $query );
				$personality_result_single=$this->_db->loadObject();

				$personality_message_result=$personality_result_single->personality_answer;
				$personality_message=$personality_result_single->personality_desc;
				$personality_article_link_id=$personality_result_single->article_id;
				
				$query = $this->_db->getQuery(true);
				$query->select('link');
				$query->from($this->_db->quoteName('#__menu'));
				$query->where('id='.$this->_db->quote($personality_article_link_id));
				$this->_db->setQuery($query);
				$personality_menu_link = $this->_db->loadResult();
				
				$personalityquiz_id = json_decode($personality_result_single->id);
			
			}
				

			$obj->p_answer = $personality_message_result;
			$obj->p_desc = $personality_message;

		}	
						

		if($session->has('fqid'.$uniqvariable)){
			$fqid =$session->get('fqid'.$uniqvariable);
			$total_flag=count($fqid);
		}else{
			$total_flag=0;
		}
		
		if($session->has('starttime'.$uniqvariable)){

			switch ($quizzesresult->totaltime_parameter) {
				case 'seconds':
					$seconds=1;
					break;
				case 'minutes':
					$seconds=60;
					break;
				default:
					$seconds=0;
			}
			
			$total_times=$seconds*$quizzesresult->total_timelimit;
			
			$enddatetime=JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
			
			$starttime = $session->get('starttime'.$uniqvariable);	
			//echo $starttime;
			//$quiz_spentdtime=strtotime(JFactory::getDate('now', JFactory::getConfig()->get('offset')))-$starttime;
			
			$startdatetime=date("H:i:s", $starttime);
			//echo $startdatetime;
		}
		else{ 
			//$quiz_spentdtime=0;
			$startdatetime =JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
			$enddatetime =JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
		}
							
						
		$quiz_questions=json_encode($quizoptions['qids']);
		$quiz_answers=json_encode($quizoptions['aids']);
		$user_comment=json_encode($quizoptions['user_comment_value']);
		$text_value_json=json_encode($quizoptions['text_value']);
		$textarea_value_json=json_encode($quizoptions['textarea_value']);
		$dragans_value_json=json_encode($quizoptions['drag_ans']);
		$hotspotAns_value_json=json_encode($quizoptions['hotspotAns']);
		$persentage_array=!empty($persentage_array)?$persentage_array:'';
		$personality_result=!empty($personality_result)?$personality_result:'';
		$personality_result_id=json_encode($array_p_ids);
		$question_group_result=	$this->QuestionGroupscore();
		
		
		
		/*---for users comaparing score  ---*/
		
		$query = 'SELECT score from #__vquiz_quizresult where quizid='.$itemid.' order by score asc';
		$this->_db->setQuery( $query );	
		$oldres=array_count_values($this->_db->loadColumn());
		$oldscores =array();
		$o_score=array_values($oldres);
		$o_user=array_keys($oldres);
		for($i=0;$i<count($o_score);$i++){
			    $new =array();
				array_push($new,$o_user[$i]);
				array_push($new,$o_score[$i]);
				array_push($oldscores,$new);
		}
		$obj->oldscores =$oldscores;

		$query = 'select score from #__vquiz_quizresult where score!=0 order by score asc';
		$this->_db->setQuery( $query );
		$column= $this->_db->loadColumn();

		if (in_array($score,$column)){
			$obj->newdata=0;
			
		}else{
			$obj->newdata=1;
		}
			if(!empty($quizzesresult->certificate))
			{
				$text = $quizzesresult->certificate;
				$cet_digits =$quizzesresult->cet_digits;
				$certificate_number =$quizzesresult->start_with;
			}
			else
			{
				$config_cet_no=$this->getConfiguration();	
				if($quizzesresult->quiztype==2 OR $quizzesresult->quiztype==22)
				{
					$text = $config_cet_no->mailformat2;
				}
				else{
					$text = $config_cet_no->mailformat;
				}
				$cet_digits =$config_cet_no->cet_digits;
				$certificate_number =$config_cet_no->start_with;
			}
				function generateRandomAlphanumericString($cet_digits) {
					return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $cet_digits);
				}
				function generateRandomAlphabeticString($cet_digits) {
					return substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $cet_digits);
				}
				function generateRandomnumericString($cet_digits) {
					return substr(str_shuffle("0123456789"), 0, $cet_digits);
				}
				
			if(!empty($quizzesresult->certificate)){
				$cet_type = $quizzesresult->cet_type;
				$cet_format = $quizzesresult->cet_format;
			}else{
				$cet_type = $config_cet_no->cet_type;
				$cet_format = $config_cet_no->cet_format;
			}
			if($cet_type==1){
			if($cet_format==1){
				$certificate_number .=generateRandomAlphanumericString($cet_digits);
			}elseif($cet_format==2){
				$certificate_number .=generateRandomAlphabeticString($cet_digits);
			}else{
				$certificate_number .=generateRandomnumericString($cet_digits);
			}
			
			}else{
			
				$query = ' SELECT count( * ) FROM #__vquiz_quizresult ';
				$this->_db->setQuery( $query );
				$input_sequnce =$this->_db->loadResult();
				$certificate_number .=str_pad($input_sequnce, $cet_digits, 0, STR_PAD_LEFT);
			}
			if(!empty($quizzesresult->certificate)){
				$certificate_number .= $quizzesresult->end_with;
			}else{
				$certificate_number .= $config_cet_no->end_with;
			}					
			$insert_r = new stdClass();
			$insert_r->id = null;
			$insert_r->quizid = $itemid;
			$insert_r->userid = $user->id;
			$insert_r->starttime = $startdatetime;
			$insert_r->endtime = $enddatetime;
			$insert_r->score = $score;
			$insert_r->passed_score = $passed_score;
			$insert_r->maxscore = $maxscore;
			$insert_r->personality_result = $personality_message_result;
			$insert_r->created = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();			
			$insert_r->drag_answer = $dragans_value_json;
			$insert_r->hotspotAns = $hotspotAns_value_json;			 
			$insert_r->ip_address = $_SERVER['REMOTE_ADDR'];
			$insert_r->cet_number=$certificate_number;
			if($this->_db->insertObject('#__vquiz_quizresult', $insert_r)){
				
				$checkresult_id = $this->_db->insertid();
				
				for($i=0;$i<count($quizoptions['qids']);$i++){
					
					$insert_a = new stdClass();
					$insert_a->resultid = $checkresult_id;
					$insert_a->qid = $quizoptions['qids'][$i];
					$insert_a->answer = $quizoptions['aids'][$i];
					$insert_a->text_answer = $quizoptions['text_value'][$i];
					$insert_a->textarea_answer = $quizoptions['textarea_value'][$i];
					$insert_a->comment = $quizoptions['user_comment_value'][$i];
					$insert_a->personality_result =isset($array_p_ids[$i])?$array_p_ids[$i]:0;
					$insert_a->multi_weight_personality =isset($array_p_result[$i])?$array_p_result[$i]:'';
					$insert_a->multi_weight_percentage =isset($persentage_array[$i])?$persentage_array[$i]:'';					
					
					$this->_db->insertObject('#__vquiz_quizresult_qna', $insert_a);
					/* try {					   
					   $this->_db->insertObject('#__vquiz_quizresult_qna', $insert_a);
					}
					catch (Exception $e){
					   $this->_db->updateObject('#__vquiz_quizresult_qna', $insert_a,'qna_id');
					} */
				}
				$question_grp_result=json_decode($question_group_result);
				foreach($question_grp_result as $key=>$val){
					$insert_b = new stdClass();
					//$insert_a->guestiongroup = $checkresult_id;
					$insert_b->score = (int)$val;
					$insert_b->resultid = $checkresult_id;
					$insert_b->guestiongroup =$key;
					$this->_db->insertObject('#__vquiz_quizresult_questiongroup', $insert_b);
				}
				if(strpos($uri,"link="))
			{
				
				$r_id=explode("r_id=",$uri);
				$link_var=explode("&link=",$r_id[1]);
				$queryUpdate = 'update #__vquiz_quizuser_invitation set played=1 ,reciver_result_id='.$this->_db->quote($checkresult_id) ;
				$queryUpdate .=	' where result_id='.$this->_db->quote($link_var[0]);
				$queryUpdate .= ' and reciver_result_id='.$this->_db->quote($link_var[1]);
				$this->_db->setQuery( $queryUpdate );
				$this->_db->execute();	
				
			}
				
				
				if($session->has('leade_generte_id'.$itemid)){
					
					$leade_generte_id =$session->get('leade_generte_id'.$itemid);
					
					$insert_lead = new stdClass();
					$insert_lead->id = $leade_generte_id;
					$insert_lead->resultid = $checkresult_id;
					
					$this->_db->updateObject('#__vquiz_leads', $insert_lead,'id');
					
				}
				$session->clear('leade_generte_id'.$itemid);
				
				/* Save Learning Path Result*/
				$CheckUpdateTable=$this->SaveLearningPathResult($itemid,$checkresult_id);
				
				/*---Learning Module content Update---*/
				//if($CheckUpdateTable->LastPlayQuiz==1){
					$module_Name = 'mod_vquiz_learning_quiz_status'; 
					$module = JModuleHelper::getModule($module_Name);
					$Learning_module_content = JModuleHelper::renderModule($module);
					$obj->Learning_module_content = $Learning_module_content;
				//}
				
				
				$session->set('checkresult_id'.$uniqvariable, $checkresult_id);
				
				if(isset($_COOKIE['vQuizPublicAccessCookie'.$itemid])){
					$attemptresult = $_COOKIE['vQuizPublicAccessCookie'.$itemid];
					setcookie("vQuizPublicAccessCookie".$itemid, $attemptresult+1, mktime (0, 0, 0, 12, 31, 2020),"/");	
				}
				
				// On Played Quiz user Trigger Jomsocial Stream Plugin.
				$plugin = JPluginHelper::getPlugin('community', 'vquiz_stream');
				$user=JFactory::getUser();
				
				if($plugin){
					$user = JFactory::getUser();
					JPluginHelper::importPlugin('community','vquiz_stream');
					$dispatcher = JDispatcher::getInstance();
					try{
						$dispatcher->trigger('onQuizPlayedStream',array($user,$checkresult_id));
					}catch(Exception $e){
						jexit('{"result":"error", "error":"'.$e->getMessage().'"}');
					}
				}
				
				//save notification on completing quiz				
				
				if($checkresult_id!=0 ){ 
					
					$data_arr = array();
					$data_arr['itemid'] = $checkresult_id;
					$data_arr['notification_type'] = 14;
						
					if(QuizHelper::checkNotification($data_arr['notification_type'])){
						$data_arr['notify_users'] = QuizHelper::findUsersToNotify('notify_complete_quiz');
						$data_arr['enotify_users'] = QuizHelper::findUsersToEnotify('enotify_complete_quiz');
						//print_r($data_arr); exit;
						QuizHelper::sendNotification($data_arr);
					}
				
				}
			
			}
			
	
							
		/*Check Learning Path end Quziz*/
		
		$learningId = JRequest::getInt('learningId',0);
		if($learningId){
			$returnResult=$this->CheckEndLearningPath($itemid);
			if($returnResult->remain_playquizId==1){
				$query=$this->_db->getQuery(true);
				$query->select('display_result,article_id,trivia_results,certificate');
				$query->from($this->_db->quoteName('#__vquiz_learning'));
				$query->where('id='.$this->_db->quote($learningId));
				$this->_db->setQuery($query);
				$learningPathResults=$this->_db->loadObject();
					if($learningPathResults->display_result==2){//for article text
						$article =JTable::getInstance("content");
						$article->load($learningPathResults->article_id);
						$content = '<h3>'. $article->get("title").'</h3>';
						$content .= $article->get("introtext"); 
					}elseif($learningPathResults->display_result==1){
						
						$content =$this->getLearningPathResult_Confi($learningId);
						
					}else{
						$content='';
					}
					$obj->LearningPathResult=$content;
					$obj->LearningPathCertifiCate=$learningPathResults->certificate;
			}else{
				$obj->LearningPathResult='';
				$obj->LearningPathCertifiCate=0;
			}
		}else{
			$obj->LearningPathResult='';
			$obj->LearningPathCertifiCate=0;
		}
							
							
		/*---Delete for later Play Session---*/
									
		$query_del=$this->_db->getQuery(true);
		$query_del->delete();
		$query_del->from('#__vquiz_quizdraft');
		$query_del->where('userid='.$this->_db->quote($user->id).' and quizid='.$this->_db->quote($itemid));
		$this->_db->setQuery($query_del);
		$this->_db->execute(); 
		
		$query='select dateformat from #__vquiz_configuration';
		$this->_db->setQuery($query);
		$dateformate_result = $this->_db->loadResult();
		
		/* -- All user Result graph-- */
		if($quizzesresult->quiztype==1){	
			
			
			$query = 'SELECT score from #__vquiz_quizresult where quizid='.$itemid.' order by score asc';
			$this->_db->setQuery( $query );	
			$oldres=array_count_values($this->_db->loadColumn());
			$scores =array();
			$o_score=array_values($oldres);
			$o_user=array_keys($oldres);
			for($i=0;$i<count($o_score);$i++){
				$new =array();
				array_push($new,$o_user[$i]);
				array_push($new,$o_score[$i]);
				array_push($scores,$new);
			}
			$obj->scores =$scores;
		
			$query = 'SELECT  r.created,r.score from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on q.id=r.quizid where r.userid='.$this->_db->quote($user->id).' and q.quiztype = 1 and r.quizid='.$itemid.' order by r.id asc';
			$this->_db->setQuery( $query );	
			$singleuserscore_result =$this->_db->loadObjectList();
			
			$singleuserscore_array=array();
		
			for($j=0;$j<count($singleuserscore_result);$j++){
				
				$mix_array1=array();
				$middle = strtotime($singleuserscore_result[$j]->created);   
				$new_date = date($dateformate_result, $middle);
				array_push($mix_array1,$new_date);
				array_push($mix_array1,$singleuserscore_result[$j]->score);
				array_push($singleuserscore_array,$mix_array1);
				
			}
			$obj->singleuserscore=$singleuserscore_array;

		
		}elseif($quizzesresult->quiztype==2){ //for Personality Quiz Graph
		
			$answer_message=array();			
			$singleUserScores=array();			

			$query = 'SELECT q.id  from #__vquiz_quizzes as q left join #__vquiz_quizresult as r on q.id=r.quizid WHERE r.quizid ='.$this->_db->quote($itemid);
			$this->_db->setQuery( $query );	
			$result=$this->_db->loadColumn(); 

			$choosedoption=array_count_values($result);
			$keyvalue=array_keys($choosedoption);

			if($quizzesresult->personality_type==1 and !empty($p_answer_keys)){

				$query = 'SELECT answer,id,color from #__vquiz_personality_message WHERE id IN ('.implode(',',$this->_db->quote($p_answer_keys)).')';

			}else{
			
				$query = 'SELECT answer,id,color from #__vquiz_personality_message WHERE quizid ='.$this->_db->quote($itemid);
			}
			
			$this->_db->setQuery($query);	
			$result_message = $this->_db->loadObjectList();

			if($quizzesresult->personality_type==1 and ($quizzesresult->userscore==1) and (!$user->guest)){
				 
				for($r=0;$r<count($persentage_array);$r++){
					$mix_array=array();
					$m_answer=$array_p_result[$r];
					$p_color=$array_p_color[$r];
					$p_percentage=$persentage_array[$r];
					array_push($mix_array,$m_answer);
					array_push($mix_array,$p_percentage);
					array_push($mix_array,$p_color);
					array_push($answer_message,$mix_array);
				}
				 
			}else{
				 
				for($j=0;$j<count($result_message);$j++){
				
					$mix_array=array();
					$m_id=$result_message[$j]->id;
					$m_answer=$result_message[$j]->answer;
					$p_color=$result_message[$j]->color;

					array_push($mix_array,$m_answer);

					if(in_array($m_id,$result)){
							array_push($mix_array,$choosedoption[$m_id]);
					}else{
						array_push($mix_array,0);
					}
					
					array_push($mix_array,$p_color);

					array_push($answer_message,$mix_array);

				}								
			}
			
			$obj->personality_chartdata =$answer_message; 
		
	 }else{
		
			$query = 'select count(questionid) from #__vquiz_quiznques where quizid = '.$this->_db->quote($itemid); 
			$this->_db->setQuery( $query );
			$countid = $this->_db->loadResult();
				
		
		if($countid==1){
			
			$voted_result="";
			if(!empty($quizoptions['aids'])){
				$query = 'select qoption from #__vquiz_option where id = '.$this->_db->quote($quizoptions['aids'][0]);
				$this->_db->setQuery( $query );
				$voted_result= $this->_db->loadResult();
			}
			$obj->voted_result=$voted_result;
			
			
			$obj->survey_types=1;
			$query = 'select q.id,q.qtitle from #__vquiz_question as q left join #__vquiz_quiznques as a on a.questionid=q.id   where a.quizid = '.$this->_db->quote($itemid); 
			
			$this->_db->setQuery( $query );
			$questions = $this->_db->loadObject();
			$obj->questin_title=strip_tags($questions->qtitle);
			$header=array("Question","Hits (%)");
			
			$tool_tip= new stdClass();
			$tool_tip->role = "style";
			array_push($header,$tool_tip);
			
			$arr=array();
			array_push($arr,$header);
			
			$q = 'SELECT a.answer from #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on r.id=a.resultid WHERE r.quizid ='.$this->_db->quote($itemid).' order by qna_id asc';
			$this->_db->setQuery( $q );	
			$result=$this->_db->loadRowList(); 
			
			$countoption=array();

			for($i=0;$i<count($result);$i++)	
			{
				$xx=json_decode($result[$i][0]);

				for($j=0;$j<count($xx);$j++){
					$zz=$xx[$j];
					$multi_option=explode(",",$zz);
					for($l=0;$l<count($multi_option);$l++){
						if($multi_option[$l]!=0)
						array_push($countoption,$multi_option[$l]);
					}
				}
			}

			$choosedoption=array_count_values($countoption);
			$keyvalue=array_keys($choosedoption);
			
			$totalhits=0;
			
			foreach ($choosedoption as $key => $value){
				$totalhits =$totalhits+$value;
			}

			
			$query = 'select id from #__vquiz_option where qid = '.$this->_db->quote($questions->id).' order by id asc';
			$this->_db->setQuery( $query );
			$options= $this->_db->loadColumn();
			
			$query = 'select qoption from #__vquiz_option where qid = '.$this->_db->quote($questions->id).' order by id asc';
			$this->_db->setQuery( $query );
			$options_list= $this->_db->loadObjectList();
					
			for($q=0;$q<count($options_list);$q++){
				$oo=array();
				array_push($oo,$options_list[$q]->qoption);
			   
				if (in_array($options[$q],$keyvalue)) {
					foreach ($choosedoption as $key => $value){
		 
						if($key==$options[$q]){	
						   $percentage=round((($value/$totalhits)*100), 2);
							array_push($oo,$percentage);
						} 
					}
					
				}else{
				
					array_push($oo,0);
				}
				
				$color=dechex(rand(0x000000, 0xFFFFFF));

				array_push($oo,''.$color.'');

				array_push($arr,$oo); 
			  
			}
			
			$obj->survey_chartdata=$arr;
			
	
		}else{

				$q = 'SELECT a.answer from #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r  on  r.id=a.resultid WHERE r.quizid ='.$this->_db->quote($itemid).' order by qna_id asc';
				$this->_db->setQuery( $q );	
				$result=$this->_db->loadRowList(); 

				$options=array();
				$countoption=array();
				$array=array();

				for($i=0;$i<count($result);$i++)	
				{
					$xx=json_decode($result[$i][0]);

					for($j=0;$j<count($xx);$j++){
						$zz=$xx[$j];					
						$multi_option=explode(",",$zz);
						for($l=0;$l<count($multi_option);$l++){
							if($multi_option[$l]!=0)
							array_push($countoption,$multi_option[$l]);
						}

					}
				}

				$choosedoption=array_count_values($countoption);
				$keyvalue=array_keys($choosedoption);

				$maxoption=0;
				
				
				$query=$this->_db->getQuery(true);
				$query->select('q.id');
				$query->from($this->_db->quoteName('#__vquiz_question').' as q');
				$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as a on a.questionid=q.id');
				$query->where('a.quizid ='.$this->_db->quote($itemid));
				$this->_db->setQuery($query);
				$loadcolumn = $this->_db->loadColumn();
				
				$query = 'select count(qid) from #__vquiz_option where qid in ('.implode(',',$this->_db->quote($loadcolumn)).') group by qid' ;
				$this->_db->setQuery( $query );
				$maxid = $this->_db->loadColumn();	
				
				for($ck=0;$ck<count($maxid);$ck++)
				{
					$xx=$maxid[$ck];
					$maxoption=$xx>$maxoption?$xx:$maxoption;
				}

				
				$query=$this->_db->getQuery(true);
				$query->select('q.id as id,q.qtitle as qtitle');
				$query->from($this->_db->quoteName('#__vquiz_question').' as q');
				$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as a on a.questionid=q.id');
				$query->where('a.quizid ='.$this->_db->quote($itemid));
				$this->_db->setQuery($query);
				$questions = $this->_db->loadObjectList();

				$arr = array();
				$qu=array('Question');
				$xx=array();
				$tool_tip= new stdClass();
				$tool_tip->type = 'string';
				$tool_tip->role = "tooltip";
			 
			
				for($h=0;$h<$maxoption;$h++){
				
					array_push($xx,chr(65+$h));
					array_push($xx,$tool_tip);							

				}

				$header=array_merge($qu,$xx);
				array_push($arr,$header);

			   for($k=0;$k<count($questions);$k++){
					
				$query = 'select id from #__vquiz_option where qid = '.$this->_db->quote($questions[$k]->id).' order by id asc';
				$this->_db->setQuery( $query );
				$options= $this->_db->loadColumn();
				
				 
				
				$query = 'select qoption from #__vquiz_option where qid = '.$this->_db->quote($questions[$k]->id).' order by id asc';
				$this->_db->setQuery( $query );
				$options_list= $this->_db->loadObjectList();
																
				$oo=array();
				$CK_false=false;

				for($q=0;$q<$maxoption;$q++){
					  
					if (count($options)>$q and in_array($options[$q],$keyvalue)) {
					
						foreach ($choosedoption as $key => $value){
							if($key==$options[$q]){	
							array_push($oo,$value);
							array_push($oo,''.$options_list[$q]->qoption.'  ,  Hits:'.$value.'');
							}
						}
					}
					else{
						if($CK_false==false){
							@array_push($oo,1);
							@array_push($oo,''.JText::_('OTHER_OPTION').' ,  Hits:1');
							$CK_false=true;
						}else{
							@array_push($oo,0);
							@array_push($oo,''.$options_list[$q]->qoption.' ,  Hits:1');
						}
					}
 
				}
					
				$ques=array(strip_tags($questions[$k]->qtitle));
				$x[$k]=array_merge($ques,$oo);
				array_push($arr,$x[$k]);
				
			}
			
			$obj->survey_chartdata=$arr;
		}					

			
	}
	

	/*-- ResultTemplate --*/

	 $query1 = 'select textformat from #__vquiz_quizzes where id='.$this->_db->quote($itemid);;
		  $this->_db->setQuery( $query1 );
		   $confiresult =$this->_db->loadObject();
		   if( empty($confiresult->textformat))
		   {
				 $query = 'select * from #__vquiz_configuration';
				 $this->_db->setQuery( $query );
				 $confiresult =$this->_db->loadObject();
				  if($quiztype==2){
					  $text = $confiresult->textformat2;
				  }else{
					$text = $confiresult->textformat;
				  }
		   }
		   else
		   {
			   $text = $confiresult->textformat;
		   }

	if($session->has('checkresult_id'.$uniqvariable)){
		$checkresult_id =$session->get('checkresult_id'.$uniqvariable);
		
		$query = 'select * from #__vquiz_quizresult where id='.$this->_db->quote($checkresult_id);
		$this->_db->setQuery( $query );
		$quizesult =$this->_db->loadObject();  

		$query = 'select a.qid from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($checkresult_id).' order by qna_id asc';
		$this->_db->setQuery( $query );
		$quiz_questions =$this->_db->loadColumn();
		
		$query = 'select a.answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($checkresult_id).' order by qna_id asc';
		$this->_db->setQuery( $query );
		$quiz_answers =$this->_db->loadColumn();
		
		$query = 'select a.text_answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($checkresult_id).' order by qna_id asc';
		$this->_db->setQuery( $query );
		$text_answer =$this->_db->loadColumn();
		
		$query = 'select a.textarea_answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($checkresult_id).' order by qna_id asc';
		$this->_db->setQuery( $query );
		$textarea_answer =$this->_db->loadColumn();
											
		$query=$this->_db->getQuery(true);
		$query->select('sum(q.flagcount)');
		$query->from($this->_db->quoteName('#__vquiz_question').' as q');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as a on a.questionid=q.id');
		$query->where('a.quizid ='.$this->_db->quote($quizesult->quizid));
		$this->_db->setQuery($query);
		$flag = $this->_db->loadResult();
		
		$query=$this->_db->getQuery(true);
		$query->select('q.title,q.passed_score,q.article_link_id');
		$query->from($this->_db->quoteName('#__vquiz_quizzes').' as q');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizresult').' as r on r.quizid=q.id');
		$query->where('q.id ='.$this->_db->quote($quizesult->quizid));
		$this->_db->setQuery($query);
		$quizData = $this->_db->loadObject();
						$query=$this->_db->getQuery(true);
						$query->select('link');
						$query->from($this->_db->quoteName('#__menu'));
						$query->where('id='.$this->_db->quote($quizData->article_link_id));
						$this->_db->setQuery($query);
						$redirect_page_link = $this->_db->loadResult();
		

	}else{
		$quizesult =array();  
		$text_answer =array();  
		$textarea_answer =array();  
		$quiz_questions =array();  
		$quiz_answers =array();  
		$flag =0;  
	}

	$given_answers=array();
	
	for($c=0;$c<count($quiz_answers);$c++){
		$given_answer=explode(',',$quiz_answers[$c]);
		$given_answers=array_merge($given_answers,$given_answer);
	}


	$query = 'select category_score,qid from #__vquiz_option where id IN ('.implode(',',$given_answers).')';
	$this->_db->setQuery( $query );
	$category_score_result =$this->_db->loadObjectList(); 

	$array_cat=array();	

	for($c=0;$c<count($category_score_result);$c++){
		
		$qid_index=array_search($category_score_result[$c]->qid,$quizoptions['qids']);
		$question_score=$quizoptions['score'][$qid_index];
		$category_score=json_decode($category_score_result[$c]->category_score);

		if($c==0){
			for($s=0;$s<count($category_score);$s++)
			array_push($array_cat,0);
		}

		for($s=0;$s<count($category_score);$s++){
			@$array_cat[$s] += $category_score[$s]*$question_score;
		}

	}

	$query = 'select category from #__vquiz_quiz_score_category  where quizid = '.$this->_db->quote($itemid);
	$this->_db->setQuery( $query );
	$category_title =$this->_db->loadColumn();

	if($answers_type==2 and !empty($category_title)){
		$html_cat_score  ='<table border="1" width="100%" cellspacing="0" cellpadding="5"><tr><th>'.JText::_('CATE_SCORE_TITLE').'</th><th>'.JText::_('CATE_SCORE_SCORE').'</th></tr>';
		for($t=0;$t<count($array_cat);$t++){
			$html_cat_score  .='<tr><td>'.$category_title[$t].'</td><td>'.$array_cat[$t].'</td></tr>';
		}
		$html_cat_score .='</table>';
	}else{
		$html_cat_score='---';
	}

	//questiongroup_score
	$check_textarea_score = $this->getCheck_textarea_question($itemid); 
	$question_group_result=json_decode($this->QuestionGroupscore());
		//print_r($question_group_result);exit;
	if(!empty($question_group_result) and $quizzesresult->enable_questiongroup==1){
		
		$html_qgroup_score  ='<table border="1" width="100%" cellspacing="0" cellpadding="5"><tr><th>'.JText::_('CATE_SCORE_TITLE').'</th><th>'.JText::_('CATE_SCORE_SCORE').'</th><th>'.JText::_('GROUP_SCORE_RATING').'</th><th>'.JText::_('GROUP_SCORE_MESSAGE').'</th></tr>';
		$k=0;
		foreach($question_group_result as $key=>$val){ 
				//$check_textarea_score = $this->getCheck_textarea_question($itemid,6); 
		$check_textarea_score = $this->getCheck_textarea_question($itemid);
		
				$query=$this->_db->getQuery(true);
				$query->select('*');
				$query->from($this->_db->quoteName('#__vquiz_quizzes_questiongroup_message'));
				$query->where('score >= ' .(int)$val);
				$query->where('groupid ='.$this->_db->quote($key));				
				$query->order('id asc');
				$query->setlimit(1);
				$this->_db->setQuery($query);
				$result = $this->_db->loadObject();
				
				if(!empty($result)){
					$qgroup_rating=$result->rating;
					
					if($result->article_id!=0){
						
						$qgroup_message=$result->message;

						$query = $this->_db->getQuery(true);
						$query->select('link');
						$query->from($this->_db->quoteName('#__menu'));
						$query->where('id='.$this->_db->quote($result->article_id));
						$this->_db->setQuery($query);
						$menu_link = $this->_db->loadResult();
			
						if($menu_link!=''){
							
							$articlelink_group=JRoute::_($menu_link.'&Itemid='.$result->article_id);

							$group_message_weblink ='<a href="'.$articlelink_group.'" target="_blank">'.$qgroup_message.'</a>';
		
						}else{
							$group_message_weblink =$qgroup_message;
		
						}
						
					}else{
						$qgroup_message=$result->message;
						$group_message_weblink =$qgroup_message;
						
					}
				}else{
					$group_message_weblink='';
					$qgroup_message='';
					$qgroup_rating='';
					
				}
				

			$query = $this->_db->getQuery(true);
			$query->select('title');
			$query->from($this->_db->quoteName('#__vquiz_quizzes_questiongroup'));
			$query->where(' qorder ='.$this->_db->quote($key));
			$this->_db->setQuery($query);
			$res = $this->_db->loadResult(); 
			$title = !empty($res)?$res:'---'; 
					if($check_textarea_score==1)
					{
						$val='--';
						$qgroup_rating='--';
						$group_message_weblink='--';
					}
			
			$html_qgroup_score  .='<tr><td>'.$title.'</td><td>'.$val.'</td>';
				$html_qgroup_score  .='<td>'.$qgroup_rating.'</td>';
			$html_qgroup_score  .='<td><p>'.$group_message_weblink.'</p></td></tr>';
		
		$k++;
		
		}
		
		$html_qgroup_score .='</table>';
	}else{
		$html_qgroup_score='---';
	}


	$score=$quizesult->score;
	$maxscore=$quizesult->maxscore;
	
	
	$stime=strtotime($quizesult->endtime)-strtotime($quizesult->starttime) ;

	$h=floor($stime/3600);
	$hr=$stime%3600;
	$m=floor($hr/60);
	$mr=$stime%60;
	$s=floor($mr); 
	$ht=$h>0?$h.'h':'';
	$mt=$m>0?$m.'m':'';
	$st=$s>0?$s.'s':'';
	$spenttime=$ht.'  ' .$mt.'  '.$st;

	$quiztitle=$quizData->title;
	$passed_score=$quizData->passed_score;
	
	$startdatetime=$quizesult->starttime;
	$enddatetime=$quizesult->endtime;
	
	$persentagescore = ($maxscore==0)?100:round($score/$maxscore*100,2)>100?100:round($score/$maxscore*100,2);
	$persentagescore=$persentagescore>0?$persentagescore:0;  

	if($persentagescore>=$passed_score){
		$passed_text='<span style="color:green">'.JText::_('PASSED').'</span>';	
	}else{
		$passed_text='<span style="color:red">'.JText::_('FAILED').'</span>';
	}

	if($user->get('guest')){
		$username=JText::_('COM_VQUIZ_GUEST');
	}else{
		$username=$user->username;
	}
	
	$obj->redirect_after_quiz=$quizData->article_link_id;
	if($quizData->article_link_id!=0)
	{
		$redirect_page=JRoute::_($redirect_page_link.'&Itemid='.$quizData->article_link_id.'&result_id='.$checkresult_id);
			 $obj->redirect_after_quiz_page=$redirect_page;
	}
	
	$obj->redirect_trivia_page=0;
	$trivia_message_weblink='';
							
	if($triviaquiz_id!=0){
		
		if($trivia_message!='' and $trivia_menu_link!=''){
			$articlelink_trivia=JRoute::_($trivia_menu_link.'&Itemid='.$article_link_id_trivia);
			$trivia_message_weblink ='<a href="'.$articlelink_trivia.'" target="_blank">'.$trivia_message.'</a>';
		}elseif($trivia_message=='' and $trivia_menu_link!='' and $check_textarea_score==0){
			$articlelink_trivia=JRoute::_($trivia_menu_link.'&Itemid='.$article_link_id_trivia);
			$obj->redirect_trivia_page=$articlelink_trivia;
		}else{
			$trivia_message_weblink=$trivia_message;
		}
		
		
	}
							
							
	/*---Personality Redirect Pages---*/
	
	$obj->redirect_personality_page=0;
	$personality_message_weblink='';
								
	if($personality_message!='' and $personality_menu_link!=''){
		$articlelink_personality=JRoute::_($personality_menu_link.'&Itemid='.$personality_article_link_id);
		$personality_message_weblink ='<a href="'.$articlelink_personality.'" target="_blank">'.$personality_message.'</a>';									
	}elseif($personality_message=='' and $personality_menu_link!=''){
		$articlelink_personality=JRoute::_($personality_menu_link.'&Itemid='.$personality_article_link_id);
		$obj->redirect_personality_page=$articlelink_personality;
	}else{
		$personality_message_weblink=$personality_message;
	}
							
							
							

	if(strpos($text, '{username}')!== false)
	{
		$text = str_replace('{username}', $username, $text);
	}
	if(strpos($text, '{quizname}')!== false)
	{ 
		$text = str_replace('{quizname}', $quiztitle, $text);
	}
	if(strpos($text, '{userscore}')!== false)
	{  
		if($check_textarea_score==1){
			$text = str_replace('{userscore}', '--', $text);
		}else{
			$text = str_replace('{userscore}', $score, $text);
		}
		
	}
	
	if(strpos($text, '{maxscore}')!== false)
	{
		if($check_textarea_score==1){
			$text = str_replace('{maxscore}', '--', $text);
		}else{
			$text = str_replace('{maxscore}', $maxscore, $text);
		}
		 
	}
	
	if(strpos($text, '{starttime}')!== false)
	{
		$text = str_replace('{starttime}', $startdatetime, $text);
	}
	if(strpos($text, '{endtime}')!== false)
	{
		$text = str_replace('{endtime}', $enddatetime, $text);
	}
	
	if(strpos($text, '{spenttime}')!== false)
	{
		$text = str_replace('{spenttime}', $spenttime, $text);
	}
	
	if(strpos($text, '{passedscore}')!== false)
	{
		
		if($check_textarea_score==1){
			$text = str_replace('{passedscore}', '--', $text);
		}else{
			$text = str_replace('{passedscore}', $passed_score, $text);
		}

	}
	
	if(strpos($text, '{percentscore}')!== false)
	{
		if($check_textarea_score==1){
			$text = str_replace('{percentscore}', '--', $text);
		}else{
			$text = str_replace('{percentscore}', $persentagescore, $text);
		}
		
	}
	
	if(strpos($text, '{passed}')!== false)
	{

		if($check_textarea_score==1){
			$text = str_replace('{passed}', '--', $text);
		}else{
			$text = str_replace('{passed}', $passed_text, $text);
		}
		 
	}
	
	if(strpos($text, '{flag}')!== false)
	{
		$text = str_replace('{flag}', $flag, $text);
	}
	
	if(strpos($text, '{trivia_message}')!== false )
	{
		$text = str_replace('{trivia_message}', $trivia_message_weblink, $text);
	}
	
	if(strpos($text, '{personality_message}')!== false)
	{	
		if($quizzesresult->personality_type==1){
			$text = str_replace('{personality_message}',' ', $text);
		}else{
			$text = str_replace('{personality_message}', $personality_message_weblink, $text);
		}
	}
							
	 if($quizzesresult->personality_type==1 and $quizzesresult->quiztype==2){
	 
		$obj->personality_message_type =1;
		
		$txt_p='<div class="p_answer_row">';

			for($r=0;$r<count($persentage_array);$r++){
			
			 if($persentage_array[$r]!=0){

				$articlelink=@JRoute::_($array_p_menu_link[$r].'&Itemid='.$array_p_article_link[$r]);
				
				$txt_p .='<p class="hasTip" title="'.@strip_tags($array_p_description[$r]).'">';
				$txt_p .='<span class="answer_span" style="color:'.@$array_p_color[$r].'">';
				
				if(@$array_p_article_link[$r]!=0){
					$txt_p .='<a href="'.$articlelink.'" style="color:'.$array_p_color[$r].'!important;text-decoration: underline;" target="_blank">'.$array_p_result[$r].'</a>';
				}else
					$txt_p .=@$array_p_result[$r];
				
				$txt_p .='</span>';
				$txt_p .='<span class="answer_percentage_span" style="color:'.@$array_p_color[$r].'">'.@$persentage_array[$r].'%</span></p>';
			 }
			 
			}
		
		$txt_p .='</div>';

	}else{
		$txt_p=$personality_message_result;
		$obj->personality_message_type =0;					
	}
	
							
	if(strpos($text, '{personality_score}')!== false)
	{
		$text = str_replace('{personality_score}', $txt_p, $text);
	} 
	
	if(strpos($text, '{categoryscore}')!== false)
	{
		$text = str_replace('{categoryscore}', $html_cat_score, $text);
	}
	
	if(strpos($text, '{questiongroup_score}')!== false)
	{
		$text = str_replace('{questiongroup_score}', $html_qgroup_score, $text);
	}
			
	/* $quiz_answers=json_decode($quizesult->quiz_answers);
	$quiz_questions=json_decode($quizesult->quiz_questions);
	$quiz_text_value=json_decode($quizesult->text_answer);
	$quiz_textarea_value=json_decode($quizesult->textarea_answer); */
	
	$given_answer_count = array_values(array_filter($quiz_answers, function($item){return $item != 0;}));
	
	$given_answer_textvalue_count = array_values(array_filter($text_answer, function($item){return $item !='';}));
	$given_answer_textareavalue_count = array_values(array_filter($textarea_answer, function($item){return $item !='';}));
	
	$givenanswers=count($given_answer_count)+count($given_answer_textvalue_count)+count($given_answer_textareavalue_count);

	if(strpos($text, '{total_questions}')!== false)
	{
		$text = str_replace('{total_questions}', count($quiz_questions), $text);
	}
	
	if(strpos($text, '{given_answers}')!== false)
	{
		$text = str_replace('{given_answers}', $givenanswers, $text);
		
	}

		$correct_answers_count=$this->getCorrect_answers($quizoptions['qids'],$quizoptions['aids'],$text_answer,$textarea_answer);
		
		if(strpos($text, '{correct_answers}')!== false)
		{
			if($quizzesresult->quiztype==1 and $quizzesresult->answers_type==0){
				$text = str_replace('{correct_answers}', $correct_answers_count, $text);
			}else{
				$text = str_replace('{correct_answers}','--', $text);
			}
		}
		
		if(strpos($text, '{date}')!== false)
		{
			$text = str_replace('{date}', JFactory::getDate('now', JFactory::getConfig()->get('offset'))->format("j F, Y"), $text);
		}
		$link=JRoute::_('index.php?option=com_vquiz&view=quizmanager&&id='.$itemid);
		
		if(strpos($text, '{quizurl}')!== false)
		{
			$text = str_replace('{quizurl}', $link, $text);
			
		}
					$this->configuration =$this->getConfiguration();
					$this->showresult=$this->getShowresult();
					$this->show_snap_btn=0;
							 ob_start();
							
							require (JPATH_SITE . '/components/com_vquiz/views/quizmanager/tmpl/quizresult.php');

							$show_result = ob_get_contents();
							
							ob_end_clean();
							if(strpos($text, '{answersheet}')!== false)
							{
								$text = str_replace('{answersheet}', $show_result, $text);
							}


		$obj->text = $text;
		$obj->result_status =$persentagescore>=$passed_score?1:0;
			
			
		$obj->result = "endquiz";
		return $obj;
							
	}
 
	   $ques_random_option=$quizzesresult->random_option;
		
	   for($j=0;$j<count($obj->item);$j++){	
	   
		$qustionid=$obj->item[$j]->id;

		$query = 'select id,qoption,image,qoptionB,imageB from #__vquiz_option where qid = '.$this->_db->quote($qustionid);
		
		if($ques_random_option==1){
			$query .=' order by RAND()';
		}else{
			$query .=' order by id asc';
		}
		
		$this->_db->setQuery( $query );
		$obj->answer[$j] = $this->_db->loadObjectList();

	   }
		$obj->result = "success";
		//$obj->limit_nextvariablekkk = $session;
		//print_r($session); jexit();
		return $obj; //kkk

	}  // --------------------------------end nextslide()----------------------------------
 
 
	/*- Personality Category combination create-*/

		function check_pcategory($quizid,$result){
			
			$query='select count_column,category from #__vquiz_quiz_personality_category where quizid='.$this->_db->Quote($quizid);
			$this->_db->setQuery($query);
			$pcategory_result = $this->_db->loadObject();
			if(!empty($pcategory_result)){
				$all_category = json_decode($pcategory_result->category);
				$arry_all=array_chunk($all_category,$pcategory_result->count_column);
			}else{
				$all_category = array();
				$arry_all=array();
			}
			 
			$ck_pc=json_decode($result);
			$array_key_category=array();
			$array_key_item=array();
			
			$count_value=array_count_values($ck_pc);
			
			for($j=0;$j<count($arry_all);$j++){
				$sub_category=$arry_all[$j];
				for($k=0;$k<count($sub_category);$k++){
						if(in_array($sub_category[$k],$ck_pc)){
							if(!in_array($j,$array_key_category)){
								array_push($array_key_category,$j);
								array_push($array_key_item,$sub_category[$k]);
							}else{
								$index=array_search($j, $array_key_category);
								if($count_value[$sub_category[$k]]>$count_value[$sub_category[$k-1]])
								$array_key_item[$index]=$sub_category[$k];
							}
						}
				}
				
			}
			return implode('',$array_key_item);
		
	}	
 
	   /*--Get Correct answers--*/
	   function getCorrect_answers($quizoptions_qids,$quizoptions_aids,$quiz_text_value,$quiz_textarea_value){
	   
			$total_correct_answer=0;
			$quizoptions['qids']=$quizoptions_qids;
			$quizoptions['aids']=$quizoptions_aids;
			$quizoptions['text_value']=$quiz_text_value;
			$quizoptions['textarea_value']=$quiz_textarea_value;
			
			for($i=0;$i<count($quizoptions['qids']);$i++){	

				$countoption=false;
				$c=0;
				
				$query = 'select id from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]).' and correct_ans = 1';
				$this->_db->setQuery( $query );
				$answers = $this->_db->loadColumn();
	
				$xx=explode(',',$quizoptions['aids'][$i]);

				for($k=0;$k<count($xx);$k++){
					if(in_array($xx[$k],$answers) and count($xx)==count($answers)){
						$countoption=true;
						$c=$c+1;
					}
					else{
						$countoption=false;
					}
				}
				
				if($countoption==true and $c==count($answers)) { 
					$total_correct_answer=$total_correct_answer+1;
				}
				else {
					$total_correct_answer=$total_correct_answer+0;
				}
				
				$query = 'select text_field_ans,case_sensitive from #__vquiz_question where id = '.$this->_db->quote($quizoptions['qids'][$i]);
				$this->_db->setQuery( $query );
				$question_option = $this->_db->loadObject();
				
				if($quizoptions['text_value'][$i]!=''){
				
					$text_field_ans = trim($question_option->text_field_ans);
					if($question_option->case_sensitive==1){
					
						if($text_field_ans === trim($quizoptions['text_value'][$i])){ 
							$total_correct_answer=$total_correct_answer+1;
						}
						
					}else{
						if(ucwords($text_field_ans) === ucwords(trim($quizoptions['text_value'][$i]))){ 
							$total_correct_answer=$total_correct_answer+1;
						}
					}
				} 	
			}
			return $total_correct_answer;
			
		}
 
		/*--Back Slide Question--*/

		function backslide()
		{
			
			$session = JFactory::getSession();
			$obj = new stdClass();
			$obj->result = "error";
			$limit=JRequest::getInt('limit_nextvariable', 0);
			$uniqvariable=JRequest::getVar('uniqvariable','');
			$itemid = JRequest::getInt('id', 0);
			$qgroupid = JRequest::getInt('qgroupid',0);
			$grp_clink=JRequest::getInt('grp_clink',0);
			
			$questions_id= stripslashes(html_entity_decode(JRequest::getVar('qid','')));
			$qid=json_decode($questions_id,true);
			
			$qspenttime = JRequest::getInt('qspenttime',0);
	 
			if($session->has('quizoptions'.$uniqvariable)){
				$quizoptions = $session->get('quizoptions'.$uniqvariable);
			}else{
				$obj->error = JText::_('INVALID_TOKEN');
				return $obj;			
			}
			
			if(count($quizoptions['qids'])<$limit){
				$limit=count($quizoptions['qids'])-1;
			}
			
			if(!$limit==0){
				$obj->first = 0;
			}
			else{
				$obj->first = 1;
			}

			$query = ' SELECT * FROM #__vquiz_quizzes where id = '.$this->_db->quote($itemid).' order by id asc';
			$this->_db->setQuery( $query );
			$quizzesresult = $this->_db->loadObject();
			
			$paging = $quizzesresult->paging;
			$random_question = $quizzesresult->random_question;
		 
			
			/*----Later Quiz Play enable in configuration-----*/
			$later_play=$this->getConfiguration()->later_play;
			if($later_play==1){
				$total_time=0;
			}else{
				 $total_time=$quizzesresult->total_timelimit;
			}
			
			$question_limit=$quizzesresult->paging_limit>1?$quizzesresult->paging_limit:1;	

			$query = 'select question_timelimit,score,penalty,expire_timescore from #__vquiz_question ';
			$query .=' where  id IN ('.implode(',',$qid).')'; 
			$this->_db->setQuery( $query );
			$result= $this->_db->loadObjectList();
			
			for($j=0;$j<count($qid);$j++){
			
				$chkqtime[$j]=$result[$j]->question_timelimit;
				$ansid = array_search($qid[$j], $quizoptions['qids']);
				if($ansid !== false){
					if($chkqtime[$j]==0 or $question_limit>1 or $total_time==0){
						$quizoptions['qspenttime'][$ansid]=-1;
					}
					else{
						$quizoptions['qspenttime'][$ansid]=$qspenttime;
					}
				}	
			}

			if($session->has('random_quizoption'.$uniqvariable)){
				$random_quizoption=$session->get('random_quizoption'.$uniqvariable);
			}
			else{ 
				$random_quizoption=$quizoptions['qids'];
			}

			$spenttimearray=$quizoptions['qspenttime'];
			
			$array2=$random_quizoption;
			$qids = array_slice($array2, -$question_limit, $question_limit, true); 

			//$query  ='select * from #__vquiz_question where quizzesid ='.$this->_db->quote($itemid).' and published = 1';
			
			$query_question_group = ' SELECT qorder FROM #__vquiz_quizzes_questiongroup where quizid = '.$this->_db->quote($itemid);
			$this->_db->setQuery($query_question_group);
			$question_groupsId=$this->_db->loadColumn();

			$query =$this->_db->getQuery(true);
			$query->select('DISTINCT i.questiongroup as questiongroup ');
			$query->from($this->_db->quoteName('#__vquiz_question').' as i');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as j on j.questionid=i.id');
			$query->where('j.quizid ='.$this->_db->quote($itemid));
			$query->where('i.questiongroup in ('.implode(',',$this->_db->quote(array_unique($quizoptions['qgroupids']))).')');
			if($grp_clink==0){
				$query->where('i.questiongroup !='.$qgroupid);
			}
			else{
				$query->where('i.questiongroup ='.$qgroupid);
				//print_r(($quizoptions['qgroupids']));
			}
			$query->order('questiongroup asc ');
			$this->_db->setQuery($query);
			$groupsId=$this->_db->loadColumn();
			$obj->SSSSSSSSSS=json_encode($groupsId);

			$lastgroupid=!empty($groupsId)?array_pop($groupsId):0;
			$obj->qgroupid = $lastgroupid;
			
			$query =$this->_db->getQuery(true);
			$query->select('i.*,g.title as question_group_title,g.description as question_group_description');
			$query->from($this->_db->quoteName('#__vquiz_question').' as i');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as j on j.questionid=i.id');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes_questiongroup').' as g on g.qorder=i.questiongroup');
			$query->where('j.quizid ='.$this->_db->quote($itemid));
			$query->where('i.published = 1');

			if($quizzesresult->paging ==3 and $quizzesresult->enable_questiongroup==1){
						
				$query .=' and i.questiongroup ='.$lastgroupid;
				$query .=' order BY i.questiongroup,i.ordering asc' ;	
				$limit =$limit-count($quizoptions['qgroupids']); 
				$obj->XXXXXXXX=$limit;
							
			}else if($random_question==1)	{
				$query .=' and i.id IN ('.implode(',',$qids).')';
			}
			else{
				//$query .=' order by i.ordering asc limit '.$limit.','.$question_limit; 
				
				if(!empty($question_groupsId) and $quizzesresult->enable_questiongroup==1){
					$query .=' group by i.id  order BY FIELD(i.questiongroup,'.implode(',',$question_groupsId).'),i.ordering asc limit '.$limit.','.$question_limit;
				}else{
					$query .=' group by i.id  order by i.ordering asc limit '.$limit.','.$question_limit;
				}
			}
						
			$this->_db->setQuery( $query );
			$obj->item = $this->_db->loadObjectList();
			$this->_db->setQuery( $query );
			$qide=$this->_db->loadColumn();
			

			/*--Random Answers--*/	
			$ques_random_option=$quizzesresult->random_option;
				
			for($j=0;$j<count($obj->item);$j++){
			
				$qustionid=$obj->item[$j]->id;

				$query = 'select * from #__vquiz_option where qid = '.$this->_db->quote($qustionid);$index = array_search($qustionid,$quizoptions['qids']);
				if($index !== false){
					$dragans_ord_arr=explode(':',$quizoptions['drag_ans'][$index])[0];
				}
				if($dragans_ord_arr!=""){
					$query ='select * from #__vquiz_option where id IN ('.$dragans_ord_arr.') ORDER BY FIELD(id, '.$dragans_ord_arr.')';
				}
				elseif($ques_random_option==1){
						$query .=' group by id  order by RAND()';
				}else{
						$query .=' group by id  order by id asc';
				}
				$this->_db->setQuery( $query );
				$obj->answer[$j] = $this->_db->loadObjectList();

			}
	 
			$checked_answer=array();
			$text_answer=array();
			$drag_answer=array();
			$hotspotAns=array();
		
				for($k=0;$k<count($qide);$k++){
				
					$index = array_search($qide[$k],$quizoptions['qids']);
					if($index !== false){
						$quespenttime=$quizoptions['qspenttime'][$index];
						$ans_explode=$quizoptions['aids'][$index];
						$anscheck_array=explode(',',$ans_explode);
						$txtans_array=explode(',',$quizoptions['text_value'][$index]);
						$dragans_array=explode(',',$quizoptions['drag_ans'][$index]);
						$hotspotAns_array=explode(',',$quizoptions['hotspotAns'][$index]);
						
						for($x=0;$x<count($anscheck_array);$x++){
							array_push($checked_answer,$anscheck_array[$x]);
						}
						for($x=0;$x<count($txtans_array);$x++){
							array_push($text_answer,$txtans_array[$x]);
						}
						for($x=0;$x<count($dragans_array);$x++){
							array_push($drag_answer,$dragans_array[$x]);
						}
						for($x=0;$x<count($hotspotAns_array);$x++){
							array_push($hotspotAns,$hotspotAns_array[$x]);
						}
						 
					}else{
						$ans_explode=0;
                        $quespenttime=0;
						array_push($checked_answer,$ans_explode);
						array_push($text_answer,'');
						array_push($drag_answer,'');
						array_push($hotspotAns,'');
					}
				}
			
				/*--continuous Question Option--*/
				$continuous_enable=$this->getConfiguration()->continuous_question;
				$obj->continuousenable=$continuous_enable;
				$circular_completed_question=0;
				
				/*------Skipped Question Enable Given Annswers Questions------*/
				if($continuous_enable==1 ){
					$completed_count=array();
					$zero_answer_keys = array_keys(array_filter($quizoptions['aids'], function($item){return $item != 0;}));
					$zero_answer_textvalue_keys = array_keys(array_filter($quizoptions['text_value'], function($item){return $item !='';}));
					$zero_answer_textareavalue_keys = array_keys(array_filter($quizoptions['textarea_value'], function($item){return $item !='';}));
					
					for($i=0;$i<count($zero_answer_keys);$i++){
						$qid=$quizoptions['qids'][$zero_answer_keys[$i]];
						array_push($completed_count,$qid);
					}
					
					for($i=0;$i<count($zero_answer_textvalue_keys);$i++){
						$qid=$quizoptions['qids'][$zero_answer_textvalue_keys[$i]];
						if(array_search($qid,$completed_count)!==true){
							array_push($completed_count,$qid);
						}
					}
					
					for($i=0;$i<count($zero_answer_textareavalue_keys);$i++){
						$qid=$quizoptions['qids'][$zero_answer_textareavalue_keys[$i]];
						if(array_search($qid,$completed_count)!==true){
							array_push($completed_count,$qid);
						}
					}
                    if($total_time>0){
                        
                         $zero_questime_keys = array_keys(array_filter($quizoptions['qspenttime'], function($item){return $item ==0;}));
                        
                        for($i=0;$i<count($zero_questime_keys);$i++){
					
                            $qid=$quizoptions['qids'][$zero_questime_keys[$i]];
                            if(array_search($qid,$completed_count)!==true){
                                array_push($completed_count,$qid);
                            }
                            
					   }    
                        
                    }
					$obj->skipped_en=$circular_completed_question;
					$circular_completed_question=count($completed_count);
			}
			$obj->circular_completed_question=$circular_completed_question;
			
			

				if($question_limit==1 and $total_time>0){
				
					/*--Without Question times--*/
					
					if($quespenttime==0 or $quespenttime==-1)
					{   
						$obj->skip_slide=1;
						
						for($j=$index;$j>0;$j--){
							if($quizoptions['qspenttime'][$j]>0 or $quizoptions['qspenttime'][$j]==-1 ) 
							break;
						}
						$qid=$quizoptions['qids'][$j]; 
						
						if($random_question==1){
						
							$index1= array_search($qid,$random_quizoption); 
							
							if($index1 ===false){
							
								$randon_spenttime=array();
								for($f=0;$f<count($random_quizoption);$f++){
									$indexes = array_search($random_quizoption[$f],$quizoptions['qids']); 
									$spenttme=$quizoptions['qspenttime'][$indexes];
									array_push($randon_spenttime,$spenttme);
								}
								
								for($k=count($random_quizoption)-1;$k>0;$k--){
									if($randon_spenttime[$k]>0 or $randon_spenttime[$k]==-1 ) 
									break;
								}
								
								$qid=$random_quizoption[$k]; 

							}
						}

						//$query = 'select * from #__vquiz_question where  published = 1';
						
						//$query = ' SELECT i.*,g.title as question_group_title,g.description as question_group_description FROM #__vquiz_question as i left join #__vquiz_quizzes_questiongroup as g on g.qorder=i.question_group where i.quizzesid = '.$this->_db->quote($itemid).' and  i.published = 1';
						
						$query =$this->_db->getQuery(true);
						$query->select('i.*,g.title as question_group_title,g.description as question_group_description');
						$query->from($this->_db->quoteName('#__vquiz_question').' as i');
						$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as j on j.questionid=i.id');
						$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes_questiongroup').' as g on g.qorder=i.questiongroup');
						$query->where('j.quizid ='.$this->_db->quote($itemid));
						$query->where('i.published = 1');
									
						$query .=' and i.id ='.$this->_db->quote($qid);
						$this->_db->setQuery( $query );
						$obj->item = $this->_db->loadObjectList();
						$this->_db->setQuery( $query );
						$qide=$this->_db->loadColumn();
						
						for($j=0;$j<count($obj->item);$j++){
						
							$qustionid=$obj->item[$j]->id;
							$query = 'select * from #__vquiz_option where qid = '.$this->_db->quote($qustionid).' order by id asc';
							$this->_db->setQuery( $query );
							$obj->answer[$j] = $this->_db->loadObjectList();
						}
						
						for($s=0;$s<count($qide);$s++){
						
							$index = array_search($qide[$s],$quizoptions['qids']); 
							
							$checked_answer=array();
							$text_answer=array();
							$drag_answer=array();
							$hotspotAns=array();

							$ans_explode=$quizoptions['aids'][$index];
							$anscheck_array=explode(',',$ans_explode);
							$txtans_array=explode(',',$quizoptions['text_value'][$index]);
							$dragans_array=explode(',',$quizoptions['drag_ans'][$index]);
							$hotspotAns_array=explode(',',$quizoptions['hotspotAns'][$index]);
							
							for($x=0;$x<count($anscheck_array);$x++){
								array_push($checked_answer,$anscheck_array[$x]);
							}
							for($x=0;$x<count($txtans_array);$x++){
								array_push($text_answer,$txtans_array[$x]);
							}
							for($x=0;$x<count($dragans_array);$x++){
								array_push($drag_answer,$dragans_array[$x]);
							}
							for($x=0;$x<count($hotspotAns_array);$x++){
								array_push($hotspotAns,$hotspotAns_array[$x]);
							}
							 
							$quespenttime=$quizoptions['qspenttime'][$index];
						}

						//$obj->limit=$index;
						$limit=$index;

						if($index==0){
							$obj->first=1;
						}
						else{
							$obj->first=0;
						}

					}

				}

				$obj->checked = $checked_answer;
				$obj->txtAns = $text_answer;
				$obj->dragOrd = implode(',',$drag_answer);
				$obj->hotspotAnswer = $hotspotAns;

				if($question_limit>1){
					$obj->quespenttime ='empty';
				}
				else{
					$obj->quespenttime = $quespenttime;
				}

				$livescore=$this->score();
				$obj->livescore = $livescore->score;
				$obj->maxscore = $livescore->maxscore;
				$obj->quiztype = $livescore->quiztype;


				if($random_question==1){
					if($question_limit==1) {
					  if($quespenttime>0 or $quespenttime==-1 ){
				
							$index = array_search($qide[0],$random_quizoption); 
							if($index !== false){
							array_splice($random_quizoption, $index, 1);
							}
						}
					}
					
					else{
						for($s=0;$s<count($qide);$s++){
							$index = array_search($qide[$s],$random_quizoption); 
							if($index !== false){
							array_splice($random_quizoption, $index, 1);
							}
						}
					}
					
					$session->set('random_quizoption'.$uniqvariable, $random_quizoption);		
				 }

				$session->set('quizoptions'.$uniqvariable, $quizoptions);
				$obj->result = "success";
				
				$obj->limit=$limit;
								
				$prepare_question_title=array();
				for($c=0;$c<count($obj->item);$c++){
					$p_title=JHtml::_('content.prepare', $obj->item[$c]->qtitle);
					array_push($prepare_question_title,$p_title);
				}
				$obj->prepare_question_title = $prepare_question_title;
				
				return $obj;
				
		} 
			

		function showresult() {
			
			$obj = new stdClass();
			$obj->result = "error";
			$limit=JRequest::getInt('limit_nextvariable', 0);
			$itemid = JRequest::getInt('id', 0);
			$session = JFactory::getSession();
			$uniqvariable = JRequest::getVar('uniqvariable','');
			
			if(!$session->has('quizoptions'.$uniqvariable))	{
				$obj->error = JText::_('PLEASE_CONTACT_ADMINISTRATOR');
				return $obj;			
			}
			
			$quizoptions = $session->get('quizoptions'.$uniqvariable);

			if($session->has('random_quizoption'.$uniqvariable)){
				$random_quizoption=$session->get('random_quizoption'.$uniqvariable);
			}else{ 
				$random_quizoption=array();
				$random_quizoption=$quizoptions['qids'];
			}
			
			$skipped_ids=array(0);
			$zero_answer_keys = array_keys(array_filter($quizoptions['aids'], function($item){return $item == 0;}));
			for($i=0;$i<count($zero_answer_keys);$i++){

				$qid=$quizoptions['qids'][$zero_answer_keys[$i]];
				array_push($skipped_ids,$qid);
			}
			
			$answered_ids=array_diff($quizoptions['qids'],$skipped_ids);
	

			$a=array();
			$query = ' SELECT * FROM #__vquiz_quizzes where id = '.$this->_db->quote($itemid);
			$this->_db->setQuery( $query );
			$quizzesresult = $this->_db->loadObject();
			
			$paging = $quizzesresult->paging;
			$questionreview_qlink = $quizzesresult->questionreview_qlink;
			$skipped_btn = $quizzesresult->skip_button;
			$prev_btn = $quizzesresult->prev_button;
			$random_question = $quizzesresult->random_question;
			$quiztype= $quizzesresult->quiztype;
			$correctans= $quizzesresult->questionreview_answer;
			$show_option= $quizzesresult->questionreview_option;
			$questionreview_question= $quizzesresult->questionreview_question;
			$questionreview= $quizzesresult->questionreview;
			$answers_type= $quizzesresult->answers_type;
			$answersheet_explanation=$quizzesresult->answersheet_explanation;
			$question_limit=$quizzesresult->paging_limit>1?$quizzesresult->paging_limit:1;
						
			$query =$this->_db->getQuery(true);
			$query->select('q.id,q.qtitle,q.explanation,q.hint,q.transcript,q.optiontype,q.text_field_ans,q.case_sensitive,q.hotspot_img, q.rectangle');
			$query->from($this->_db->quoteName('#__vquiz_question').' as q');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as qq on qq.questionid=q.id');
			$query->where('q.published=1 ');
			$query->where('qq.quizid ='.$this->_db->quote($itemid));
			
			if($questionreview==0){
				if($random_question==1)	{
					$qids = array_slice($random_quizoption, -$question_limit, $question_limit, true); 
					$query .=' and q.id IN ('.implode(',',$qids).')';
				}
				else
					$query .=' group by q.id  order by q.ordering asc limit '.$limit.','.$question_limit; 
			}else{
				
					
					if($questionreview_question==0){
						$query .=' and q.id IN ('.implode(',',$skipped_ids).')';
					}elseif($questionreview_question==1){
						$query .=' and q.id IN ('.implode(',',$answered_ids).')';
					}else{
						$query .=' and q.id IN ('.implode(',',$quizoptions['qids']).') ORDER BY FIELD(ID,'.implode(',',$quizoptions['qids']).')';
					}
					
			}

			$this->_db->setQuery( $query );
			$obj->item = $this->_db->loadObjectList();
			//$queryk = $query;

			$prepare_question_title=array();
			for($c=0;$c<count($obj->item);$c++){
				$p_title=JHtml::_('content.prepare', $obj->item[$c]->qtitle);
				array_push($prepare_question_title,$p_title);
			}
			$obj->prepare_question_title = $prepare_question_title; 
			
				
			for($j=0;$j<count($obj->item);$j++){
			
				$qustionid=$obj->item[$j]->id;
				$query = 'select * from #__vquiz_option where qid = '.$this->_db->quote($qustionid).' order by id asc';
				$this->_db->setQuery( $query );
		 
				$obj->answer[$j] = $this->_db->loadObjectList();

				$index = array_search($qustionid,$quizoptions['qids']);
				$a1=$quizoptions['aids'][$index];
				array_push($a,$a1)	;
				$obj->textarea_value[$j]=$quizoptions['textarea_value'][$index];
				$obj->text_value[$j]=$quizoptions['text_value'][$index];
				//$obj->hotspotAns[$j]=$hotspotAns_array[$j];
			}

			$obj->checked = $a;	
			$obj->quiztype = $quiztype;
			$obj->correctans=$correctans;
			$obj->prev_btn=$prev_btn;
			$obj->skipped_btn=$skipped_btn;
			$obj->answers_type=$answers_type;
			$obj->show_options=$show_option;
			$obj->questionreview_qlink=$questionreview_qlink;
			$obj->answersheet_explanation=$answersheet_explanation;
			
			if($session->has('checkresult_id'.$uniqvariable.'')){
					
				$checkresult_id =$session->get('checkresult_id'.$uniqvariable);
				$query = ' SELECT hotspotAns FROM #__vquiz_quizresult  WHERE id = '.$this->_db->quote($checkresult_id).' order by id asc ';
				
				$this->_db->setQuery($query);
				$result = $this->_db->loadObject();
				$hotspot_value_json=$result->hotspotAns; 
				$hotspotAns_array=json_decode($hotspot_value_json); 
				$obj->hotspotAns = $hotspotAns_array;
			}
			
			$obj->result = "success";
			//$obj->queryk = $queryk;
			return $obj;

		} 
		
		
		function questionexplanation() {
		
			$obj = new stdClass();
			$obj->result = "error";
			$limit=JRequest::getInt('limit_nextvariable', 0);
			$itemid = JRequest::getInt('id', 0);
			$session = JFactory::getSession();
			$uniqvariable = JRequest::getVar('uniqvariable','');
			
			/* if(!$session->has('quizoptions'.$uniqvariable))	{
				$obj->error = JText::_('PLEASE_CONTACT_ADMINISTRATOR');
				return $obj;			
			} */
			
			$quizoptions = $session->get('quizoptions'.$uniqvariable);

			if($session->has('random_quizoption'.$uniqvariable)){
				$random_quizoption=$session->get('random_quizoption'.$uniqvariable);
			}else{ 
				$random_quizoption=array();
				$random_quizoption=$quizoptions['qids'];
			}

			$a=array();
			$query = ' SELECT * FROM #__vquiz_quizzes where id = '.$this->_db->quote($itemid);
			$this->_db->setQuery( $query );
			$quizzesresult = $this->_db->loadObject();
			
			$paging = $quizzesresult->paging;
			$random_question = $quizzesresult->random_question;
			$quiztype= $quizzesresult->quiztype;
			$question_limit=$quizzesresult->paging_limit>1?$quizzesresult->paging_limit:1;
						
			$query =$this->_db->getQuery(true);
			$query->select('q.id,q.qtitle,q.explanation,q.hint,q.transcript,q.optiontype,q.text_field_ans,q.case_sensitive');
			$query->from($this->_db->quoteName('#__vquiz_question').' as q');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as qq on qq.questionid=q.id');
			$query->where('q.published=1 ');
			$query->where('qq.quizid ='.$this->_db->quote($itemid));

			if($random_question==1)	{
				$qids = array_slice($random_quizoption, -$question_limit, $question_limit, true); 
				$query .=' and q.id IN ('.implode(',',$qids).')';
			}
			else
				$query .=' group by q.id  order by q.ordering asc limit '.$limit.','.$question_limit; 
			
			$this->_db->setQuery( $query );
			$obj->item = $this->_db->loadObjectList();


			$prepare_question_title=array();
			for($c=0;$c<count($obj->item);$c++){
				$p_title=JHtml::_('content.prepare', $obj->item[$c]->qtitle);
				array_push($prepare_question_title,$p_title);
			}
			
			$obj->prepare_question_title = $prepare_question_title; 
 

			$obj->checked = $a;	
			$obj->quiztype = $quiztype;
			$obj->result = "success";
			return $obj;

		} 
		
		function questionhint() {
		
			$obj = new stdClass();
			$obj->result = "error";
			$limit=JRequest::getInt('limit_nextvariable', 0);
			$itemid = JRequest::getInt('id', 0);
			$session = JFactory::getSession();
			$uniqvariable = JRequest::getVar('uniqvariable','');
			
			
			$quizoptions = $session->get('quizoptions'.$uniqvariable);
			

			if($session->has('random_quizoption'.$uniqvariable)){
				$random_quizoption=$session->get('random_quizoption'.$uniqvariable);
			}else{ 
				$random_quizoption=array();
				$random_quizoption=$quizoptions['qids'];
			}

			$a=array();
			$query = ' SELECT * FROM #__vquiz_quizzes where id = '.$this->_db->quote($itemid);
			$this->_db->setQuery( $query );
			$quizzesresult = $this->_db->loadObject();
			
			$paging = $quizzesresult->paging;
			$random_question = $quizzesresult->random_question;
			$quiztype= $quizzesresult->quiztype;
			$question_limit=$quizzesresult->paging_limit>1?$quizzesresult->paging_limit:1;
						
			$query =$this->_db->getQuery(true);
			$query->select('q.id,q.qtitle,q.explanation,q.hint,q.transcript,q.optiontype,q.text_field_ans,q.case_sensitive');
			$query->from($this->_db->quoteName('#__vquiz_question').' as q');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as qq on qq.questionid=q.id');
			$query->where('q.published=1 ');
			$query->where('qq.quizid ='.$this->_db->quote($itemid));

			if($random_question==1)	{
				$qids = array_slice($random_quizoption, -$question_limit, $question_limit, true); 
				$query .=' and q.id IN ('.implode(',',$qids).')';
			}
			else
				$query .=' group by q.id  order by q.ordering asc limit '.$limit.','.$question_limit; 
			
			$this->_db->setQuery( $query );
			$obj->item = $this->_db->loadObjectList();


			$prepare_question_title=array();
			for($c=0;$c<count($obj->item);$c++){
				$p_title=JHtml::_('content.prepare', $obj->item[$c]->qtitle);
				array_push($prepare_question_title,$p_title);
			}
			
			$obj->prepare_question_title = $prepare_question_title; 
 

			$obj->checked = $a;	
			$obj->quiztype = $quiztype;
			$obj->result = "success";
			return $obj;

		}
		
		function questiontranscript() {
		
			$obj = new stdClass();
			$obj->result = "error";
			$limit=JRequest::getInt('limit_nextvariable', 0);
			$itemid = JRequest::getInt('id', 0);
			$session = JFactory::getSession();
			$uniqvariable = JRequest::getVar('uniqvariable','');
			
			
			$quizoptions = $session->get('quizoptions'.$uniqvariable);
			

			if($session->has('random_quizoption'.$uniqvariable)){
				$random_quizoption=$session->get('random_quizoption'.$uniqvariable);
			}else{ 
				$random_quizoption=array();
				$random_quizoption=$quizoptions['qids'];
			}

			$a=array();
			$query = ' SELECT * FROM #__vquiz_quizzes where id = '.$this->_db->quote($itemid);
			$this->_db->setQuery( $query );
			$quizzesresult = $this->_db->loadObject();
			
			$paging = $quizzesresult->paging;
			$random_question = $quizzesresult->random_question;
			$quiztype= $quizzesresult->quiztype;
			$question_limit=$quizzesresult->paging_limit>1?$quizzesresult->paging_limit:1;
						
			$query =$this->_db->getQuery(true);
			$query->select('q.id,q.qtitle,q.explanation,q.hint,q.transcript,q.optiontype,q.text_field_ans,q.case_sensitive');
			$query->from($this->_db->quoteName('#__vquiz_question').' as q');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as qq on qq.questionid=q.id');
			$query->where('q.published=1 ');
			$query->where('qq.quizid ='.$this->_db->quote($itemid));

			if($random_question==1)	{
				$qids = array_slice($random_quizoption, -$question_limit, $question_limit, true); 
				$query .=' and q.id IN ('.implode(',',$qids).')';
			}
			else
				$query .=' group by q.id  order by q.ordering asc limit '.$limit.','.$question_limit; 
			
			$this->_db->setQuery( $query );
			$obj->item = $this->_db->loadObjectList();


			$prepare_question_title=array();
			for($c=0;$c<count($obj->item);$c++){
				$p_title=JHtml::_('content.prepare', $obj->item[$c]->qtitle);
				array_push($prepare_question_title,$p_title);
			}
			
			$obj->prepare_question_title = $prepare_question_title; 
 

			$obj->checked = $a;	
			$obj->quiztype = $quiztype;
			$obj->result = "success";
			return $obj;

		}
			
			/*---Check Quiz Access--*/
			
			function quizzesdesc($itemid)
			{ 
			
				$user = JFactory::getUser();	
				$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
				$lang = JFactory::getLanguage();
				$app = JFactory::getApplication();
				$session = JFactory::getSession();
				
				
				$obj = new stdClass();
				$obj->result = "error";
				
				/*  Learning path check   */
				$learningId = JRequest::getInt('learningId',0);
				if($learningId){
					$obj->LPathAccess =1;
					$returnResult=$this->checkLearningAccess($itemid,$learningId,1);
					
					if($returnResult->restrictplay==1){
						$obj->access =1; 
						return $obj;
					}

					if($returnResult->play==1){
						$obj->LPathAccess =0;
						$obj->LPathMessage=JText::_('UNAUTH_ACCESS_FIRST_PLAY').$returnResult->fistPlay;
						$obj->access =0; 
						return $obj;
					}
					$NextLearningPathQuizPlay=$this->NextLearningPathQuizPlay($itemid,$learningId);
				 
					if($NextLearningPathQuizPlay->play==1){	
						$obj->LPathAccess =0;
						$obj->LPathMessage =$NextLearningPathQuizPlay->youCanaccess;
						$obj->access =0;
						return $obj;
					}
/* 					$query=$this->_db->getQuery(true);
					$query->select('lessons_order');
					$query->from($this->_db->quoteName('#__vquiz_learning'));
					$query->where('id='.$this->_db->quote($learningId));
					$this->_db->setQuery($query);
					$lessons_order=explode(',',$this->_db->loadResult());
					
					$query=$this->_db->getQuery(true);
					$query->select('quizes_order');
					$query->from($this->_db->quoteName('#__vquiz_learning'));
					$query->where('id='.$this->_db->quote($learningId));
					$this->_db->setQuery($query);
					$quizzes_order=explode(',',$this->_db->loadResult());
					
					$lessonId=0;
					$LessonLink='';
					$quizIndex=array_search($itemid,$quizzes_order);
					if($quizIndex>0){
						$lessonId=$lessons_order[$quizIndex-1];
						if($lessonId!=0){
							for($i=$quizIndex-1;$i>0;$i--){
								if($quizzes_order[$i]!=0){
									$lessonId=$lessons_order[$i+1];
									break;
								}
							}
							$LessonLink=JRoute::_('index.php?option=com_vquiz&view=lessons&layout=lessondetails&id='.$lessonId.'&learningId='.$learningId);
						}
					}

					$obj->beforeLesson=$lessonId;
					$obj->LessonLink=$LessonLink; */
				}
				
				/* if(!empty($quizzes_order)){
					
					$LearningQuizzes=explode(',',$quizzes_order);
					$QuizIndex=array_search($itemid,$LearningQuizzes);
					if($QuizIndex!==false){
						
					}
				} 
				*/
							
				$query="select access,access_token,attempt_count,count_ipaddress,attempt_delay,delay_periods,ipaddress_allow,play_users,set_price from #__vquiz_quizzes";	
				
				$where = array();
				
				$where[] = ' id = '.$this->_db->quote($itemid);
				$where[] = ' published = 1';
				$where[] = ' access in ('.implode(',', $user->getAuthorisedViewLevels()).')';
				if($app->getLanguageFilter())	{
					$where[] = ' language in ('.$this->_db->quote($lang->getTag()).', '.$this->_db->Quote('*').')';
				}
				$query .= ' where ' . implode(' and ', $where);
				$query .=' order by id asc'; //echo $query; //exit;
				$this->_db->setQuery($query);
				$result = $this->_db->loadObject();
				//print_r($result); 
				if(!empty($result)){
					$set_price = $result->set_price;
					$accessuser = $result->access;
					$access_token = $result->access_token;
					$attempt_count = $result->attempt_count;
					$count_ipaddress = $result->count_ipaddress;
					$attempt_delay = $result->attempt_delay;
					$delay_periods = $result->delay_periods;
					$ipaddress_allow = json_decode($result->ipaddress_allow);
					$play_users = explode(',',$result->play_users);
				}else{
					$set_price = 0;
					$access_token = '';
					$accessuser = '';
					$attempt_count = 0;
					$count_ipaddress = 0;
					$attempt_delay = 0;
					$delay_periods ='';
					$ipaddress_allow = '';
					$play_users = array();
				}
				
 		
				switch ($delay_periods) {
					case 'days':
					$days=1;
					break;
					case 'week':
					$days=7;
					break;
					case 'month':
					$days=30;
					break;
					case 'hour':
					$days=1/24;
					break;
					default:
					$days=0;
				}
				
				$atteptdate=$attempt_delay * $days;
				$atteptdate_tounix=$atteptdate * 24*60*60;
				
				$query='select starttime from #__vquiz_quizresult where userid ='.$this->_db->quote($user->id).' and quizid='.$this->_db->quote($itemid).' order by id desc Limit 1';	
				$this->_db->setQuery($query);
				$first_start_date = $this->_db->loadResult();

				//$curent_date=JFactory::getDate()->toUnix();
				$curent_date=strtotime(JFactory::getDate('now', JFactory::getConfig()->get('offset')));
				$next_attempt_date=strtotime($first_start_date)+$atteptdate_tounix;
				
				$query='select count(userid) from #__vquiz_quizresult where userid ='.$this->_db->quote($user->id).' and userid !=0 and quizid='.$this->_db->quote($itemid);	
				$this->_db->setQuery($query);
				
				$attemptresult = $this->_db->loadResult();
				
				$app = JFactory::getApplication('site');
				$access_keyword = $app->input->getVar('access','');
 
				if($access_token !='' and $access_keyword !== $access_token){
					$obj->access =1;
					return $obj;
				}	
				
				$Levels=$user->getAuthorisedViewLevels();

						/* if(in_array($accessuser,$Levels))
						{							
							if($attempt_count>0)
							{	
								if($attemptresult<$attempt_count){
									$obj->access =0;							
								}
								else{
									$obj->access =1;
								} 
								
								if($attempt_delay>0){
								
									if($curent_date>$next_attempt_date){
										$obj->access =0;							
									}
									else{
										$obj->access =1;
									} 
								}  
							}
							else{
								$obj->access =0;
							} */	

						 /* }
						else{
							$obj->access =1;
						} */

						if($accessuser==1){
							
							if($attempt_count>0)
							{ //echo 'k';
								if(isset($_COOKIE['vQuizPublicAccessCookie'.$itemid])){
									$publicattempt=$_COOKIE['vQuizPublicAccessCookie'.$itemid];//echo 'L'; echo $publicattempt;
								}else{
									$publicattempt=$attemptresult;
									setcookie("vQuizPublicAccessCookie".$itemid, $publicattempt, mktime (0, 0, 0, 12, 31, 2020),"/");//echo 'M';
								}
	 
								if($publicattempt<$attempt_count){
									$obj->access =0;		//echo 'k';						
								}
								else{
									$obj->access =1;
								} 
								
								if($attempt_delay>0){
								
									if($curent_date>$next_attempt_date){
										$obj->access =0;							
									}
									else{
										$obj->access =1;
									} 
								} 
								
							}
							else{
								$obj->access =0;
								setcookie("vQuizPublicAccessCookie".$itemid,0, time()-3600,"/");
							}
							
						}elseif(in_array($accessuser,$Levels))
						{	
							if($attempt_count>0)
							{	
								if($attemptresult<$attempt_count){
									$obj->access =0;							
								}
								else{
									$obj->access =1;
								} 
								
								if($attempt_delay>0){
								
									if($curent_date>$next_attempt_date){
										$obj->access =0;							
									}
									else{
										$obj->access =1;
									} 
								}  
							}
							else{
								$obj->access =0;
							}

						 }
						else{
							$obj->access =1;
						}
					/*---Check Server ip addrss---*/
					if($count_ipaddress==1)
						{	
							$ipaddress_user=$_SERVER['REMOTE_ADDR'];
							$query='select count(ip_address) from #__vquiz_quizresult where ip_address=' .$this->_db->quote($ipaddress_user).'and quizid='.$this->_db->quote($itemid);	
							$this->_db->setQuery($query);
							$attempt_ip_result = $this->_db->loadResult();
							if($attempt_ip_result<$attempt_count or $attempt_count==0)
							{
							$obj->access =0;							
							}
							else{
								$obj->access =1;
							} 
						}
					
					if(!empty($ipaddress_allow)){
						if(in_array($_SERVER['REMOTE_ADDR'],$ipaddress_allow)){
							$obj->access =0;
						}else{
							$obj->access =1;
						}
					}
					/*---Check user who assign this quiz for play---*/

					if(!empty($play_users) and $result->play_users!=''){
						
						$check_play_users=array_search($user->id,$play_users);
						if($check_play_users!=false){
							$obj->access =0;
						}else{
							$obj->access =1;
						}
					}
			  
			  if($set_price){ //echo 'B';
				
					$checkaccess = QuizHelper::quizaccess($itemid,$user->id);
					//print_r($set_price);
					if(!$checkaccess){
						$obj->access =1;
					}else{
								$obj->access =0;
					}
			  }
					$obj->result = "success"; //print_r($obj); exit;
					return $obj;
			}
			
 
			function getCategory_info(){
			
				$categoryid = JRequest::getInt('id',0);
				$query =' select path as title,meta_desc,meta_keyword';
				$query .=' from #__vquiz_category where id='.$this->_db->quote($categoryid);
				$this->_db->setQuery( $query );
				$result = $this->_db->loadObject();
				return $result;
			}
			
			function getChild_category()
			{
				$itemid = JRequest::getInt('id',0);
				$parent_id_array=array($itemid);
				$Children=$this->GetCategoriesWithChildren($parent_id_array);
				if($Children){
					$query ='select a.id , a.title , a.level,a.photopath ';
					$query .=' from #__vquiz_category As a ';
					$query .=' LEFT join #__vquiz_category AS b ON a.lft > b.lft AND a.rgt < b.rgt';
					
					$where = array();
					$where[] = 'a.id !=1';
					
					$where[] = 'a.id in ('.implode(',',$Children).')';
					$where[] = 'a.id !='.$itemid;
					$where[] = 'a.published=1';
					$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
					$query .= $filter;
					$query .=' group by a.id, a.title, a.level, a.lft, a.rgt, a.parent_id order by a.lft ASC';
			 

					$this->_db->setQuery($query);
					$result=$this->_db->loadObjectList();
					return $result;
				}
				
				return false;
			}

			function getDescription(){
			
				$user = JFactory::getUser();
				$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
				$app = JFactory::getApplication();
				$lang = JFactory::getLanguage();
				$id = JRequest::getInt('id',0);
				$lessonid = JRequest::getInt('lessonid',0);
				if($lessonid==0){
					$ckLessons=$this->CheckLessons();
					if($ckLessons->beforeLesson !=0){
						$app->redirect($ckLessons->LessonLink);
						return false;
					}
				}
				
				$query ='select id,description,title,set_price,price,lead_generate,lead_generate_mandatory,input_mobile,input_company,input_title,input_email,input_first_name,input_last_name,access_token from #__vquiz_quizzes';
				
				$where = array();
				
				$where[] =  ' id ='.$this->_db->quote($id);
				$where[] =  ' access in ('.implode(',', $user->getAuthorisedViewLevels()).')';
				$where[] = ' startpublish_date <= '.$this->_db->quote($date->format('Y-m-d')).' and (endpublish_date >= '.$date->format('Y-m-d').' or endpublish_date='.('0000-00-00').')';

				if($app->getLanguageFilter())	{
					$where[] = 'language in ('.$this->_db->quote($lang->getTag()).', '.$this->_db->Quote('*').')';
				}
				$query .= ' where ' . implode(' and ', $where);	
				$query .= ' and  published =1';
				$this->_db->setQuery($query);
				$result = $this->_db->loadObject();
				//print_r($result);exit;
				return $result;
 
			}
			
			function CheckLessons(){
				
				$learningId = JRequest::getInt('learningId',0);
				$itemid = JRequest::getInt('id',0);
				$obj = new stdClass();
				$query=$this->_db->getQuery(true);
				$query->select('lessionid');
				$query->from($this->_db->quoteName('#__vquiz_learning_lnq'));
				$query->where('id='.$this->_db->quote($learningId));
				$this->_db->setQuery($query);
				$lessons_order=$this->_db->loadColumn();
				//$lessons_order=explode(',',$this->_db->loadResult());
				
				$query=$this->_db->getQuery(true);
				$query->select('quizid');
				$query->from($this->_db->quoteName('#__vquiz_learning_lnq'));
				$query->where('id='.$this->_db->quote($learningId));
				$this->_db->setQuery($query);
				$quizzes_order=$this->_db->loadColumn();
				//$quizzes_order=explode(',',$this->_db->loadResult());
				
				$lessonId=0;
				$nextQuizId=0;
				$LessonLink='';
				$quizIndex=array_search($itemid,$quizzes_order);
		 
				if($quizIndex>0 and isset($lessons_order[$quizIndex-1])){
					$lessonId=$lessons_order[$quizIndex-1];
					if($lessonId!=0){
						for($i=$quizIndex-1;$i>0;$i--){
							if(isset($quizzes_order[$i]) and $quizzes_order[$i]!=0){
								$lessonId=$lessons_order[$i+1];
								break;
							}
						}
						$LessonLink=JRoute::_('index.php?option=com_vquiz&view=lessons&layout=lessondetails&id='.$lessonId.'&learningId='.$learningId);
					} 
				}
				
				$obj->beforeLesson=$lessonId;
				$obj->LessonLink=$LessonLink;
				
				return $obj;
			}
 
 
			function getShowresult(){ 
			
				    $user = JFactory::getUser();
					$session = JFactory::getSession();
             
                    $uniqvariable = JRequest::getVar('uniqvariable','');
					
					if($session->has('checkresult_id'.$uniqvariable.'')){
					
						$checkresult_id =$session->get('checkresult_id'.$uniqvariable);
						$query = ' SELECT r.* ,q.hint,q.transcript,q.title as quiztitle, q.description as quizdescription, q.answers_type as answers_type,q.correctans as  correctans,q.personality_type as personality_type,q.enable_questiongroup as enable_questiongroup,q.show_qgroup_title as show_qgroup_title,q.show_qgroup_description as show_qgroup_description,q.quiztype as quiztype,q.questionreview_qlink as questionreview_qlink FROM #__vquiz_quizresult as r left join  #__vquiz_quizzes as q on q.id=r.quizid WHERE r.id = '.$this->_db->quote($checkresult_id).' order by r.id asc ';  //order by r.id asc
					}
					else{
						$query = ' SELECT r.* ,q.hint,q.transcript,q.title as quiztitle, q.description as quizdescription, q.answers_type as answers_type,q.correctans as  correctans,q.personality_type as personality_type,q.enable_questiongroup as enable_questiongroup,q.show_qgroup_title as show_qgroup_title,q.show_qgroup_description as show_qgroup_description,q.quiztype as quiztype,q.questionreview_qlink as questionreview_qlink FROM #__vquiz_quizresult as r left join  #__vquiz_quizzes as q on q.id=r.quizid WHERE r.userid = '.$this->_db->quote($user->id).'  order by r.id asc';
					}
					
					$this->_db->setQuery( $query );
					$result = $this->_db->loadObject(); //print_r($result); exit;
					$quiztype=$result->quiztype;
					$quiztitle=$result->quiztitle;
					$quizdescription=$result->quizdescription;
					$hint=$result->hint;
					$transcript=$result->transcript; $questionreview_qlink=$result->questionreview_qlink;
					$drag_value_json=$result->drag_answer;
					$hotspot_value_json=$result->hotspotAns; 

					$query = 'select a.qid from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
					$this->_db->setQuery( $query );
					$question =$this->_db->loadColumn();//exit;
					
					$query = 'select a.answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
					$this->_db->setQuery( $query );
					$quiz_answers =$this->_db->loadColumn();
					
					$query = 'select a.comment from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
					$this->_db->setQuery( $query );
					$user_comment =$this->_db->loadColumn();
					
					$query = 'select a.text_answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
					$this->_db->setQuery( $query );
					$text_answer =$this->_db->loadColumn();
					
					$query = 'select a.textarea_answer from  #__vquiz_quizresult_qna as a left join #__vquiz_quizresult as r on a.resultid=r.id where r.id='.$this->_db->quote($result->id).' order by qna_id asc';
					$this->_db->setQuery( $query );
					$textarea_answer =$this->_db->loadColumn(); //textarea_score
			
					//$quiz_questions=$result->quiz_questions;
					//$quiz_answers=$result->quiz_answers;
					//$user_comments=$result->user_comment;
					//$textarea_value_json=$result->textarea_answer;
					//$text_value_json=$result->text_answer;
					
					
					//$question=json_decode($quiz_questions);
					//print_r($question);exit;
					//$answers=json_decode($quiz_answers);
					//$user_comment=json_decode($user_comments);
					//$textarea_answer=json_decode($textarea_value_json);
					//$text_answer=json_decode($text_value_json);
					
					$drag_answer=json_decode($drag_value_json);
					$hotspotAns=json_decode($hotspot_value_json); //print_r($hotspotAns); exit;

					$query1= ' SELECT correctans,answersheet_explanation,answers_type,answer_sheet_option FROM #__vquiz_quizzes  WHERE id = '.$this->_db->quote($result->quizid);
					$this->_db->setQuery( $query1);
					$result_quiz = $this->_db->loadObject();
					$answers_type=$result_quiz->answers_type;
					$answer_sheet_option=$result_quiz->answer_sheet_option;
					$answersheet_explanation=$result_quiz->answersheet_explanation;
					
					$qusetion_item = new stdClass(); //print_r($question); exit;
					
					for($j=0;$j<count($question);$j++){
					
						$query = 'select qtitle,explanation,optiontype,text_field_ans,case_sensitive,hotspot_img, rectangle  from #__vquiz_question where id = '.$this->_db->quote($question[$j]);
						$this->_db->setQuery( $query );
						$qusetion_item->question[$j] = $this->_db->loadObject();
												
						$query = 'select i.*,p.answer as personality_answer from #__vquiz_option as i left join #__vquiz_personality_message as p on i.personality_optionid=p.id where i.qid = '.$this->_db->quote($question[$j]).' order by id asc';
						$this->_db->setQuery( $query );
						
						$qusetion_item->options[$j] = $this->_db->loadObjectList();
							if($drag_answer[$j]!=""){
								$dragIds = explode(',',explode(':',$drag_answer[$j])[0]);
								$dragOrd = explode(',',explode(':',$drag_answer[$j])[1]);
								$arr = array();
								for($i = 0; $i<count($dragIds); $i++){
									$arr[$dragIds[$i]] = $dragOrd[$i];
								}
								sort($dragIds);
								ksort($arr);
								$dragIds = implode(',',$dragIds);
								$dragOrd = implode(',',$arr);
								$drag_answer[$j] = $dragIds.":".$dragOrd;
							}						
					}
					
					$qusetion_item->givenanswer =$quiz_answers;
					$qusetion_item->question_array = $question;
					$qusetion_item->quiztype = $quiztype;
					$qusetion_item->quiztitle = $quiztitle;
					$qusetion_item->quizdescription = $quizdescription; 
					$qusetion_item->answers_type = $answers_type;
					$qusetion_item->answer_sheet_option = $answer_sheet_option;
					$qusetion_item->answersheet_explanation = $answersheet_explanation;
					$qusetion_item->user_comment = $user_comment;	
					$qusetion_item->correctans = $result_quiz->correctans;
					$qusetion_item->text_answer = $text_answer;	
					$qusetion_item->textarea_answer = $textarea_answer;	
					$qusetion_item->drag_answer = $drag_answer;
					$qusetion_item->hotspotAns = $hotspotAns;
					$qusetion_item->hint = $hint;
					$qusetion_item->transcript = $transcript; $qusetion_item->questionreview_qlink = $questionreview_qlink;
					//print_r($qusetion_item);exit;
					return $qusetion_item;

			} 

			
		function score(){
			
		    $session = JFactory::getSession();
            $uniqvariable = JRequest::getVar('uniqvariable','');
			$quizid = JRequest::getInt('id', 0);
			
            if(!$session->has('quizoptions'.$uniqvariable))	{
                $obj->error = JText::_('INVALID_TOKEN');
                return $obj;			
            }
			
            $quizoptions = $session->get('quizoptions'.$uniqvariable);
			$query = 'select quiztype,answers_type from #__vquiz_quizzes where id = '.$this->_db->quote($quizid);
			$this->_db->setQuery( $query );
			$qresult = $this->_db->loadObject();
			
			$data = new stdClass();
			$datamaxscore=0;
			$data_score=0;			
			
			for($i=0;$i<count($quizoptions['qids']);$i++){	

				$countoption=false;
				$c=0;
				
				if($qresult->quiztype==1 || $qresult->quiztype==11)
				{
					 
					$data->quiztype=$qresult->quiztype;
					
					$countoption=false;
					$query = 'select id from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]).' and correct_ans = 1 order by id asc';
					$this->_db->setQuery( $query );
					$answers = $this->_db->loadColumn();
					
					
					$query = 'select optiontype,text_field_ans,case_sensitive,rectangle from #__vquiz_question where id = '.$this->_db->quote($quizoptions['qids'][$i]);
					$this->_db->setQuery( $query );
					$question_option = $this->_db->loadObject();
					
					$chek_option_type = $question_option->optiontype;
					
	
					$max_option_score=0;
					
					if($qresult->answers_type==2){
					
						$score_depend=$this->_score_depend_index;
						
						$query = 'select category_score  from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]);
						$this->_db->setQuery( $query );
						$category_score = $this->_db->loadColumn();

						for($g=0;$g<count($category_score);$g++){
						
							$max_option_score_aa =json_decode($category_score[$g]);
							if(!empty($max_option_score_aa)){
								$max_option_score +=$max_option_score_aa[$score_depend];
							}
						} 
						 
					}elseif($chek_option_type==2 and $qresult->answers_type==0){
						
						$query = 'select options_score from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]);
						$this->_db->setQuery( $query );
						$calculate_score = $this->_db->loadColumn();
		
						for($n=0;$n<count($calculate_score);$n++){
							$max_option_score +=$calculate_score[$n];
						}
					
					}else{
						
						$query = 'select max(options_score) from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]);
						$this->_db->setQuery( $query );
						$max_option_score = $this->_db->loadResult();
						
					}
					
					if($qresult->answers_type==1 OR $qresult->answers_type==2){
						$datamaxscore += $quizoptions['score'][$i]*$max_option_score;
					}else{
						$datamaxscore += $quizoptions['score'][$i];
					}

					$data->maxscore =round($datamaxscore,2);
					
					if($quizoptions['aids'][$i]!=''){

						if($qresult->answers_type==1){
							
							$xx=explode(',',$quizoptions['aids'][$i]);							
							$query = 'select options_score from #__vquiz_option where id IN ('.implode(',',$xx).')';
							$this->_db->setQuery( $query );
							$differnetscore = $this->_db->loadObjectList();
							
							$differnetscore_add=0;
							for($g=0;$g<count($differnetscore);$g++){
								$differnetscore_add +=$differnetscore[$g]->options_score;
							}
							
							$data_score +=$differnetscore_add*$quizoptions['score'][$i];
							
						}elseif($qresult->answers_type==2){

							$score_depend=$this->_score_depend_index;
							
							$xx=explode(',',$quizoptions['aids'][$i]);							
							$query = 'select category_score  from #__vquiz_option where id IN ('.implode(',',$xx).')';
							$this->_db->setQuery( $query );
							$category_score = $this->_db->loadColumn();
							$differnetscore_add=0;
							for($g=0;$g<count($category_score);$g++){
								$differnetscore_add_aa =json_decode($category_score[$g]);
								if(!empty($differnetscore_add_aa)){
									$differnetscore_add +=$differnetscore_add_aa[$score_depend];
								}
							} 

							$data_score +=$differnetscore_add*$quizoptions['score'][$i]; 	
							
						}else{	
						
							$data->answers_type=0;						
							$xx=explode(',',$quizoptions['aids'][$i]);
			 				
							for($k=0;$k<count($xx);$k++){
									if(in_array($xx[$k],$answers) and count($xx)==count($answers)){
										$countoption=true;
										$c=$c+1;
									}
									else
									$countoption=false;
							}
							
							if($countoption==true and $c==count($answers)) { 
								//$data_score +=$quizoptions['score'][$i]-$quizoptions['expire_timescore'][$i];
								$data_score +=$quizoptions['score'][$i];
							 
							}
							else {
								$data_score -=$quizoptions['penalty'][$i];
							}
							
							$data_score =round($data_score,2);

						}
						
						
						
						
					}elseif(@$quizoptions['text_value'][$i]!=''){
					
						$text_field_ans = trim($question_option->text_field_ans);
						if($question_option->case_sensitive==1){
						
							if($text_field_ans === trim($quizoptions['text_value'][$i])){ 
							$data_score +=$quizoptions['score'][$i];
							}
							
						}else{
							if(ucwords($text_field_ans) === ucwords(trim($quizoptions['text_value'][$i]))){ 
							$data_score +=$quizoptions['score'][$i];
							}
						}

					}elseif(@$quizoptions['hotspotAns'][$i]!=''){
						$rectangle = $question_option->rectangle;
						$hotspotAns = explode(':',$quizoptions['hotspotAns'][$i]);
						$points = explode(':',$rectangle);
						$p1 = explode(',',$points[0]);
						$p2 = explode(',',$points[1]);
						if(($p1[0]<=$hotspotAns[0] && $hotspotAns[0]<=$p2[0]) && ($p1[1]<=$hotspotAns[1] && $hotspotAns[1]<=$p2[1]))
							$data_score +=$quizoptions['score'][$i];
					}elseif(@$quizoptions['hotspotAns'][$i]!=''){
						$rectangle = $question_option->rectangle;
						$hotspotAns = explode(':',$quizoptions['hotspotAns'][$i]);
						$points = explode(':',$rectangle);
						$p1 = explode(',',$points[0]);
						$p2 = explode(',',$points[1]);
						if(($p1[0]<=$hotspotAns[0] && $hotspotAns[0]<=$p2[0]) && ($p1[1]<=$hotspotAns[1] && $hotspotAns[1]<=$p2[1]))
							$data_score +=$quizoptions['score'][$i];
					}elseif(@$quizoptions['drag_ans'][$i]!=':'){
					
						$query = 'select id, correct_ans from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]);
						$this->_db->setQuery( $query );
						$dragAns = $this->_db->loadObjectList();
						$dragAnsOrd = array();
						foreach($dragAns as $ind=>$dragA){
							$dragA->correct_ans = $dragAns[$dragA->correct_ans-1]->id;
							$dragAnsOrd[$dragA->id] = $dragA->correct_ans;
						}
						$dragIds = explode(',',explode(':',$quizoptions['drag_ans'][$i])[0]);
						$dragOrd = array();
						foreach($dragIds as $id){
							array_push($dragOrd,$dragAnsOrd[$id]);
						}
						$dragOrd = implode(',',$dragOrd);
						$dragIds = implode(',',$dragIds);
						$dragOrder = $dragIds.":".$dragOrd;
						if($dragOrder == $quizoptions['drag_ans'][$i]){ 
							$data_score +=$quizoptions['score'][$i];
						}

					}else{

						$data_score +=0;
						$data_score =round($data_score,2);

					}
				 }
				 
				 elseif($qresult->quiztype==2){
						$data->quiztype=2;
						$data_score =0;
						$data->maxscore =0;				 
				   }
				 else{
						$data->quiztype=3;
						$data_score =0;
						$data->maxscore =0;			   
				  }
				  
				 $data->score =$data_score;
	
			}

			return $data;
		}
		
	function QuestionGroupscore(){
			
		    $session = JFactory::getSession();
            $uniqvariable = JRequest::getVar('uniqvariable','');
			$quizid = JRequest::getInt('id', 0);
			
			$data = new stdClass();
			$data_score=0;	
			$question_groups_id=array();
			$question_groups_score=array();	
			
            if(!$session->has('quizoptions'.$uniqvariable))	{
                $obj->error = JText::_('INVALID_TOKEN');
                return $obj;			
            }
			
            $quizoptions = $session->get('quizoptions'.$uniqvariable);
			
			$query=$this->_db->getQuery(true);
			$query->select(' q.id,q.questiongroup ');
			$query->from($this->_db->quoteName('#__vquiz_question'). ' as q ');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as qq on qq.questionid=q.id ');
			$query->where('qq.quizid='.$this->_db->quote($quizid));
			$query->where('q.id IN ('.implode(',',$quizoptions['qids']).')');
			$query->order('FIELD (q.id,'.implode(',',$quizoptions['qids']).')');
			$this->_db->setQuery($query);
			$q_groups_id=$this->_db->loadObjectList(); 
			
			$query = 'select quiztype,answers_type from #__vquiz_quizzes where id = '.$this->_db->quote($quizid);
			$this->_db->setQuery( $query );
			$qresult = $this->_db->loadObject();
			$grp_score=array();
			$data = new stdClass();
			$datamaxscore=0;
			$data_score=0;			
			
			for($i=0;$i<count($quizoptions['qids']);$i++){	

				$countoption=false;
				$c=0;
				
				if($qresult->quiztype==1 || $qresult->quiztype==11)
				{
					 
					$data->quiztype=$qresult->quiztype;
					
					$countoption=false;
					$query = 'select id from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]).' and correct_ans = 1 order by id asc';
					$this->_db->setQuery( $query );
					$answers = $this->_db->loadColumn();
					
					
					$query = 'select optiontype,text_field_ans,case_sensitive,rectangle from #__vquiz_question where id = '.$this->_db->quote($quizoptions['qids'][$i]);
					$this->_db->setQuery( $query );
					$question_option = $this->_db->loadObject();
					
					$chek_option_type = $question_option->optiontype;
					
	
					$max_option_score=0;
					
					if($qresult->answers_type==2){
					
						$score_depend=$this->_score_depend_index;
						
						$query = 'select category_score  from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]);
						$this->_db->setQuery( $query );
						$category_score = $this->_db->loadColumn();

						for($g=0;$g<count($category_score);$g++){
						
							$max_option_score_aa =json_decode($category_score[$g]);
							if(!empty($max_option_score_aa)){
								$max_option_score +=$max_option_score_aa[$score_depend];
							}
						} 
						 
					}elseif($chek_option_type==2 and $qresult->answers_type==0){
						
						$query = 'select options_score from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]);
						$this->_db->setQuery( $query );
						$calculate_score = $this->_db->loadColumn();
		
						for($n=0;$n<count($calculate_score);$n++){
							$max_option_score +=$calculate_score[$n];
						}
					
					}else{
						
						$query = 'select max(options_score) from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]);
						$this->_db->setQuery( $query );
						$max_option_score = $this->_db->loadResult();
						
					}
					
					if($qresult->answers_type==1 OR $qresult->answers_type==2){
						$datamaxscore += $quizoptions['score'][$i]*$max_option_score;
					}else{
						$datamaxscore += $quizoptions['score'][$i];
					}

					$data->maxscore =round($datamaxscore,2);
					
					if($quizoptions['aids'][$i]!=''){

						if($qresult->answers_type==1){
							
							$xx=explode(',',$quizoptions['aids'][$i]);							
							$query = 'select options_score from #__vquiz_option where id IN ('.implode(',',$xx).')';
							$this->_db->setQuery( $query );
							$differnetscore = $this->_db->loadObjectList();
							
							$differnetscore_add=0;
							for($g=0;$g<count($differnetscore);$g++){
								$differnetscore_add +=$differnetscore[$g]->options_score;
							}
							
							$data_score =$differnetscore_add*$quizoptions['score'][$i];
							
						}elseif($qresult->answers_type==2){

							$score_depend=$this->_score_depend_index;
							
							$xx=explode(',',$quizoptions['aids'][$i]);							
							$query = 'select category_score  from #__vquiz_option where id IN ('.implode(',',$xx).')';
							$this->_db->setQuery( $query );
							$category_score = $this->_db->loadColumn();
							$differnetscore_add=0;
							for($g=0;$g<count($category_score);$g++){
								$differnetscore_add_aa =json_decode($category_score[$g]);
								if(!empty($differnetscore_add_aa)){
									$differnetscore_add +=$differnetscore_add_aa[$score_depend];
								}
							} 

							$data_score =$differnetscore_add*$quizoptions['score'][$i]; 	
							
						}else{	
						
							$data->answers_type=0;						
							$xx=explode(',',$quizoptions['aids'][$i]);
			 				
							for($k=0;$k<count($xx);$k++){
									if(in_array($xx[$k],$answers) and count($xx)==count($answers)){
										$countoption=true;
										$c=$c+1;
									}
									else
									$countoption=false;
							}
							
							if($countoption==true and $c==count($answers)) { 
								//$data_score +=$quizoptions['score'][$i]-$quizoptions['expire_timescore'][$i];
								$data_score =$quizoptions['score'][$i];
							 
							}
							else {
								$data_score -=$quizoptions['penalty'][$i];
							}
							
							$data_score =round($data_score,2);

						}
						
						
						
						
					}elseif(@$quizoptions['text_value'][$i]!=''){
					
						$text_field_ans = trim($question_option->text_field_ans);
						if($question_option->case_sensitive==1){
						
							if($text_field_ans === trim($quizoptions['text_value'][$i])){ 
							$data_score =$quizoptions['score'][$i];
							}
							
						}else{
							if(ucwords($text_field_ans) === ucwords(trim($quizoptions['text_value'][$i]))){ 
							$data_score =$quizoptions['score'][$i];
							}
							
						}

					}elseif(@$quizoptions['hotspotAns'][$i]!=''){
						$rectangle = $question_option->rectangle;
						$hotspotAns = explode(':',$quizoptions['hotspotAns'][$i]);
						$points = explode(':',$rectangle);
						$p1 = explode(',',$points[0]);
						$p2 = explode(',',$points[1]);
						if(($p1[0]<=$hotspotAns[0] && $hotspotAns[0]<=$p2[0]) && ($p1[1]<=$hotspotAns[1] && $hotspotAns[1]<=$p2[1]))
							$data_score =$quizoptions['score'][$i];
					}elseif(@$quizoptions['drag_ans'][$i]!=':'){
					
						$query = 'select id, correct_ans from #__vquiz_option where qid = '.$this->_db->quote($quizoptions['qids'][$i]);
						$this->_db->setQuery( $query );
						$dragAns = $this->_db->loadObjectList();
						$dragAnsOrd = array();
						foreach($dragAns as $ind=>$dragA){
							$dragA->correct_ans = $dragAns[$dragA->correct_ans-1]->id;
							$dragAnsOrd[$dragA->id] = $dragA->correct_ans;
						}
						$dragIds = explode(',',explode(':',$quizoptions['drag_ans'][$i])[0]);
						$dragOrd = array();
						foreach($dragIds as $id){
							array_push($dragOrd,$dragAnsOrd[$id]);
						}
						$dragOrd = implode(',',$dragOrd);
						$dragIds = implode(',',$dragIds);
						$dragOrder = $dragIds.":".$dragOrd;
						if($dragOrder == $quizoptions['drag_ans'][$i]){ 
							$data_score =$quizoptions['score'][$i];
						}

					}else{

						$data_score =0;
						$data_score =round($data_score,2);

					}
				 }
				 
				 elseif($qresult->quiztype==2){
						$data->quiztype=2;
						$data_score =0;
						$data->maxscore =0;				 
				   }
				 else{
						$data->quiztype=3;
						$data_score =0;
						$data->maxscore =0;			   
				  }
				  
				 $data->score =$data_score;
					$grp_score[$i]=$data_score;
			}
			
					
					$a = array_unique($quizoptions['qgroupids']);

					$a = array_combine($a, array_fill(0, count($a), 0));
					foreach($quizoptions['qgroupids'] as $k=>$v) {

					 $a[$v] += $grp_score[$k];

					}
					return json_encode($a);
				
					
		}	
			function share_snapshot()
			{
				$obj = new stdClass();
				$obj->result = "error";
				$img_val= JRequest::getVar('img_data','');
				$image_tmp=substr($img_val, strpos($img_val, ",")+1);

				$foldername=JPATH_SITE.'/components/com_vquiz/assets/images/shareresult';
				
				if (!JFolder::exists($foldername)) 
				{
					JFolder::create($foldername);
				}

				$image_name=JText::_('Quizresult.png');
				$name=$foldername.'/'.$image_name;
				$unencodedData=base64_decode($image_tmp);

				file_put_contents($name, $unencodedData);
				$thumb = new Imagick();
				$thumb->readImage($name);    
				$thumb->resizeImage(500,300,Imagick::FILTER_LANCZOS,1);
				$thumb->writeImage($name);
				$thumb->clear();
				$thumb->destroy(); 
				move_uploaded_file($img_resize, $name);
				$obj->result = "success";
				return $obj;
			} 

			function getConfiguration()
			{
				$query='select * from #__vquiz_configuration';
				$this->_db->setQuery($query);
				$result = $this->_db->loadObject();
				return $result;
			}
			
			
			function getQuizCategory()
			{
				$itemid=JRequest::getInt('id',0);
				
				$query = ' SELECT catid,ordering FROM #__vquiz_quizzes where id = '.$this->_db->quote($itemid);
				$this->_db->setQuery( $query );
				$categoryid = $this->_db->loadObject();
				
				return $categoryid;
			}

			function getNextQuiz($condition)
			{
				
				$learningId = JRequest::getInt('learningId',0);
				$itemid = JRequest::getInt('id',0);
				
				//echo $learningId; echo $itemid; exit;
				
				if($learningId){
										
					$query=$this->_db->getQuery(true);
					$query->select('quizid');
					$query->from($this->_db->quoteName('#__vquiz_learning_lnq'));
					$query->where('learningid='.$this->_db->quote($learningId).' order by ordering asc');					
					
					$this->_db->setQuery($query);
					$quizzes_order=$this->_db->loadColumn();
					
					$quizids=array_values(array_diff($quizzes_order,array(0)));
		
					$quizindex=array_search($itemid,$quizids);
					
					if($condition==1){
						$quizid=isset($quizids[$quizindex+1])?$quizids[$quizindex+1]:0;
					}else{
						$quizid=isset($quizids[$quizindex-1])?$quizids[$quizindex-1]:0;
					}
			
					return $quizid;
				
				}

				$categoryid=$this->getQuizCategory();
				$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
				$lang = JFactory::getLanguage();
				$user = JFactory::getUser();
				$app  = JFactory::getApplication();
								
				$query = ' select id FROM #__vquiz_quizzes';
				$where[] = ' catid = '.$this->_db->quote($categoryid->catid);
				if($condition==1){
					$where[] = ' ordering >'.$this->_db->quote($categoryid->ordering);
				}else{
					$where[] = ' ordering <'.$this->_db->quote($categoryid->ordering);
				}
				$query .= ' where ' . implode(' and ', $where);
				
				if($condition==1){
					$query .= 'order by ordering asc limit 1'; 
				}else{
					$query .= 'order by ordering desc limit 1'; 
				}
				
				$this->_db->setQuery( $query );
				$quizid = $this->_db->loadResult();
				
				/* $quizzesdesc_get=$this->quizzesdesc($quizid);
				$access_result_check=$quizzesdesc_get->access;
 
				if($access_result_check==1){
					$quizid=0;	
				} */

				return $quizid;
				
			}

			
			function SaveLeadUserInfo(){
				
					$quizid=JRequest::getInt('quizid', 0);
					$user_fname = JRequest::getVar('user_fname','');
					$user_lname = JRequest::getVar('user_lname','');
					$user_company = JRequest::getVar('user_company','');
					$user_title = JRequest::getVar('user_title','');
					$user_email = JRequest::getVar('user_email','');
					$user_mobile = JRequest::getVar('user_mobile','');
					
				$uniqvariable=JRequest::getVar('uniqvariable','');
				$session = JFactory::getSession();
				
				if($session->has('checkresult_id'.$uniqvariable) and $uniqvariable!=''){
					$resultid =$session->get('checkresult_id'.$uniqvariable);
				}else{
					$resultid=0;
				}
				
				$insert = new stdClass();
				$insert->id = null;
				$insert->quizid = $quizid;
				$insert->resultid = $resultid;
				$insert->user_fname = $user_fname;
				$insert->user_lname = $user_lname;
				$insert->user_company = $user_company;
				$insert->user_title = $user_title;
				$insert->user_email = $user_email;
				$insert->user_mobile = $user_mobile;
				$insert->created = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
				$result =$this->_db->insertObject('#__vquiz_leads', $insert);
				$lead_user_name=$user_fname.' '.$user_lname;
				//echo $lead_user_name;exit;
				$session->set('lead_user_name'.$quizid, $lead_user_name);
				if($resultid==0){
					$leade_generte_id = $this->_db->insertid();
					$session->set('leade_generte_id'.$quizid, $leade_generte_id);
				}
		
				return $result;
				
			}
			
			
			/*Learning path quiz result save */
			function SaveLearningPathResult($quizid,$resultid){
				
				$learningId=JRequest::getInt('learningId',0);
				$session=JFactory::getSession();
				$user=JFactory::getUser();
				
				$obj=new stdClass();
				$obj->success=0;

				if($learningId){

					$UniqLearningPath='onThePlayvQuizLearningPath'.$learningId;
									
					if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
						$UniqLearningPath=$_COOKIE['vQuizLearningPath'.$UniqLearningPath];
					}else{
						setcookie("vQuizLearningPath".$UniqLearningPath, $UniqLearningPath, mktime (0, 0, 0, 12, 31, 2020),"/");
					}
					

					$insert = new stdClass();
					$insert->id = null;
					$insert->learning_id = $learningId;
					$insert->quizid = $quizid;
					$insert->resultid = $resultid;
					if($user->id!=0) {
						$insert->userid = $user->id;
						$insert->cookieId = null;

					}else{//if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
						$insert->userid =0;
						$insert->cookieId = $UniqLearningPath;
					}

					$insert->created = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
					$result =$this->_db->insertObject('#__vquiz_learning_playedquizzes', $insert);
					if($result){
						 $CheckLastPlayuiz=$this->checkLearningAccess($quizid,$learningId,0);
						 $obj->LastPlayQuiz=$CheckLastPlayuiz->LastPlayQuiz;
					}
				}
				return $obj;
			}
			
			/*Check access for quiz learning paths*/
			
			function checkLearningAccess($quizid,$learningId,$asset){
				
 				$user=JFactory::getUser();
				$UniqLearningPath='onThePlayvQuizLearningPath'.$learningId;
				$obj=new stdClass();
				
				$obj->restrictplay=0;
				
				if($asset==1 and $this->CheckAccess($learningId)!=1){
					$obj->restrictplay=1;
					return $obj;
				}
				
				$query=$this->_db->getQuery(true);
				$query->select('quizid');
				$query->from($this->_db->quoteName('#__vquiz_learning_playedquizzes'));
				$query->where('learning_id='.$this->_db->quote($learningId));
				if($user->id!=0) {
					$query->where('userid='.$this->_db->quote($user->id));
				}else if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
					$cookieId = $_COOKIE['vQuizLearningPath'.$UniqLearningPath];
					$query->where('cookieId='.$this->_db->quote($cookieId));
				}
				$query->where('played = 0');
				$this->_db->setQuery($query);
				$result_quizid=$this->_db->loadColumn();

				/* $query=$this->_db->getQuery(true);
				$query->select('quizes_order');
				$query->from($this->_db->quoteName('#__vquiz_learning'));
				$query->where('id='.$this->_db->quote($learningId));
				$this->_db->setQuery($query);
				$quizesorder=$this->_db->loadResult(); */
				//$quizes_order=explode(',',$quizesorder);
							
				$query  ='  select quizid from #__vquiz_learning_lnq';
				$query .= ' where learningid ='.$learningId;
				$query .= ' ORDER BY id asc';
				$this->_db->setQuery( $query);		
				$quizesorder = $this->_db->loadColumn();

				if(!empty($quizesorder)){
					$query_id  ='  select id from #__vquiz_quizzes';
					$query_id .= ' where id in ('.implode(',',$quizesorder).')';
					$query_id .= ' and published=1';
					$query_id .= ' ORDER BY FIELD(id,'.implode(',',$quizesorder).')';
					$this->_db->setQuery( $query_id );		
					$quizes_order = $this->_db->loadColumn();
				}else{
					$quizes_order=array();
				}

				$remain_playquizId=array_diff($quizes_order,$result_quizid);
				$quiz_Index=array_search($quizid,$quizes_order);

				if(!empty($remain_playquizId)){
					
					$remain_playquizId_key=array_keys($remain_playquizId);
					
					$obj->LastPlayQuiz=0;

				}else{					
						$remain_playquizId_key[0]=0;
						$obj->LastPlayQuiz=1;
					
						//if($asset==0){

							$CheckLearningQuizPass=$this->CheckLearningQuizPass($quizid,$learningId);
							$CheckQuizPass=$CheckLearningQuizPass->passed;
							
						/* }else{
							$CheckQuizPass=0;
						} */
						
						
						if($CheckQuizPass==1){
					
							$query=$this->_db->getQuery(true);
							$query->select('played_id');
							$query->from('#__vquiz_learning_result');
							if($user->id!=0) {
								$query->where('userid='.$this->_db->quote($user->id));
							}else if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
								$cookieId = $_COOKIE['vQuizLearningPath'.$UniqLearningPath];
								$query->where('cookieId='.$this->_db->quote($cookieId));
							}
							$query->where('learning_id ='.$this->_db->quote($learningId));
							$query->where('lession_id = 0');
							$query->order('id desc');
							$query->setLimit(1);
							$this->_db->setQuery($query);
							$Last_played_id=$this->_db->loadResult();
							
							if($Last_played_id==1 OR $Last_played_id==''){
								
								$insert_final = new stdClass();
								$insert_final->id = null;
								$insert_final->played_id =0;
								$insert_final->learning_id = $learningId;
								if($user->id!=0) {
									$insert_final->userid = $user->id;
									$insert_final->cookieId = null;
								}else{
									$insert_final->userid =0;
									$insert_final->cookieId = $UniqLearningPath;
								}
								$insert_final->created = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
								$result =$this->_db->insertObject('#__vquiz_learning_result', $insert_final);
								//$played_id_LastInertid = $this->_db->insertid();
								
								//save notification on completing Learning Path
																
								if($this->_db->insertid()){ 
					
									$data_arr = array();
									$data_arr['itemid'] = $this->_db->insertid();
									$data_arr['notification_type'] = 15;
										
									if(QuizHelper::checkNotification($data_arr['notification_type'])){
										$data_arr['notify_users'] = QuizHelper::findUsersToNotify('notify_complete_lpath');
										$data_arr['enotify_users'] = QuizHelper::findUsersToEnotify('enotify_complete_lpath');
										//print_r($data_arr); exit;
										QuizHelper::sendNotification($data_arr);
									}
								
								}							
								
								
							}
							
							
							if($this->CheckAccess($learningId)==1){
								if($user->id!=0) {
									
									$queryUpdate = 'update #__vquiz_learning_playedquizzes set played=1 where userid='.$this->_db->quote($user->id);
									$queryUpdate .= ' and learning_id='.$this->_db->quote($learningId);
									$this->_db->setQuery( $queryUpdate );
									$this->_db->execute();	
									
								}else if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){

									$queryUpdate = 'update #__vquiz_learning_playedquizzes set played=1 where  cookieId ='.$this->_db->quote($UniqLearningPath);
									$queryUpdate .= ' and learning_id='.$this->_db->quote($learningId);
									$this->_db->setQuery( $queryUpdate );
									$this->_db->execute();	
								} 
								
								$queryUpdate_playedID = 'update #__vquiz_learning_result set played_id=1  where   learning_id ='.$this->_db->quote($learningId).' AND lession_id = 0 ';
								$this->_db->setQuery( $queryUpdate_playedID );
								$this->_db->execute();	
							}
							
 
						}
					}

					if($remain_playquizId_key[0]==$quiz_Index OR in_array($quizid,$result_quizid)){
						$obj->play=0;
					}else{
						$obj->play=1;
						$query=$this->_db->getQuery(true);
						$query->select('title');
						$query->from($this->_db->quoteName('#__vquiz_quizzes'));
						$query->where('id='.$this->_db->quote($quizes_order[$remain_playquizId_key[0]]));
						$this->_db->setQuery($query);
						$title=$this->_db->loadResult();
						$obj->fistPlay=$title;
					}

				return $obj;
			}
			
			/*---Check Learning Path Access--*/
	
			function CheckAccess($learningId){ 
		 
				$user = JFactory::getUser();	
				$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
				$lang = JFactory::getLanguage();
				$app = JFactory::getApplication();
 
				$UniqLearningPath='onThePlayvQuizLearningPath'.$learningId;
				
				$query = ' SELECT i.access,i.attempt_count,i.attempt_delay,i.attempt_delay_param,i.ipaddress_allow as ipaddress FROM #__vquiz_learning as i ';
		 
				$where = array();
				
				$where[] = ' i.id = '.$this->_db->quote($learningId);
				$where[] = ' i.published = 1';
				$where[] = ' i.access in ('.implode(',', $user->getAuthorisedViewLevels()).')';
				if($app->getLanguageFilter())	{
					$where[] = ' i.language in ('.$this->_db->quote($lang->getTag()).', '.$this->_db->Quote('*').')';
				}
				$query .= ' where ' . implode(' and ', $where);
				$query .=' order by i.id asc';
				$this->_db->setQuery($query);
				$result = $this->_db->loadObject();
				
				if(!empty($result)){
					$accessuser = $result->access;
					$attempt_count = $result->attempt_count;
					$attempt_delay = $result->attempt_delay;
					$delay_periods = $result->attempt_delay_param;
					$ipaddress_allow = explode(',',$result->ipaddress);
				}else{
					$accessuser = '';
					$attempt_count = 0;
					$attempt_delay = 0;
					$delay_periods ='';
					$ipaddress_allow = '';
					return false;
				}
		 
				switch ($delay_periods) {
					case 'days':
					$days=1;
					break;
					case 'week':
					$days=7;
					break;
					case 'month':
					$days=30;
					break;
					case 'hour':
					$days=1/24;
					break;
					default:
					$days=0;
				}
				
				$attemptdate=$attempt_delay * $days;
				$attemptdate_tounix=$attemptdate * 24*60*60;

				$query=$this->_db->getQuery(true);
				$query->select('created');
				$query->from('#__vquiz_learning_playedquizzes');
				if($user->id!=0) {
					$query->where('userid='.$this->_db->quote($user->id));
				}else if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
					$cookieId = $_COOKIE['vQuizLearningPath'.$UniqLearningPath];
					$query->where('cookieId='.$this->_db->quote($cookieId));
				}
				$query->where('learning_id ='.$this->_db->quote($learningId));
				$query->where('played = 1');
				$query->order('id asc');
				$query->setLimit(1);
				
				$this->_db->setQuery($query);
				$first_start_date=$this->_db->loadResult();

				$curent_date=strtotime(JFactory::getDate('now', JFactory::getConfig()->get('offset')));
				$next_attempt_date=strtotime($first_start_date)+$attemptdate_tounix;
				
				$query=$this->_db->getQuery(true);
				$query->select('count(learning_id )');
				$query->from('#__vquiz_learning_playedquizzes');//vquiz_learning_result
				if($user->id!=0) {
					$query->where('userid='.$this->_db->quote($user->id));
				}else if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
					$cookieId = $_COOKIE['vQuizLearningPath'.$UniqLearningPath];
					$query->where('cookieId='.$this->_db->quote($cookieId));
				}
				$query->where('learning_id ='.$this->_db->quote($learningId));
				//$query->where('lession_id = 0');
				$this->_db->setQuery($query);
				$attemptresult=$this->_db->loadResult(); 
 
							if($attempt_count>0)
							{	
								if($attemptresult<$attempt_count){
									$access_path =1;							
								}
								else{
									$access_path =0;
								} 
								
								if($attempt_delay>0){
								
									if($curent_date>$next_attempt_date){
										$access_path =1;							
									}
									else{
										$access_path =0;
									} 
								}   
							}
							else{
								$access_path =1;
							} 

		 
					//---Check Server ip addrss---//
		 
					if(!empty($ipaddress_allow) and $access_path==1 ){
						if(in_array($_SERVER['REMOTE_ADDR'],$ipaddress_allow)){
							$access_path =0;
						}else{
							$access_path =1;
						}
					}   
 
					return $access_path;
			} 

			/*Check access for  learning paths play Time*/
			
			function NextLearningPathQuizPlay($quizid,$learningId){
				
				$user=JFactory::getUser();
				$UniqLearningPath='onThePlayvQuizLearningPath'.$learningId;
				$obj=new stdClass();
				$obj->play=0;
 
				$query=$this->_db->getQuery(true);
				$query->select('*');
				$query->from($this->_db->quoteName('#__vquiz_learning'));
				$query->where('id='.$this->_db->quote($learningId));
				$this->_db->setQuery($query);
				$quizesSetting=$this->_db->loadObject();
				
				if(!empty($quizesSetting)){
						
					$query  ='  select quizid from #__vquiz_learning_lnq';
					$query .= ' where learningid ='.$quizesSetting->id;
					$query .= ' ORDER BY id asc';
					$this->_db->setQuery( $query);		
					$quizesorder = $this->_db->loadColumn(); 
					
					if($quizesorder){
						$query_id  =' select id from #__vquiz_quizzes';
						$query_id .= ' where id in ('.implode(',',$quizesorder).')';
						$query_id .= ' and published=1';
						$query_id .= ' ORDER BY FIELD(id,'.implode(',',$quizesorder).')';
						$this->_db->setQuery( $query_id );		
						$quizes_order = $this->_db->loadColumn();
					}else{
						$quizes_order=array();
					}
 
					
					$quiz_Index=array_search($quizid,$quizes_order);
					
					if($quiz_Index>0){
						$prev_quizId=$quizes_order[$quiz_Index-1];
					}else{
						$prev_quizId='';
					}
					if(count($quizes_order)>$quiz_Index+1){
						$next_quizId=$quizes_order[$quiz_Index+1];
					}else{
						$next_quizId='';
					}
					$next_quiz_delay=$quizesSetting->next_quiz_delay;
					$delay_periods=$quizesSetting->delay_periods;
					$minimum_per_Learning=$quizesSetting->minimum_per;
					$minimum_custom_per_Learning=$quizesSetting->minimum_custom_per;
				}else{
					$next_quizId='';
					$prev_quizId='';
					$next_quiz_delay=0;
					$delay_periods=0;
					$minimum_per_Learning=0;
					$minimum_custom_per_Learning=0;
				}
				
				$query=$this->_db->getQuery(true);
				$query->select('l.id,l.quizid,r.score,r.maxscore,r.passed_score,l.created');
				$query->from('(select id,created,quizid,learning_id,userid,played,resultid,cookieId from `#__vquiz_learning_playedquizzes` order by id desc) As l');
				$query->join('left',$this->_db->quoteName('#__vquiz_quizresult', 'r') . ' ON (' . $this->_db->quoteName('r.id') . ' = ' . $this->_db->quoteName('l.resultid') . ')');
				$query->where('learning_id='.$this->_db->quote($learningId));
				if($user->id!=0) {
					$query->where('l.userid='.$this->_db->quote($user->id));
				}else if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
					$cookieId = $_COOKIE['vQuizLearningPath'.$UniqLearningPath];
					$query->where('cookieId='.$this->_db->quote($cookieId));
				}
				$query->where('l.played = 0');
				//$query->group('l.quizid');
				$query->order('l.id desc');
				$this->_db->setQuery($query);
				$result_quizid=$this->_db->loadObjectList();
 
				
				/*  -----  */
				
				$query=$this->_db->getQuery(true);
				$query->select('l.quizid');
				$query->from('(select id,learning_id,userid ,quizid ,cookieId,played from #__vquiz_learning_playedquizzes order by id desc) as l');
				$query->where('l.learning_id='.$this->_db->quote($learningId));
				
				if($user->id!=0) {
					$query->where('l.userid='.$this->_db->quote($user->id));
				}else if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
					$cookieId = $_COOKIE['vQuizLearningPath'.$UniqLearningPath];
					$query->where('l.cookieId='.$this->_db->quote($cookieId));
				}
				
				$query->where('l.played = 0');
				//$query->group('l.quizid');
				$query->order('l.id desc');
				$this->_db->setQuery($query);
				$PlayedQuizids=$this->_db->loadColumn();
 
				$resultIndex=array_search($prev_quizId,$PlayedQuizids,true);

				if(!empty($result_quizid) and $resultIndex!==false){
					$score=$result_quizid[$resultIndex]->score;
					$maxscore=$result_quizid[$resultIndex]->maxscore;
					$passed_score=$result_quizid[$resultIndex]->passed_score;
					$result_PlayedDateTime=$result_quizid[$resultIndex]->created; 
				}else{
					$score=0;
					$maxscore=0;
					$passed_score=0;
					$result_PlayedDateTime=0; 
				}

				if($next_quizId!='' and $prev_quizId!='' and $next_quiz_delay!=0){
					
					

					if(!empty($result_PlayedDateTime)){

						switch ($delay_periods) {
							case 'days':
								$days=1;
							break;
							case 'week':
								$days=7;
							break;
							case 'month':
								$days=30;
							break;
							case 'hour':
								$days=1/24;
							break;
							default:
								$days=0;
						}
						
						//$curent_date=JFactory::getDate()->toUnix();
						$curent_date=strtotime(JFactory::getDate('now', JFactory::getConfig()->get('offset')));
						
						$countDelayDate=$next_quiz_delay * $days;
						
						$DelayTounix=$countDelayDate * 24*60*60;
						$PlayedTime=strtotime($result_PlayedDateTime);
						
						if(($PlayedTime+$DelayTounix)<=$curent_date){
							$obj->play=0;
						}else{
							$obj->play=1;

							if(floor((($DelayTounix+$PlayedTime)-$curent_date)/3600)<=24){
								$hourse=floor((($DelayTounix+$PlayedTime)-$curent_date)/3600);//hourse
								$obj->youCanaccess ='Your Are unauthorized,You can Play this Quiz After '.$hourse.' Hours';
							}else{
								$days=floor((($DelayTounix+$PlayedTime)-$curent_date)/86400);//days
								$obj->youCanaccess ='Your Are unauthorized,You can Play this Quiz After '.$days.' Days';
							}
						}
					
					}else{
						$obj->play=0;
					}

				}else{
					$obj->play=0;
				}
				
				 
				if($obj->play==0 and $prev_quizId!=''){
					 
					if($minimum_per_Learning==1){
						$passed_score=$minimum_custom_per_Learning;
					}

					if($maxscore==0){
						$persentagescore=100;
					}else{
						$persentagescore=round($score/$maxscore*100,2)>100?100:round($score/$maxscore*100,2);
					}

					$persentagescore=$persentagescore>0?$persentagescore:0;

					if($persentagescore<$passed_score){
						$obj->play=1;
						$obj->youCanaccess ='Your Are unauthorized ,You can Play and passed the Previous Quiz First';
					}
				} 

				return $obj; 
				
			}
			
			
			/* get learning path  path Restricted quizzes */
			
			function LearningPathRestrictedUrlQuizzes(){
				
				$learningId=JRequest::getInt('learningId',0);
				$resTrictedQuizzes=array();
				
				if($learningId==0){
					$query=$this->_db->getQuery(true);
					$query->select('lq.quizid');
					$query->from($this->_db->quoteName('#__vquiz_learning_lnq').' as lq');
					$query->join('LEFT',$this->_db->quoteName('#__vquiz_learning').' as l on l.id=lq.learningid');
					$query->where('l.urlrestriction= 1');
					$query->where('l.published= 1');
					$this->_db->setQuery($query);
					$Quizzes=$this->_db->loadColumn();
					
				}else{
					$Quizzes=array();
				}
				
				return $Quizzes;
				
			}
			
			/*-- Learning paths Check Last Quiz  --*/
			
			function CheckEndLearningPath(){
				
				$learningId=JRequest::getInt('learningId',0);
				$user=JFactory::getUser();
				$UniqLearningPath='onThePlayvQuizLearningPath'.$learningId;
				$obj=new stdClass();
				
				$query=$this->_db->getQuery(true);
				$query->select('quizid');
				$query->from($this->_db->quoteName('#__vquiz_learning_playedquizzes'));
				$query->where('learning_id='.$this->_db->quote($learningId));
				if($user->id!=0) {
					$query->where('userid='.$this->_db->quote($user->id));
				}else if(isset($_COOKIE['vQuizLearningPath'.$UniqLearningPath])){
					$cookieId = $_COOKIE['vQuizLearningPath'.$UniqLearningPath];
					$query->where('cookieId='.$this->_db->quote($cookieId));
				}
				$query->where('played = 0');
				$this->_db->setQuery($query);
				$result_quizid=$this->_db->loadColumn();
				if(!empty($result_quizid)){
					$obj->remain_playquizId=0;
				}else{
					$obj->remain_playquizId=1;
				}
				
				return $obj;
				
			}
			
			/*Check running qui Passed*/
			function CheckLearningQuizPass($quizid,$learningId){
				
				$obj=new stdClass();
				
				$query=$this->_db->getQuery(true);
				$query->select('minimum_per,minimum_custom_per');
				$query->from($this->_db->quoteName('#__vquiz_learning'));
				$query->where('id='.$this->_db->quote($learningId));
				$this->_db->setQuery($query);
				$learningSetting=$this->_db->loadObject();
				
				$query=$this->_db->getQuery(true);
				$query->select('score,maxscore,passed_score');
				$query->from($this->_db->quoteName('#__vquiz_quizresult'));
				$query->where('quizid='.$this->_db->quote($quizid));
				$query->order('id desc');
				$query->setLimit(1);
				$this->_db->setQuery($query);
				$quizresultSetting=$this->_db->loadObject();
				
				$score=$quizresultSetting->score;
				$maxscore=$quizresultSetting->maxscore;
				if($learningSetting->minimum_per==1){
					$passed_score=$learningSetting->minimum_custom_per;
				}else{
					$passed_score=$quizresultSetting->passed_score;
				
				}
				if($maxscore==0){
					$persentagescore=100;
				}else{
					$persentagescore=round($score/$maxscore*100,2)>100?100:round($score/$maxscore*100,2);
				}
				
				$persentagescore=$persentagescore>0?$persentagescore:0;
				
				if($persentagescore>=$passed_score){
					$obj->passed=1;
				}
				else{
					$obj->passed=0;
				}
				
				return $obj;

			}
			
			function getLearningPaths(){
				
				$learningId = JRequest::getInt('learningId',0);
				$query=$this->_db->getQuery(true);
				$query->select('*');
				$query->from($this->_db->quoteName('#__vquiz_learning'));
				$query->where('id='.$this->_db->quote($learningId));
				$this->_db->setQuery($query);
				$learningPathResults=$this->_db->loadObject();
				return $learningPathResults;
				
			}
			
					
			/*---Get Learning PathResults ---*/
			function getLearningPathResult_Confi($learningId){
				
				$user = JFactory::getUser();
				$date =JFactory::getDate('now', JFactory::getConfig()->get('offset'));
				$datetime = $date->toSQL();
				
				$query=$this->_db->getQuery(true);
				$query->select('*');
				$query->from($this->_db->quoteName('#__vquiz_learning'));
				$query->where('id='.$this->_db->quote($learningId));
				$this->_db->setQuery($query);
				$learningPathcertificate=$this->_db->loadObject();
				
				
				if(!empty($learningPathcertificate)){
					$text = $learningPathcertificate->trivia_results;
					$learningtitle=$learningPathcertificate->title;
					$arIds=$learningPathcertificate->article_id;
					$articleid=JRoute::_('index.php?option=com_content&view=article&id='.$arIds);
					$total_questions=count(explode(',',$learningPathcertificate->quizes_order));
					 
				}else{
					$text = '';
				}

				if(!empty($certificate_name)){
					$username=$certificate_name;
				}elseif(!$user->get('guest')){
					$username=$user->username;
				}else{
					$username=JText::_('GUEST');
				}	
				
				if(!$user->get('guest')){
					$email=$user->email;
				}else{
					$email='';
				}
				
				
				if(strpos($text, '{username}')!== false)
				{
					$text = str_replace('{username}', $username, $text);
				}
				
				if(strpos($text, '{email}')!== false)
				{
					$text = str_replace('{email}', $email, $text);
				}
				
				if(strpos($text, '{learningtitle}')!== false)
				{
					$text = str_replace('{learningtitle}', $learningtitle, $text);
				}

				if(strpos($text, '{date}')!== false)
				{
					$text = str_replace('{date}', JFactory::getDate('now', JFactory::getConfig()->get('offset'))->format("j F, Y"), $text);
				}
				
				if(strpos($text, '{total_questions}')!== false)
				{
					$text = str_replace('{total_questions}', $total_questions, $text);
				}	
				
				if(strpos($text, '{articleid}')!== false)
				{
					$text = str_replace('{articleid}', $articleid, $text);
				}	
	 
				return $text;
			
			}
			
						
			/*--Lead Generate guest user check email--*/
			function CheckRedudancyLeadUser($quizid,$user_email)
			{
				
				$user = JFactory::getUser();	
				$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
				$lang = JFactory::getLanguage();
				$app = JFactory::getApplication();
				
				$query=$this->_db->getQuery(true);
				$query->select('resultid,created');
				$query->from('#__vquiz_leads');
				$query->where('user_email='.$this->_db->quote($user_email));
				$query->where('quizid='.$this->_db->quote($quizid));
				$query->where('resultid != 0');
				$query->setlimit(1);
				$query->order('id desc');
	 
				$this->_db->setQuery($query);
				$lead_result=$this->_db->loadobject();
				
			
									
				$obj = new stdClass();
				$obj->result = 0;
				
				if(!empty($lead_result)){

					$query="select access,attempt_count,attempt_delay,delay_periods,lead_generate_mandatory from #__vquiz_quizzes";	
					
					$where = array();
					
					$where[] = ' id = '.$this->_db->quote($quizid);
					/* $where[] = ' published = 1';
					$where[] = ' access in ('.implode(',', $user->getAuthorisedViewLevels()).')';
					if($app->getLanguageFilter())	{
						$where[] = ' language in ('.$this->_db->quote($lang->getTag()).', '.$this->_db->Quote('*').')';
					} */
					$query .= ' where ' . implode(' and ', $where);
					//$query .=' order by id asc';
					$this->_db->setQuery($query);
					$result = $this->_db->loadObject();
					
					if(!empty($result)){
						$accessuser = $result->access;
						$attempt_count = $result->attempt_count;
						$attempt_delay = $result->attempt_delay;
						$delay_periods = $result->delay_periods;
						$lead_generate_mandatory = $result->lead_generate_mandatory;
					}else{
						$accessuser = '';
						$attempt_count = 0;
						$attempt_delay = 0;
						$delay_periods ='';
						$lead_generate_mandatory =0;
					}
 
					
					$obj->lead_mendatory=$lead_generate_mandatory;
					
					switch ($delay_periods) {
						case 'days':
						$days=1;
						break;
						case 'week':
						$days=7;
						break;
						case 'month':
						$days=30;
						break;
						case 'hour':
						$days=1/24;
						break;
						default:
						$days=0;
					}
					
					$atteptdate=$attempt_delay * $days;
					$atteptdate_tounix=$atteptdate * 24*60*60;
					
					$first_start_date = $lead_result->created;
					$next_attempt_date=strtotime($first_start_date)+$atteptdate_tounix;
					

					
					$query=$this->_db->getQuery(true);
					$query->select('count(user_email)');
					$query->from('#__vquiz_leads');
					$query->where('user_email='.$this->_db->quote($user_email));
					$query->where('quizid='.$this->_db->quote($quizid));
					$query->where('resultid != 0');
					$query->order('id desc');
					$this->_db->setQuery($query);
					$attemptresult=$this->_db->loadResult();
 
			
					$curent_date=JFactory::getDate('now', JFactory::getConfig()->get('offset'))->toUnix();
					
						if($attempt_count>0)
						{	
							if($attemptresult<$attempt_count){
								$obj->allowresult =0;							
							}
							else{
								$obj->allowresult =1;
							} 
							
							if($attempt_delay>0){
							
								if($curent_date>$next_attempt_date){
									$obj->allowresult =0;							
								}
								else{
									$obj->allowresult =1;
								} 
							}  
						}
						else{
							$obj->allowresult =0;
						}
					
				
				}else{
					$obj->allowresult =0;
					$obj->lead_mendatory=0;
				}
				
				return $obj;
			}
			function createUserOrderBeforePay()
			{	
				$time = time();
				$config = QuizHelper::getConfiguration();
				//print_r($config);exit;
				
				$time = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
				$session=JFactory::getSession();
				$user = JFactory::getUser();
				if ($user->id==0)
				{
				$userid = $session->get('REGISTRATION_USER_ID', 0);
				}
				else{
				$userid = $user->id;
				}
			    $quiz_id=JRequest::getVar('quiz_id','');
				$query ='select title,price from #__vquiz_quizzes where id = '.$quiz_id;
				$this->_db->setQuery( $query );
				$quiz_detail = $this->_db->loadrow();
				//print_r($title);exit;
				//$title=JRequest::getVar('title','');print_r($title);exit;
				//$plan_id = JRequest::getVar('plan_id','');
				$subscription_id = JRequest::getVar('subid','');
				//$plan = QuizHelper::planDetail($plan_id);
				$total = $config->tax_enable==1?QuizHelper::pricewithtax($quiz_detail[1]):$quiz_detail[1];
				$subscriptions = $this->getTable('subscriptions', 'Table');
				$subscriptions->load($subscription_id);
				$subscriptions->status = QuizHelper::SUBSCRIPTION_NONE;
				$subscriptions->total =  $total;
				$subscriptions->subscription_date = $time;
				$subscriptions->plan_id = 0; //$plan_id
				$subscriptions->quiz_id = $quiz_id;
				$subscriptions->user_id = $userid;
				$param = new stdClass();
				$param->expirationtype = 'forever';
				$param->expiration = '000000000000';
				$param->price = $quiz_detail[1];  //$total 
				
				$param->title = $quiz_detail[0];
				$subscriptions->params  = json_encode($param);
				//print_r($subscriptions);
				if (!$subscriptions->store())
				{
				$this->setError( $subscriptions->getError() );
				return false; 
				}

				   
					JRequest::setVar('subid', $subscriptions->id);
					
					$order_id = JRequest::getVar('order_id','');
					$order =  $this->getTable('Orders', 'Table');
					$order->load($order_id);
					//print_r($order);exit;
					$order->subscr_id = $subscriptions->id;
					$order->app_id = 1;  
					$order->tax = $config->tax_enable==1?$total-$quiz_detail[1]:'0.00000';
					$order->currency = $config->currencyname;
					
					
					
					$order->total = $total;
					$order->subtotal = $quiz_detail[1]; 
					$order->status = QuizHelper::ORDER_NONE;
					$order->coupon_code = "";
					$order->buyer_id = $userid;
					$order->created_date = $time;
					$order->modified_date = $time;
					 
					$order->order_key = QuizHelper::generateSerialCode(12);
					
					$param = new stdClass();
					$param->expirationtype = 'forever';
					$param->expiration = '000000000000';
					$param->price = $quiz_detail[1]; // $total
					$param->title = $quiz_detail[0];
					$order->params = json_encode($param); 
					//print_r($order);exit;
					if (!$order->store()) {
						$this->setError( $order->getErrorMsg() );
						return false;
					}
					JRequest::setVar('order_key', $order->order_key);
					
					$subscription =  $this->getTable('subscriptions', 'Table');
					$subscription->load($subscriptions->id);
					$subscription->total = $order->total; 
					$param = new stdClass();
					$param->expirationtype = 'forever';
					$param->expiration = '000000000000';
					$param->title = $quiz_detail[0];
					$param->order_id = $order->order_id;
					$param->order_key = $order->order_key;
					$param->price = $quiz_detail[1]; //  $order->total; 
					$subscription->params = json_encode($param);
					$subscription->store();
				   
				return true;

				}
	function grp_paging()
	{ 
			$obj = new stdClass();
			$obj->result = "error";
			$limit=JRequest::getInt('index', 0);
			$itemid = JRequest::getInt('id', 0);
			$session = JFactory::getSession();
			$uniqvariable = JRequest::getVar('uniqvariable','');
			
			if(!$session->has('quizoptions'.$uniqvariable))	{
				$obj->error = JText::_('PLEASE_CONTACT_ADMINISTRATOR');
				return $obj;			
			}
			
			$quizoptions = $session->get('quizoptions'.$uniqvariable);
			//print_r($quizoptions);exit;
			$grp_id=$quizoptions['qgroupids'][$limit-1];
			$q_id=$quizoptions['qids'][$limit-1];
		
			$obj->q_id=$q_id;
			$obj->grp_id=$grp_id;
			$obj->result = "success";
			return $obj;
	}
	
	function verify_answer()
	{
		$obj = new stdClass();
		$obj->result = "error";
		
		$questions_id= stripslashes(html_entity_decode(JRequest::getVar('qid','')));
		$qid=json_decode($questions_id,true);
			
		//$qid = 40;
		
		$query = 'select id,correct_ans from #__vquiz_option where qid IN ('.implode(',',$this->_db->quote($qid)).') order by id asc';
		
		$this->_db->setQuery($query);
		$options_list= $this->_db->loadObjectList();
		
		$option_arr = array();
		foreach($options_list as $option){
			$option_arr[$option->id] = $option->correct_ans;
		}
		
		$obj->option_list = $option_arr;
		
		$obj->result = "success";
		return $obj;
	}
	
	function submit_slide(){		
		
			$session = JFactory::getSession();
			$itemid = JRequest::getInt('id', 0);
			
			$uniqvariable = JRequest::getVar('uniqvariable','');
			
			$questions_id= stripslashes(html_entity_decode(JRequest::getVar('qid','')));
			$qid=json_decode($questions_id,true);

			$user_comment_value= JRequest::getVar('user_comment_value',0, '', 'array');
			$aid= JRequest::getVar('aid',0, '', 'array');
			$text_value= JRequest::getVar('text_value','', '', 'array');
			$textarea_value= JRequest::getVar('textarea_value','', '', 'array');
			
			$drag_ans= JRequest::getVar('drag_ans','', '', 'array');
			$hotspotAns= JRequest::getVar('hotspotAns','', '', 'array');
			
			$obj = new stdClass();
			
		if($session->has('quizoptions'.$uniqvariable)){
		
			$quizoptions = $session->get('quizoptions'.$uniqvariable);
			
			if(empty($aid[0]) and empty($text_value[0]) and empty($textarea_value[0]) and empty($drag_ans[0]) and empty($hotspotAns[0]) and empty($user_comment_value)){
				$obj->error = JText::_('CHOOSE_ANSWER_FIRST');
				return $obj;
			}

		}
		else{
			
				$quizoptions = array('qids'=>array(), 'aids'=>array(),'text_value'=>array(),'textarea_value'=>array(),'drag_ans'=>array(),'hotspotAns'=>array(),'score'=>array(),'penalty'=>array(),'expire_timescore'=>array(),'qspenttime'=>array(),'user_comment_value'=>array(),'qgroupids'=>array());		
		}
		
		for($j=0;$j<count($qid);$j++){
			
				$ansid = array_search($qid[$j], $quizoptions['qids']);
				
				
				if($ansid !== false){
						
				$quizoptions['user_comment_value'][$ansid]=$user_comment_value[$j];	
				//$quizoptions['aids'][$ansid]=$aid[$j];

					if($aid[$j]=='' and $text_value[$j]!=''){
						$quizoptions['text_value'][$ansid]=$text_value[$j];
					}elseif($aid[$j]=='' and $textarea_value[$j]!=''){
						$quizoptions['textarea_value'][$ansid]=$textarea_value[$j];
					}elseif($aid[$j]=='' and $drag_ans[$j]!=''){
						$quizoptions['drag_ans'][$ansid]=$drag_ans[$j];
					}elseif($aid[$j]=='' and $hotspotAns[$j]!=''){
						$quizoptions['hotspotAns'][$ansid]=$hotspotAns[$j];
					}else{
						$aid[$j]=$aid[$j]!=''?$aid[$j]:0;
						$quizoptions['aids'][$ansid]=$aid[$j];
					} 									
						
				}else{
				
						array_push($quizoptions['qids'], $qid[$j]);
						
						
							 array_push($quizoptions['user_comment_value'], $user_comment_value[$j]);

							if(empty($aid[$j]) and !empty($text_value[$j])){
								array_push($quizoptions['text_value'], $text_value[$j]);
								array_push($quizoptions['aids'],0);
								array_push($quizoptions['textarea_value'], '');
								array_push($quizoptions['drag_ans'], '');
								array_push($quizoptions['hotspotAns'], '');
							}elseif(empty($aid[$j]) and !empty($textarea_value[$j])){
								array_push($quizoptions['textarea_value'], $textarea_value[$j]);
								array_push($quizoptions['text_value'],'');
								array_push($quizoptions['aids'],0);
							array_push($quizoptions['drag_ans'], '');
								array_push($quizoptions['hotspotAns'], '');
							}elseif(empty($aid[$j]) and !empty($drag_ans[$j])){
								array_push($quizoptions['drag_ans'], $drag_ans[$j]);
								array_push($quizoptions['text_value'],'');
								array_push($quizoptions['aids'],0);
								array_push($quizoptions['textarea_value'], '');
								array_push($quizoptions['hotspotAns'], '');
							}elseif(empty($aid[$j]) and !empty($hotspotAns[$j])){
								array_push($quizoptions['hotspotAns'], $hotspotAns[$j]);
								array_push($quizoptions['text_value'],'');
								array_push($quizoptions['aids'],0);
								array_push($quizoptions['textarea_value'], '');
								array_push($quizoptions['drag_ans'], '');
							}else{
								$aid[$j]=$aid[$j]!=''?$aid[$j]:0;
								array_push($quizoptions['aids'], $aid[$j]);
								array_push($quizoptions['text_value'],'');
								array_push($quizoptions['textarea_value'], '');
								array_push($quizoptions['drag_ans'], '');
								array_push($quizoptions['hotspotAns'], '');
							}
						
						array_push($quizoptions['qgroupids'], $qgroupid);

							
				}
			}
		
			/*---main Session Set all Quiz information--- */
			$session->set('quizoptions'.$uniqvariable, $quizoptions);
			
			$quizoptions = $session->get('quizoptions'.$uniqvariable);
			
		//print_r($session->get('quizoptions'.$uniqvariable)); jexit();
		
		$obj->result = "success";
		return $obj;	
	
	}//end submit_slide()
	
}