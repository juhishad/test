<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.modellist');
 
class VquizModelSubscriptions extends JModelList
{
		 function __construct()
			{
				parent::__construct();

				$mainframe = JFactory::getApplication();
				$context	= 'com_vquiz.subscriptions.list.';
				// Get pagination request variables
				$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
				$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );

				// In case limit has been changed, adjust it
				$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
				$this->setState('limit', $limit);
				$this->setState('limitstart', $limitstart);				 
				$array = JRequest::getVar('cid',  0, '', 'array');
				$this->setId((int)$array[0]);
			}

		function _buildQuery()
		{
			$db =JFactory::getDBO();
			$user = JFactory::getUser();
			
			$query="SELECT i.* , p.title, `u`.`name` FROM #__vquiz_plans_subscription as i left join #__vquiz_plans as p ON i.plan_id = p.id left join `#__users` as `u` on `u`.`id`=`i`.`user_id` where u.id=".$user->id; //exit;
			
			return $query;
		}

		function setId($id)	
		{
			$this->_id		= $id;
			$this->_data	= null;
 		}

		
		function &getItem()
		{
			if (empty( $this->_data )) {
			
				$query = ' SELECT * FROM #__vquiz_plans_subscription '.
					'  WHERE id = '.$this->_id;
				
				$this->_db->setQuery( $query );
				$this->_data = $this->_db->loadObject();
			
			}



			if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->user_id = null;
			$this->_data->plan_id = null;
			$this->_data->total = null;
			$this->_data->status = null;
					
			
			$this->_data->subscription_date= null;
			$this->_data->expiration_date= null;
			
			$this->_data->created_by= null;
			}
			
			return $this->_data;
		}




		 function &getItems(){
		 
			// Lets load the data if it doesn't already exist
			if (empty( $this->_data ))
			{
				 $query = $this->_buildQuery();
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();
				 
				 $query .= $filter;
				 $query .= $orderby;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			}
	
			return $this->_data;
		}
	 


	
		function getTotal()
		{
				
			if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$query .= $this->_buildContentFilter();
			$this->_total = $this->_getListCount($query);    
			}
			return $this->_total;
 		}



		function _buildItemOrderBy(){
		
			$mainframe = JFactory::getApplication();
			$context	= 'com_vquiz.subscriptions.list.';
			$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
			$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
			$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
			return $orderby;
		}



		function getPagination(){
			// Load the content if it doesn't already exist
			if (empty($this->_pagination)) {
				jimport('joomla.html.pagination');
				$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
			}
			return $this->_pagination;
		}
 

		  function _buildContentFilter(){
		  
				$mainframe =JFactory::getApplication();
				$user = JFactory::getUser();
				$context	= 'com_vquiz.subscriptions.list.';
				$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
				
				
				$search		= JString::strtolower( $search );
		 
				$where = array();
				$OR = array();
				
 

				if($search)
				{	
					if (is_numeric($search)) 
					{		 
						$where[] = 'LOWER(  i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
					}
					else
					{
					 $where[] = 'p.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
					}
				}
				
				

				$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
				
				if(empty($filter)){
					$filter = count($OR) ? ' WHERE ' . implode(' OR  ', $OR) : '';
				}else{
					$filter .= count($OR) ? ' OR ' . implode(' OR  ', $OR) : '';
				}
				 
				return $filter;
			}
		
 
	function store()
 	{	
		$time = time();
		$row =& $this->getTable();
		$data = JRequest::get( 'post' );
		
 		if (!$row->bind($data)) {
 		$this->setError($this->_db->getErrorMsg());
 		return false;
 		}

  		if (!$row->check()) {
 		$this->setError($this->_db->getErrorMsg());
 		return false;
 		}
 
		if (!$row->store()) {
 		$this->setError( $row->getErrorMsg() );
 		return false; 
 		}
 		return true;

	}
 

	function delete()
	{
 		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
 		$row =& $this->getTable();
 		if (count( $cids )) {
 		foreach($cids as $cid) {
 			if (!$row->delete( $cid )) {
 				$this->setError( $row->getErrorMsg() );
 				return false;
 				}
				
				$query = 'DELETE FROM `#__vquiz_plans_order` where `subscr_id`='.$this->_db->quote($cid);
					$this->_db->setQuery($query);
					$this->_db->execute();
 			}
 		}
 		return true;
 	}

 		
	
		function getConfiguration(){

			$query='select * from #__vquiz_configuration';
			$this->_db->setQuery($query);
			$result = $this->_db->loadObject();
			return $result;
		}
		
		function getPlans(){
		$query = 'select `id`, `title` from `#__vquiz_plans` where `published`=1;';
		$this->_db->setQuery($query);
		return $this->_db->loadObjectList();
	}
		
}