<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author Team WDMtech
# copyright Copyright (C) 2018 www.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support: Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
JHtml::_('behavior.tooltip');
JHTML::_('behavior.modal');

$document = JFactory::getDocument();
$app=JFactory::getApplication();
$document->setTitle('Learning Path'.' - '.$app->getCfg( 'sitename' ) );
//$document->addScript(JURI::root().'components/com_vquiz/assets/js/library.js');
$user=JFactory::getUser();

?>

 <form action="<?php echo JRoute::_('index.php?option=com_vquiz&view=learning')?>" method="post" name="adminForm" id="adminForm">
 
	<div class="adminform">

		<div class="cpanel-left">
			<div class="board"> 
			
				<h1 class="play_quiz"><?php echo JText::_('COM_VQUIZ_LEARNING_PATH'); ?></h1> 
				<?php
				$k = 0;
				for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
				$row = &$this->items[$i];
				
				if(($row->set_price==0) or ($row->set_price==1 and QuizHelper::learningaccess($row->id,$user->id))){
					
				 $link 	= JRoute::_( 'index.php?option=com_vquiz&view=learning&layout=description&id='. $row->id );
				
				}else{
				 $link =JRoute::_('index.php?option=com_vquiz&view=learning&task=subscribe&learning_id='.$row->id, false);	
				} 
			
				?>

				<div class="<?php echo "row$k"; ?> vcat <?php echo "list_column".$this->configuration->list_column; ?>">
				<div class="quiz-listing">
				<?php if($row->set_price!=0){?>
							<div class="price-tag">
								<span><?php echo JText::_('COM_VQUIZ_LEARNING_PATH_PAID'); ?></span>
							</div>
							<?php } ?>
					<a class="cat_img" href="<?php echo $link;?>">    
					
					<?php 
					if(!empty($row->image)){ 
						echo '<img class="hasTip" src="'.JURI::root().'/media/com_vquiz/vquiz/images/photoupload/learning/thumbs/thumb_'.$row->image. '" alt="'.$row->title.'" title="'.$row->title.'" width="'.$this->configuration->categorythumbnailwidth.'" height="'.$this->configuration->categorythumbnailheight.'" / >'; 
					}else { echo '<img class="hasTip" src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" width="'.$this->configuration->categorythumbnailwidth.'" height="'.$this->configuration->categorythumbnailheight.'" />';} 

					?>
					</a>   
					
					<a class="title" href="<?php echo $link; ?>">
						<?php echo $row->title; ?>
					</a>
				</div>
 

				<?php
				$k = 1 - $k;
				}
				?>           

			</div>
	
		</div>
	</div>
	<tfoot>
		<tr>
		<td colspan="0">
		<?php if($this->pagination->getPagesLinks()){?>
		<div class="pagination"><?php echo $this->pagination->getPagesLinks(); ?></div>
		<?php }?>
		</td>
		</tr>
	</tfoot>
	<div class="clr"></div> 
	<input type="hidden" name="option" value="com_vquiz" /> 
	<input type="hidden" name="view" value="learning" />
	<input type="hidden" name="task" value=""/>  
</form>
 