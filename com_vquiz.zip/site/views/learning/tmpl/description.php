<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
defined( '_JEXEC' ) or die( 'Restricted access' );

JHTML::_('behavior.tooltip');

$document = JFactory::getDocument();
$app=JFactory::getApplication();
$title=$this->description->title;
$document->setTitle($title.' - '.$app->getCfg( 'sitename' ) );

if($this->configuration->load_jquery==1){ 
	$document->addScript(JURI::root().'components/com_vquiz/assets/js/jquery.min.js');
}
$user = JFactory::getUser();	
//echo 1;
?>
<script type="text/javascript"> 
	var jQuery=jQuery.noConflict();
	jQuery(document).ready(function(){
	
		 jQuery('.quiz_disabled').click(function(){ 
			alert('<?php echo JText::_('COM_VQUIZ_PLS_PLAY_QUIZ_IN_ORDER'); ?>');
		 });
	});
</script>	
<style type="text/css">
.main_lp_div{
	width:100%;
	display:inline-block;
}
.main_lp_div .board{
	margin:10px 0;
}
.main_lp_div .lp_quiz .title{
	font-size:13px !important;
}

.cat_img{
	position:relative;
	overflow:hidden;
}
.cat_img::before {
    background: rgba(0, 0, 0, 0.6) none repeat scroll 0 0;
    content: "";
    height: 100%;
    left: 0;
    position: absolute;
    bottom: 100%;
    width: 100%;
	opacity:0;
	transition:all 0.55s ease 0s;
	z-index:-1;
}
.cat_img:hover:before {
	opacity:1;
	bottom: 0;
	z-index:1;
}
.quiz_disabled{
	
}
</style>

	<div class="main_lp_div">
	
		<div class="board"> 
		
			<h1 class="play_quiz"><?php echo $this->description->title; ?></h1> 
			<div class="quizzes">
			
			<?php
			
			$k = 0; $disabled_class = "";
			for ($i=0, $n=count($this->learningPath ); $i < $n; $i++)	{
			$row = $this->learningPath[$i];
			if($this->description->level_release=="all")
			{
			if(!empty($this->learningPath[$i]->quizid))
			{
				if(($this->description->set_price==0) or ($this->description->set_price==1 and QuizHelper::learningaccess($this->description->id,$user->id))){ 
				
					if($this->lessons_completed==1){
						$link 	= JRoute::_( 'index.php?option=com_vquiz&view=quizmanager&layout=description&learningId='.$this->description->id.'&id='. $row->quizid);
					}else{
						$link ="javascript:alert('". JText::_('COM_VQUIZ_PLS_WATCH_ALL_LESSONS')."')";
					} 
				
				}else{
					$link =JRoute::_('index.php?option=com_vquiz&view=learning&task=subscribe&learning_id='.$this->description->id, false);
				}
			}
			else if(!empty($this->learningPath[$i]->lessionid))
			{
				if(($this->description->set_price==0) or ($this->description->set_price==1 and QuizHelper::learningaccess($this->description->id,$user->id))){ 
				
					$link 	= JRoute::_( 'index.php?option=com_vquiz&view=lessons&layout=lessondetails&learningId='.$this->description->id.'&id='. $row->lessionid);
				}else{
					$link =JRoute::_('index.php?option=com_vquiz&view=learning&task=subscribe&learning_id='.$this->description->id, false);
				}
			}
			else
			{
				$link ='#';
			}
			}
			else if($this->description->level_release=="sequential")
			{
				//if($i==0)
				//{ 
					if(!empty($this->learningPath[$i]->quizid))
					{						
						if(($this->description->set_price==0) or ($this->description->set_price==1 and QuizHelper::learningaccess($this->description->id,$user->id))){ 
				
							//if($this->lessons_completed==1){
							if($i==0){ 
							$link 	= JRoute::_( 'index.php?option=com_vquiz&view=quizmanager&layout=description&learningId='.$this->description->id.'&id='. $row->quizid);
							}else{
								$link ="javascript:alert('". JText::_('COM_VQUIZ_PLS_PLAY_QUIZ_IN_ORDER')."')";
								$disabled_class = "quiz_disabled";
								//$link ="javascript:alert('". JText::_('COM_VQUIZ_PLS_WATCH_ALL_LESSONS')."')";
							}
						
						}else{
							$link =JRoute::_('index.php?option=com_vquiz&view=learning&task=subscribe&learning_id='.$this->description->id, false);
						}
					}
					else if(!empty($this->learningPath[$i]->lessionid))
					{
						if(($this->description->set_price==0) or ($this->description->set_price==1 and QuizHelper::learningaccess($this->description->id,$user->id))){ 
				
						$link 	= JRoute::_( 'index.php?option=com_vquiz&view=lessons&layout=lessondetails&learningId='.$this->description->id.'&id='. $row->lessionid);
						}else{
							$link =JRoute::_('index.php?option=com_vquiz&view=learning&task=subscribe&learning_id='.$this->description->id, false);
						}						
					}
					else
							{
								$link ='#';
							}
				//}
			}
			else
			{
				$link='#';
			}
			?>
			<div class="quiz">
			<div class="<?php echo "row$k"; ?>  lp_quiz vcat <?php echo "list_column".$this->configuration->list_column; ?>">
			
				<span class="active_quiz order_quiz"><?php echo $i+1;?></span>
			<?php if(!empty($this->learningPath[$i]->quizid)){ ?>
				<a class="cat_img" <?php if($disabled_class==""){echo 'href="'.$link.'"';}?>>    
				
				<?php 
				
					if(!empty($row->quizimage)){ 
						echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/photoupload/quizzes/thumbs/thumb_'.$row->quizimage. '" alt="'.$row->quiztitle.'" title="'.$row->quiztitle.'" width="'.$this->configuration->categorythumbnailwidth.'" height="'.$this->configuration->categorythumbnailheight.'" / >'; 
						}
					else { 
							echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" width="'.$this->configuration->categorythumbnailwidth.'" height="'.$this->configuration->categorythumbnailheight.'" />';
						 } 
				
				?>
				</a>   
				
				<a class="title <?php echo $disabled_class?>" <?php if($disabled_class==""){echo 'href="'.$link.'"';}?>>
					<?php echo $row->quiztitle; ?>
				</a>
			<?php }
				else if(!empty($this->learningPath[$i]->lessionid)){
				?>
				<a class="cat_img" href="<?php echo $link;?>">    
				
				<?php 
				if(!empty($row->lessonimage)){ 
					echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/photoupload/lessons/thumbs/thumb_'.$row->lessonimage. '" alt="'.$row->lessontitle.'" title="'.$row->lessontitle.'" width="'.$this->configuration->categorythumbnailwidth.'" height="'.$this->configuration->categorythumbnailheight.'" / >'; 
				}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" width="'.$this->configuration->categorythumbnailwidth.'" height="'.$this->configuration->categorythumbnailheight.'" />';} 

				?>
				</a>   
				
				<a class="title" href="<?php echo $link; ?>">
					<?php echo $row->lessontitle; ?>
				</a>
			<?php } ?>
			</div>
			</div>

			<?php
			$k = 1 - $k;
			}
			?>           
		</div>
	</div>
		<div class="desc" >
			<?php if(!empty($this->description->image)){ 
				echo '<img class="hasTip" src="'.JURI::root().'/media/com_vquiz/vquiz/images/photoupload/learning/thumbs/thumb_'.$this->description->image. '" alt="'.$this->description->title.'" title="'.$this->description->title.'" width="'.$this->configuration->categorythumbnailwidth.'" height="'.$this->configuration->categorythumbnailheight.'" / >'; 
			}?>
			<?php echo $this->description->description ; ?>
		</div>
 </div>
 
<div class="clr"></div> 
<input type="hidden" name="option" value="com_vquiz" /> 
<input type="hidden" name="view" value="learning" />
<input type="hidden" name="task" value="" />  

 