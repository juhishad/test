<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author Team WDMtech
# copyright Copyright (C) 2018 www.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support: Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
class VquizViewLearning extends JViewLegacy
{ 
 
    function display($tpl = null)
    {
		
		$document =  JFactory::getDocument();
		$this->state	= $this->get('State');
		$this->params = $this->state->get('params');
		$menukeyword=$this->params->get('menu-meta_keywords');
		$menudescription=$this->params->get('menu-meta_description');
	
		if($menukeyword)
			$document->setMetadata('keywords', $menukeyword);
		if($menudescription)
			$document->setDescription($menudescription);
		
		$layout = JRequest::getCmd('layout', '');
		
		if(count($errors=$this->get('Errors')))
		{
			JError::raiseError(500,implode('<br />',$errors));
			return false;
		}
	
		if($layout == 'description'){
			
			$this->description = $this->get('Description');
			//echo "<pre>"; print_r($this->description); //exit;
			//$this->selectedQuizzes = $this->get('SelectedQuizzes');
			//$this->selectedLessons = $this->get('SelectedLessons');
			$this->learningPath = $this->get('LearningPath');									$this->lessons_completed = $this->get('LessonViewedStatus');			//echo "<pre>";print_r($this->lessons_completed); 			
			
		}else{
			$this->items = $this->get('Items');	 //print_r($this->items);
			$pagination =$this->get('Pagination');
			$this->assignRef('pagination', $pagination);
		}
		
		$this->configuration = $this->get('Configuration');
		
		$document = JFactory::getDocument();
		$document->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/style.css');
		$document->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/responsive_layout.css');
		
		parent::display($tpl);
		
    }
 
}



			  

			  

