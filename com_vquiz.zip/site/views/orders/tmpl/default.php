<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access'); 
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
JHtml::_('behavior.multiselect');

	if(version_compare(JVERSION, '3.0', '>=')) 
	JHtml::_('formbehavior.chosen', 'select');
	$user = JFactory::getUser();
	
//echo 1;exit;
?>

<script type="text/javascript">
Joomla.submitbutton = function(task) {
     var x=jQuery('#questioncsv').val();	

				if (task == 'cancel') {
				Joomla.submitform(task, document.getElementById('adminForm'));
				} 
				else if(task=='import') {
					lightbox_import();
					var form = document.adminForm;
					if(x == "")  {
					alert("<?php echo JText::_('PLZ_CHOSE_CSV'); ?>");
					return false;
					}
				}

				  else if(task=='export') {
					var form = document.adminForm;
					if (document.adminForm.boxchecked.value==0)  {
					alert("<?php echo JText::_('PLZCHOOSEQUESTION'); ?>");
					return false;
					}
				}

					else if(task=='copy') {
					var form = document.adminForm;
					if (document.adminForm.boxchecked.value==0)  {
					alert("<?php echo JText::_('PLZCHOOSEQUESTION'); ?>");
					return false;
					}

					else{
					lightbox_copy();
					return false;
					}

				}

					else if(task=='move') {
					var form = document.adminForm;
					if (document.adminForm.boxchecked.value==0)  {
					alert("<?php echo JText::_('PLZCHOOSEQUESTION'); ?>");
					return false;
					}

					else{
					lightbox_move();
					return false;
					}

				}

				Joomla.submitform(task, document.getElementById('adminForm'));

}
jQuery(document).ready(function(){
	/* jQuery('#payplans-order-confirm').click(function(){
		alert('Final Payment work in progress');
	} */
	
	jQuery(".vquiz .timeago").timeago();
	jQuery('#app_id').on('change', function(){
		jQuery("#payment_app_id").val(jQuery(this).val());
	});
	showpaypalpro();
});
(function($) {
  $.timeago = function(timestamp) { 
    if (timestamp instanceof Date) {
      return inWords(timestamp);
    } else if (typeof timestamp === "string") {
      return inWords($.timeago.parse(timestamp));
    } else {
      return inWords($.timeago.datetime(timestamp));
    }
  };
  var $t = $.timeago;

  $.extend($.timeago, {
    settings: {
      refreshMillis: 60000,
      allowFuture: true,
      strings: {
        prefixAgo: null,
        prefixFromNow: null,
        suffixAgo: "ago",
        suffixFromNow: "from now",
        seconds: "less than a minute",
        minute: "about a minute",
        minutes: "%d minutes",
        hour: "about an hour",
        hours: "about %d hours",
        day: "a day",
        days: "%d days",
        month: "about a month",
        months: "%d months",
        year: "about a year",
        years: "%d years",
        numbers: []
      }
    },
    inWords: function(distanceMillis) {
      var $l = this.settings.strings;
      var prefix = $l.prefixAgo;
      var suffix = $l.suffixAgo;
      if (this.settings.allowFuture) {
        if (distanceMillis < 0) {
          prefix = $l.prefixFromNow;
          suffix = $l.suffixFromNow;
        }
        distanceMillis = Math.abs(distanceMillis);
      }

      var seconds = distanceMillis / 1000;
      var minutes = seconds / 60;
      var hours = minutes / 60;
      var days = hours / 24;
      var years = days / 365;

      function substitute(stringOrFunction, number) {
        var string = $.isFunction(stringOrFunction) ? stringOrFunction(number, distanceMillis) : stringOrFunction;
        var value = ($l.numbers && $l.numbers[number]) || number;
        return string.replace(/%d/i, value);
      }

      var words = seconds < 45 && substitute($l.seconds, Math.round(seconds)) ||
        seconds < 90 && substitute($l.minute, 1) ||
        minutes < 45 && substitute($l.minutes, Math.round(minutes)) ||
        minutes < 90 && substitute($l.hour, 1) ||
        hours < 24 && substitute($l.hours, Math.round(hours)) ||
        hours < 48 && substitute($l.day, 1) ||
        days < 30 && substitute($l.days, Math.floor(days)) ||
        days < 60 && substitute($l.month, 1) ||
        days < 365 && substitute($l.months, Math.floor(days / 30)) ||
        years < 2 && substitute($l.year, 1) ||
        substitute($l.years, Math.floor(years));

      return $.trim([prefix, words, suffix].join(" "));
    },
    parse: function(iso8601) {
      var s = $.trim(iso8601);
      s = s.replace(/\.\d\d\d+/,""); // remove milliseconds
      s = s.replace(/-/,"/").replace(/-/,"/");
      s = s.replace(/T/," ").replace(/Z/," UTC");
      s = s.replace(/([\+\-]\d\d)\:?(\d\d)/," $1$2"); // -04:00 -> -0400
      return new Date(s);
    },
    datetime: function(elem) {
      // jQuery's `is()` doesn't play well with HTML5 in IE
      var isTime = $(elem).get(0).tagName.toLowerCase() === "time"; // $(elem).is("time");
      var iso8601 = isTime ? $(elem).attr("datetime") : $(elem).attr("title");
      return $t.parse(iso8601);
    }
  });

  $.fn.timeago = function() {
    var self = this;
    self.each(refresh);

    var $s = $t.settings;
    if ($s.refreshMillis > 0) {
      setInterval(function() { self.each(refresh); }, $s.refreshMillis);
    }
    return self;
  };

  function refresh() {
    var data = prepareData(this);
    if (!isNaN(data.datetime)) {
      $(this).text(inWords(data.datetime));
    }
    return this;
  }

  function prepareData(element) {
    element = $(element);
    if (!element.data("timeago")) {
      element.data("timeago", { datetime: $t.datetime(element) });
      var text = $.trim(element.text());
      if (text.length > 0) {
      	element.attr("title", text );
      }
    }
    return element.data("timeago");
  }

  function inWords(date) {
    return $t.inWords(distance(date));
  }

  function distance(date) {
    return (new Date().getTime() - date.getTime());
  }

  // fix for IE6 suckage
  document.createElement("abbr");
  document.createElement("time");
}(jQuery));
/* function applydiscount() {
        jQuery.noConflict();
        
        var jqxhr = jQuery.ajax({
            type: "POST",
            url: "<?php echo JRoute::_('index.php?option=com_vquiz&view=orders&order_key='.$this->orderDetail->order_key); ?>",
            data: {"tmpl":"component","coupon_key":jQuery('#app_discount_code_id').val()}
        }).done(function(resp){ 
            console.log('REFRESH');
            jQuery('.vquiz-order-conform').replaceWith(resp);
            // restores
            
        });
    } */
 function discount_apply(){	//alert(1);
		if(jQuery('#app_discount_code_id').val()=='')
		{
			alert('<?php echo JText::_('COM_VQUIZ_PLZ_ENTER_VALID_DISCOUNT_CODE');?>');
			jQuery('#app_discount_code_id').focus();
			return false;
		}
	   var subscription_id = <?php echo $this->orderDetail->subscr_id;?>;
	   var order_id = <?php echo $this->orderDetail->order_id;?>;
	   jQuery.ajax({
			  url: "index.php",
			  type: "POST",
			   data: {"option":"com_vquiz", "view":"orders", "task":"applycoupon", "subscription_id":subscription_id, "order_id":order_id, "couponkey":jQuery('#app_discount_code_id').val()},
			   beforeSend: function()	{ 
						jQuery(".vmap_overlay").show();
						},
			   complete: function()	{ 
						jQuery(".vmap_overlay").hide();
						}
		}).done(function( resp ) { 
			 var obj = jQuery.parseJSON(resp); 
		  jQuery('#pp-discount-spinner').text(obj.message);
		    alert(obj.message);
			location.reload();			
		});	
   }
   
  function update_payment_parameters(e)
  {
	 jQuery('#payplans-order-confirm').attr('disabled', 'disabled');
	 if(parseInt(jQuery(e).val())==1){ 
		 jQuery('.payment-parameters').html('');
		  jQuery('#payplans-order-confirm').removeAttr('disabled');
		
	 } 
	 else{
		 jQuery.ajax({
			url: "index.php",
			type: "POST",
			dataType: "json",
			data: {"option":"com_vquiz", "view":"orders", "task":"paymentDetail", "payment_id":jQuery(e).val()},
			beforeSend:function(){
			jQuery(".subscription_overlay").show();
			},
			complete:function(){
			jQuery(".subscription_overlay").hide();	
			},
			success:function(res){
			if(res.result == "success"){
			jQuery(".payment-parameters").html(res.html);
            jQuery('#payplans-order-confirm').removeAttr('disabled');			
			}
            else
			 alert(res.error);			
			
			},
			error: function(jqXHR, textStatus, errorThrown)	{
			alert(textStatus);				  
			} 			
		 });
	 }
  }

function showpaypalpro() { 
	if(jQuery("input[name='payment_type']:checked").val()=='paypal_pro'){
		
		jQuery('.card-payment').css('display','block');
		
		jQuery('#card_number').attr('required','true');
		jQuery('#expiry_month').attr('required','true');
		jQuery('#expiry_year').attr('required','true');
		jQuery('#cvv').attr('required','true');
		
		jQuery('#card_type').attr('required','true');
		
		jQuery('#first_name').attr('required','true');
		jQuery('#last_name').attr('required','true');
		jQuery('#street').attr('required','true');
		jQuery('#city').attr('required','true');
		jQuery('#state').attr('required','true');
		jQuery('#country').attr('required','true');
		jQuery('#zip').attr('required','true');
		
		
		
		
	}else{
		jQuery('.card-payment').css('display','none');
		
		jQuery('#card_number').removeAttr('required');
		jQuery('#expiry_month').removeAttr('required');
		jQuery('#expiry_year').removeAttr('required');
		jQuery('#cvv').removeAttr('required');
		
		jQuery('#card_type').removeAttr('required');
		
		jQuery('#first_name').removeAttr('required');
		jQuery('#last_name').removeAttr('required');
		jQuery('#street').removeAttr('required');
		jQuery('#city').removeAttr('required');
		jQuery('#state').removeAttr('required');
		jQuery('#country').removeAttr('required');
		jQuery('#zip').removeAttr('required');
	}
}
 
function validateForm() { 
	if(jQuery("input[name='payment_type']:checked").val()=='paypal_pro'){
		
		
		var card_number = jQuery('#card_number').val(); 
		var expiry_month = jQuery('#expiry_month').val();
		var expiry_year = jQuery('#expiry_year').val();
		var cvv = jQuery('#cvv').val();

		  if(!card_number.match(/^\d+$/)){
			alert("Please enter numeric characters(0-9) only without spaces for card number!");
			return false;
		  }
		  else if(!expiry_month.match(/^\d+$/)){
			alert("Please enter numeric characters(0-9) only for expiry month!");
			return false;
		  }		  
		  else if(!expiry_year.match(/^\d+$/)){
			alert("Please enter numeric characters(0-9) only for expiry year!");
			return false;
		  }
		  else if(!cvv.match(/^\d+$/)){
			alert("Please enter numeric characters(0-9) only for cvv!");
			return false;
		  }
		  else{
			  return true;
		  }
		  
		
		
		
		
	}
}
</script>
<div class="row-fluid vquiz-order-conform">
<h2><?php echo JText::_('COM_VQUIZ_ORDER_CONFIRM_HEADING');?></h2>
<div class="vquiz-order-conform_inner">
<form action="index.php?option=com_vquiz&view=orders" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data" onSubmit="return validateForm();">
    <div class="row-fluid order_title_price">
		<div class="span6 payplans-wordbreak">
		<h3><?php  $params=json_decode($this->orderDetail->params);echo $params->title; ?></h3>
		<span class="muted">
			
		</span>
		</div>
		<h3 class="span6 text-right first-amount">
			<?php if(floatval(0) == floatval($this->orderDetail->subtotal)):?>
									<?php echo JText::_('COM_VQUIZ_PLAN_PRICE_FREE');?>
							<?php else : 
									echo QuizHelper::priceformat($params->price);?>
							<?php endif;?>
		</h3>
	</div> 
	<!-- User Header -->
	<div class="row-fluid order_user_info">	
		<div class="span6">
			<div><h6><?php if($user->name != 'Not_Registered') : ?></h6></div>
			<div><h6><?php echo $user->name; ?></h6></div>
			<div class="pp-gap-top10"><?php echo $user->email; endif; ?></div>
			<div class="pp-gap-top10"><h6>#<?php echo $this->orderDetail->order_key;?></h6></div>
		</div>
		
		<div class="span6">
			
		</div>
	</div>
	
	<div class="row-fluid pp-gap-top10 pp-gap-bottom05 vquiz_order_info">
		
		<!-- Pricing Details -->
		<div class="span6">
			<?php $args = compact('invoice', 'order', 'user','subtotal','currency','total', 'tax_amount','discount','recurring', 'plugin_result','payment_apps');?>
	<table class="table table-borderless" border="0" cellspacing="0" cellpadding="0">

		<!-- Regular Price -->
		<tr>
			<td>
				<div><?php echo JText::_('COM_VQUIZ_ORDER_CONFIRM_REGULAR_TOTAL');?></div>
				<div><sup>(<?php echo JText::_('COM_VQUIZ_ORDER_CONFIRM_DISCOUNTABLE_TAXABLE'); ?>)</sup>&nbsp;</div>
			</td>
			<td class="text-right vquiz-payment-header-price"><?php echo QuizHelper::priceformat($params->price);?></td>
		</tr>
		<?php $config = QuizHelper::getConfiguration(); 
		if($config->enableDiscount==1) : ?>
        <tr class="discountable-amount"> 
				<td>
					<div></div>
					<div><sup>(<?php echo JText::_('COM_VQUIZ_ORDER_CONFIRM_DISCOUNTABLE_AMOUNT'); ?>)</sup>&nbsp;</div>
				</td>
				<td class="text-right vquiz-payment-header-price2">
					<span style="font-size: 11px;"><?php 
					
					echo (($this->orderDetail->discount_amount) > 0) ? '(-)&nbsp;' : '(+)&nbsp;'; ?></span>
					<?php echo QuizHelper::priceformat($this->orderDetail->discount_amount); ?>
				</td>
			</tr>
		
		<?php endif;
		
		if($config->tax_enable==1) : 
		$taxes = $this->orderDetail->tax;
		
		?>
		 
			
			<tr class="taxable-amount">
				<td>
					<div></div>
					<div><sup>(<?php echo JText::_('COM_VQUIZ_ORDER_CONFIRM_NON_DISCOUNTABLE_TAXABLE'); ?>)</sup>&nbsp;</div>
				</td>
				<td class="text-right vquiz-payment-header-price2 pp-amount" style="vertical-align:middle;">
					<span style="font-size: 11px;"><?php echo ($taxes < 0) ? '(-)&nbsp;' : '(+)&nbsp;'; ?></span>
					<span class="quiz-amount"><?php echo QuizHelper::priceformat($taxes); ?></span>
				</td>
			</tr>
		<?php endif;?>
	 	
		
		<!-- Total Payable Amount -->
		<tr class="table-row-border">
			<td><?php echo JText::_('COM_VQUIZ_ORDER_CONFIRM_AMOUNT_PAYABLE');?></td>
			<td class="text-right vquiz-payment-header-price payable first-amount">
				
				<?php echo QuizHelper::priceformat($this->orderDetail->total);?>
			</td>
		</tr>

	</table>
	</div>
	<?php if($config->enableDiscount==1) : ?>
	
		<div class="span6 right">			
			<div class="input-append">
					<input class="span9 input-medium" id="app_discount_code_id" type="text" name="app_discount_code" size="9" value="" placeholder="<?php echo JText::_("COM_VQUIZ_ENTER_DISCOUNT_CODE"); ?>" />
					
					<button type="button" id="app_discount_code_submit" class="btn" data-loading-text="wait..." title = "<?php  echo JText::_("COM_VQUIZ_PRODISCOUNT_APPLY_TOOLTIP"); ?>" onClick="discount_apply();"><?php  echo JText::_("COM_VQUIZ_APP_DISCOUNT_APPLY"); ?></button>
					
					
					
			</div>
			
			<span id="pp-discount-spinner"  style="height:12px;">&nbsp;&nbsp;</span>
			
			<!--<div id="app-discount-apply-error" class="text-error">&nbsp;
			</?php /* if(isset($this->obj->result) ){
			echo JText::_($this->obj->message);	
			} */ 
			?></div>-->
		
  <?php endif; ?>
  <div class="pp-gap-top10 pp-gap-bottom05 row-fluid">
			<div class="span6">
					<?php echo JText::_('COM_VQUIZ_ORDER_MAKE_PAYMENT_FROM');?>
			</div>
			<div class="span6">
				<span class="pp-payment-method">
					            
                 <?php 
				 if(floatval(0) == floatval($this->orderDetail->subtotal)){
					 echo '<div class="span12"><label><input id="" type="radio" checked="checked" name="payment_type" class="payment_type form-control input-medium"  value="free" /> <span class="payment_plugin_label">Free</span></label></div>';
				 }
				 else{
					for($p=0;$p<count($this->Payment_integration);$p++)
				    { 
						$p_details =$this->Payment_integration[$p];  
					
					 echo '<div class="span12"><label><input id="" type="radio"'.($p_details->featured==1?' checked="checked"':'').' name="payment_type" class="payment_type form-control input-medium"  value="'.$p_details->plugin_type.'" onclick="showpaypalpro()" />';
			         echo '<span class="payment_plugin_icon"><img src="'.JUri::root().'components/com_vquiz/assets/upload/icon/'.$p_details->icon.'" alt="'.$p_details->title.'"></span><span class="payment_plugin_label">'.JText::_($p_details->title).'</span></label></div>';
						
                    } 
				 }
                   ?>
				</span>	
			</div>
	</div>
	</div>
	
	<!-- For paypal pro -->
	
	<div class="card-payment" style="display:none">
    <h3>PayPal Pro</h3>
    <div id="paymentSection">
        
           
            <ul> 
                <li>
                    <label for="card_number">Card number</label>
                    <input type="text" placeholder="1234 5678 9012 3456" id="card_number" name="card_number" required="true">
                </li>
    
                <li class="vertical">
                    <ul>
                        <li>
                            <label for="expiry_month">Expiry month</label>
                            <select name="expiry_month" id="expiry_month" required="true">
							<option value="">MM</option>
							<option value="01">01</option>
							<option value="02">02</option>
							<option value="03">03</option>
							<option value="04">04</option>
							<option value="05">05</option>
							<option value="06">06</option>
							<option value="07">07</option>
							<option value="08">08</option>
							<option value="09">09</option>
							<option value="10">10</option>
							<option value="11">11</option>
							<option value="12">12</option>
						</select>
                        </li>
                        <li>
                            <label for="expiry_year">Expiry year</label>
                            <select name="expiry_year" id="expiry_year" required="true">
							<option value="">YYYY</option>
							<?php 
							$cur_year=date('Y');
							$max_exp_year = $cur_year+15;
							for($i=$cur_year;$i<=$max_exp_year;$i++){?>
							<option value="<?php echo $i;?>"><?php echo $i;?></option>
							<?php }?>
							</select>
                        </li>
                        <li>
                            <label for="cvv">CVV</label>
                            <input type="text" placeholder="123" maxlength="4" id="cvv" name="cvv" required="true">
                        </li>
                    </ul>
                </li>
               
                <li>
					<label for="card_type">Card type</label>
                     <select name="card_type" id="card_type" required="true">
						<option value="">Select Card Type</option>
						<option value="Amex">American Express</option>
						<option value="Discover">Discover</option>
						<option value="MasterCard">MasterCard</option>
						<option value="Visa">Visa</option>
						
						
						
				   </select>
                   
                </li>
				
				<!-- Billing Info -->
				
				<h3>Billing Address</h3>
				
				<li>
                    <label for="first_name">FIRST NAME</label>
                    <input type="text" placeholder="FIRST NAME" id="first_name" name="first_name" required="true">
                </li>
				<li>
                    <label for="last_name">LAST NAME</label>
                    <input type="text" placeholder="Name" id="last_name" name="last_name" required="true">
					
					<input type="hidden" name="email" value="<?php echo isset($user->email)?$user->email:'none'; ?>">
					
                </li>
				<li>
                    <label for="street">STREET</label>
                    <input type="text" placeholder="STREET" id="street" name="street" required="true">
                </li>
				<li>
                    <label for="city">CITY</label>
                    <input type="text" placeholder="CITY" id="city" name="city" required="true">
                </li>
				<li>
                    <label for="state">STATE</label>
                    <input type="text" placeholder="STATE" id="state" name="state" required="true">
                </li>
				<li>
                    <label for="country">COUNTRY</label>
                    <input type="text" placeholder="COUNTRY" id="country" name="country" required="true">
                </li>
				<li>
                    <label for="zip">ZIP</label>
                    <input type="text" placeholder="ZIP" id="zip" name="zip" required="true">
                </li>
								
            </ul>
        
    </div>
    
</div>
	
	<!--//End for paypal pro -->
	
		<div class="row-fluid well">
		
			<!-- for tos -->
			

			<!-- for checkout button -->
				<div class="text-right">
						<button type="submit" id="payplans-order-confirm" class="btn-large btn btn-primary ">
							<i class="icon-white icon-shopping-cart "></i>
							<?php echo JText::_('COM_VQUIZ_ORDER_CONFIRM_BTN')?>
						</button>
				</div>

		</div>
</div>

   
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="confirm" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="orders" />
<input type="hidden" name="order_key" value="<?php echo $this->orderDetail->order_key;?>" />
</form>
</div>
</div>
	