<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');  
$document = JFactory::getDocument();    

/* 
$document->addScript(JUri::root().'/components/com_vquiz/assets/js/jquery-ui.js');     
$document->addStyleSheet('components/com_vquiz/assets/css/jquery-ui.css'); */

$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$user = JFactory::getUser();
if(version_compare(JVERSION, '3.0', '>=')) 
	JHtml::_('formbehavior.chosen', 'select');
$editor = JFactory::getEditor();
jimport( 'joomla.html.html.tabs' );    

$options = array(
'onActive' => 'function(title, description){
        description.setStyle("display", "block");
        title.addClass("open").removeClass("closed");
    }',
    'onBackground' => 'function(title, description){
        description.setStyle("display", "none");
        title.addClass("closed").removeClass("open");
    }',

    'startOffset' => 0,  // 0 starts on the first tab, 1 starts the second, etc...

    'useCookie' => true, // this must not be a string. Don't use quotes.

);

//echo $this->quiz_count; exit;
?>
<script type="text/javascript"> 
var jq=jQuery.noConflict();

jq(document).ready(function(){ 

	
			  
});

</script>

<div class="manage_quizzes vquizpanel">
<div class="profile-section profile-section_inner">  
<div class="hx_top_bar">
<div class="hx_dash_title"><img src="<?php echo JURI::root();?>/media/com_vquiz/vquiz/images/vquiz-logo.png" alt="vQuiz"> <span class="hx_main_title"><?php echo JText::_( 'VQUIZ_DASHBOARD' );?></span></div>
<div class="hx_dash_buttons hx_dash_buttons_four">

		<?php if($user->authorise('core.useradmin','com_vquiz')){ ?>
                    <a class="btn btn-dashboard" href="<?php echo JRoute::_('index.php?option=com_vquiz&view=useradmin');?>"><span class="icon-dashboard"></span> <?php echo JText::_('DASHBOARD'); ?></a>	
					
		<?php } if($user->authorise('core.userquizzes','com_vquiz')){ ?>
                    <a class="btn btn-quizzes" href="<?php echo JRoute::_('index.php?option=com_vquiz&view=usersquizzes');?>"><span class="icon-question-2"></span> <?php echo JText::_('COM_VQUIZ_QUIZZES'); ?></a> 
	
	    <?php }if($user->authorise('core.userquizzesresult','com_vquiz')){ ?>
                    <a class="btn btn-quiz-results" href="<?php echo JRoute::_('index.php?option=com_vquiz&view=quizresult');?>">
					<span class="icon-file-2"></span> <?php echo JText::_('COM_VQUIZ_DISPLAY_QUIZ_RESULT'); ?></a> 
 
	   <?php }if($user->authorise('core.userresult','com_vquiz')){ ?>
                    <a class="btn btn-my-results" href="<?php echo JRoute::_('index.php?option=com_vquiz&view=quizresult&layout=myresults');?>">
					<span class="icon-file-2"></span> <?php echo JText::_('COM_VQUIZ_YOUR_RESULT'); ?></a> 
		<?php }?>
		
		 <a class="btn btn-my-subscriptions active" href="<?php echo JRoute::_('index.php?option=com_vquiz&view=subscriptions');?>">
					<span class="icon-file-2"></span> <?php echo JText::_('COM_VQUIZ_YOUR_SUBSCRIPTIONS'); ?></a> 
</div>

</div>
<div class="clr"></div>

<div id="toolbar" class="btn-toolbar">
<div class="vqz_title"><?php echo JText::_('CONFIGURATION'); ?></div>
	
	<div id="toolbar-apply" class="btn-wrapper">
			<button class="btn btn-small btn-success" onclick="Joomla.submitbutton('apply')">
			<span class="icon-apply"></span> <?php echo JText::_('SAVE');?></button>
		</div>
		
</div>

<form action="index.php?option=com_vquiz&view=config" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<?php if (!empty( $this->sidebar)) : ?>   
		<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
		</div>
		<div id="j-main-container" class="span10">
		<?php else : ?>
		<div id="j-main-container">
		<?php endif;?>
		<div class="clr" style="clear:both;"></div>
		
<legend><?php // echo JText::_('COM_VQUIZ_CONFIGURATION'); ?></legend>
		
<div class="col101">

	<div id="tabs" class="config_alert">
	
	<?php echo JHtml::_('tabs.start', 'tab_group_id', $options); ?>     
	<?php echo JHtml::_('tabs.panel', JText::_('NOTIFICATION'), 'notification'); ?>
	
				
		
		<div id="notification">
			<table class="adminform table table-striped">
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notfify_add_quizcategory" value="1" <?php if($this->item->notfify_add_quizcategory) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADD_NEW_CATEGORY');?>"><?php echo JText::_('COM_VQUIZ_ADD_NEW_CATEGORY');?></label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notfify_add_quiz" value="1" <?php if($this->item->notfify_add_quiz) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADD_NEW_QUIZZES');?>"><?php echo JText::_('COM_VQUIZ_ADD_NEW_QUIZZES');?></label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notify_add_lpath" value="1" <?php if($this->item->notify_add_lpath) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADD_NEW_LEARNING_PATH');?>"><?php echo JText::_('COM_VQUIZ_ADD_NEW_LEARNING_PATH');?></label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notify_add_lesson" value="1" <?php if($this->item->notify_add_lesson) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADD_NEW_LESSION');?>"><?php echo JText::_('COM_VQUIZ_ADD_NEW_LESSION');?></label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notify_add_skill" value="1" <?php if($this->item->notify_add_skill) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADD_NEW_SKILL');?>"><?php echo JText::_('COM_VQUIZ_ADD_NEW_SKILL');?></label>					
					</td>
				</tr>
				
				<?php if($this->quiz_count>0){ //if user has added atleast one quiz ?>
				<tr>
					<td class="key">					
					<input type="checkbox" name="notify_send_invitation" value="1" <?php if($this->item->notify_send_invitation) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SEND_NEW_INVITATION');?>"><?php echo JText::_('COM_VQUIZ_SEND_NEW_INVITATION');?>*</label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notify_complete_invitation" value="1" <?php if($this->item->notify_complete_invitation) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_COMPLETE_INVITATION');?>"><?php echo JText::_('COM_VQUIZ_COMPLETE_INVITATION');?>*</label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notify_send_certificate" value="1" <?php if($this->item->notify_send_certificate) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SEND_CERTIFICATE');?>"><?php echo JText::_('COM_VQUIZ_SEND_CERTIFICATE');?>*</label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notify_complete_quiz" value="1" <?php if($this->item->notify_complete_quiz) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZ_COMPLETION');?>"><?php echo JText::_('COM_VQUIZ_QUIZ_COMPLETION');?>*</label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notify_complete_lpath" value="1" <?php if($this->item->notify_complete_lpath) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LEARNING_PATH_COMPLETION');?>"><?php echo JText::_('COM_VQUIZ_LEARNING_PATH_COMPLETION');?>*</label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notify_incomplete_quiz" value="1" <?php if($this->item->notify_incomplete_quiz) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_INCOMPLETE_QUIZ');?>"><?php echo JText::_('COM_VQUIZ_INCOMPLETE_QUIZ');?>*</label>					
					</td>
				</tr>
				
				<?php } ?>
				
				
			</table>
		</div>
		
										<!-- Email Notification-->
		<?php echo JHtml::_('tabs.panel', JText::_('EMAIL_NOTIFICATION'), 'email_notification');?>
		
		<div id="email_notification">
			<table class="adminform table table-striped">
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notfify_add_quizcategory" value="1" <?php if($this->item->notfify_add_quizcategory) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADD_NEW_CATEGORY');?>"><?php echo JText::_('COM_VQUIZ_ADD_NEW_CATEGORY');?></label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="notfify_add_quiz" value="1" <?php if($this->item->notfify_add_quiz) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADD_NEW_QUIZZES');?>"><?php echo JText::_('COM_VQUIZ_ADD_NEW_QUIZZES');?></label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="enotify_add_lpath" value="1" <?php if($this->item->notify_add_lpath) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADD_NEW_LEARNING_PATH');?>"><?php echo JText::_('COM_VQUIZ_ADD_NEW_LEARNING_PATH');?></label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="enotify_add_lesson" value="1" <?php if($this->item->enotify_add_lesson) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADD_NEW_LESSION');?>"><?php echo JText::_('COM_VQUIZ_ADD_NEW_LESSION');?></label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="enotify_add_skill" value="1" <?php if($this->item->enotify_add_skill) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADD_NEW_SKILL');?>"><?php echo JText::_('COM_VQUIZ_ADD_NEW_SKILL');?></label>					
					</td>
				</tr>
				
				<?php if($this->quiz_count>0){ //if user has added atleast one quiz ?>
				<tr>
					<td class="key">					
					<input type="checkbox" name="enotify_send_invitation" value="1" <?php if($this->item->enotify_send_invitation) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SEND_NEW_INVITATION');?>"><?php echo JText::_('COM_VQUIZ_SEND_NEW_INVITATION');?>*</label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="enotify_complete_invitation" value="1" <?php if($this->item->enotify_complete_invitation) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_COMPLETE_INVITATION');?>"><?php echo JText::_('COM_VQUIZ_COMPLETE_INVITATION');?>*</label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="enotify_send_certificate" value="1" <?php if($this->item->enotify_send_certificate) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SEND_CERTIFICATE');?>"><?php echo JText::_('COM_VQUIZ_SEND_CERTIFICATE');?>*</label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="enotify_complete_quiz" value="1" <?php if($this->item->enotify_complete_quiz) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZ_COMPLETION');?>"><?php echo JText::_('COM_VQUIZ_QUIZ_COMPLETION');?>*</label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="enotify_complete_lpath" value="1" <?php if($this->item->enotify_complete_lpath) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LEARNING_PATH_COMPLETION');?>"><?php echo JText::_('COM_VQUIZ_LEARNING_PATH_COMPLETION');?>*</label>					
					</td>
				</tr>
				
				<tr>
					<td class="key">					
					<input type="checkbox" name="enotify_incomplete_quiz" value="1" <?php if($this->item->enotify_incomplete_quiz) echo 'checked="checked"';?> />
					
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_INCOMPLETE_QUIZ');?>"><?php echo JText::_('COM_VQUIZ_INCOMPLETE_QUIZ');?>*</label>					
					</td>
				</tr>
				<?php } ?>
				
			</table>
		</div>
				<?php echo JHtml::_('tabs.end'); ?> 
				
				<?php if($this->quiz_count>0){ //if user has added atleast one quiz ?>
				<p>* <?php echo JText::_('COM_VQUIZ_APPLLICABLE_ON_YOUR_QUIZ');?></p>
				<?php } ?>
	</div>
	
</div>

<div class="clr"></div>
<?php echo JHTML::_( 'form.token' ); ?>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="config" />
</form>
</div>

