<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport( 'joomla.application.component.view' );

class VquizViewConfig extends JViewLegacy
{ 

	function display($tpl = null){
	 
			$mainframe =JFactory::getApplication();
			$document = JFactory::getDocument();
			$user=JFactory::getUser();
			
			$layout = JRequest::getCmd('layout', '');
			$item = $this->get('Item');
			$this->assignRef( 'item', $item );
			
			if($user->id==0){
				$mainframe->redirect(JURI::base().'index.php?option=com_users&view=login', $error, 'error' );
			} 

			if($user->get('guest')){
				jerror::raiseWarning('403', JText::_('UNAUTH_ACCESS_PLZ_LOGIN'));
				return false;	
			}
			
			$this->quiz_count = $this->get('QuizCount');
			
			//print_r($item);
			//print_r($this->config); exit;
			
			$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
			$document->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/adminpanel.css');
			$document->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/responsive_layout.css');
			$document->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/icomoon.css');
			$document->addScript(JURI::root().'components/com_vquiz/assets/css/jquery-ui.css');
			
			parent::display($tpl);
			

		}
 
}
