<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die(); 
jimport( 'joomla.application.component.view');

class VquizViewLessons extends JViewLegacy
{
    
    function display($tpl = null)
    {
	    $layout = JRequest::getCmd('layout', '');
		$doc =JFactory::getDocument();	
		if($layout == 'lessondetails'){
			
			$this->lesson =$this->get('Item');
			$this->learningnextlevel =$this->get('Learningnextlevel');									$this->videodetail =$this->get('VideoDetail');			$this->lessons_completed = $this->get('LessonViewedStatus');
			//print_r($this->videodetail); 
		}else{
			$this->items = $this->get('Items'); 
			$this->pagination = $this->get('Pagination');
			$this->configuration = $this->get('Configuration');
		
        }
		$doc->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/style.css');
		$doc->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/responsive_layout.css');
		$doc->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/jquery-ui.css');
		$doc->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/smoothness.css');
		parent::display($tpl);
        
    }
  
}
