<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
defined('_JEXEC') or die('Restricted msg');
JHTML::_('behavior.tooltip');

$document = JFactory::getDocument();
$app=JFactory::getApplication();
$document->setTitle('Quiz Lessons'.' - '.$app->getCfg( 'sitename' ) );
$document->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/style.css');
?>

<form action="index.php?option=com_vdirectory&view=category" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">		
	
<div class="adminform">

	<div class="cpanel-left">
		<div class="board"> 
		<h1 class="play_quiz"><?php echo JText::_('COM_VQUIZ_LESSONS'); ?></h1> 

		<?php for($i=0;$i<count($this->items);$i++)  
			 { ?>
		 
		 	<div class="<?php echo "row$i"; ?> vcat <?php echo "list_column".$this->configuration->list_column; ?>">
	            
				<a class="cat_img" href="<?php echo JRoute::_( 'index.php?option=com_vquiz&view=lessons&layout=lessondetails&id='. $this->items[$i]->id); ?>">               
				<?php  
                if(!empty($this->items[$i]->thumbnail)){ 
                echo '<img class="hasTip" src="'.JURI::root().'/media/com_vquiz/vquiz/images/photoupload/lessons/thumbs/thumb_'.$this->items[$i]->thumbnail. '" alt="'.$this->items[$i]->title.'" title="'.$this->items[$i]->title.'" width="'.$this->configuration->categorythumbnailwidth.'" height="'.$this->configuration->categorythumbnailheight.'" / >'; 
                }else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" width="'.$this->configuration->categorythumbnailwidth.'" height="'.$this->configuration->categorythumbnailheight.'" />';} 
                
                ?>
				</a>  
				<a href="<?php echo JRoute::_( 'index.php?option=com_vquiz&view=lessons&layout=lessondetails&id='. $this->items[$i]->id); ?>">
				<h4><?php echo $this->items[$i]->title; ?></h4></a>
			
			</div>
	 
		<?php } ?>

	</div>
</div>
</div>
<div class="pagination" id="pagination"><?php echo $this->pagination->getListFooter(); ?></div>
</form>
