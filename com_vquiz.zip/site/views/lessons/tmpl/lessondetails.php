<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/

defined('_JEXEC') or die('Restricted msg');
JHTML::_('behavior.tooltip');
$title=JRequest::getInt('id')!=0?$this->lesson->title: JText::_('COM_VQUIZ_LESSONS');
$doc =JFactory::getDocument();	
$doc->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/owl.carousel.min.css');
$doc->addStyleSheet(JURI::root().'components/com_vquiz/assets/css/owl.theme.default.min.css');
$doc->addScript(JURI::root().'components/com_vquiz/assets/js/owl.carousel.min.js');
?>
<style>
video::-internal-media-controls-download-button {
    display:none;
}
 
video::-webkit-media-controls-enclosure {
    overflow:hidden;
}
 
video::-webkit-media-controls-panel {
    width: calc(100% + 30px); /* Adjust as needed */
}
</style>
<script type="text/javascript">
var $r=jQuery.noConflict();
	var slideIndex = 1;
	
$r(document).ready(function(){ 
	var owl = $r('.owl-carousel');
	owl.owlCarousel({
		items:<?php echo $this->lesson->num_carousel>0?$this->lesson->num_carousel:1 ;?>,
		loop:true,
		margin:10,
		autoplay:<?php echo $this->lesson->auto_slide==1?'true':'false'?>,
		autoplayTimeout:<?php echo $this->lesson->slidesdelay>0?$this->lesson->slidesdelay:3000 ;?>,
		autoplayHoverPause:true,
		lazyLoad: true
		//autoHeight:true
	});
	$r('.owl-play').on('click',function(){
		owl.trigger('play.owl.autoplay',[1000])
	})
	$r('.owl-stop').on('click',function(){
		owl.trigger('stop.owl.autoplay')
	})
	$r('.owl-prev').on('click',function(){
		owl.trigger('prev.owl.carousel',[1000])
	})
	$r('.owl-next').on('click',function(){
		owl.trigger('next.owl.carousel',[1000])
	})
});

</script>
<form action="index.php?option=com_vquiz&view=lessons" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">			
				
<div id="maindiv" class="board maindiv">
	<div class="inner_board">
	<h1 class="page_header"><?php echo $title;?></h1>
	<div class="row0">
	<div class="col-md-8 col-sm-8">
	<?php 

		$imgext = array('jpg','jpeg','png','gif');
		$docext= array('doc','docx','txt','csv','xl');
		$pdfext= array('pdf','swf');
		$audext = array('mp3','wav','avi');
		$vidext = array('mp4','avi','mov');
		$lfile = array('zip','rar','exc');
		
		$filetype = JURI::root().'/media/com_vquiz/vquiz/images/files/'.$this->lesson->files;
		$filePtah = JPATH_ROOT.'/media/com_vquiz/vquiz/images/files/'.$this->lesson->files;
		
        $ext = strtolower(pathinfo($filetype, PATHINFO_EXTENSION)); 
		
		if($this->lesson->type =="slide") {
			 
			$slide_img = json_decode($this->lesson->slide_img);
	 
			if(!empty($slide_img)){?>
 
			<div  class="owl-carousel">
			<?php for($i=0;$i<count($slide_img);$i++){
				$slide_imgsrc = JURI::root().'/media/com_vquiz/vquiz/images/slide/'.$slide_img[$i];
				?>
				  <div><img src="<?php echo $slide_imgsrc;?>" /></div>
			<?php }?>
			</div>
			
			<?php if($this->lesson->slide_control==1) {?>
				<div class="control-owl">
					<div class="inline-block"><a class="owl-prev btn btn-small">Prev</a></div>
					<div class="inline-block"><a class="owl-play btn btn-small">Play</a></div>
					<div class="inline-block"><a class="owl-stop btn btn-small">Stop</a></div>
					<div class="inline-block"><a class="owl-next btn btn-small">Next</a></div>
				</div>
			<?php }}
			
		}elseif($this->lesson->type!="text") {
			
                if (in_array($ext, $imgext)) {				
                 if(!empty($this->lesson->files) and file_exists($filePtah)){ 
                   echo '<img height="100" width="100" src="'.$filetype.'" alt="'.$this->lesson->files.'" />'; 
                   } 
               }
			   
			   if (in_array($ext, $pdfext)) {				
                 if(!empty($this->lesson->files) and file_exists($filePtah)){ 
                   echo '<a class="prev" href="'.$filetype.'" target="_blank"> <img height="50" width="50" src="'.JURI::root().'/media/com_vquiz/vquiz/images/pdf.png"/></a>'; 
				   echo $this->lesson->files; 
				   }
               }
			   
			   if (in_array($ext, $docext)) {				
                  if(!empty($this->lesson->files) and file_exists($filePtah)){ 
                   echo '<a class="prev" href="'.$filetype.'" target="_blank"> <img height="50" width="50" src="'.JURI::root().'/media/com_vquiz/vquiz/images/doc.jpg"/></a>'; 
				   echo $this->lesson->files; 
				   }
               }
			   
			   if (in_array($ext, $lfile)) {				
                  if(!empty($this->lesson->files) and file_exists($filePtah)){ 
                   echo '<a class="prev" href="'.$filetype.'" target="_blank"> <img height="50" width="50" src="'.JURI::root().'/media/com_vquiz/vquiz/images/file.jpg"/></a>'; 
				   echo $this->lesson->files; 
				   }
               }
			   
			   if (in_array($ext, $audext)) {				
                 if(!empty($this->lesson->files) and file_exists($filePtah)){
				     echo '<audio width="400" controls oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
                           <source src="'.$filetype.'" type="audio/mp3">
                           <source src="'.$filetype.'" type="audio/avi">
						   <source src="'.$filetype.'" type="audio/wav">
                            '.JText::_('YOUR_BROWSER_NOT_SUPPORT_THIS_AUDIO').'
							</audio>' ;
				   }
               }
			   
			   if (in_array($ext, $vidext)) {				
                 if(!empty($this->lesson->files) and file_exists($filePtah)){ 
				      echo '<video width="400" id="vid" controls oncontextmenu="return false" onselectstart="return false" ondragstart="return false">
                           <source src="'.$filetype.'" type="video/mp4">
                           <source src="'.$filetype.'" type="video/avi">
						   <source src="'.$filetype.'" type="video/mov">
							'.JText::_('YOUR_BROWSER_NOT_SUPPORT_THIS_VIDEO').'
                       </video>' ;
				   }
               }
	  } else{
		  echo $this->lesson->description;
	  }?>
	  
	  
		</div>
	</div>

	<div class="row0">
	<?php if($this->learningnextlevel->learningquizId !=0){?>
		<div class="col-md-4 col-sm-4">		
			<div class="text-center">			<?php			if($this->lessons_completed==1){?>						<a href="<?php echo JRoute::_('index.php?option=com_vquiz&view=quizmanager&layout=description&learningId='.$this->learningnextlevel->learningId.'&id='.$this->learningnextlevel->learningquizId.'&lessonid='.$this->lesson->id);?>" class="btn btn-success" title="<?php echo JText::_('COM_VQUIZ_PLAY_LEARNING_PATH');?>"><?php echo JText::_('COM_VQUIZ_PLAY_NOW');?></a>						<?php					}else{?>						<a href="javascript:alert('<?php echo JText::_('COM_VQUIZ_PLS_WATCH_ALL_LESSONS');?>');" class="btn btn-success"><?php echo JText::_('COM_VQUIZ_PLAY_NOW');?></a>											<?php } 			?>
				
			</div>
		</div>
	<?php }else if( $this->learningnextlevel->lessonId !=0){?>
		<div class="col-md-4 col-sm-4">		
			<div class="pull-right">
				<a href="<?php echo JRoute::_('index.php?option=com_vquiz&view=lessons&layout=lessondetails&id='.$this->learningnextlevel->lessonId.'&learningId='.$this->learningnextlevel->learningId) ?>" class="btn btn-info" title="<?php echo JText::_('COM_VQUIZ_NEXT_LESSONS');?>"><?php echo JText::_('COM_VQUIZ_NEXT');?></a>
			</div>
		</div>
	<?php } ?>
	</div>
	
	</div>
</div>
<script>
var learning_id = <?php echo $learning_id = JRequest::getInt('learningId',0); ?>;
var lession_id = <?php echo !empty($this->lesson->id)?$this->lesson->id:0?>; 
var video = document.getElementById("vid");
var viewedpos = <?php echo !empty($this->videodetail->video_seen)?$this->videodetail->video_seen:0?>; 
var completed = <?php echo !empty($this->videodetail->completed)?$this->videodetail->completed:0?>; video.addEventListener('loadedmetadata', function() {  video.currentTime = viewedpos;}, false);video.addEventListener('seeking', function() {  var curpos = video.currentTime;	if(curpos > viewedpos) {	  video.currentTime=viewedpos;	}}, false);
video.addEventListener('play', function() {   interval = setInterval(updateVideo,2000); 
}, false);
video.addEventListener('pause', function() {  clearInterval(interval);}, false);
video.addEventListener('ended', function() {   completed = 1;  updateVideo();  }, false);

function updateVideo(){     learning_rs_id = $r('#learning_rs_id').val(); 		request = $r.ajax({        url: "<?php echo JURI::root();?>",        type: "post",		dataType:"json",        data: {'option':'com_vquiz', 'view':'lessons','task':'setvideoinfo', 'tmpl':'component','learning_rs_id':learning_rs_id,'learning_id':learning_id,'lession_id':lession_id,'viewedpos':viewedpos,'curpos':video.currentTime,'completed':completed,"<?php echo JSession::getFormToken(); ?>":1}     });	    request.done(function (response, textStatus, jqXHR){       		 if(response.learning_rs_id){			$r('#learning_rs_id').val(response.learning_rs_id); 		} 		viewedpos = response.video_seen;    });    request.fail(function (jqXHR, textStatus, errorThrown){               console.error(            "The following error occurred: "+            textStatus, errorThrown        );    });        request.always(function () {           });}	

 $r(document).ready(function() {
    $r("video").bind("contextmenu",function(){
        return false;
        });
 } );	
</script>
<input type="hidden" id="learning_rs_id" value="<?php echo !empty($this->videodetail->id)?$this->videodetail->id:0?>" />
</form>