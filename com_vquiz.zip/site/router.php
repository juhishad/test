<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );

/*
 *
 * @param	array	A named array
 * @return	array
 */


class VquizRouter extends JComponentRouterBase
{
	public function build(&$query )
	{
		$db = JFactory::getDBO();
		$segments = array();
		$app = JFactory::getApplication();
		$menu = $app->getMenu();
		
		if (empty($query['Itemid'])) {
			$menuItem = $menu->getActive();
			$menuItemGiven = false;
		} else {
			$menuItem = $menu->getItem($query['Itemid']);
			$menuItemGiven = true;
		}
		
		// Check again
		if ($menuItemGiven && isset($menuItem) && $menuItem->component != 'com_vquiz')
		{
			$menuItemGiven = false;
			unset($query['Itemid']);
		} 
	
		if(isset($query['view']))	{
			
			switch($query['view'])	{
			   
			   case 'vquiz':
				   $segments[] ='quiz-categories';
				   unset($query['view']);
			   break;
			   case 'dashboard':
				   $segments[] ='dashboard';
				   unset($query['view']);
			   break;
			   case 'orders':
				   $segments[] ='orders';
				   unset($query['view']);
				   if(isset($query['task'])){
					 $segments[] =$query['task'];
						unset($query['task']);  
					 }
				   if(isset($query['order_key'])){
					 $segments[] =$query['order_key'];
						//unset($query['order_key']);  
					 }
			   break;
			   case 'plans':
				   $segments[] ='plans';
				   unset($query['view']);
				   if(isset($query['task'])){
					 $segments[] =$query['task'];
						unset($query['task']);  
					 }
					 if(isset($query['plan_id'])){
					 $q = 'select alias from #__vquiz_plans where id = '.(int)$query['plan_id'];
								$db->setQuery( $q );
								$alias = $db->loadResult();
								$segments[] = empty($alias)?$query['id']:$alias;
					 
						$segments[] = $query['plan_id'];
						unset($query['plan_id']);  
					 }
			   break;
			   
			   case 'learning':
					$segments[]='learning-paths';
					
					if(isset($query['id']))	{ 
						
						$q = 'select alias from #__vquiz_learning where id = '.(int)$query['id'];
						$db->setQuery( $q );
						$item = $db->loadResult();

						if(!empty($item)){						
							$segments[] = empty($item)?$query['id']:$item;																
						}
						
						unset($query['id']);
					}
					
					if(isset($query['layout'])){
						switch($query['layout']){ 
							case 'description':
							$segments[] = 'quizzes';
							break;
						}
						unset($query['layout']);
					}
					break;
					
					case 'lessons':
					$segments[]='lessons';
					
					if(isset($query['id']))	{ 
						
						$q = 'select alias from #__vquiz_lessons where id = '.(int)$query['id'];
						$db->setQuery( $q );
						$item = $db->loadResult();					
						$segments[] = empty($item)?$query['id']:$item;
						unset($query['id']);
					}
										
					if(isset($query['layout'])){
						switch($query['layout']){ 
							case 'lessondetails':
							$segments[] = 'details';
							break;
						}
						unset($query['layout']);
					}
					
					break;
				
				case 'quizmanager' :
										
				$segments[] ='quizzes';
					
				if(isset($query['layout'])){
												
						switch($query['layout'])	{ 
						
						case 'quizzes':
							
							if(isset($query['id']))	{ 
								if($query['id']==0)
									$segments[] = 'browse-all';
								else{
									$q = 'select alias from #__vquiz_category where id = '.(int)$query['id'];
									$db->setQuery( $q );
									$alias = $db->loadResult();
									$segments[] = empty($alias)?$query['id']:$alias;
									
									if(isset($query['learningId']))	{ 
										if($query['learningId']!=0){
											$q = 'select alias from #__vquiz_learning where id = '.(int)$query['learningId'];
											$db->setQuery( $q );
											$alias = $db->loadResult();			
											$segments[] = empty($alias)?$query['learningId']:$alias;					
											
										} 
										unset($query['learningId']);
									}
								}
								unset($query['id']);

							}else{	
								$segments[] = 'browse-all';
							}
												
							
							if(isset($query['modulorder']))	{ //jexit('exit');
							
								switch($query['modulorder'])	{
								
									case '1':
									$segments[] ='latest';//$query['latest'];
									break;
									case '2':
									$segments[] ='most-popular';//$query['most'];
									break;
									case '3':
									$segments[] ='recently-played';//$query['recent'];
									break;
									case '4':
									$segments[] ='random';//$query['recent'];
									break;
												
								}						
								
							}
							
							if(isset($query['featured']))	{ 
								if($query['featured']==1)
									$segments[] = 'featured';
								
								unset($query['featured']);
							}
						
						break;
						
						case 'description':
						
													
							/* if(isset($query['learningId']))	{ 
							
								//if($query['learningId']!=0){
									$q = 'select alias from #__vquiz_learning where id = '.(int)$query['learningId'];
									$db->setQuery( $q );
									$alias = $db->loadResult();			
									$segments[] = empty($alias)?$query['learningId']:$alias;					
								//}
								unset($query['learningId']);
							}  */
							
							if(isset($query['id']))	{ 
							
								$q = 'select i.alias, i.catid, c.alias as catalias from #__vquiz_quizzes as i join #__vquiz_category as c on i.catid=c.id where i.id = '.(int)$query['id'];
								$db->setQuery( $q );
								$item = $db->loadObject();
								
								if(!empty($item)){
									
									$segments[] = empty($item->catalias)?$item->catid:$item->catalias;
																
									$segments[] = empty($item->alias)?$query['id']:$item->alias;
																
								}
								
								unset($query['id']);
							}	
 		
						
						break;
				 
						}
					}

						/* if(isset($query['learningId'])){
						
							if($query['learningId']!=0){
								$q = 'select alias from #__vquiz_learning where id = '.(int)$query['learningId'];
								$db->setQuery( $q );
								$alias = $db->loadResult();			
								$segments[] = empty($alias)?$query['learningId']:$alias;
							}							
							unset($query['learningId']);

						}  */
					 
						if(isset($query['id']))	{ 
						
							$q = 'select i.alias, i.catid, c.alias as catalias from #__vquiz_quizzes as i join #__vquiz_category as c on i.catid=c.id where i.id = '.(int)$query['id'];
							$db->setQuery( $q );
							$item = $db->loadObject();
							
							if(!empty($item)){
								
								$segments[] = empty($item->catalias)?$item->catid:$item->catalias;			
								$segments[] = empty($item->alias)?$query['id']:$item->alias;
								$segments[] = 'play';
															
							}
							unset($query['id']);
						
						}
 
					if(isset($query['layout']))
						unset($query['layout']);
					if(isset($query['modulorder']))
						unset($query['modulorder']);
					if(isset($query['view']))
						unset($query['view']);
					
				break;
				
				case 'quizresult' :
					$segments[] = $query['view'];
					unset($query['view']);
				
				break;
				case 'quizdraft' :
					$segments[] = $query['view'];
					unset($query['view']);
				
				break;
				case 'usersquizzes' :
					$segments[] = $query['view'];
					unset($query['view']);
				
				break;
				case 'quizquestion' :
					$segments[] = $query['view'];
					unset($query['view']);
				
				break;
				case 'users' :
					$segments[] = $query['view'];
					unset($query['view']);
				
				break;
				case 'useradmin' :
					$segments[] = $query['view'];
					unset($query['view']);
				
				break;
				
				case 'subscriptions' :
					$segments[] = $query['view'];
					unset($query['view']);
				
				break;
				
				default:
					$segments[] = $query['view'];
					unset($query['view']);
				break;
				
				 
			}
			
			unset($query['view']);
		}

		return $segments;
	}



	public function parse( &$segments )
	{	

		$db = JFactory::getDBO();
		$app = JFactory::getApplication();
		$menu = $app->getMenu();
		$item = $menu->getActive();
		$vars = array();

		$count = count($segments); 
		
		for ($i = 0; $i < $count; $i++)
		{
			$segments[$i] = preg_replace('/-/', ':', $segments[$i]);
		}	
		if ($count)
		{
			$segments[0] = str_replace(':', '-', $segments[0]);
			
			switch($segments[0])	{			
				case 'learning-paths':
					$vars['view'] = 'learning';
					$count--;
					array_shift( $segments );
					if($count)
					{
						$segments[0] = str_replace(':', '-', $segments[0]);
						$q = 'select id from #__vquiz_learning where alias = '.$db->Quote($segments[0]);			
						$db->setQuery( $q );
						$id = $db->loadResult();
						$vars['id'] = empty($id)?$segments[0]:$id;
						$count--;
						array_shift( $segments );
					}

						
					if($count)	{
						$segments[0] = str_replace(':', '-', $segments[0]);
							switch($segments[0]){
							case 'quizzes':
							$vars['layout']='description';
							$count--;
							array_shift( $segments );
							break;
						}	
					
					}
					break;
					
					case 'lessons':
					$vars['view'] = 'lessons';
					$count--;
					array_shift( $segments );

					if($count)
					{
						$segments[0] = str_replace(':', '-', $segments[0]);
						$q = 'select id from #__vquiz_lessons where alias = '.$db->Quote($segments[0]);			
						$db->setQuery( $q );
						$id = $db->loadResult();
						$vars['id'] = empty($id)?$segments[0]:$id;
						$count--;
						array_shift( $segments );
					}
					
					if($count)	{
						$segments[0] = str_replace(':', '-', $segments[0]);
							switch($segments[0]){
							case 'details':
							$vars['layout']='lessondetails';
							$count--;
							array_shift( $segments );
							break;
						}	
					
					}
					
					break;
					
					case 'quizzes':

					$vars['view'] = 'quizmanager';
					$count--;
					array_shift( $segments );

					if($count)	{
						$segments[0] = str_replace(':', '-', $segments[0]);
						
						  if($segments[0]<>'browse-all'){
							$q = 'select id from #__vquiz_category where alias = '.$db->Quote($segments[0]);			
							$db->setQuery( $q );
							$id = $db->loadResult();
							$vars['id'] = empty($id)?$segments[0]:$id;								
							$count--;
							array_shift( $segments );
				
						}

					}
					
					if($count)	{
						$segments[0] = str_replace(':', '-', $segments[0]);
			
						switch($segments[0])	{
						 
							case 'latest':
							$vars['modulorder']=1;
							$vars['layout']='quizzes';
							break;
							case 'most-popular':
							$vars['modulorder']=2;
							$vars['layout']='quizzes';
							break;
							case 'recently-played':
							$vars['modulorder']=3;
							$vars['layout']='quizzes';
							break;
							case 'random':
							$vars['modulorder']=4;
							$vars['layout']='quizzes';
							break;
							
							default:
			 
					 			/* if($count)
								{
									$segments[0] = str_replace(':', '-', $segments[0]);
									$q = 'select id from #__vquiz_learning where alias = '.$db->Quote($segments[0]);
									$db->setQuery( $q );
									$id = $db->loadResult();
									$vars['learningId'] = empty($id)?$segments[0]:$id;
									$count--;
									array_shift( $segments );
								}   */
								
								$q = 'select id from #__vquiz_quizzes where alias = '.$db->Quote(str_replace(':', '-', $segments[0]));			
								$db->setQuery( $q );
								$id = $db->loadResult();
								$vars['id'] = empty($id)?$segments[0]:$id;
								$count--;
								array_shift( $segments );
										
								if($count<1){
									$vars['layout']='description';
								}
																
							break;
							
						
						}
						if($count){
							if($segments[0]=='featured')	{
								$vars['featured'] =1;
							}
						}
						
					}
					else
						$vars['layout']='quizzes';					
		
					break;
					
					
					
					case 'quizresult' :
					$vars['view'] = 'quizresult';
					$count--;
					array_shift( $segments );
					
					break;
					
					case 'quizdraft' :
					$vars['view'] = 'quizdraft';
					$count--;
					array_shift( $segments );
					
					break;
					
					case 'usersquizzes' :
					$vars['view'] = 'usersquizzes';
					$count--;
					array_shift( $segments );
					
					break;
					case 'dashboard' :
					$vars['view'] = 'dashboard';
					$count--;
					array_shift( $segments );
					
					break;
					case 'orders' :
					$vars['view'] = 'orders';
					$count--;
					array_shift( $segments );
					if(isset($segments[0])){
						   $vars['task'] = $segments[0];
							$count--;
							array_shift($segments);
						 }
					if(isset($segments[0])){
						   $vars['order_key'] = $segments[0];
							$count--;
							array_shift($segments);
						 }
					break;
					case 'plans':
					$vars['view'] = 'plans';
					$count--;
					array_shift($segments);
					
					   if(isset($segments[0])){
						   $vars['task'] = 'subscribe';
							$count--;
							array_shift($segments);
						 }
						if($count)
						{
							$segments[0] = str_replace(':', '-', $segments[0]);
							$q = 'select id from #__vquiz_plans where alias = '.$db->Quote($segments[0]);			
							$db->setQuery( $q );
							$id = $db->loadResult();
							$vars['plan_id'] = empty($id)?$segments[0]:$id;
							$count--;
							array_shift( $segments ); 
						}
					break;
					case 'quizquestion' :
					$vars['view'] = 'quizquestion';
					$count--;
					array_shift( $segments );
					
					break;
					case 'users' :
					$vars['view'] = 'users';
					$count--;
					array_shift( $segments );
					
					break;
					case 'useradmin' :
					$vars['view'] = 'useradmin';
					$count--;
					array_shift( $segments );
					
					break;
					
					case 'subscriptions' :
					$vars['view'] = 'subscriptions';
					$count--;
					array_shift( $segments );
					
					break;
					
				 default:
					 
					$vars['view'] = 'vquiz';
					
					$count--;
					array_shift( $segments );
					
				break;
				  
			}
			
		}

		return $vars;
	 
	}
	
}

	function VquizBuildRoute(&$query)
	{
		$router = new VquizRouter;
		return $router->build($query);
	}

	function VquizParseRoute($segments)
	{
		$router = new VquizRouter;
		return $router->parse($segments);
	}

	function get_text($text)
	{
		return str_replace(' ', '-', (strtolower(JText::_($text))));
	}