<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2015 wwww.wdmtech.com. All Rights Reserved.
# @license - http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: http://www.wdmtech.com
# Technical Support:  Forum - http://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
defined('_JEXEC') or die('Restricted access');
JFormHelper::loadFieldClass('list');
/**
 * Form Field class for the Joomla Framework.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_menus
 * @since       1.6
 */
class JFormFieldQuizlist extends JFormField
{
	/**
	 * The form field type.
	 *
	 * @var		string
	 * @since   1.6
	 */
	protected $type = 'Quizlist';

	/**
	 * Method to get the field input markup.
	 *
	 * @return  string	The field input markup.
	 * @since   1.6
	 */
	/*protected function getInput()
	{return 'xyz';
		$html 		= array();
		$recordId	= (int) $this->form->getValue('id');
		$size		= ($v = $this->element['size']) ? ' size="' . $v . '"' : '';
		$class		= ($v = $this->element['class']) ? ' class="' . $v . '"' : 'class="text_area"';

		// Get a reverse lookup of the base link URL to Title
		$model 	= JModelLegacy::getInstance('menutypes', 'menusModel');
		$rlu 	= $model->getReverseLookup();

		switch ($this->value)
		{
			case 'url':
				$value = JText::_('COM_MENUS_TYPE_EXTERNAL_URL');
				break;

			case 'alias':
				$value = JText::_('COM_MENUS_TYPE_ALIAS');
				break;

			case 'separator':
				$value = JText::_('COM_MENUS_TYPE_SEPARATOR');
				break;

			case 'heading':
				$value = JText::_('COM_MENUS_TYPE_HEADING');
				break;

			default:
				$link	= $this->form->getValue('link');
				// Clean the link back to the option, view and layout
				$value	= JText::_(JArrayHelper::getValue($rlu, MenusHelper::getLinkKey($link)));
				break;
		}
		// Load the javascript and css
		JHtml::_('behavior.framework');
		JHtml::_('behavior.modal');

		$html[] = '<span class="input-append"><input type="text" disabled="disabled" readonly="readonly" id="' . $this->id . '" value="' . $value . '"' . $size . $class . ' /><a class="btn btn-primary" onclick="SqueezeBox.fromElement(this, {handler:\'iframe\', size: {x: 600, y: 450}, url:\''.JRoute::_('index.php?option=com_menus&view=menutypes&tmpl=component&recordId='.$recordId).'\'})"><i class="icon-list icon-white"></i> '.JText::_('JSELECT').'</a></span>';
		$html[] = '<input class="input-small" type="hidden" name="' . $this->name . '" value="'.htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '" />';

		return implode("\n", $html);
	}*/

protected function getInput()
  {
	  // Load modal behavior
	  JHtml::_('behavior.modal', 'a.modal');
	  JHtml::_('bootstrap.tooltip');
	  JHtml::_('behavior.framework');
 		$allowEdit		= ((string) $this->element['edit'] == 'true') ? true : false;
		$allowClear		= ((string) $this->element['clear'] != 'false') ? true : false;
		JFactory::getLanguage()->load('com_vquiz', JPATH_ADMINISTRATOR);
	  // Build the script
	  
	  $script = array();
	  $script[] = ' jQuery( document ).ready(function(){ jQuery("#reset").click(function() { ';
	  $script[] = '  document.id("'.$this->id.'_id").value ="";';
	  $script[] = '  document.id("'.$this->id.'_name").value ="Select Quizzes";';
	  $script[] = '});});';
	  $script[] = '  function jSelectQuizzes_jform_request_id(id, title, object) {';
	  $script[] = '  document.id("'.$this->id.'_id").value = id;';
	  $script[] = '  document.id("'.$this->id.'_name").value = title;';
	  if ($allowEdit)
		{
			$script[] = '		jQuery("#' . $this->id . '_edit").removeClass("hidden");';
		}
	if ($allowClear)
		{
			$script[] = '		jQuery("#' . $this->id . '_clear").removeClass("hidden");';
		}
	  $script[] = '  SqueezeBox.close();';
	  $script[] = '    }';
 
	  // Add to document head
	  JFactory::getDocument()->addScriptDeclaration(implode("\n", $script));
 
	  // Setup variables for display
	  $html = array();
	  $link = JRoute::_('index.php?option=com_vquiz&view=quizmanager'.
                  '&tmpl=component&function=jSelectQuizzes_jform_request_id&from_userview=1');
		if (isset($this->element['language']))
		{
			$link .= '&forcedLanguage=' . $this->element['language'];
		}
 
	  $db = JFactory::getDbo();
	  $query = $db->getQuery(true);
	  $query->select('title');
	  $query->from('#__vquiz_quizzes');
	  $query->where('id in ('.$this->value.')');
	  if(!empty($this->value)){
	  $db->setQuery($query);
	  $arrtitle = $db->loadColumn();
	  $title=implode(",",$arrtitle);
	  }
	  //print_r($title);exit;
	  /*if (!$title = $db->loadResult()) {
		  JError::raiseWarning(500, $db->getErrorMsg());
	  }*/
	  if (empty($title)) {
		  $title = JText::_('SELECT_QUIZZES');
	  }
	  $title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
	  
	  if (0 == (int) $this->value)
		{
			$value = '';
		}
		else
		{
			$value = (int) $this->value;
		}
 
	  
	  $html[] = '<span class="input-append"><input type="text" id="'.$this->id.'_name" value="'.$title.'" disabled="disabled" size="35" />';
	  
	  $html[] = '<a class="modal btn hasTooltip" title="' . JHtml::tooltipText('COM_VQUIZ_CHANGE_QUIZ') . '"  href="' . $link . '&' . JSession::getFormToken() . '=1" rel="{handler: \'iframe\', size: {x: 800, y: 450}}"><i class="icon-file"></i> ' . JText::_('JSELECT') . '</a>';
  
	  $html[] = '<input class="btn" id="reset" type="button" name="reset" value="'.JText::_('RESET').'" />';
	  
	  $html[] = '<input class="input-small" id="'.$this->id.'_id" type="hidden" name="' . $this->name . '" value="'.htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') . '" />';
 

 
	  return implode("\n", $html);
  }
}
