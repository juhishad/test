if (typeof(xi)=='undefined')
{
	var xi = {
		jQuery: window.jQuery,
		extend: function(obj){
			this.jQuery.extend(this, obj);
		}
	}
}
xi.extend({
	registration : {		
		check : function(fieldId, funcName) {
			var $field = jQuery('#'+fieldId);
	        var url = urls;
	        
	    	jQuery('.'+fieldId+' .badge-success').hide();
	    	jQuery('.'+fieldId+' .badge-info').show();
	    	jQuery('.'+fieldId+' .badge-warning').hide();
			  
	    	
			var args   = {'option':'com_vquiz','view':'plans','task':funcName,'event_args':[fieldId,$field.val()]};
			jQuery.ajax({
			dataType: "JSON",
			url: url,
			method:'post',
			data: args,
			beforeSend: function()	{
							jQuery(".vquiz_overlay").show();
							},
			complete: function()	{
							jQuery(".vquiz_overlay").hide();
							},
			success: function(res){
				xi.registration.validate(res[0][3][0], res[0][3][1], res[0][3][2]);
			},
			});
           
		},

		validate : function(fieldId, result, msg) {
			var $field = jQuery('#'+fieldId);

			jQuery('#err-'+fieldId).html(msg);
					
        	if(result == true){
        		
    	    	jQuery('.'+fieldId+' .badge-success').show();
    	    	jQuery('.'+fieldId+' .badge-info').hide();
    	    	jQuery('.'+fieldId+' .badge-warning').hide();
        		
	        	return true;
	        }
	       
	    	jQuery('.'+fieldId+' .badge-success').hide();
	    	jQuery('.'+fieldId+' .badge-info').hide();
	    	jQuery('.'+fieldId+' .badge-warning').show();
        	
		}
	}
});



jQuery(document).ready(function (){	

	
	jQuery('#vquizRegisterAutoUsername').blur(function(){
		
    	jQuery('.'+this.id+' .badge-success').hide();
    	jQuery('.'+this.id+' .badge-info').hide();
    	jQuery('.'+this.id+' .badge-warning').show();
		
		jQuery(this).trigger("submit.validation").trigger("validationLostFocus.validation");
		
		if (!jQuery(this).jqBootstrapValidation("hasErrors")) {
				xi.registration.check(this.id, 'checkusername');
		}
		
	});

	jQuery('#vquizRegisterAutoEmail').blur(function(){
		
    	jQuery('.'+this.id+' .badge-success').hide();
    	jQuery('.'+this.id+' .badge-info').hide();
    	jQuery('.'+this.id+' .badge-warning').show();
		
		jQuery(this).trigger("submit.validation").trigger("validationLostFocus.validation");
		
		if (!jQuery(this).jqBootstrapValidation("hasErrors")) {
			xi.registration.check(this.id, 'checkemail');
		}
	});
	
	jQuery('#vquizRegisterAutoPassword').blur(function(){
		
    	jQuery('.'+this.id+' .badge-success').hide();
    	jQuery('.'+this.id+' .badge-info').hide();
    	jQuery('.'+this.id+' .badge-warning').show();
    	
    	if (!jQuery(this).jqBootstrapValidation("hasErrors")) {
    		
        	jQuery('.'+this.id+' .badge-success').show();
        	jQuery('.'+this.id+' .badge-info').hide();
        	jQuery('.'+this.id+' .badge-warning').hide();			
    	}
	});
	
	jQuery('#vquizRegisterAutoConfirmPassword').blur(function(){
		
		if (jQuery('#vquizRegisterAutoPassword').val() === jQuery('#vquizRegisterAutoConfirmPassword').val()) { 
        	jQuery('.'+this.id+' .badge-success').show();
        	jQuery('.'+this.id+' .badge-info').hide();
        	jQuery('.'+this.id+' .badge-warning').hide();
		}
		else {
	    	jQuery('.'+this.id+' .badge-success').hide();
	    	jQuery('.'+this.id+' .badge-info').hide();
	    	jQuery('.'+this.id+' .badge-warning').show();
		}
	});
});