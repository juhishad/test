<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );

abstract class VquizHelperRoute
{
	protected static $lookup;
	protected static $lang_lookup = array();
	public static function getVquizRoute($id, $catid, $language = 0)
	{
		$needles = array(
			'article'  => array((int) $id)
	);
	
		// Create the link
		$link = 'index.php?option=com_vquiz&view=quizmanager&id=' . $id;
		if ($language && $language != "*" && JLanguageMultilang::isEnabled())
		{
			self::buildLanguageLookup();
			if (isset(self::$lang_lookup[$language]))
			{
				$link .= '&lang=' . self::$lang_lookup[$language];
				$needles['language'] = $language;
			}
		}
		if ($item = self::_findItem($needles))
		{
			$link .= '&Itemid=' . $item;
		}
		return $link;
	}
	public static function getMenuitemRoute($id, $catid, $language = 0)
	{
		$needles = array(
			'article'  => array((int) $id)
		);
		// Create the link
		$link = 'index.php?option=com_vquiz&view=quizmanager&id=' . $id;
		if ($language && $language != "*" && JLanguageMultilang::isEnabled())
		{
			self::buildLanguageLookup();
			if (isset(self::$lang_lookup[$language]))
			{
				$link .= '&lang=' . self::$lang_lookup[$language];
				$needles['language'] = $language;
			}
		}
		if ($item = self::_findItem($needles))
		{
			$link .= '&Itemid=' . $item;
		}
		return $link;
	}
	
	protected static function _findItem($needles = null)
	{
		$app		= JFactory::getApplication();
		$menus		= $app->getMenu('site');
		$language	= isset($needles['language']) ? $needles['language'] : '*';
		// Prepare the reverse lookup array.
		if (self::$lookup === null)
		{
			self::$lookup = array();
			$component	= JComponentHelper::getComponent('com_vquiz');
			$items		= $menus->getItems('component_id', $component->id);
			if ($items) {
				foreach ($items as $item)
				{
					if (isset($item->query) && isset($item->query['view']))
					{
						$view = $item->query['view'];
						if (!isset(self::$lookup[$view]))
						{
							self::$lookup[$view] = array();
						}
						// Only match menu items that list one tag
						if (isset($item->query['id'][0]) && count($item->query['id']) == 1)
						{
							// Here it will become a bit tricky
							// language != * can override existing entries
							// language == * cannot override existing entries
							if (!isset(self::$lookup[$language][$view][$item->query['id'][0]]) || $item->language != '*')
							{
								self::$lookup[$language][$view][$item->query['id'][0]] = $item->id;
							}
							self::$lookup[$view][$item->query['id'][0]] = $item->id;
						}
						if (isset($item->query["tag_list_language_filter"]) && $item->query["tag_list_language_filter"] != '')
						{
							$language = $item->query["tag_list_language_filter"];
						}
					}
				}
			}
		}
		if ($needles)
		{
			foreach ($needles as $view => $ids)
			{
				if (isset(self::$lookup[$view]))
				{
					foreach($ids as $id)
					{
						if (isset(self::$lookup[$view][(int) $id]))
						{
							return self::$lookup[$view][(int) $id];
						}
					}
				}
			}
		}
		else
		{
			$active = $menus->getActive();
			if ($active)
			{
				return $active->id;
			}
		}
		return null;
	}
}