	<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );
 
class TableQuizquestion extends JTable

{
 
	var $id = null;
    var $titleid = null;
	var $qtitle = null;
	var $optiontype = null;
	var $created = null;
	var $modified_date = null;
	var $published = null;
	var $correct_point = null;
	var $negative_point =null;
	var $options_score =null;
	var $personality_optionid =null;
	var $image =null;
	
	function __construct(& $db) {

		parent::__construct('#__vquiz_question', 'id', $db);

	}
	
 	function bind($array, $ignore = '')
		{
			return parent::bind($array, $ignore);
		}
		
	function store($updateNulls = false)
	{

		if(!parent::store($updateNulls))	{

			return false;

		}
 
		$data = JRequest::get( 'post' );
		jimport('joomla.filesystem.file');
 
		$data['qoption']	= JRequest::getVar('qoption', array(), 'post', 'array');
		$data['image'] = JRequest::getVar('image', null, 'FILES', 'array');
		$data['correct_ans'] = JRequest::getVar('correct_ans', array(), 'post', 'array'); 		
		$data['options_score'] = JRequest::getVar('options_score', array(), 'post', 'array'); 
		$data['personality_optionid'] = JRequest::getVar('personality_optionid', array(), 'post', 'array'); 
		$data['multi_p_options_score'] = JRequest::getVar('multi_p_options_score', array(), 'post', 'array'); 
		
		$score_category_count = JRequest::getInt('score_category_count',0); 
		
		$category_score_array=array();
		
		for($h=0;$h<count($data['qoption']);$h++){
		
			$array_ccat[$h]=array();

			for($b=0,$c=0;$b<$score_category_count;$b++){
				$data_category_score[$b]= JRequest::getVar('category_score'.$b, array(), 'post', 'array'); 
				array_push($array_ccat[$h],$data_category_score[$b][$h]);				
			}

			array_push($category_score_array,json_encode($array_ccat[$h]));	
		}
	
		$query='select id from #__vquiz_option where qid='.$this->id.' order by id asc';
	    $this->_db->setQuery($query);
	    $exid = $this->_db->loadColumn(); 
		
		$query='select categorythumbnailwidth,categorythumbnailheight from #__vquiz_configuration';
		$this->_db->setQuery($query);
		$configuration_img=$this->_db->loadObject();
		$configuration_width=$configuration_img->categorythumbnailwidth;
		$configuration_height=$configuration_img->categorythumbnailheight;
		
 
		
	 for($i=0;$i<count($data['qoption']);$i++)
	 { 
		 
		if(!empty($data['qoption'][$i]) OR !empty($data['image']['name'][$i])){
		
			$option_image='';
			
			if(!empty($data['image']['name'][$i]))
			{
		
				$allowed = array('.jpg', '.jpeg', '.gif', '.png');
				$dirpath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/';
				$thumbPath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'; 
				$image_name=str_replace(' ', '', JFile::makeSafe($data['image']['name'][$i]));
				$image_tmp = $data['image']['tmp_name'][$i];
				$time = time();

				if($image_name <> "" )
				{
					
					$ext = strrchr($image_name, '.');
					
					if(!in_array($ext, $allowed)){
						$msg_error=JText::_('THIS_IMAGE_TYPE_NOT_ALLOWED');
						$this->setError($msg_error);
						return false;
					}		

					$size = getimagesize($image_tmp);
					$src_w = $size[0];
					$src_h = $size[1];

 					if($src_w > $src_h ){
					
						if(!empty($configuration_width) and is_numeric($configuration_width))
							$width = $configuration_width;    
						else
							$width = 125; 
						
						if(!empty($configuration_height) and is_numeric($configuration_height))
							$height =$configuration_height;
						else   
							$height = $size[1]/$size[0]*$width; 
						
 						$width1 = 300;   
 						$height1 = $size[1]/$size[0]*$width; 


					}else{
					
						if(!empty($configuration_height) and is_numeric($configuration_height))
							$height =$configuration_height;
						else
							$height = 125;
						if(!empty($configuration_width) and is_numeric($configuration_width))
							$width = $configuration_width;    
						else
							$width = $size[0]/$size[1]*$height; 
						
 						$height1 = 360;
 						$width1 = $size[0]/$size[1]*$height; 
					}

						$new_image = imagecreatetruecolor($width, $height);
 						$new_image1 = imagecreatetruecolor($width1, $height1);
						
 						if($size['mime'] == "image/jpeg")
							$tmp = imagecreatefromjpeg($image_tmp);
 						elseif($size['mime'] == "image/gif")
							$tmp = imagecreatefromgif($image_tmp);
 						else
							$tmp = imagecreatefrompng($image_tmp);
					
 						imagecopyresampled($new_image, $tmp,0,0,0,0, $width, $height, $src_w, $src_h);


						if($size['mime'] == "image/jpeg")
							imagejpeg($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
						elseif($size['mime'] == "image/gif")
							imagegif($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
						else
							imagepng($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);

						imagecopyresampled($new_image1, $tmp,0,0,0,0, $width1, $height1, $src_w, $src_h);


						if($size['mime'] == "image/jpeg")
							imagejpeg($new_image1, $dirpath.$time.'_'.$image_name);
						elseif($size['mime'] == "image/gif")
							imagegif($new_image1, $dirpath.$time.'_'.$image_name);
						else
							imagepng($new_image1, $dirpath.$time.'_'.$image_name);
						
						if(move_uploaded_file($image_tmp, $dirpath.$time.'_'.$image_name)){
							$option_image = $time.'_'.$image_name;
						}
					
				}
				
			}
		
			if(in_array($i,$data['correct_ans']))
				$ans = 1;
			else
				$ans = 0;
			
			if(count($exid)>0)	{
				$id = array_shift($exid);
				
				$query_image = ' select image from #__vquiz_option where id = '.$this->_db->quote($id);
				$this->_db->setQuery( $query_image );
				$oldimage_path = $this->_db->loadResult();
				
				if($option_image==''){
					$option_image=$oldimage_path;
				}else{
				   unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/'.$oldimage_path);
				   unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$oldimage_path);
				} 
				
				$query = 'update #__vquiz_option set qoption = '.$this->_db->quote($data['qoption'][$i]).',image = '.$this->_db->quote($option_image).',options_score = '.$this->_db->quote($data['options_score'][$i]).',multi_p_options_score = '.$this->_db->quote($data['multi_p_options_score'][$i]).',personality_optionid = '.$this->_db->quote($data['personality_optionid'][$i]).', correct_ans = '.$this->_db->quote($ans).',category_score = '.$this->_db->quote($category_score_array[$i]).'  where id = '.$this->_db->quote($id);
				
 
			}
			
			else{ 
				$query = 'insert into #__vquiz_option(qid,qoption,image,correct_ans,options_score,personality_optionid,category_score,multi_p_options_score) values('.$this->_db->quote($this->id).', '.$this->_db->quote($data['qoption'][$i]).','.$this->_db->quote($option_image).', '.$this->_db->quote($ans).','.$this->_db->quote($data['options_score'][$i]).','.$this->_db->quote($data['personality_optionid'][$i]).','.$this->_db->quote($category_score_array[$i]).','.$this->_db->quote($data['multi_p_options_score'][$i]).')';
			}
		  
			$this->_db->setQuery( $query );
						
			if(!$this->_db->execute())	
			{
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		}	
	 
	}
 
		if(count($exid)>0 and !empty($data['qoption']))	{			
			$query = 'delete from #__vquiz_option where id in ('.implode(', ', $exid).')';
			$this->_db->setQuery( $query );
						
			if(!$this->_db->execute())	
			{
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		
		}
 
 		return true;
	
	}
	
		
	function delete($id = null)
	{
	
		if(!parent::delete($id))
			return false;
		else	{
			$query = 'delete from #__vquiz_option where qid = '.(int)$this->id;
			
			$this->_db->setQuery( $query );
			
			if(!$this->_db->query())	{
				$this->setError($this->_db->getErrorMsg());
				return false;
			}			
		}
		
		return true;
	
	}
	
 

}