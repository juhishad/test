<?php 
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
class VquizTableQuizzes extends JTable
{
     
	var $id = null;
	var $title = null;
	var $catid = null;
	var $description = null;
	var $published = null;
 
	function __construct(& $db) {
 		parent::__construct('#__vquiz_quizzes', 'id', $db);
	}
	
	function bind($array, $ignore = ''){
		
		return parent::bind($array, $ignore);
	}
	
	
	function check(){

			if (trim($this->title) == '')
			{
				$this->setError(JText::_('JLIB_DATABASE_ERROR_MUSTCONTAIN_A_TITLE_CATEGORY'));
				return false;
			}
	
			$this->alias = trim($this->alias);
	
			if (empty($this->alias))
			{
				$this->alias = $this->title;
			}
	
			$this->alias = JApplication::stringURLSafe($this->alias);
	
			if (trim(str_replace('-', '', $this->alias)) == '')
			{
				$this->alias = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->format('Y-m-d-H-i-s');
			}
	
			return true;
			
		}
	
		function qgroup_messagescore($quizid,$groupid,$chk_gid){	
 
			$session=JFactory::getSession();
 			$input=JFactory::getApplication()->input;
			
			if($session->has('qgroup_message_session'))	{
				$qgroup_messagescore = $session->get('qgroup_message_session');
			}else{
				$qgroup_messagescore = array('qorder'=>array(), 'score'=>array(),'message'=>array(),'article_id'=>array());	
			}
			if($chk_gid==0){
				for($k=0;$k<count($qgroup_messagescore['message']);$k++){
					
					$score=$qgroup_messagescore['score'][$k];
					$message=$qgroup_messagescore['message'][$k];
					$article_id=$qgroup_messagescore['article_id'][$k];
				
					for($i=0;$i<count($qgroup_message);$i++)
					{
						$query = 'insert into #__vquiz_quizzes_questiongroup_message(id,groupid,message,score,article_id) values('.$this->_db->quote($quizid).','.$this->_db->quote($groupid).','.$this->_db->quote($message[$i]).','.$this->_db->quote($score[$i]).','.$this->_db->quote($article_id[$i]).')';

						$this->_db->setQuery($query);
												
						if(!$this->_db->execute()){
						
							$this->setError($this->_db->getErrorMsg());
							return false;
						}					
					
					}
				}
			}
 
			return true;
 
		} 
	
		function store($updateNulls = false)
		{
			if(!parent::store($updateNulls))	{
				return false;
			}
			
			$session=JFactory::getSession();
			
			/* --Question group save--*/
			$input=JFactory::getApplication()->input;

			$questiongroup_title=$input->post->get('questiongroup_title','',array());
			$questiongroup_order=$input->post->get('questiongroup_order','',array());
			
			$query=$this->_db->getQuery(true);
			$query->delete('#__vquiz_quizzes_questiongroup');
			$query->where('quizid='.$this->_db->quote($this->id));
			$this->_db->setQuery($query);
			$this->_db->execute();
			
			for($i=0,$j=1;$i<count($questiongroup_title);$i++,$j++){
				
				if($questiongroup_title[$i]!=''){
					$obj=new stdClass();
					$obj->id=null;
					if(isset($questiongroup_order[$i]) and $questiongroup_order[$i]!=''){
						$obj->qorder=$questiongroup_order[$i];
						$chk_gid=1;
					}else{
						$obj->qorder=$this->id+$j;
						$chk_gid=0;
					}
					$obj->title=$questiongroup_title[$i];
					$obj->quizid=$this->id;
					if(!$this->_db->insertObject('#__vquiz_quizzes_questiongroup',$obj,'id')){
						
						$this->setError(JText::_('JLIB_DATABASE_ERROR_MUSTCONTAIN_A_TITLE_CATEGORY'));
						return false;
					} 
					
					$this->qgroup_messagescore($this->id,$obj->qorder,$chk_gid);
					
				}else{
					
				}
				
			}
			
			//jexit('ext');
			
			$session->clear('qgroup_message_session');

								
			
			if($session->has('message_text')){
 
				$message=$session->get('message_text');

				$insert = new stdClass();
				$insert->quizid =$this->id;
				$insert->text1 = $message['text1'];
				$insert->text2 = $message['text2'];
				$insert->text3 = $message['text3'];
				$insert->text4 = $message['text4'];
				$insert->text5 = $message['text5'];
				$insert->upto1	= $message['upto1'];
				$insert->upto2	= $message['upto2'];
				$insert->upto3	= $message['upto3'];
				$insert->upto4	= $message['upto4'];
				$insert->upto5	= $message['upto5'];
				try{		
					$this->_db->insertObject('#__vquiz_score_message', $insert, 'id');
					$session->clear('message_text');
				}
				catch (Exception $e){
					$this->setError($e->getMessage());
					return false;
				}
	 		}
			
			/*---Score Category Enable---*/
			
			$data['score_category_label'] = JRequest::getVar('score_category_label', array(), 'post', 'array'); 
			$data['score_depend'] = JRequest::getVar('score_depend', array(), 'post', 'array'); 
			
			$query='select id from #__vquiz_quiz_score_category where quizid='.$this->id.' order by id asc';
			$this->_db->setQuery($query);
			$exid = $this->_db->loadColumn(); 
			
			for($i=0;$i<count($data['score_category_label']);$i++)
			{ 
					if(!empty($data['score_category_label'][$i])){
					
						if(in_array($i,$data['score_depend']))
							$ans = 1;
						else
							$ans = 0;
					
						if(count($exid)>0)	{
						$id = array_shift($exid);
						$query = 'update #__vquiz_quiz_score_category set category = '.$this->_db->quote($data['score_category_label'][$i]).',score_depend = '.$this->_db->quote($ans).' where id = '.$this->_db->quote($id);
					}
					else {
						$query = 'insert into #__vquiz_quiz_score_category(quizid,category,score_depend) values('.$this->_db->quote($this->id).', '.$this->_db->quote($data['score_category_label'][$i]).','.$this->_db->quote($ans).')';
					}
					
					$this->_db->setQuery( $query );
					
					if(!$this->_db->execute()){
						$this->setError($this->_db->getErrorMsg());
						return false;
					}
					
				}
			}
			
			 
			if(count($exid)>0 and !empty($data['score_category_label'])){	
			
				$query = 'delete from #__vquiz_quiz_score_category where id in ('.implode(', ', $exid).')';
				$this->_db->setQuery( $query );
							
				if(!$this->_db->execute())	
				{
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
			}
			
			/*--------Personality Category--------*/
			
			$data['personality_category'] = JRequest::getVar('personality_category', array(), 'post', 'array'); 
			$data['p_category_c_count'] = JRequest::getInt('p_category_c_count', 'post'); 
			
			$query='select id from #__vquiz_quiz_personality_category where quizid='.$this->id.' order by id asc';
			$this->_db->setQuery($query);
			$exid_id = $this->_db->loadResult(); 
					
			if(count($exid_id)>0)	{
				$query = 'update #__vquiz_quiz_personality_category set category = '.$this->_db->quote(json_encode($data['personality_category'])).',count_column = '.$this->_db->quote($data['p_category_c_count']).' where id = '.$this->_db->quote($exid_id);
			}
			else {
				$query = 'insert into #__vquiz_quiz_personality_category(quizid,count_column,category) values('.$this->_db->quote($this->id).','.$this->_db->quote($data['p_category_c_count']).', '.$this->_db->quote(json_encode($data['personality_category'])).')';
			}
		
			$this->_db->setQuery( $query );
			
			if(!$this->_db->execute()){
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
			
			/*--Quiz Branching Section--*/
			
				$data['ruleid']= JRequest::getVar('branching_ruleid', array(), 'post', 'array');				
				$data['rule_questiontitle']= JRequest::getVar('rule_questiontitle', array(), 'post', 'array');				
				$data['apply_text']= JRequest::getVar('apply_text', array(), 'post', 'array');
				$data['rule_questionid']= JRequest::getVar('branching_rulequestionid', array(), 'post', 'array');
				$data['rule_optionid']= JRequest::getVar('branching_ruleoptionid', array(), 'post', 'array');
				$data['rule_weight']= JRequest::getVar('rule_weight', array(), 'post', 'array');
				$data['rule_weight_check']= JRequest::getVar('rule_weight_check', array(), 'post', 'array');
				$data['rule_scorepercentile']= JRequest::getVar('score_percentile', array(), 'post', 'array');
				$data['apply_questiontitle']= JRequest::getVar('apply_questiontitle', array(), 'post', 'array');
				$data['applyid']= JRequest::getVar('branching_applyid', array(), 'post', 'array');
				$data['apply_questionid']= JRequest::getVar('branching_applyquestionid', array(), 'post', 'array');
				$data['apply_weight']= JRequest::getVar('apply_weight', array(), 'post', 'array');
				$data['apply_weight_check']= JRequest::getVar('apply_weight_check', array(), 'post', 'array');
				$data['rule_wno_question']= JRequest::getVar('rule_wno_question', array(), 'post', 'array');
				
				$data['rule_specific_select']= JRequest::getVar('rule_specific_select', array(), 'post', 'array');
				
				
				$query='select id from #__vquiz_quizzes_branching where quizid='.$this->id.' order by id asc';
				$this->_db->setQuery($query);
				$r_exid = $this->_db->loadColumn(); 
				
 
				for($i=0;$i<count($data['ruleid']);$i++)
				{ 
					
					if(count($r_exid)>0){
					
						$id = array_shift($r_exid);

						$query = 'update #__vquiz_quizzes_branching set ruleid = '.$this->_db->quote($data['ruleid'][$i]).',apply_text = '.$this->_db->quote($data['apply_text'][$i]).',rule_questionid = '.$this->_db->quote($data['rule_questionid'][$i]).',rule_optionid = '.$this->_db->quote($data['rule_optionid'][$i]).',rule_weight = '.$this->_db->quote($data['rule_weight'][$i]).', rule_weight_check = '.$this->_db->quote($data['rule_weight_check'][$i]).',rule_scorepercentile = '.$this->_db->quote($data['rule_scorepercentile'][$i]).',rule_wno_question='.$this->_db->quote($data['rule_wno_question'][$i]).',rule_specific_select='.$this->_db->quote($data['rule_specific_select'][$i]).',applyid='.$this->_db->quote($data['applyid'][$i]).',apply_questionid='.$this->_db->quote($data['apply_questionid'][$i]).',apply_weight='.$this->_db->quote($data['apply_weight'][$i]).',apply_weight_check='.$this->_db->quote($data['apply_weight_check'][$i]).',rule_questiontitle='.$this->_db->quote($data['rule_questiontitle'][$i]).',apply_questiontitle='.$this->_db->quote($data['apply_questiontitle'][$i]).'  where id = '.$this->_db->quote($id);

					}
					
					else{ 
						
						$query = 'insert into #__vquiz_quizzes_branching(quizid,ruleid,apply_text,rule_questionid,rule_optionid,rule_weight,rule_weight_check,rule_scorepercentile,rule_wno_question,rule_specific_select,applyid,apply_questionid,apply_weight,apply_weight_check,apply_questiontitle,rule_questiontitle) values('.$this->_db->quote($this->id).', '.$this->_db->quote($data['ruleid'][$i]).','.$this->_db->quote($data['apply_text'][$i]).','.$this->_db->quote($data['rule_questionid'][$i]).', '.$this->_db->quote($data['rule_optionid'][$i]).','.$this->_db->quote($data['rule_weight'][$i]).','.$this->_db->quote($data['rule_weight_check'][$i]).','.$this->_db->quote($data['rule_scorepercentile'][$i]).','.$this->_db->quote($data['rule_wno_question'][$i]).','.$this->_db->quote($data['rule_specific_select'][$i]).','.$this->_db->quote($data['applyid'][$i]).','.$this->_db->quote($data['apply_questionid'][$i]).','.$this->_db->quote($data['apply_weight'][$i]).','.$this->_db->quote($data['apply_weight_check'][$i]).','.$this->_db->quote($data['apply_questiontitle'][$i]).','.$this->_db->quote($data['rule_questiontitle'][$i]).')';

					}
				  
					$this->_db->setQuery( $query );
								
					if(!$this->_db->execute())	
					{
						$this->setError($this->_db->getErrorMsg());
						return false;
					} 
			
				}

				//if(count($r_exid)>0 and empty($data['ruleid']))	{			
				if(count($r_exid)>0)	{			
					$query = 'delete from #__vquiz_quizzes_branching where id in ('.implode(', ', $r_exid).')';
					$this->_db->setQuery( $query );
					
								
					if(!$this->_db->execute())	
					{
						$this->setError($this->_db->getErrorMsg());
						return false;
					}

				
				}
				
			
		
			 return true;
		}
 
}