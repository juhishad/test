<?php
/*------------------------------------------------------------------------
# com_vquiz - vquiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizController extends JControllerLegacy
{
	function display($cachable = false, $urlparams = false)
	{
		 if(!$this->sstatus())
		{  
			JRequest::setVar('view', 'vquiz');
			JRequest::setVar('layout', 'information');
		}
     parent::display();
	}
    function sstatus()
	{
		$db = JFactory::getDbo();
		$task = JFactory::getApplication()->input->get('task', '');
		if($task =='checkstatus')
			return true;
		$query = 'select `sstatus` from `#__vquiz_configuration`';
		$db->setQuery($query);  
		if($db->loadResult())
		{
		return true;	
		}
		else
		return false;	
			
		
	}
	function checkstatus(){
		JSession::checkToken() or jexit('{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}');
		$password = JFactory::getApplication()->input->get('password', '', 'RAW');
		$emailaddress = JFactory::getApplication()->input->get('emailaddress', '', 'RAW');
		$url = 'https://www.wdmtech.com/demo/index.php';
		$postdata = array("option"=>"com_vmap", "task"=>"checkstatus", "password"=>$password, "emailaddress"=>$emailaddress, "componentname"=>"com_vquiz", "token"=>JSession::getFormToken());
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		
		$status = curl_exec($ch);
		$sub = new stdClass();
		$sub->result ="success";
		$sub->status = "No";  
		if($status === false)
		{  
		jexit('{"result":"error", "error":"'.curl_error($ch).'"}');
		}
		else
		{
			$status = json_decode($status); 
			if(isset($status->result) && $status->result=="success")
			{
				
				$sub->msg = $status->error;
				if(isset($status->status) && $status->status=="subscr")
				{
					$db =  JFactory::getDbo();
					$query = 'update `#__vquiz_configuration` set `sstatus`=1';
					$db->setQuery($query);
					$db->execute();
					$sub->result ="success";
					$sub->status ="ok";
				}
			}
			
		}
		
		curl_close($ch);
		jexit(json_encode($sub));
		
	}
	function showToolbar()
	{
		$view = JRequest::getVar('view', 'vquiz');
		
		JSubMenuHelper::addEntry( '<span class="add_item hasTip" title="'.JText::_('DASHBOARD').'">'.JText::_('DASHBOARD').'</span>' , 'index.php?option=com_vquiz&view=vquiz', $view == 'vquiz' );
		JSubMenuHelper::addEntry( '<span class="add_item hasTip" title="'.JText::_('CONFIGURATION').'">'.JText::_('CONFIGURATION').'</span>' , 'index.php?option=com_vquiz&view=configuration', $view == 'configuration' );
		JSubMenuHelper::addEntry( '<span class="add_item hasTip" title="'.JText::_('MAILINBOX').'">'.JText::_('MAILINBOX').'</span>' , 'index.php?option=com_vquiz&view=mailinbox', $view == 'mailinbox' );
		JSubMenuHelper::addEntry( '<span class="add_item hasTip" title="'.JText::_('QUIZ_MANAGER').'">'.JText::_('QUIZ_MANAGER').'</span>' , 'index.php?option=com_vquiz&view=quizmanager', $view == 'quizmanager' );

	}
	
	/* -- Score compare module tasks -- */
    function getTscore() {
        
        $db = JFactory::getDbo();
        $user=JFactory::getuser();
        $app = JFactory::getApplication();
        $post = JRequest::get( 'post' );
        $datetime = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
		$graph=isset($post['graph'])?$post['graph']:'';
		//echo $graph;exit;
		$detecresult = $post['detecresult'];
		$cid = $post['category'];
		$sid = $post['skills'];
		$limit = $post['limit'];
		$timeopts = $post['clickedVal'];
		$today=date('Y-m-d', strtotime('0 day'));
		$week=date('Y-m-d', strtotime('-1 Week'));
		$month=date('Y-m-d', strtotime('-1 month'));
		$year=date('Y-m-d', strtotime('-1 year'));
		$qsearch=isset($post['qsearch'])?$post['qsearch']:'';
		$items=new stdClass();
		$items->result = "error";
		
		/*-- logedin user result --*/
		
		$query= 'SELECT i.quizid,q.title as quiztitle, u.id, u.name as username,avg(i.score) as userscore FROM #__vquiz_quizresult as i left join #__vquiz_quizzes as q on q.id=i.quizid left join #__vquiz_category as c on q.catid=c.id left join #__vquiz_quizns as s on s.quizid=i.quizid left join #__users as u on i.userid=u.id'; 
			
		$where = array();
		if($timeopts==1){
			$where[]= ' i.created='.$db->quote($today);
		}
		elseif($timeopts==2){
			$where[]= ' i.created>='.$db->quote($week);
		}
		elseif($timeopts==3){
			$where[]= ' i.created>='.$db->quote($month);
		}
		elseif($timeopts==4){
			$where[]= ' i.created>='.$db->quote($year);
		}
		
		if($cid){
			$where[]= ' c.id ='.$db->quote($cid);
		}
		if($sid){
			$where[]= ' s.skillid ='.$db->quote($sid);
		}
		
		$orderby = ' order by i.score desc ';
		$groupby = ' group by i.quizid ';		
		$where[] = ' q.quiztype =1';
		
		$where[] = ' i.userid ='.$user->id;
		
		if($detecresult==1){
			
			$checkview = JRequest::getVar('view', '');
			$layout = JRequest::getCmd('layout', '');
			$detect_quizid = JRequest::getInt('id', 0);
			
			if($detect_quizid!=0){
				if($checkview=='quizmanager' and $layout=='quizzes'){
					$where[]= ' c.id ='.$db->quote($detect_quizid);
				}elseif($checkview=='quizmanager' and $layout==''){
					 $where[] = 's.skillid ='.$db->quote($detect_quizid);
				}
			}

		}
		
		$query .= ' where ' . implode(' and ', $where); 
		$query .= $groupby ;
		$query .= $orderby ;
		
		if(is_numeric($limit) && !empty($limit)){	
			$query .= ' limit '.$limit;
		} 

		try{
			
			$db->setQuery( $query );				
			$logedinuser_result = $db->loadObjectList();
			$db->setQuery( $query );
			$quizids=$db->loadColumn();
		}
		catch (Exception $e)
		{
			throw new Exception($e->getMessage());
			$logedinuser_result=array();
		}
	//	print_r($logedinuser_result);exit;
		/*-- all other user result --*/
		
		$query = 'SELECT q.id as quizid,q.title as quiztitle, u.id, u.name as username, avg(i.score) as userscore FROM #__vquiz_quizresult as i left join #__vquiz_quizzes as q on q.id=i.quizid left join #__vquiz_category as c on q.catid=c.id left join #__vquiz_quizns as s on s.quizid=i.quizid left join #__users as u on i.userid=u.id'; 
			 
		$where = array();

		if($timeopts==1){
			$where[]= ' i.created='.$db->quote($today);
		}
		elseif($timeopts==2){
			$where[]= ' i.created>='.$db->quote($week);
		}
		elseif($timeopts==3){
			$where[]= ' i.created>='.$db->quote($month);
		}
		elseif($timeopts==4){
			$where[]= ' i.created>='.$db->quote($year);
		}

		if($cid){
			$where[]= ' c.id ='.$db->quote($cid);
		}
		if($sid){
			$where[]= ' s.skillid ='.$db->quote($sid);
		}
		
		if($detecresult==1){
			
			$checkview = JRequest::getVar('view', '');
			$layout = JRequest::getCmd('layout', '');
			$detect_quizid = JRequest::getInt('id', 0);
			
			if($detect_quizid!=0){
				if($checkview=='quizmanager' and $layout=='quizzes'){
					$where[]= ' c.id ='.$db->quote($detect_quizid);
				}elseif($checkview=='quizmanager' and $layout==''){
					 $where[] = 's.skillid ='.$db->quote($detect_quizid);
				}
			}

		}
		
		$groupby = ' group by i.quizid ';
		
		$orderby = ' order by i.score desc ';

		$where[] = ' q.quiztype =1';
		
		$where[] = ' i.userid !='.$user->id;
		
		if(!empty($quizids)){
			$where[] = ' i.quizid in('.implode(',',$quizids).')';
		}
		
		$query .= ' where ' . implode(' and ', $where); 
		
		$query .= $groupby ;
		$query .= $orderby ;
		
		if(is_numeric($limit) && !empty($limit)){	
			$query .= ' limit '.$limit;
		} 

		try{
			
			$db->setQuery( $query );				
			$otheruser_result = $db->loadObjectList();
		}
		catch (Exception $e)
		{
			throw new Exception($e->getMessage());
			$otheruser_result=array();
		}
	
        if(!empty($logedinuser_result)){
				for($i=0;$i<count($logedinuser_result);$i++)
				{
					for($j=0;$j<count($otheruser_result);$j++)
					{
						if($logedinuser_result[$i]->quizid==$otheruser_result[$j]->quizid)
						{
							$logedinuser_result[$i]->userscore=number_format((float)$logedinuser_result[$i]->userscore, 2, '.', '');
							$logedinuser_result[$i]->avgscore =number_format((float)$otheruser_result[$j]->userscore, 2, '.', '');
							
						}
					}
				}
			
          $userdata ='';
          for($i=0;$i<count($logedinuser_result);$i++){
            
			$userdata .='<div class="row">';
			$userdata .='<div class="td">'.$logedinuser_result[$i]->quiztitle.'</div>';
			$userdata .='<div class="td">'.$logedinuser_result[$i]->userscore.'</div>';
			$userdata .='<div class="td">'.$logedinuser_result[$i]->avgscore.'</div>';
			$userdata .='</div>';
        
         }
			$obj->html = $userdata;
        }
        else{
            $obj->html= JText::_("NO_RESULT_FOUND");
 
        }
		 if($graph=='graph')
		{
			$selfluserscore=array();
			
			for($j=0;$j<count($logedinuser_result);$j++){
				
				$mix_array1=array();
				$quiztitle=$logedinuser_result[$j]->quiztitle;
				/* $middle = strtotime($logedinuser_result[$j]->playdate);   
				$new_date = date('F j, Y', $middle); */
				array_push($mix_array1,$quiztitle);
				array_push($mix_array1,$logedinuser_result[$j]->userscore);
				array_push($mix_array1,$logedinuser_result[$j]->avgscore);
				array_push($selfluserscore,$mix_array1);				
			}
			
			$items->result = "success";
			$items->selfluserscore=$selfluserscore;
			//jexit(print_r($items));
			 jexit(json_encode($items));
		}
		else{  
        jexit(json_encode($obj));
		}
    }
	
	
	function quizSearch(){
		
        $obj = new stdClass();
        $obj->result = 'success'; 
        $db = JFactory::getDbo();
        $qsearch = JRequest::getVar('qsearch', '');
        $query= 'SELECT id,title FROM #__vquiz_quizzes WHERE title LIKE "%'.$qsearch.'%" or alias LIKE "%'.$qsearch.'%" '.(is_numeric($qsearch)?' or id='.$qsearch:'');
        $db->setQuery( $query );
        $data = $db->loadObjectList();
        
        $total_quiz_result = array();
        for($quiz=0;$quiz<count($data);$quiz++)
        {
        $new = new stdClass();
        $new->value = $data[$quiz]->id;
        $new->label = $data[$quiz]->title;
         array_push($total_quiz_result, $new);
        }
        $obj->html = $total_quiz_result;
        jexit(json_encode($obj));
    }

	function search(){
		
        $obj = new stdClass();
        $obj->result = 'success'; 
        $db = JFactory::getDbo();
        $qsearch = JRequest::getVar('qsearch', '');
        $query= 'SELECT id,title FROM #__vquiz_quizzes WHERE title LIKE "%'.$qsearch.'%" or alias LIKE "%'.$qsearch.'%" '.(is_numeric($qsearch)?' or id='.$qsearch:'');
        $db->setQuery( $query );
        $data = $db->loadObjectList();
        
        $total_quiz_result = array();
        for($quiz=0;$quiz<count($data);$quiz++)
        {
        $new = new stdClass();
        $new->value = $data[$quiz]->id;
        $new->label = $data[$quiz]->title;
         array_push($total_quiz_result, $new);
        }
        $obj->html = $total_quiz_result;
        jexit(json_encode($obj));
    }
}