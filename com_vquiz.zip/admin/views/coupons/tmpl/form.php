<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');
JHTML::_('behavior.modal');
$document = JFactory::getDocument();$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

//error_reporting(0);
//echo "<pre>";print_r($this->item);
//var_dump($this->item->applicable_user); //exit;

?>
<script type="text/javascript">

var jq=jQuery.noConflict();
jq(document).ready(function(){
	
	jq('#reset_users').click(function(){
		jQuery('#jform_request_user_id').val('');
		//jQuery('#jform_request_user_name').val('<?php echo JText::_('COM_VQUIZ_SELECT_USER');?>');	
	});
	
	jq('#reset_quiz').click(function(){
		jQuery('#jform_request_id_id').val('');
		//jQuery('#jform_request_id_name').val('<?php echo JText::_('COM_VQUIZ_SELECT_QUIZ');?>');	
	});

});
	function jSelectQuizzes_jform_request_id(id, title, object){
		jQuery('#jform_request_id_id').val(id);
		//jQuery('#jform_request_id_name').val(title);	
		SqueezeBox.close();
	}
	
	function jSelectUsers_jform_request_id(id, title, object){
		jQuery('#jform_request_user_id').val(id);
		//jQuery('#jform_request_user_name').val(title);	
		SqueezeBox.close();
	}
	
Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
 
			if(!jQuery('input[name="codes"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_COUPONS_PLZ_ENTER_COUPON_CODE', true); ?>');
				document.adminForm.codes.focus();
				return false;
			}
			if(!jQuery('input[name="offer"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_COUPONS_PLZ_ENTER_COUPON_DISCOUNT', true); ?>');
				document.adminForm.offer.focus();
				return false;
			}			
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}
</script>
<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col101">
    <fieldset class="adminform">
    
        <table class="adminform table table-striped">
		
	    <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_COUPONS_CODES_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_COUPONS_CODES_LBL'); ?><span class="star">*</span></label></td>
			
			<td><input type="text"  name="codes" id="" class="title" value="<?php echo $this->item->codes;?>"/></td>
			
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_COUPONS_OFFER_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_COUPONS_OFFER_LBL'); ?><span class="star">*</span></label></td>
			
			<td><input type="text"  name="offer" id="" class="title" value="<?php echo $this->item->offer;?>"/></td>
			
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_COUPONS_OFFER_TYPE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_COUPONS_OFFER_TYPE_LBL'); ?></label></td>
			
			<td>
				<select  name="type_offer" id="type_offer" >
					<option value="0" <?php if($this->item->type_offer==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PERCENTAGE'); ?> </option>
					<option value="1" <?php if($this->item->type_offer==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_CURRENCY'); ?> </option>					
				</select>
				</td>
			 
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_COUPONS_MINIMUM_AMOUNT_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_COUPONS_MINIMUM_AMOUNT_LBL'); ?></label></td>
			
			<td><input type="text"  name="above_amount" id="" class="title" value="<?php echo $this->item->above_amount;?>"/></td>
			
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_COUPONS_MAXIMUM_DISCOUNT_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_COUPONS_MAXIMUM_DISCOUNT_LBL'); ?></label></td>
			
			<td><input type="text"  name="maximum_discount" id="" class="title" value="<?php echo $this->item->maximum_discount;?>"/></td>
			
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_COUPONS_START_DATE_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_COUPONS_START_DATE_LBL'); ?></label></td>
			
			<td>
			<?php
					echo JHtml::_('calendar', $this->item->start_date, 'start_date', 'start_date', '%Y-%m-%d %H:%M:%S', ''); ?>
			</td>
			
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_COUPONS_EXPIRY_DATE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_COUPONS_EXPIRY_DATE_LBL'); ?></label></td>
			
			<td>
			<?php
					echo JHtml::_('calendar', $this->item->expiry_date, 'expiry_date', 'expiry_date', '%Y-%m-%d %H:%M:%S', ''); ?>
					</td>
			
        </tr>
		
		
		
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_STATUS'); ?>"><?php echo JText::_('COM_VQUIZ_STATUS'); ?></label></td>
			
			<td>
				<select  name="published" id="published" >
				<option value="1" <?php if($this->item->published==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?> </option>
				<option value="0" <?php if($this->item->published==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?> </option>
				</select>

			</td>
		</tr>
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_COUPONS_APPLICABLE_PLAN_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_COUPONS_APPLICABLE_PLAN_LBL'); ?></label></td>
			
			<td>
				<select name="plan_id" id="plan_id">
					<option value=""><?php echo JText::_('COM_VQUIZ_ALL_PLANS'); ?> 
						<?php    for ($i=0; $i <count($this->plans); $i++)	
						{	
						?>
						<option value="<?php echo $this->plans[$i]->id;?>"  <?php  if($this->plans[$i]->id == $this->item->plan_id) echo 'selected="selected"'; ?> >
						<?php
						echo $this->plans[$i]->title;
						?> 
						</option>		
						<?php
						}
						?>
						</select>
				</td>
			 
        </tr>
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_COUPONS_APPLICABLE_QUIZ_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_COUPONS_APPLICABLE_QUIZ_LBL'); ?></label></td>
			
			<td>
			
			<span class="input-append">
			   <?php  
					 if(!empty($this->item->quizids)){
						$this->item->quizids = json_decode($this->item->quizids); 
						$appquizzes=implode(',',$this->item->quizids);
				   }else{
						$appquizzes='';
				   }
				  
				?>
				
					
					<input type="hidden" value="<?php echo $appquizzes;?>" name="quizids" class="required modal-value" id="jform_request_id_id" aria-required="true" required="required">

					 <a currten_id="" rel="{handler: 'iframe', size: {x: 800, y: 450}}" href="index.php?option=com_vquiz&amp;view=quizmanager&amp;tmpl=component&amp;function=jSelectQuizzes_jform_request_id&from_userview=1&selected_userquiz=<?php echo $appquizzes;?>" title="" class="modal btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_QUIZ');?>"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_SELECT");?></a> 
					 
					<input type="button" value="Reset" name="reset" currten_id="" id="reset_quiz" class="btn reset">
					
				</span>
						</td>
			
        </tr>
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_COUPONS_APPLICABLE_USERS_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_COUPONS_APPLICABLE_USERS_LBL'); ?></label></td>
			
			<td>
			
			 <span class="input-append">
			   <?php  
					 if(!empty($this->item->applicable_user)){
						$this->item->applicable_user = json_decode($this->item->applicable_user); 
						$appusers=implode(',',$this->item->applicable_user);
				   }else{
						$appusers='';
				   }
				  
				?>
				
					
					
					<input type="hidden" value="<?php echo $appusers;?>" name="applicable_user" class="required modal-value" id="jform_request_user_id" aria-required="true" required="required">

					 <a currten_id="" rel="{handler: 'iframe', size: {x: 800, y: 450}}" href="index.php?option=com_vquiz&amp;view=users&amp;tmpl=component&amp;function=jSelectUsers_jform_request_id&from_userview=1&selected_users=<?php echo $appusers;?>" title="" class="modal btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_USERS');?>"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_SELECT");?></a> 
					 
					<input type="button" value="Reset" name="reset" currten_id="" id="reset_users" class="btn reset">
					
						</span>
			</td>
			
        </tr>
		
		
		
		
		
		
	   
       </table>
    </fieldset>

</div> 

<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="coupons" />
</form>







