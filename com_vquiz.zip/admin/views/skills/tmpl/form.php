<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');

$document = JFactory::getDocument();$document->addStyleSheet('components/com_vquiz/assets/css/select2.min.css');$document->addStyleSheet('components/com_vquiz/assets/css/style.css');if(version_compare(JVERSION, '3.0', '>=')) JHtml::_('formbehavior.chosen', 'select');

?>
<script type="text/javascript">
Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
 
			if(!jQuery('input[name="title"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_PLZ_ENTER_SKILL_TITLE', true); ?>');
				document.adminForm.title.focus();
				return false;
			}				
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}
</script>
<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col101">
    <fieldset class="adminform">
    <legend><?php echo JText::_('COM_VQUIZ_SKILLS_DETAILS'); ?></legend>
        <table class="adminform table table-striped">
		
	    <tr>
        <td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_SKILL_TITLE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_SKILL_TITLE'); ?></label></td>
		<td><input type="text"  name="title" id="title" class="title" value="<?php echo $this->item->title;?>"/></td>
        </tr>
		
		<tr>
		<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_STATUS_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_STATUS'); ?></label></td>
		
        <td>
			<select  name="published" id="published" >
			<option value="1" <?php if($this->item->published==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?> </option>
			<option value="0" <?php if($this->item->published==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?> </option>
			</select>

        </td>
		</tr>
	   
       </table>
    </fieldset>

</div> 

<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="skills" />
</form>







