<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );

JHTML::_('behavior.tooltip');
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$document->addScript('components/com_vquiz/assets/js/script.js');

?>

<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col101 result_table">
	<table class="adminlist table table-striped table-hover">
		<tr><th><?php echo JText::_('QUIZ_TITLE'); ?></th><th><?php  echo $this->item->quiztitle;?></th></tr>
		<tr><th><?php echo JText::_('QUIZ_TYPE'); ?></th>
		<th>
		<?php 					
		if($this->item->optinscoretype==1)
			echo JText::_("TRIVIA_QUIZ");
		else if($this->item->optinscoretype==2)
			echo JText::_("PERSONALITY_QUIZ");
		else if(optinscoretype)
			echo JText::_("SURVEY_QUIZ");
		?>  
		</th>
		</tr>
	</table>

	<fieldset class="adminform">
		<legend><div style="text-align:center"><?php echo JText::_('DETAILS'); ?></div></legend>
	
		<div align="center" class="trivia_quiz">
			<table class="adminlist table table-striped table-hover">
				<tbody>
				<tr>
					<td><label><?php echo JText::_( 'USER_NAME' ); ?></label></td>
					<td>	
						<?php 					
							echo $this->item->username; 
						?> 
					</td>
				</tr>

				<tr>
				<td><label><?php echo JText::_('STARTTIME');?></label></td>
				<td><?php echo $this->item->created_date; ?></td>
				</tr>
 				
				<tr>
					<td><label><?php echo JText::_('TOTAL_QUESTIONS');?></label></td>
					<td><?php echo $this->showresult->total_question;?></td>
				</tr>
				<tr>
					<td><label><?php echo JText::_('GIVEN_ANSWERS');?></label></td>
					<td><?php 
							$givenanswer=$this->showresult->givenanswer;
							//$remove = array(0);
							//$givenanswers = array_values(array_diff($givenanswer, $remove));  
							echo count($givenanswer); 
							 
						?></td>
				</tr>
				<?php if($this->showresult->answers_type==0 and $this->item->optinscoretype==1){?>
				<tr>
					<td><label><?php echo JText::_('CORRECT_ANSWERS');?></label></td>
					<td><?php echo $this->showresult->correct_answers_count;?></td>
				</tr>
				<?php }?>

				
				</tbody>
			</table>
		</div>
	</fieldset>


	<div class="all_quiz">
		<?php 
		for( $i=0;$i<count($this->showresult->question_array);$i++){
			$given_answer=explode(',',$this->showresult->givenanswer[$i]);
			$user_comment=@$this->showresult->user_comment[$i];
			$user_comment_other=explode(',',$user_comment);

			if($user_comment_other[0]=='other'){
				$user_comment_value=1;
			}else{
				$user_comment_value=0;
			}
		?>

		<div class="result_quiz">
			<div class="result_quiz_data">
				<span class="qbx"><?php echo JText::_('QUESTION');echo $i+1; ?></span>
				<h4><?php echo $this->showresult->question[$i]->qtitle;?> </h4>
				<?php if($this->showresult->question[$i]->score!=0 and $this->showresult->question[$i]->optiontype==5){?>
					<label>
						 <?php echo JText::_('TEXT_AREA_ANSWER_LABEL');
							echo '<b>'.$this->showresult->textarea_answer[$i].'</b>';
						 ?>
					</label>
					
					<div style="border-top:1px solid #ccc;margin:10px 0;clear:both">
						<div style="float:left;">
							<label><?php echo JText::_('SCORE')?></label>
							<label>
							<input type="text" name="text_area_score[]" value="<?php echo $this->showresult->textarea_admin_score[$i];?>" style="width:100px;"/>
							</label>
						</div>
						<div style="float:left; margin:0 10px;text-align:center;">
							<label><?php echo JText::_('OUT_OF_SCORE')?></label>
							<label>
							<?php echo $this->showresult->question[$i]->score;?> 
							</label>
						</div>
					</div>
				<?}elseif($this->showresult->question[$i]->optiontype==4){?>
					<label>
						<?php echo JText::_('TEXT_FIELD_ANSWER_LABEL');
							echo '<b>'.$this->showresult->text_answer[$i].'</b>';
						?>
					</label>
		
					<input type="hidden" name="text_area_score[]" value="0"/>
				<?php }else{?>
					<input type="hidden" name="text_area_score[]" value="0"/>
				<?php }?>
				
			</div>
			
		<?php if($this->showresult->question[$i]->optiontype!=5 and  $this->showresult->question[$i]->optiontype!=4){?>	
		
		<table border="0" width="100%" cellpadding="5" cellspacing="0">
			<tr>
				<th><?php echo JText::_('COUNT');?></th><th><?php echo JText::_('OPTIONS');?></th>

				<th>
				<?php
				echo JText::_('YOUR_ANSWER');
				if($user_comment_value==0){
					if(!empty($user_comment)){
						echo '<label style="margin:5px opx;padding-left:9px;font-size:12px;display:block">(<b>'.JText::_('COMMENT').'</b>'.$user_comment.')</label>';
					}else{
						for($k=0;$k<count($given_answer);$k++){
							if($given_answer[$k]==0)
							echo '<label style="padding-left:10px;font-size:9px">('.JText::_('SKIP_QUESTION').')</label>';
						} 
					}
				}

				?>
				</th>
				<?php if($this->showresult->correctans==1){  ?>    
					<th>
					<?php
					echo JText::_('CORRECT_ANSWER');				  
					?>
					</th>

				<?php }?>
			</tr>


			<?php for( $j=0;$j<count($this->showresult->options[$i]);$j++){?>
				<tr>
					<td><p><?php echo $j+1;?></p></td>
					<td><p><?php echo $this->showresult->options[$i][$j]->qoption;?></p></td>
					<td>
					<p style="text-align:center;">
					<?php
					if($this->showresult->optiontypescore==1 and $this->showresult->answers_type==1)
					{

						for($k=0;$k<count($given_answer);$k++){
							if ($given_answer[$k]==$this->showresult->options[$i][$j]->id and ($this->showresult->options[$i][$j]->correct_ans!=1) ){
								echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/delete-icon.png" />';
							}
							else if($given_answer[$k]==$this->showresult->options[$i][$j]->id and ($this->showresult->options[$i][$j]->correct_ans==1)){
								echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/Ok-icon.png" />';
							}
						}

					}

					else//if($this->showresult->optiontypescore==2)
					{  
						for($k=0;$k<count($given_answer);$k++){
							if($this->showresult->options[$i][$j]->id==$given_answer[$k])
							echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/Ok-icon.png" />';
						}

					}
					?>

					</p>
					</td>
					<?php if($this->showresult->correctans==1){  ?>
						<td>
						<p style="text-align:center;">
						<?php   
						if($this->showresult->options[$i][$j]->correct_ans==1 and  $this->showresult->correctans==1){
						echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/Ok-icon.png" />';
						$check_redudency=true;
						}?>

						</p>
						</td>
					<?php }?> 
				</tr> 
			<?php }?>

			<?php if($user_comment_value==1){?>
				<tr><td><p><?php echo $j+1;?></p></td><td><p><?php echo JText::_('OTHER_OPTION')?></p></td><td><p><?php if(!empty($user_comment_other[1])) echo $user_comment_other[1];?></p></td></tr>
			<?php }?>

		</table>    
		<?}?>
		
		</div>    
		<?php }?>
	</div>

</div>
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="quizdraft" />
<input type="hidden" name="id" value="<?php echo $this->item->id;?>" />
</form>







