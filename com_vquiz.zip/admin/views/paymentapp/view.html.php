<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );
class VquizViewPaymentapp extends JViewLegacy
{ 
 
		function display($tpl = null)
 		{
			  $mainframe =JFactory::getApplication();
			  $user = JFactory::getUser();
			  
			  if(!$user->authorise('core.userviews','com_vquiz')){
				jerror::raiseWarning('403', JText::_('UNAUTH_ACCESS'));
				return false;	 
			  }

			  $session=JFactory::getSession();
			  
		      $context	= 'com_vquiz.paymentapp.list.'; 
			  $layout = JRequest::getCmd('layout', '');
			  
			  $search = $mainframe->getUserStateFromRequest( $context.'search', 'search', '',	'string' );
		      $search = JString::strtolower( $search );

		     
			  $filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
       		  $filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
 			  
			  $this->config = $this->get('Configuration');	
			
 				if($layout == 'form')
 				{
 					//$this->access = $this->get('Access');					
					$this->item =$this->get('Item');
					$isNew		= ($this->item->id < 1); 
					
					$this->plans  = $this->get('Plans');
					
					$this->PaymentPlugins  = $this->get('PaymentPlugins');
					
					
					//echo "<pre>";print_r($this); exit;
					
					//$this->assignRef( 'item', $item );
					
					$this->configuration  = $this->get('Configuration');

							
					
					if($isNew)	{
						JToolBarHelper::title( JText::_( 'COM_EDIT_PAYMENT_PLUGINS' ), 'credit-2.png' );	// set subscription image here	
					}else{
						
						JToolBarHelper::title( JText::_( 'COM_EDIT_PAYMENT_PLUGINS' ), 'credit-2.png' );
						
					}
					
					if($isNew)
					{
						if($isNew && JFactory::getUser()->authorise('core.create','com_vquiz'))
						{
							JToolBarHelper::apply();
							JToolBarHelper::save();	
							
						}
					}else{
						if($user->authorise('core.edit','com_vquiz') OR ($user->authorise('core.edit.own','com_vquiz') and $this->item->created_by == $user->get('id')))
						{
							JToolBarHelper::apply();
							JToolBarHelper::save();		
						}
						
					}


					JToolBarHelper::cancel();
					
					JToolBarHelper::help('help', true);
					
					$this->ordering = array();
					// Preprocess the list of items to find ordering divisions.

			}else{
				
				JToolBarHelper::title( JText::_('COM_QUIZ_PAYMENT_PLUGINS'), 'credit-2.png' );
				
				if(JFactory::getUser()->authorise('core.create','com_vquiz')){
						JToolBarHelper::addNew();
					}
					
				if(JFactory::getUser()->authorise('core.edit','com_vquiz')){
					JToolBarHelper::editList();
				}
								
				if(JFactory::getUser()->authorise('core.edit.state','com_vquiz')){
					JToolBarHelper::publish();
					JToolBarHelper::unpublish();
				}
				if(JFactory::getUser()->authorise('core.delete','com_vquiz')){
						JToolBarHelper::deleteList(JText::_('DO_YOU_WANT_DELETE_RECORD'));	
					}	
								
				JToolBarHelper::help('help', true);
				$version = new JVersion;
				$joomla = $version->getShortVersion();
				$jversion = substr($joomla,0,3);
				$this->sidebar ='';
				if($jversion>=3.0)
				{
				$this->sidebar = JHtmlSidebar::render();
				}
				if(JFactory::getUser()->authorise('core.admin','com_vquiz')){
					JToolBarHelper::preferences('com_vquiz','', '','ACL');
				}
				
 				$this->items = $this->get('Items');
				
				$this->plans  = $this->get('Plans');
				//echo '<pre>'; print_r($this->items);exit;
				
				//$this->assignRef( 'items', $items ); 
				
				$this->pagination = $this->get('Pagination');
				$this->lists['search']= $search;
				
				//$this->assignRef( 'lists', $lists );
				
				
				
				// Table ordering.
				$this->lists['order_Dir'] = $filter_order_Dir;
				$this->lists['order']     = $filter_order;
				
				
				//echo '<pre>'; print_r($this->pagination);exit;//echo 1; exit;
  			   }
 
			 parent::display($tpl);
 
		 }
		
 
} 