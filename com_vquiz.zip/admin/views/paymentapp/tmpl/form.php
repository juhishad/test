<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');
$document = JFactory::getDocument();$document->addStyleSheet('components/com_vquiz/assets/css/style.css');

if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

//error_reporting(0);
//print_r($this->item); exit;

$params = (!empty($this->item->params))?json_decode($this->item->params):new  stdclass();



//var_dump($selected_plans);

//echo "<pre>";print_r($params); exit;
?>
<script type="text/javascript">

jQuery(document).ready(function(){
		
		setPaymentFileds();
		
	});
	
Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
 
			if(!jQuery('input[name="title"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PLZ_ENTER_PLAN_TITLE', true); ?>');
				document.adminForm.title.focus();
				return false;
			}				
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}

	function setPaymentFileds(){
		if(jQuery("#plugin_id").val()=='paypal'){
			
			//jQuery('#wire_status').hide();
			//jQuery('#paypal_email').show();
			//jQuery('#paypal_sandbox').show();
			
			jQuery('#wire_status').parent().parent().hide();
			jQuery('#paypal_pro_email').parent().parent().hide();
			jQuery('#paypal_pro_sandbox').parent().parent().hide();
			jQuery('#paypal_pro_api_username').parent().parent().hide();
			jQuery('#paypal_pro_api_password').parent().parent().hide();
			jQuery('#paypal_pro_api_signature').parent().parent().hide();
			
			jQuery('#paypal_email').parent().parent().show();
			jQuery('#paypal_sandbox').parent().parent().show();
			
			
			//jQuery('#selected_plans').val('[]');
			
		}
		else if(jQuery("#plugin_id").val()=='paypal_pro'){
			
			//jQuery('#wire_status').hide();
			//jQuery('#paypal_email').show();
			//jQuery('#paypal_sandbox').show();
			
			jQuery('#wire_status').parent().parent().hide();
			jQuery('#paypal_email').parent().parent().hide();
			jQuery('#paypal_sandbox').parent().parent().hide();
			
			jQuery('#paypal_pro_email').parent().parent().show();
			jQuery('#paypal_pro_sandbox').parent().parent().show();
			jQuery('#paypal_pro_api_username').parent().parent().show();
			jQuery('#paypal_pro_api_password').parent().parent().show();
			jQuery('#paypal_pro_api_signature').parent().parent().show();
			  
			//jQuery('#selected_plans').val('[]');
			
		}
		else if(jQuery("#plugin_id").val()=='wire'){
			
			//jQuery('#paypal_email').hide();
			//jQuery('#paypal_sandbox').hide();
			//jQuery('#wire_status').show();
			
			jQuery('#paypal_email').parent().parent().hide();
			jQuery('#paypal_sandbox').parent().parent().hide();
			jQuery('#paypal_pro_email').parent().parent().hide();
			jQuery('#paypal_pro_sandbox').parent().parent().hide();
			jQuery('#paypal_pro_api_username').parent().parent().hide();
			jQuery('#paypal_pro_api_password').parent().parent().hide();
			jQuery('#paypal_pro_api_signature').parent().parent().hide();
			
			jQuery('#wire_status').parent().parent().show();
			
			//jQuery('.plans_list').addClass('required');
		}
		else{
			jQuery('#paypal_email').parent().parent().hide();
			jQuery('#paypal_sandbox').parent().parent().hide();
			jQuery('#paypal_pro_email').parent().parent().hide();
			jQuery('#paypal_pro_sandbox').parent().parent().hide();
			jQuery('#paypal_pro_api_username').parent().parent().hide();
			jQuery('#paypal_pro_api_password').parent().parent().hide();
			jQuery('#paypal_pro_api_signature').parent().parent().hide();
			jQuery('#wire_status').parent().parent().hide();
		}
	}

</script>
<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col101">
    <fieldset class="adminform">
    <legend><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_EDIT_DETAILS'); ?></legend>
        <table class="adminform table table-striped">
		
	    <tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PAYMENT_APP_PAYMENT_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PAYMENT_LBL'); ?></label></td>
			<td>
			<?php 
				
				for ($i=0; $i <count($this->PaymentPlugins); $i++)	
				{ 
					if($this->PaymentPlugins[$i]->element==$this->item->plugin_type){ 
						echo JText::_($this->PaymentPlugins[$i]->name);
					}
				}
				?>
				
			<!--<select name="plugin_type" id="plugin_id" onchange="setPaymentFileds()">
								<option value="">-< ?php echo JText::_('COM_VQUIZ_PAYMENT_APP_SELECT_PAYMENT_LBL'); ?>-</option>
									
				< ?php 
				
				for ($i=0; $i <count($this->PaymentPlugins); $i++)	
				{ 
				?>
				<option value="< ?php echo $this->PaymentPlugins[$i]->element;?>"  < ?php  if($this->PaymentPlugins[$i]->element==$this->item->plugin_type){ echo 'selected="selected"';} ?> >< ?php echo JText::_($this->PaymentPlugins[$i]->name);?></option>		
				< ?php
				}
				?>
			</select>-->

	</td>
        </tr>
		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PAYMENT_APP_PAYPAL_ACC_EMAIL_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PAYPAL_ACC_EMAIL_LBL'); ?></label></td>
			<td><input type="text"  name="params[paypal_email]" id="paypal_email" class="title" value="<?php if(isset($params->paypal_email)) {echo $params->paypal_email;}?>"/></td>
        </tr>

		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PAYMENT_APP_PAYPAL_SANDBOX_ENABLE_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PAYPAL_SANDBOX_ENABLE_LBL'); ?></label></td>
			<td>
			<select  name="params[paypal_sandbox]" id="paypal_sandbox">
				<option value="1" <?php if(isset($params->paypal_sandbox) && $params->paypal_sandbox==1) echo 'selected="selected"'; ?>><?php echo JText::_('Yes'); ?> </option>
				<option value="0" <?php if(isset($params->paypal_sandbox) && $params->paypal_sandbox==0) echo 'selected="selected"'; ?>><?php echo JText::_('No'); ?> </option>
				</select>
			</td>
        </tr>
		
		<!--pro-->
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PAYMENT_APP_PAYPAL_PRO_ACC_EMAIL_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PAYPAL_PRO_ACC_EMAIL_LBL'); ?></label></td>
			<td><input type="text"  name="params[paypal_pro_email]" id="paypal_pro_email" class="title" value="<?php if(isset($params->paypal_pro_email)) {echo $params->paypal_pro_email;}?>"/></td>
        </tr>
		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PAYMENT_APP_PAYPAL_PRO_ACC_USERNAME_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PAYPAL_PRO_ACC_USERNAME_LBL'); ?></label></td>
			<td><input type="text"  name="params[paypal_pro_api_username]" id="paypal_pro_api_username" class="title" value="<?php if(isset($params->paypal_pro_api_username)) {echo $params->paypal_pro_api_username;}?>"/></td> 
        </tr>
		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PAYMENT_APP_PAYPAL_PRO_ACC_PASSWORD_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PAYPAL_PRO_ACC_PASSWORD_LBL'); ?></label></td>
			<td><input type="text"  name="params[paypal_pro_api_password]" id="paypal_pro_api_password" class="title" value="<?php if(isset($params->paypal_pro_api_password)) {echo $params->paypal_pro_api_password;}?>"/></td>
        </tr>
		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PAYMENT_APP_PAYPAL_PRO_ACC_SIGNATURE_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PAYPAL_PRO_ACC_SIGNATURE_LBL'); ?></label></td>
			<td><input type="text"  name="params[paypal_pro_api_signature]" id="paypal_pro_api_signature" class="title" value="<?php if(isset($params->paypal_pro_api_signature)) {echo $params->paypal_pro_api_signature;}?>"/></td>
        </tr>

		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PAYMENT_APP_PAYPAL_PRO_SANDBOX_ENABLE_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PAYPAL_PRO_SANDBOX_ENABLE_LBL'); ?></label></td>
			<td>
			<select  name="params[paypal_pro_sandbox]" id="paypal_pro_sandbox">
				<option value="1" <?php if(isset($params->paypal_pro_sandbox) && $params->paypal_pro_sandbox==1) echo 'selected="selected"'; ?>><?php echo JText::_('Yes'); ?> </option>
				<option value="0" <?php if(isset($params->paypal_pro_sandbox) && $params->paypal_pro_sandbox==0) echo 'selected="selected"'; ?>><?php echo JText::_('No'); ?> </option>
				</select>
			</td>
        </tr>
		<!--/pro-->
		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PAYMENT_APP_PARAMETERS_LBL'); ?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PARAMETERS_LBL'); ?></label></td>
			<td>
		
<?php echo JText::_('COM_VQUIZ_PAYMENT_APP_ORDER_STATUS_LBL'); ?>

<select name="params[wire_status]" id="wire_status">
				<option value="0" <?php if(isset($params->wire_status) && $params->wire_status==0) echo 'selected="selected"'; ?>>Pending</option>
				<option value="1" <?php if(isset($params->wire_status) && $params->wire_status==1) echo 'selected="selected"'; ?>>Success</option>
			</select>


			
			</td>
        </tr>
		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_GRID_TOOLTIP_PAYMENT_APP_TITLE'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_GRID_PAYMENT_APP_TITLE'); ?></label></td>
			<td><input type="text"  name="title" id="title" class="title" value="<?php echo $this->item->title;?>"/></td>
        </tr>
		
		
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PAYMENT_APP_EDIT_TOOLTIP_PLANS_DESCRIPTION'); ?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_APP_PLANS_DESCRIPTION'); ?></label></td>
			
			<td>
				
				<textarea name="description" id="description" style="width: 237px; height: 108px;"><?php echo isset($this->item->description)?$this->item->description:'';?></textarea>

			</td>
		</tr>
		
				
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_STATUS'); ?>"><?php echo JText::_('COM_VQUIZ_STATUS'); ?></label></td>
			
			<td>
				<select  name="published" id="published" >
				<option value="1" <?php if($this->item->published==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?> </option>
				<option value="0" <?php if($this->item->published==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?> </option>
				</select>

			</td>
		</tr>
		
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_DEFAULT'); ?>"><?php echo JText::_('COM_VQUIZ_DEFAULT'); ?></label></td>
			
			<td>
				<select  name="featured" id="featured" >
				<option value="1" <?php if($this->item->featured==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_YES'); ?> </option>
				<option value="0" <?php if($this->item->featured==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_NO'); ?> </option>
				</select>

			</td>
		</tr>
		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('Icon'); ?><br /><?php echo JText::_('COM_VQUIZ_PAYMETHOD_FORM_ICON_FIELD_DESC');?>"><?php echo JText::_('Icon'); ?></label></td>
			<td><input type="file"  name="icon" id="pay_icon" class="title" accept=".gif,.jpg,.jpeg,.png"/></td>
        </tr>
		
		<?php if($path=$this->item->icon){;?>
		<tr>
			<td class="key" width="200"></td>
			<td>
				<img src="<?php echo JURI::root();?>components/com_vquiz/assets/upload/icon/<?php echo $path; ?>" width="50" height="50"/>
                            <a href="javascript:void(0);" class="pm_rimg btn btn-small" id="<?php echo $path;?>" style="margin-left:20px"><span class="icon-delete"></span> <?php echo JText::_('COM_VQUIZ_REMOVE');?></a>
			</td>
        </tr>
		<?php }?>
		
                   
                    
		
		
       </table>
    </fieldset>

</div> 

<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="paymentapp" />
</form>







