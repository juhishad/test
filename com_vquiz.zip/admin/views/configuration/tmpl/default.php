<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');  
$document = JFactory::getDocument();    

/* 
$document->addScript(JUri::root().'/components/com_vquiz/assets/js/jquery-ui.js');     
$document->addStyleSheet('components/com_vquiz/assets/css/jquery-ui.css'); */

$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
if(version_compare(JVERSION, '3.0', '>=')) 
	JHtml::_('formbehavior.chosen', 'select');
$editor = JFactory::getEditor();    
 
?>
<script type="text/javascript"> 
var jq=jQuery.noConflict();

jq(document).ready(function(){ 

	jq("#tabs").tabs();
	jq("#tabs_certificate").tabs();
	jq( "#tabs_results").tabs();
	jq("#mpanel1").slideDown("slow");	
	jq("#tpanel").slideDown("slow");
	jq("#certificate_flip").click(function(){	
		//$("#mpanel1").slideToggle("slow");
		jq("#mpanel").slideUp("slow");
		jq("#mpanel2").slideUp("slow");
		jq("#mpane13").slideUp("slow");
		jq("#mpane14").slideUp("slow");
		
	});			

	jq("#tflip").click(function(){	
		//$("#tpanel").slideToggle("slow");
		jq("#tpanel2").slideUp("slow");
	});
	
	jq("#mflip").click(function(){
		//$("#mpanel").slideToggle("slow");
		jq("#mpanel2").slideUp("slow");
		jq("#mpanel1").slideUp("slow");
	});

	jq("#tflip2").click(function(){
		//$("#tpanel2").slideToggle("slow");
		jq("#tpanel").slideUp("slow");
	});
	
	jq("#mflip2").click(function(){
		//$("#mpanel2").slideToggle("slow");
		jq("#mpanel").slideUp("slow");
		jq("#mpanel1").slideUp("slow");
	});

/* 	  if(jq('input[name="get_certificate"]').val()==0){
		  jq('.ckeck_downlaod_certificate').hide();
	  }
	  
	 jq('input[name="get_certificate"]').on('click',function(){
		  var get_certificate=jQuery(this).val();
		  if(get_certificate==0)
			  jq('.ckeck_downlaod_certificate').hide("slow");
		  else
			  jq('.ckeck_downlaod_certificate').show("slow");
	  }); */
	 
	 jq('#cet_type').on('change',function(){
		 
		  var cet_type=jQuery(this).val();
		  
		  if(cet_type==0){
			  jq('.cet_format').css("display","none");
		  }else{
			  jq('.cet_format').css("display","");
		  }
	  });
	  
	 /*Share Button */
	  jq('input[name="share_button"]').on('click',function(){
		  var value=jQuery(this).val();
		  if(value==0)
			  jq('.showButton').hide();
		  else
			  jq('.showButton').show();
	  }); 
	  
	  jq('#default_cert_link').on('click',function(){
			
				  jq('#tabs ul li a[href="#emailtext"]').click();				  			
									
			  });
	  
	  jq('#default_result_link').on('click',function(){
			
				  jq('#tabs ul li a[href="#quiztext"]').click();
				  		
									
			  }); 
			  
});

</script>

<form action="index.php?option=com_vquiz&view=configuration" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<?php if (!empty( $this->sidebar)) : ?>   
		<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
		</div>
		<div id="j-main-container" class="span10">
		<?php else : ?>
		<div id="j-main-container">
		<?php endif;?>
		<div class="clr" style="clear:both;"></div>
<legend><?php echo JText::_('COM_VQUIZ_CONFIGURATION'); ?></legend>		
<div class="col101">

	<div id="tabs">
	
		<ul>
		<li><a href="#addtional"><?php echo JText::_('COM_VQUIZ_GENERAL'); ?></a></li> 
		<li><a href="#new"><?php echo JText::_('NEW'); ?></a></li> 		
		<li><a href="#emailtext"><?php echo JText::_('COM_VQUIZ_CERTIFICATE'); ?></a></li>     
		<li><a href="#quiztext"><?php echo JText::_('COM_VQUIZ_RESULT'); ?></a></li>   
		<li><a href="#g_ads"><?php echo JText::_('COM_VQUIZ_ADS'); ?></a></li>   
		</ul>

	<!--Result Template Container-->

		<div  id="quiztext">    

			<fieldset class="adminform">   
				<legend><?php echo JText::_( 'COM_VQUIZ_QUIZ_RESULT_TEMPLATE'); ?></legend>
			<div class="conf_left_panel_options">
			<div id="tabs_results">
				<ul>
				<li><a href="#tpanel"><?php echo JText::_('COM_VQUIZ_TRIVIA_QUIZ'); ?></a></li>
				<li><a href="#tpanel2"><?php echo JText::_('COM_VQUIZ_PERSONALITY_QUIZ'); ?></a></li>
				<li><a href="#tpanel3"><?php echo JText::_('COM_VQUIZ_SIMULATION'); ?></a></li>
				<li><a href="#tpanel4"><?php echo JText::_('COM_VQUIZ_MBTI'); ?></a></li>
				<li><a href="#tpanel5"><?php echo JText::_('COM_VQUIZ_SURVEY'); ?></a></li>
				</ul>
						
						<div id="tpanel">
							<h4 style="text-align:center"><?php echo JText::_('COM_VQUIZ_TRIVIA_QUIZ')?></h4>
							<?php 
							echo $editor->display("textformat",  $this->item->textformat, "400", "400", "20", "5", 1, null, null, null, array());
							?>
						</div> 
						<div  id="tpanel2">
							<h4><?php echo JText::_('COM_VQUIZ_PERSONALITY_QUIZ')?></h4>
							<?php 

							echo $editor->display("textformat2",  $this->item->textformat2, "400", "400", "20", "5", 1, null, null, null, array());
							?>
						</div>
						
						<div  id="tpanel3">
							<h4><?php echo JText::_('COM_VQUIZ_SIMULATION')?></h4>
							<?php 

							echo $editor->display("textformat3",  $this->item->textformat3, "400", "400", "20", "5", 1, null, null, null, array());
							?>
						</div>
						
						<div  id="tpanel4">
							<h4><?php echo JText::_('COM_VQUIZ_MBTI')?></h4>
							<?php 

							echo $editor->display("textformat4",  $this->item->textformat4, "400", "400", "20", "5", 1, null, null, null, array());
							?>
						</div>
						
						<div  id="tpanel5">
							<h4><?php echo JText::_('COM_VQUIZ_SURVEY')?></h4>
							<?php 

							echo $editor->display("textformat5",  $this->item->textformat5, "400", "400", "20", "5", 1, null, null, null, array());
							?>
						</div>
						
					</div>
				</div>

				<div class="conf_right_panel">

					<div class="conf-para">
						<h3><?php echo JText::_("COM_VQUIZ_PARAMETER");?></h3>
						
						<div class="">
						
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{certificate_number}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CERTIFICATE_NUMBER')?>">{certificate_number}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{username}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERNAME')?>">{username}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{spenttime}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_SPENTTIME')?>">{spenttime}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{quizname}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUIZNAME')?>">{quizname}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{startdate}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_STARTTIME')?>">{startdate}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{enddate}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_ENDTIME')?>">{enddate}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{maxscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_MAXSCORE')?>">{maxscore}</span></a>
							<br>

							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{userscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERSCORE')?>">{userscore}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{percentscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERCENTSCORE')?>">{percentscore}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{passedscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERCENTSCORE')?>">{passedscore}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{passed}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PASSED')?>">{passed}</span></a>
							<br>

							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{email}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_EMAIL')?>">{email}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{flag}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_FLAG')?>">{flag}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{trivia_message}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_TRIVIA_MESSAGE')?>">{trivia_message}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{questiongroup_score}', 'params_Value');return false;" href=""><span class="class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUESTIONGROUP_SCORE')?>">{questiongroup_score}</span></a>
							<br>	
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{categoryscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CATEGORY_MESSAGE')?>">{categoryscore}</span></a>
							<br>
							
							<a class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERSONALITY_MESSAGE')?>" onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{personality_message}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERSONALITY_MESSAGE')?>">{personality_message}</span></a>
							
							<br>
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{personality_score}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERSONALITY_SCORE')?>">{personality_score}</span></a>
							
							<br>
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{total_questions}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_TOTAL_QUESTIONS')?>">{total_questions}</span></a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{given_answers}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_GIVEN_ANSWERS')?>">{given_answers}</span></a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{correct_answers}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CORRECT_ANSWERS')?>">{correct_answers}</span></a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{catid}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CORRECT_CATID')?>">{catid}</span></a>

							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{articleid}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_ARTICLE_ID')?>">{articleid}</span></a>
							<br>
							
							<a class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_DATE')?>" onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{play_date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_DATE')?>">{play_date}</span></a>
							<br>
							
							<a class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CURRENT_DATE')?>" onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CURRENT_DATE')?>">{date}</span></a>
							<br>
							<a class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ANSWERSHEET')?>" onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{answersheet}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ANSWERSHEET')?>">{answersheet}</span></a>							<br>							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{quizid}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUIZID')?>">{quizid}</span></a>							<br>							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{	quizurl}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUIZURL')?>">{quizurl}</span></a>

						</div>
					</div>
				</div>
				</fieldset>
		</div>
		
		
		

		<!--Email Template Container-->
		
		<div id="emailtext">
		
		<table class="adminform table table-striped" width="100%">
								<tbody>
									<tr>
										<td><label ><?php echo JText::_('COM_VQUIZ_SAVE_CERTIFICATE');?></label></td>
										<td>
											<fieldset class="radio btn-group">
												<label for="save_certificate1" id="save_certificate1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
												<input type="radio" name="save_certificate" id="save_certificate1" value="1" <?php if($this->item->save_certificate==1) echo 'checked="checked"';?>/>
												<label for="save_certificate0" id="save_certificate0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
												<input type="radio" name="save_certificate" id="save_certificate0" value="0" <?php if($this->item->save_certificate==0) echo 'checked="checked"';?>/>
											</fieldset>
										</td>
									</tr>
									
									<tr>
										<td><label ><?php echo JText::_('COM_VQUIZ_QUIZZES_START_WITH');?></label></td>
										<td><label ><input type="text" name="start_with" value="<?php echo $this->item->start_with?>"/></label></td>
									</tr>
									
									<tr>
										<td><label><?php echo JText::_('COM_VQUIZ_TYPES');?></label></td>
										<td><label>
											<select name="cet_type" id="cet_type">
											<option value="0" <?php if($this->item->cet_type==0) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_CET_SEQ');?></option>
											<option value="1" <?php if($this->item->cet_type==1) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_CET_RAND');?></option>
											</select>
											
										</label></td>
									</tr>
									<tr class="cet_format" style="<?php if($this->item->cet_type==0) echo 'display:none';?>">
										<td><label><?php echo JText::_('COM_VQUIZ_FORMAT');?></label></td>
										<td><label>
											<select name="cet_format" id="cet_format">
											<option value="0" <?php if($this->item->cet_format==0) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_NUMERIC');?></option>
											<option value="1" <?php if($this->item->cet_format==1) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_ALPHA_NUMERIC');?></option>
											<option value="2" <?php if($this->item->cet_format==2) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_ALPHABETIC');?></option>
											</select>
											
										</label></td>
									</tr>
									
									<tr>
										<td><label><?php echo JText::_('COM_VQUIZ_QUIZZES_NUMBER_OF_DIGITS');?></label></td>
										<td><label>
											<input type="text" name="cet_digits" value="<?php echo $this->item->cet_digits;?>"/>
										</label></td>
									</tr>
									
									<tr>
										<td><label ><?php echo JText::_('COM_VQUIZ_QUIZZES_END_WITH');?></label></td>
										<td><label ><input type="text" name="end_with" value="<?php echo $this->item->end_with?>"/></label></td>
									</tr>
									
									<tr>
										<td><label><?php echo JText::_('COM_VQUIZ_CERTIFICATE_NAME');?></label></td>
										<td><label>
											<input type="text" name="cet_name" value="<?php echo $this->item->cet_name;?>"/><?php echo JText::_('COM_VQUIZ_CERTIFICATE_NAME_SUFFIX');?>
										</label></td>
									</tr>
									
									
								</tbody>
								</table>
								<br />

			<fieldset class="adminform"> 
				<legend><?php echo JText::_('COM_VQUIZ_CERTIFICATE_TEMPLATE'); ?></legend>
				
			<div class="conf_left_panel_options">
			
				<div id="tabs_certificate">
					<ul>
					<!--<li><a href="#mpanel1">< ?php echo JText::_('COM_VQUIZ_QUIZZES_CERTIFICATE_NUMBER'); ?></a></li>--> 
					
					<li><a href="#mpanel"><?php echo JText::_('COM_VQUIZ_TRIVIA_QUIZ'); ?></a></li>
					<li><a href="#mpanel2"><?php echo JText::_('COM_VQUIZ_PERSONALITY_QUIZ'); ?></a></li>
					<li><a href="#mpane13"><?php echo JText::_('COM_VQUIZ_SIMULATION'); ?></a></li>
					<li><a href="#mpane14"><?php echo JText::_('COM_VQUIZ_MBTI'); ?></a></li>
					</ul>
				
					<!--<div  id="mpanel1">
							kkk
					</div>--> 
						
					<div  id="mpanel">
						<h4><?php echo JText::_('COM_VQUIZ_TRIVIA_QUIZ')?></h4>
						<?php 
						echo $editor->display("mailformat",  $this->item->mailformat, "400", "400", "20", "5", 1, null, null, null, array());
						?>
					</div> 


					<div  id="mpanel2">
						<h4><?php echo JText::_('COM_VQUIZ_PERSONALITY_QUIZ')?></h4>
						<?php 
						echo $editor->display("mailformat2",  $this->item->mailformat2, "400", "400", "20", "5", 1, null, null, null, array());
						?>
					</div>
					<div  id="mpane13">
						<h4><?php echo JText::_('COM_VQUIZ_SIMULATION')?></h4>
						<?php 
						echo $editor->display("mailformat3",  $this->item->mailformat3, "400", "400", "20", "5", 1, null, null, null, array());
						?>
					</div>
					<div  id="mpane14">
						<h4><?php echo JText::_('COM_VQUIZ_MBTI')?></h4>
						<?php 
						echo $editor->display("mailformat4",  $this->item->mailformat4, "400", "400", "20", "5", 1, null, null, null, array());
						?>
					</div>
					</div>
				</div>
 
			
				<div class="conf_right_panel"> 

					<div class="conf-para">
					
					<h3><?php echo JText::_("COM_VQUIZ_PARAMETER");?></h3>

						<div class="">
						
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{certificate_number}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CERTIFICATE_NUMBER')?>">{certificate_number}</span></a>
							<br>
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{username}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERNAME')?>">{username}</span></a>
							<br>

							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{spenttime}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_SPENTTIME')?>">{spenttime}</span></a>
							<br>

							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{quizname}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUIZNAME')?>">{quizname}</span></a>
							<br>

							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{startdate}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_STARTTIME')?>">{starttime}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{enddate}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_ENDTIME')?>" >{endtime}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{maxscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_MAXSCORE')?>">{maxscore}</span></a>
							<br>

							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{userscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERSCORE')?>"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERSCORE')?>">{userscore}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{percentscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERCENTSCORE')?>" >{percentscore}</span></a>
							<br>

							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{passedscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PASSEDSCORE')?>">{passedscore}</span></a>
							<br>

							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{passed}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PASSED')?>">{passed}</span></a>
							<br>

							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{email}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_EMAIL')?>">{email}</span></a>
							<br>

							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{resultslink}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_FLAG')?>">{flag}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{trivia_message}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_TRIVIA_MESSAGE')?>">{trivia_message}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{categoryscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CATEGORY_MESSAGE')?>">{categoryscore}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{questiongroup_score}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUESTIONGROUP_SCORE');?>">{{questiongroup_score}}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{personality_message}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERSONALITY_MESSAGE')?>">{personality_message}</span></a>
							
							<br>
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{personality_score}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERSONALITY_MESSAGE')?>">{personality_score}</span></a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{total_questions}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_TOTAL_QUESTIONS')?>" >{total_questions}</span></a>
							
							<br>
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{given_answers}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_GIVEN_ANSWERS')?>">{given_answers}</span></a>
							
							<br>
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{correct_answers}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CORRECT_ANSWERS')?>">{correct_answers}</span></a>
							
							<br>
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{catid}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CORRECT_CATID')?>">{catid}</span></a>

							<br>
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{articleid}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_ARTICLE_ID')?>">{articleid}</span></a>
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{play_date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_DATE')?>" >{play_date}</span></a>
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CURRENT_DATE')?>">{date}</span></a>
							
						</div>
					</div>
				</div>                 
			</fieldset>
		</div> 
		<div id="addtional">
			<table class="adminform table table-striped">
				<tr>
					<td width="250" class="hasTip"  title="<?php echo JText::_('COM_VQUIZ_LOAD_JQUERY_TOOLTIP') ?>">
						<?php echo JText::_('COM_VQUIZ_LOAD_JQUERY') ?>
					</td>
					<td>
						<fieldset class="radio btn-group">
							<label for="load_jquery1" id="load_jquery1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
							<input type="radio" name="load_jquery" id="load_jquery1" value="1" <?php if($this->item->load_jquery==1) echo 'checked="checked"';?>/>
							<label for="load_jquery0" id="load_jquery0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="load_jquery" id="load_jquery0" value="0" <?php if($this->item->load_jquery==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>
				
				  
				<tr>
					<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_NEXT_QUIZ_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_NEXT_QUIZ');?></label></td>
					<td>
						<fieldset class="radio btn-group">
						<label for="next_quiz1" id="next_quiz1-lbl" class="radio"><?php echo JText::_( 'YS' ); ?></label>
						<input type="radio" name="next_quiz" id="next_quiz1" value="1" <?php if($this->item->next_quiz ==1) echo 'checked="checked"';?>/>
						<label for="next_quiz0" id="next_quiz0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
						<input type="radio" name="next_quiz" id="next_quiz0" value="0" <?php if($this->item->next_quiz ==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>
				<tr>
					<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_PREV_QUIZ_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_PREV_QUIZ');?></label></td>
					<td>
						<fieldset class="radio btn-group">
						<label for="prev_quiz1" id="prev_quiz1-lbl" class="radio"><?php echo JText::_( 'YS' ); ?></label>
						<input type="radio" name="prev_quiz" id="prev_quiz1" value="1" <?php if($this->item->prev_quiz ==1) echo 'checked="checked"';?>/>
						<label for="prev_quiz0" id="prev_quiz0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
						<input type="radio" name="prev_quiz" id="prev_quiz0" value="0" <?php if($this->item->prev_quiz ==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>
				
				<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_PREPARE_CONTENT_DESC');?>"><?php echo JText::_('COM_VQUIZ_PREPARE_CONTENT');?></label>
					</td>
					<td>
						<fieldset class="radio btn-group">
							<label for="qp_button1" id="qp_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
							<input type="radio" name="quiz_prepare_content" id="qp_button1" value="1" <?php if($this->item->quiz_prepare_content==1) echo 'checked="checked"';?>/>
							<label for="qp_button0" id="qp_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="quiz_prepare_content" id="qp_button0" value="0" <?php if($this->item->quiz_prepare_content==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>
				
				<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_PREPARE_CONTENT_DESC');?>"><?php echo JText::_('COM_VQUIZ_QUESTION_PREPARE_CONTENT');?></label>
					</td>
					<td>
						<fieldset class="radio btn-group">
							<label for="q_button1" id="q_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
							<input type="radio" name="question_prepare_content" id="q_button1" value="1" <?php if($this->item->question_prepare_content==1) echo 'checked="checked"';?>/>
							<label for="q_button0" id="q_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="question_prepare_content" id="q_button0" value="0" <?php if($this->item->question_prepare_content==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>
				
				
								
				<tr>
					<td width="250" class="hasTip"  >						
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SUBCATEGORY_SHOWS_QUIZLIST_LAYOUT_DESC') ?>"><?php echo JText::_('COM_VQUIZ_SUBCATEGORY_SHOWS_QUIZLIST_LAYOUT');?></label>
					</td>
					<td>
						<fieldset class="radio btn-group">
							<label for="subcategory_list_layout1" id="subcategory_list_layout1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
							<input type="radio" name="subcategory_list_layout" id="subcategory_list_layout1" value="1" <?php if($this->item->subcategory_list_layout==1) echo 'checked="checked"';?>/>
							<label for="subcategory_list_layout0" id="subcategory_list_layout0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="subcategory_list_layout" id="subcategory_list_layout0" value="0" <?php if($this->item->subcategory_list_layout==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>
				
								
				<tr class="showButton" style="<?php if($this->item->share_button==0) echo "display:none;"?>">
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_FACEBOOK_APPID_DESC');?>"><?php echo JText::_('COM_VQUIZ_FACEBOOK_APPID');?></label>
					</td>
					<td>
						<input type="text" name="facebook_appid" value="<?php echo $this->item->facebook_appid?>"/>
					</td>
				</tr>
				<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CERTIFICATE_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_CERTIFICATE');?></label>
					</td>
					<td>
						<select name="certificate">
							<option value="0" <?php if($this->item->certificate==0) echo 'selected="selected"';?>><?php echo JText::_("COM_VQUIZ_DOWNLOAD_BUTTON")?></option>
							<option value="1" <?php if($this->item->certificate==1) echo 'selected="selected"';?>><?php echo JText::_("COM_VQUIZ_EMAIL_BUTTON")?></option>
							<option value="2" <?php if($this->item->certificate==2) echo 'selected="selected"';?>><?php echo JText::_("COM_VQUIZ_AUTOMATIC_EMAIL")?></option>
							<option value="3" <?php if($this->item->certificate==3) echo 'selected="selected"';?>><?php echo JText::_("COM_VQUIZ_EMAIL_BY_ADMIN")?></option>
						</select>
					</td>
				</tr>
									
				<tr>
					<td>
					<label class="hasTip" title="<?php echo JText::_('COLUMN_LIMIT_DESC');?>"><?php echo JText::_('DASHBOARD_COLUMN');?></label>
					</td>

					<td><input class="text_area" type="number" name="column_limit" id="column_limit" value="<?php echo $this->item->column_limit;?>"/>
					</td>
				</tr>
		
				<tr>  
					<td>
					<label class="hasTip" title="<?php echo JText::_('ROW_LIMIT_DESC');?>"><?php echo JText::_('DASHBOARD_ROW');?></label>
					</td>

					<td>
					<input class="text_area" type="number" step="25" name="row_limit" id="row_limit" value="<?php echo $this->item->row_limit;?>" />
					</td>
				</tr>
				
				<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CATEGORY_IMG_DESC');?>"><?php echo JText::_('COM_VQUIZ_CATEGORY_IMG');?></label>
					<td class="thm_width">
						<input type="text" title="<?php echo JText::_('COM_VQUIZ_WIDTH_ONLY_NUMERIC') ?>" name="categorythumbnailwidth"  value="<?php echo $this->item->categorythumbnailwidth; ?>" /> 
						<input type="text" title="<?php echo JText::_('COM_VQUIZ_HEIGHT_ONLY_NUMERIC') ?>" name="categorythumbnailheight"  value="<?php echo $this->item->categorythumbnailheight; ?>" />
					</td>
				</tr>
				
				<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LIST_COLUMNS_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_LIST_COLUMNS');?></label>
					</td>
					
					<td>
						<input type="number" min="1" max="5" title="<?php echo JText::_('COM_VQUIZ_LIST_COLUMNS_TOOLTIP') ?>" name="list_column"  value="<?php echo $this->item->list_column==0?1:$this->item->list_column; ?>" /> 
					</td>
				</tr>
				
				<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CURRENCY_LABEL');?>"><?php echo JText::_('COM_VQUIZ_CURRENCY_LABEL');?></label>
					</td>
					<td>
						<input type="text" name="currencyname" value="<?php echo $this->item->currencyname?>"/>
					</td>
				</tr>
				
				<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CURRENCY_SYMBOL');?>"><?php echo JText::_('COM_VQUIZ_CURRENCY_SYMBOL');?></label>
					</td>
					<td>
						<input type="text" name="currencysymbol" value="<?php echo $this->item->currencysymbol?>"/>
					</td>
				</tr>
				
				<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_PAYMENT_SYSTEM_DESC');?>"><?php echo JText::_('COM_VQUIZ_PAYMENT_SYSTEM');?></label>
					</td>
					
					<td>
						<fieldset class="radio btn-group">
							<label for="payment_system1" id="payment_system1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
							<input type="radio" name="payment_system" id="payment_system1" value="1" <?php if($this->item->payment_system==1) echo 'checked="checked"';?>/>
							<label for="payment_system0" id="payment_system0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="payment_system" id="payment_system0" value="0" <?php if($this->item->payment_system==0) echo 'checked="checked"';?>/>							
						</fieldset>
					</td>
				</tr>
				
	<tr>
	<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LEAD_GENERATION');?>"><?php echo JText::_('COM_VQUIZ_LEAD_GENERATION');?></label></td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="lead_generation1" id="lead_generation1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
		<input type="radio" name="lead_generation" id="lead_generation1" value="1" <?php if($this->item->lead_generation ==1) echo 'checked="checked"';?>/>
		<label for="lead_generation0" id="lead_generation0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
		<input type="radio" name="lead_generation" id="lead_generation0" value="0" <?php if($this->item->lead_generation ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		
	</td>
</tr>


				
				<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ENTER_DATE_TOOLTIP') ?>"><?php echo JText::_('COM_VQUIZ_ENTER_DATE') ?></label> 
					</td>
					<td>
						<input type="text" name="dateformat"  value="<?php echo $this->item->dateformat; ?>" />
					</td>
				</tr>
				
				<tr>
					<td></td>
					<td>
						<a href="https://php.net/manual/en/datetime.formats.date.php" target="_blank"><?php echo JText::_('COM_VQUIZ_RF_LINK') ?></a>
					</td>
				</tr>
				
			</table>
		</div>

		<!--New Container-->
		<div id="new">
			<table class="adminform table table-striped">
			<tr>
				<th><?php echo JText::_('COM_VQUIZ_FUNCTIONALITY');?></th>
				<th><?php echo JText::_('COM_VQUIZ_FRONTEND_ACCESS');?></th>
				<th><?php echo JText::_('COM_VQUIZ_DEFAULT_VALUE');?></th>
			</tr>
			
			<tr>
				<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ACCESSLEVEL');?>"><?php echo JText::_('COM_VQUIZ_ACCESSLEVEL');?></label></td>
				
				<td>
					<fieldset class="radio btn-group">
					<label for="allowed_accesslevel1" id="allowed_accesslevel1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
					<input type="radio" name="allowed_accesslevel" id="allowed_accesslevel1" value="1" <?php if($this->item->allowed_accesslevel ==1) echo 'checked="checked"';?>/>
					<label for="allowed_accesslevel0" id="allowed_accesslevel0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
					<input type="radio" name="allowed_accesslevel" id="allowed_accesslevel0" value="0" <?php if($this->item->allowed_accesslevel ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
				
				<td>
					<?php echo $this->lists['access']; ?>
				</td>
			</tr>
			
			<tr>
				<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ALIAS');?>"><?php echo JText::_('COM_VQUIZ_ALIAS');?></label></td>
				
				<td>
					<fieldset class="radio btn-group">
					<label for="allowed_alias1" id="allowed_alias1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
					<input type="radio" name="allowed_alias" id="allowed_alias1" value="1" <?php if($this->item->allowed_alias ==1) echo 'checked="checked"';?>/>
					<label for="allowed_alias0" id="allowed_alias0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
					<input type="radio" name="allowed_alias" id="allowed_alias0" value="0" <?php if($this->item->allowed_alias ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
				
				<td>
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ALIAS_DEFAULT_VALUE');?>"><?php echo JText::_('COM_VQUIZ_ALIAS_DEFAULT_VALUE');?></label>
				</td>
			</tr>
			
			<tr>
				<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ORDERING');?>"><?php echo JText::_('COM_VQUIZ_ORDERING');?></label></td>
				
				<td>
					<fieldset class="radio btn-group">
					<label for="allowed_ordering1" id="allowed_ordering1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
					<input type="radio" name="allowed_ordering" id="allowed_ordering1" value="1" <?php if($this->item->allowed_ordering ==1) echo 'checked="checked"';?>/>
					<label for="allowed_ordering0" id="allowed_ordering0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
					<input type="radio" name="allowed_ordering" id="allowed_ordering0" value="0" <?php if($this->item->allowed_ordering ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
				
				<td>
					<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ORDERING_DEFAULT_VALUE');?>"><?php echo JText::_('COM_VQUIZ_ORDERING_DEFAULT_VALUE');?></label>
				</td>
			</tr>
			
			<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_PUBLISHED');?>"><?php echo JText::_('COM_VQUIZ_PUBLISHED');?></label>
					</td>
					
					<td>
						<fieldset class="radio btn-group">
							<label for="allowed_published1" id="allowed_published1-lbl" class="radio"><?php echo JText::_( 'YS' ); ?></label>
							<input type="radio" name="allowed_published" id="allowed_published1" value="1" <?php if($this->item->allowed_published==1) echo 'checked="checked"';?>/>
							<label for="allowed_published0" id="allowed_published0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="allowed_published" id="allowed_published0" value="0" <?php if($this->item->allowed_published==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
					
					<td>
						<fieldset class="radio btn-group">
							<label for="published1" id="published1-lbl" class="radio"><?php echo JText::_( 'YS' ); ?></label>
							<input type="radio" name="published" id="published1" value="1" <?php if($this->item->published==1) echo 'checked="checked"';?>/>
							<label for="published0" id="published0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="published" id="published0" value="0" <?php if($this->item->published==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>
			 
			 <tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_TAKE_SNAPSHOT_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_TAKE_SNAPSHOT');?></label>
					</td>
					
					<td>
						<fieldset class="radio btn-group">
							<label for="allowed_take_snapshot1" id="allowed_take_snapshot1-lbl" class="radio"><?php echo JText::_( 'YS' ); ?></label>
							<input type="radio" name="allowed_take_snapshot" id="allowed_take_snapshot1" value="1" <?php if($this->item->allowed_take_snapshot==1) echo 'checked="checked"';?>/>
							<label for="allowed_take_snapshot0" id="allowed_take_snapshot0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="allowed_take_snapshot" id="allowed_take_snapshot0" value="0" <?php if($this->item->allowed_take_snapshot==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
					
					<td>
						<fieldset class="radio btn-group">
							<label for="take_snapshot1" id="take_snapshot1-lbl" class="radio"><?php echo JText::_( 'YS' ); ?></label>
							<input type="radio" name="take_snapshot" id="take_snapshot1" value="1" <?php if($this->item->take_snapshot==1) echo 'checked="checked"';?>/>
							<label for="take_snapshot0" id="take_snapshot0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="take_snapshot" id="take_snapshot0" value="0" <?php if($this->item->take_snapshot==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>

				<tr>
					<td>
						<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CONTINUOUS_QUESTION_DESC');?>"><?php echo JText::_('COM_VQUIZ_CONTINUOUS_QUESTION');?></label>
					</td>
					
					<td>
						<fieldset class="radio btn-group">
							<label for="allowed_cq_button1" id="allowed_cq_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
							<input type="radio" name="allowed_continuous_question" id="allowed_cq_button1" value="1" <?php if($this->item->allowed_continuous_question==1) echo 'checked="checked"';?>/>
							<label for="allowed_cq_button0" id="allowed_cq_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="allowed_continuous_question" id="allowed_cq_button0" value="0" <?php if($this->item->allowed_continuous_question==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
					
					<td>
						<fieldset class="radio btn-group">
							<label for="cq_button1" id="cq_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
							<input type="radio" name="continuous_question" id="cq_button1" value="1" <?php if($this->item->continuous_question==1) echo 'checked="checked"';?>/>
							<label for="cq_button0" id="cq_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="continuous_question" id="cq_button0" value="0" <?php if($this->item->continuous_question==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
					
				</tr>

				<tr>
	<td>
		<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LATER_QUIZ_PLAY_DESC');?>"><?php echo JText::_('COM_VQUIZ_LATER_QUIZ_PLAY');?></label>
	</td>
	<td>
		<fieldset class="radio btn-group">
			<label for="allowed_lq_button1" id="allowed_lq_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
			<input type="radio" name="allowed_later_play" id="allowed_lq_button1" value="1" <?php if($this->item->allowed_later_play==1) echo 'checked="checked"';?>/>
			<label for="allowed_lq_button0" id="allowed_lq_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
			<input type="radio" name="allowed_later_play" id="allowed_lq_button0" value="0" <?php if($this->item->allowed_later_play==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	<td>
		<fieldset class="radio btn-group">
			<label for="lq_button1" id="lq_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
			<input type="radio" name="later_play" id="lq_button1" value="1" <?php if($this->item->later_play==1) echo 'checked="checked"';?>/>
			<label for="lq_button0" id="lq_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
			<input type="radio" name="later_play" id="lq_button0" value="0" <?php if($this->item->later_play==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
</tr>

<tr>
	<td>
		<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SENT_INVITATION_DESC');?>"><?php echo JText::_('COM_VQUIZ_SENT_INVITATION');?></label>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
			<label for="allowed_inv_button1" id="allowed_inv_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
			<input type="radio" name="allowed_invite" id="allowed_inv_button1" value="1" <?php if($this->item->allowed_invite==1) echo 'checked="checked"';?>/>
			<label for="allowed_inv_button0" id="allowed_inv_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
			<input type="radio" name="allowed_invite" id="allowed_inv_button0" value="0" <?php if($this->item->allowed_invite==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
			<label for="inv_button1" id="inv_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
			<input type="radio" name="invite" id="inv_button1" value="1" <?php if($this->item->invite==1) echo 'checked="checked"';?>/>
			<label for="inv_button0" id="inv_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
			<input type="radio" name="invite" id="inv_button0" value="0" <?php if($this->item->invite==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
</tr>

<tr>
	<td>
		<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_DISABLE_COPY_PRINT_RESULT_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_DISABLE_COPY_PRINT_RESULT');?></label>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
			<label for="allowed_dpc_button1" id="allowed_dpc_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
			<input type="radio" name="allowed_disable_print_copy_result" id="allowed_dpc_button1" value="1" <?php if($this->item->allowed_disable_print_copy_result==1) echo 'checked="checked"';?>/>
			<label for="allowed_dpc_button0" id="allowed_dpc_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
			<input type="radio" name="allowed_disable_print_copy_result" id="allowed_dpc_button0" value="0" <?php if($this->item->allowed_disable_print_copy_result==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
			<label for="dpc_button1" id="dpc_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
			<input type="radio" name="disable_print_copy_result" id="dpc_button1" value="1" <?php if($this->item->disable_print_copy_result==1) echo 'checked="checked"';?>/>
			<label for="dpc_button0" id="dpc_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
			<input type="radio" name="disable_print_copy_result" id="dpc_button0" value="0" <?php if($this->item->disable_print_copy_result==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
</tr>

<tr>
	<td>
		<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SHARE_BUTTON_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_SHARE_BUTTON');?></label>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
			<label for="allowed_share_button1" id="allowed_share_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
			<input type="radio" name="allowed_share_button" id="allowed_share_button1" value="1" <?php if($this->item->allowed_share_button==1) echo 'checked="checked"';?>/>
			<label for="allowed_share_button0" id="allowed_share_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
			<input type="radio" name="allowed_share_button" id="allowed_share_button0" value="0" <?php if($this->item->allowed_share_button==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
			<label for="share_button1" id="share_button1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
			<input type="radio" name="share_button" id="share_button1" value="1" <?php if($this->item->share_button==1) echo 'checked="checked"';?>/>
			<label for="share_button0" id="share_button0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
			<input type="radio" name="share_button" id="share_button0" value="0" <?php if($this->item->share_button==0) echo 'checked="checked"';?>/>
		</fieldset>
		
		<?php $share_btn_choosed=explode(',',$this->item->share_btn_choosed);?>
		
			<div class="radio btn-group showButton" data-toggle="buttons" style="<?php if($this->item->share_button==0) echo "display:none;"?>">
			
			 <label class="btn btn-success">
				<input type="checkbox" name="share_btn_choosed[]" value="1" <?php if(in_array(1,$share_btn_choosed)==true) echo 'checked="checked"';?>>
				<span>Facebook</span>
			  </label>
			  <label class="btn btn-success">
				<input type="checkbox" name="share_btn_choosed[]" value="2" <?php if(in_array(2,$share_btn_choosed)==true) echo 'checked="checked"';?>>
				<span>Twitter</span>
			  </label>
			  <label class="btn btn-success">
				<input type="checkbox" name="share_btn_choosed[]" value="3" <?php if(in_array(3,$share_btn_choosed)==true) echo 'checked="checked"';?>>
				<span>Google+</span>
			  </label><label class="btn btn-success">
				<input type="checkbox" name="share_btn_choosed[]" value="0" <?php if(in_array(0,$share_btn_choosed)==true) echo 'checked="checked"';?>>
				<span>Others</span>
			  </label>
			</div>

	</td>
	</tr>
	
<tr>
	<td width="250" class="hasTip"  title="<?php echo JText::_('COM_VQUIZ_QUESTION_KEY_TOOLTIP') ?>">
		<?php echo JText::_('COM_VQUIZ_QUESTION_KEY') ?>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
			<label for="allowed_question_key1" id="allowed_question_key1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
			<input type="radio" name="allowed_question_key" id="allowed_question_key1" value="1" <?php if($this->item->allowed_question_key==1) echo 'checked="checked"';?>/>
			<label for="allowed_question_key0" id="allowed_question_key0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
			<input type="radio" name="allowed_question_key" id="allowed_question_key0" value="0" <?php if($this->item->allowed_question_key==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
			<label for="question_key1" id="question_key1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
			<input type="radio" name="question_key" id="question_key1" value="1" <?php if($this->item->question_key==1) echo 'checked="checked"';?>/>
			<label for="question_key0" id="question_key0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
			<input type="radio" name="question_key" id="question_key0" value="0" <?php if($this->item->question_key==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
</tr>

<tr>
	<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_FEATURED_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_FEATURED');?></label></td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="allowed_featured1" id="allowed_featured1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
		<input type="radio" name="allowed_featured" id="allowed_featured1" value="1" <?php if($this->item->allowed_featured ==1) echo 'checked="checked"';?>/>
		<label for="allowed_featured0" id="allowed_featured0-lbl" class="radio"><?php echo JText::_('NOS'); ?></label>
		<input type="radio" name="allowed_featured" id="allowed_featured0" value="0" <?php if($this->item->allowed_featured ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="featured1" id="featured1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
		<input type="radio" name="featured" id="featured1" value="1" <?php if($this->item->featured ==1) echo 'checked="checked"';?>/>
		<label for="featured0" id="featured0-lbl" class="radio"><?php echo JText::_('NOS'); ?></label>
		<input type="radio" name="featured" id="featured0" value="0" <?php if($this->item->featured ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
</tr>

<tr>
	<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_FLAG_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_FLAG');?></label></td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="allowed_flag1" id="allowed_flag1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
		<input type="radio" name="allowed_flag" id="allowed_flag1" value="1" <?php if($this->item->allowed_flag ==1) echo 'checked="checked"';?>/>
		<label for="allowed_flag0" id="allowed_flag0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
		<input type="radio" name="allowed_flag" id="allowed_flag0" value="0" <?php if($this->item->allowed_flag ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="flag1" id="flag1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
		<input type="radio" name="flag" id="flag1" value="1" <?php if($this->item->flag ==1) echo 'checked="checked"';?>/>
		<label for="flag0" id="flag0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
		<input type="radio" name="flag" id="flag0" value="0" <?php if($this->item->flag ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
</tr>

<tr>
	<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_PAGING_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_PAGING');?></label></td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="allowed_paging1" id="allowed_paging1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
		<input type="radio" name="allowed_paging" id="allowed_paging1" value="1" <?php if($this->item->allowed_paging ==1) echo 'checked="checked"';?>/>
		<label for="allowed_paging0" id="allowed_paging0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
		<input type="radio" name="allowed_paging" id="allowed_paging0" value="0" <?php if($this->item->allowed_paging ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		<select  name="paging" id="paging" >
			<option value="1" <?php if($this->item->paging==1) echo 'selected="selected"'; ?>><?php echo JText::_('ONEQUESTION_PERPAGE'); ?> </option>
			
			<option value="2" <?php if($this->item->paging ==2) echo 'selected="selected"'; ?>><?php echo JText::_('ALLQUESTION_PERPAGE'); ?> </option>			
			
			<option value="3" <?php if($this->item->paging ==3) echo 'selected="selected"'; ?>><?php echo JText::_('QUESTION_GROUP_PERPAGE'); ?> </option>
			
		</select>
	</td>
</tr>

<tr>
	<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CERTIFICATE_TEMPLATE');?>"><?php echo JText::_('COM_VQUIZ_CERTIFICATE_TEMPLATE');?></label></td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="allowed_certificate1" id="allowed_certificate1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
		<input type="radio" name="allowed_certificate" id="allowed_certificate1" value="1" <?php if($this->item->allowed_certificate ==1) echo 'checked="checked"';?>/>
		<label for="allowed_certificate0" id="allowed_certificate0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
		<input type="radio" name="allowed_certificate" id="allowed_certificate0" value="0" <?php if($this->item->allowed_certificate ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SET_DEFAULT');?>"><a href="javascript:void(0);" id="default_cert_link"><?php echo JText::_('COM_VQUIZ_SET_DEFAULT');?></a></label>
	</td>
</tr>

<tr>
	<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CERTIFICATE_TEMPLATE_FOR_LPATH');?>"><?php echo JText::_('COM_VQUIZ_CERTIFICATE_TEMPLATE_FOR_LPATH');?></label></td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="allowed_learning_certificate1" id="allowed_learning_certificate1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
		<input type="radio" name="allowed_learning_certificate" id="allowed_learning_certificate1" value="1" <?php if($this->item->allowed_learning_certificate ==1) echo 'checked="checked"';?>/>
		<label for="allowed_learning_certificate0" id="allowed_learning_certificate0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
		<input type="radio" name="allowed_learning_certificate" id="allowed_learning_certificate0" value="0" <?php if($this->item->allowed_learning_certificate ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		
	</td>
</tr>

<tr>
	<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZ_RESULT_TEMPLATE');?>"><?php echo JText::_('COM_VQUIZ_QUIZ_RESULT_TEMPLATE');?></label></td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="allowed_result1" id="allowed_result1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
		<input type="radio" name="allowed_result" id="allowed_result1" value="1" <?php if($this->item->allowed_result ==1) echo 'checked="checked"';?>/>
		<label for="allowed_result0" id="allowed_result0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
		<input type="radio" name="allowed_result" id="allowed_result0" value="0" <?php if($this->item->allowed_result ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SET_DEFAULT');?>"><a href="javascript:void(0);" id="default_result_link"><?php echo JText::_('COM_VQUIZ_SET_DEFAULT');?></a></label>
	</td>
</tr>

<tr>
	<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SUBMIT_BUTTON');?>"><?php echo JText::_('COM_VQUIZ_SUBMIT_BUTTON');?></label></td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="allow_submit_button1" id="allow_submit_button1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
		<input type="radio" name="allow_submit_button" id="allow_submit_button1" value="1" <?php if($this->item->allow_submit_button ==1) echo 'checked="checked"';?>/>
		<label for="allow_submit_button0" id="allow_submit_button0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
		<input type="radio" name="allow_submit_button" id="allow_submit_button0" value="0" <?php if($this->item->allow_submit_button ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
	<td>
		<fieldset class="radio btn-group">
		<label for="submit_button1" id="submit_button1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
		<input type="radio" name="submit_button" id="submit_button1" value="1" <?php if($this->item->submit_button ==1) echo 'checked="checked"';?>/>
		<label for="submit_button0" id="submit_button0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
		<input type="radio" name="submit_button" id="submit_button0" value="0" <?php if($this->item->submit_button ==0) echo 'checked="checked"';?>/>
		</fieldset>
	</td>
	
</tr>



				
			</table>
		</div>	<!-- kkk -->
		
		<div id="g_ads">
			<table class="adminform table table-striped">
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADS_SHOW_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_ADS_SHOW');?></label></td>
					<td>
					<select name="ads_shows" id="ads_shows ">
						<option value="0" <?php if($this->item->ads_shows==0) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_ADS_BOX_NONE');?></option>
						<option value="1" <?php if($this->item->ads_shows==1) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_ADS_BOX_BEFORE_RESULTS');?></option>
						<option value="2" <?php if($this->item->ads_shows==2) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_ADS_BOX_RESULTS_AT_TOP');?></option>
						<option value="3" <?php if($this->item->ads_shows==3) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_ADS_BOX_RESULTS_AT_BOTTOM');?></option>
						
					</select>
					</td>
				</tr>
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ADS_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_ADS');?></label></td>
					<td>
						<div class="g_ads_inner">
						<textarea name="g_ads"><?php echo $this->item->g_ads;?></textarea>
						</div>
					<td>
				</tr>
			</table>
		</div>

	</div>

</div>

<div class="clr"></div>
<?php echo JHTML::_( 'form.token' ); ?>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="configuration" />
</form>
</div>

