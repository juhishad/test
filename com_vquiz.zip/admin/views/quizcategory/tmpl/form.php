<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');


$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
//$document->addScript('components/com_vquiz/assets/js/library.js');
$document->addStyleSheet('components/com_vquiz/assets/css/jquery-ui.css');
$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

?>
<script type="text/javascript">
	var jq=jQuery.noConflict();
	
	
	jq(document).ready(function(){
		
		jq( "#tabs" ).tabs();
		jq( "#tabs_certificate" ).tabs();
		jq( "#tabs_results" ).tabs();		
		jq(".js-example-tags").select2({
			tags: true
		})
	});
</script>		
<script type="text/javascript">
Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
 
			if(!jQuery('input[name="title"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_CATEGORY_ENTER_TITLE', true); ?>');
				document.adminForm.qtitle.focus();
				return false;
			}				
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}
</script>
<form class="vquiz_form" action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col101">
    <fieldset class="adminform">
    <legend><?php echo JText::_( 'COM_VQUIZ_CATEGORY_DETAILS' ); ?></legend>
	
	<div id="tabs">
	<ul>
		<li><a href="#b_t"><?php echo JText::_('COM_VQUIZ_CATEGORY_BASIC'); ?></a></li>		
		<li><a href="#permissions"><?php echo JText::_('COM_VQUIZ_CATEGORY_PERMISSIONS'); ?></a></li>
	</ul>
	
	<div id="b_t">
        <table class="adminform table table-striped">
	    <tr>
        <td class="key" width="200"><label  class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CATEGORY_TITLE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_TITLE'); ?></label></td>
		<td><input type="text"  name="title" id="title" class="title" value="<?php echo $this->item->title;?>"/></td>
        </tr>
		       
        <tr><td><label><?php echo JText::_('COM_VQUIZ_ALIAS'); ?></label></td>
        <td><input type="text" name="alias" id="alias"  value="<?php echo !empty($this->item->alias)?$this->item->alias:'';?>"  placeholder="Automatic Genarated"/></td></tr>
		
		 <tr>
        <td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_PARENT_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_PARENT'); ?></label></td>
        <td>
  
        <select  name="parent_id" id="parent_id" >
          <option level="0"  value="1"><?php echo JText::_('ROOT');?></option>
          <?php for($k=0;$k<count($this->parentcategory);$k++){?>
           <option value="<?php echo $this->parentcategory[$k]->id;?>" <?php if($this->parentcategory[$k]->id==$this->item->parent_id) echo 'selected="selected"'; ?> level="<?php echo $this->parentcategory[$k]->level;?>">
         <?php
		 if($this->parentcategory[$k]->level>0){
 			echo str_repeat('-', $this->parentcategory[$k]->level-1);
		 }
			echo $this->parentcategory[$k]->title;
         ?> 
        </option>
		
        <?php }?>
        </select>
        <input type="hidden" name="level" id="level" value="<?php echo $this->item->level;?>" />
 
        </td>
        </tr>

        <tr>
         <td class="key"><label><?php echo JText::_('COM_VQUIZ_IMAGE'); ?></label></td>

		  <td class="upimg"><input type="file" name="photopath" id="photopath" />
	<?php 
    if(!empty($this->item->photopath) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/thumbs/'.'thumb_'.$this->item->photopath)){ 
    echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/photoupload/thumbs/'.'thumb_'.$this->item->photopath. '" alt="" />'; 
    }else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
    ?>
	</td>
	</tr>
	<tr>

	<td class="key"><label class="" title=""><?php echo JText::_('COM_VQUIZ_STATUS'); ?></label></td>
	<td>

	<fieldset class="radio btn-group">
	
	<label for="published1" id="published1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?></label>
	
	<input type="radio" name="published" id="published1" value="1" <?php if($this->item->published ==1) echo 'checked="checked"';?>/>
	
	<label for="published0" id="published0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?></label>
	
	<input type="radio" name="published" id="published0" value="0" <?php if($this->item->published ==0) echo 'checked="checked"';?>/>
	</fieldset>

	</td>
	</tr>
        <tr>
        <td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ORDETING_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_ORDERING'); ?></label></td>
        <td>
        <input type="number" name="ordering" id="ordering" value="<?php echo $this->item->ordering;?>" />
        </td>
        </tr>
            <tr>
            <td valign="top" class="key">
            <label><?php echo JText::_('COM_VQUIZ_ACCESS_LEVEL'); ?></label>
            </td>
            <td><label><?php echo $this->lists['access']; ?></label></td>
            </tr>

            <tr>
            <td class="key"><label><?php echo JText::_('COM_VQUIZ_LANGUAGE'); ?></label></td>
            <td colspan="2">
            <select name="language" id="language">
            <?php echo JHtml::_('select.options', JHtml::_('contentlanguage.existing', true, true), 'value', 'text', $this->item->language);?>
            </select>
            </td>
 		 </tr>
            <tr>
            <td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_META_DES_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_META_DESCRIPTION'); ?></label></td>
            <td><textarea name="meta_desc" id="meta_desc" cols="150" rows="5"><?php echo !empty($this->item->meta_desc)?$this->item->meta_desc:'';?></textarea></td>
            </tr>
            <tr>
            <td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_META_KEY_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_META_KEY'); ?></label></td>
            <td><textarea name="meta_keyword" id="meta_keyword" cols="150" rows="5"><?php echo!empty($this->item->meta_keyword)?$this->item->meta_keyword:'';?></textarea></td>
            </tr>

        </table>
	</div>
	
	<!-- Permissions tab-->
		<div id="permissions">
		<div id="jform_title">
		<legend><?php echo JText::_( 'COM_VQUIZ_CATEGORY_PERMISSIONS' ); ?></legend>
			<tr>
				<td>
						<?php echo $this->form->getInput('rules'); ?>
				</td>
			</tr>
		</div>
		</div>
	
	</div>
    </fieldset>

</div> 
	

<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="quizcategory" />
</form>







