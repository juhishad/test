<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );
jimport( 'joomla.html.html.list' );
class VquizViewQuizcategory extends JViewLegacy
{ 
	
		function getSortFields()  { 
			return array( 'i.lft' => JText::_('JGRID_HEADING_ORDERING'),
			'i.id' => JText::_('JGRID_HEADING_ID') ); 
		}

		function display($tpl = null){
				
			  $user = JFactory::getUser();
			  
				if(!$user->authorise('core.userviews','com_vquiz')){
					jerror::raiseWarning('403', JText::_('UNAUTH_ACCESS'));
					return false;	 
				}  
				
	          $mainframe =JFactory::getApplication();
		      $context	= 'com_vquiz.category.list.';
			  $layout = JRequest::getCmd('layout', '');
			  $search = $mainframe->getUserStateFromRequest( $context.'search', 'search', '',	'string' );
		      $search = JString::strtolower( $search );
			  $publish_item= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );
			  
			  $filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
       		  $filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
			  
			  $this->config = $this->get('Config');	
				//$this->form=$this->get('Form');	
				if($layout == 'form')
				{
					
					$this->form=$this->get('Form');	
					
					$this->parentcategory = $this->get('Parentcategory');
					$this->item =  $this->get('Item');
					$isNew		= ($this->item->id < 1);
 
					$this->lists['access'] = JHtml::_('access.assetgrouplist', 'access',$this->item->access);

					if($isNew)	{
						JToolBarHelper::title( JText::_('COM_VQUIZ_NEW_CATEGORY'), 'folder.png' );
					}
					else{
						JToolBarHelper::title( JText::_('COM_VQUIZ_EDIT_CATEGORY'), 'folder.png' );
					}
					
					if($isNew)
					{
						if($isNew && JFactory::getUser()->authorise('core.create','com_vquiz'))
						{
							JToolBarHelper::apply();
							JToolBarHelper::save();	
						}
						if ( JFactory::getUser()->authorise('core.create','com_vquiz'))
					{
						JToolbarHelper::save2new('save2new');
					}
					}
					else
					{
						if($user->authorise('core.edit','com_vquiz') OR ($user->authorise('core.edit.own','com_vquiz') and $this->item->created_by == $user->get('id')))
						{
							JToolBarHelper::apply();
							JToolBarHelper::save();		
						}
						if ( JFactory::getUser()->authorise('core.create','com_vquiz'))
						{
							JToolbarHelper::save2new('save2new');
							JToolbarHelper::save2copy('save2copy');
						}
					}

					JToolBarHelper::cancel('cancel','Close');
					JToolBarHelper::help('help', true);
					 
			}else{

			    $delete_msg=JText::_('COM_VQUIZ_DELETE_CATEGORY_MSG');
				JToolBarHelper::title( JText::_( 'COM_VQUIZ_CATEGORY' ), 'folder.png' );
				
				if($user->authorise('core.create','com_vquiz')){
					JToolBarHelper::addNew();
				}
				if(JFactory::getUser()->authorise('core.edit','com_vquiz')){
					JToolBarHelper::editList();
				}
				if(JFactory::getUser()->authorise('core.edit.state','com_vquiz')){
					JToolBarHelper::publish();
					JToolBarHelper::unpublish();
				}
				if(JFactory::getUser()->authorise('core.delete','com_vquiz')){
					JToolBarHelper::deleteList(JText::_('DO_YOU_WANT_DELETE_RECORD'));	
				}
				
 				if(JFactory::getUser()->authorise('core.import','com_vquiz')){
					JToolBarHelper::custom( 'import', 'download', 'upload', JText::_('CSV_IMPORT_TITLE' ), false );
				}
				
				if(JFactory::getUser()->authorise('core.export','com_vquiz')){
									
					JToolBarHelper::custom( 'export', 'upload', 'download', JText::_( 'CSV_EXPORT_TITLE'), false );
				}

				
				
				JToolBarHelper::help('help', true);
				$version = new JVersion;
			$joomla = $version->getShortVersion();
			$jversion = substr($joomla,0,3);
			$this->sidebar ='';
			if($jversion>=3.0)
			{
			$this->sidebar = JHtmlSidebar::render();
			}
				if(JFactory::getUser()->authorise('core.admin','com_vquiz')){
					JToolBarHelper::preferences('com_vquiz','', '','ACL');
				}
				
				
				$items = $this->get('Items');
				$this->assignRef( 'items', $items );
				$this->pagination = $this->get('Pagination');
				
				$lists['search']= $search;
				$lists['publish_item']= $publish_item;
				$this->assignRef( 'lists', $lists );
				
				// Table ordering.
				$this->lists['order_Dir'] = $filter_order_Dir;
				$this->lists['order']     = $filter_order;
				
				$this->ordering = array();
  				// Preprocess the list of items to find ordering divisions.
				foreach ($this->items as $item)
				{
					$this->ordering[$item->parent_id][] = $item->id;
 				}
				
			}
			parent::display($tpl);
			 
	}

}
 