<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );

$document = JFactory::getDocument();  

$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');
jimport( 'joomla.html.pagination');	
JHtml::_('behavior.framework');
JHtml::_('behavior.tooltip');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');
?>

 
<script type="text/javascript">
var jq=jQuery.noConflict();
	 
	 Joomla.submitbutton = function(task) {
		 

		if (task == 'cancel') {
			Joomla.submitform(task, document.getElementById('adminForm'));
		}else if(task =='export' || task =='Leadexport' ) {
			var form = document.adminForm;
			if (document.adminForm.boxchecked.value==0)  {
			alert("<?php echo JText::_('COM_VQUIZ_RESULTS_PLZ_CHOSE_RESULT'); ?>");
			return false;
			}
			Joomla.submitform(task, document.getElementById('adminForm'));
			document.adminForm.task.value='';
		}else if(task =='sendTemplate') {
			var form = document.adminForm;
			if (document.adminForm.boxchecked.value==0)  {
				alert("<?php echo JText::_('COM_VQUIZ_RESULTS_PLZ_CHOSE_RESULT'); ?>");
				return false;
			}/* else if(user_id<=0){
				alert("<?php echo JText::_('COM_VQUIZ_RESULTS_GUEST_NOT_ALLOWED'); ?>");
				return false;
			} */
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
			Joomla.submitform(task, document.getElementById('adminForm'));
		}
		
	}
</script>

<div class="poploadingbox">
<?php echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/loading.gif"/>' ?>
</div>
<form action="index.php?option=com_vquiz&view=quizresult" method="post" name="adminForm" id="adminForm" return>
<?php if (!empty( $this->sidebar)) : ?>   
		<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
		</div>
		<div id="j-main-container" class="span10">
		<?php else : ?>
		<div id="j-main-container">
		<?php endif;?>
		<legend><?php echo JText::_('COM_VQUIZ_QUIZ_RESULT'); ?></legend>
		<div class="clr" style="clear:both;"></div>	
            <div class="search_buttons">
                <div class="btn-wrapper input-append">
                <input placeholder="Search" type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
                <button class="btn" onclick="this.form.submit();"><i class="icon-search"></i><span class="search_text"><?php echo JText::_('COM_VQUIZ_SEARCH'); ?></button>
                <button class="btn" onclick="document.getElementById('search').value='';this.form.submit();"><?php echo JText::_('COM_VQUIZ_RESET'); ?></button>
                </div>
            </div>
			<!--document.getElementById('filter_user').value='';this.form.submit();--> 
			<div class="filter_calendar filter-select fltrt" style="float:right;">
			
			<?php 
				echo JHTML::calendar($this->lists['startdatesearch'],'startdatesearch', 'startdatesearch', '%Y-%m-%d',array('size'=>'8','maxlength'=>'19','placeholder'=>'start date',));
			?>
									
			
			<?php 
				echo JHTML::calendar($this->lists['enddatesearch'],'enddatesearch', 'enddatesearch', '%Y-%m-%d',array('size'=>'8','maxlength'=>'19','placeholder'=>'start date',));
			?>
			
			<button class="btn" onclick="this.form.submit();">
			<?php echo JText::_('COM_VQUIZ_GO'); ?></button>
			
			<button class="btn" onclick="document.getElementById('startdatesearch').value='';document.getElementById('enddatesearch').value='';this.form.submit();"><?php echo JText::_('COM_VQUIZ_RESET'); ?></button>
	
			<div class="btn-group pull-right hidden-phone">
				<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
				<?php echo $this->pagination->getLimitBox(); ?>
			</div>
			
      
  
			<?php /*
			<div class="search_b" style="float:left;">
				<input class="btn btn-small" type="button" id="sendmail" value="<?php echo JText::_('COM_VQUIZ_RESULTS_SEND_CERTIFICATE'); ?>" />
			</div>*/?>
	
	<div class="btn-group pull-right hidden-phone">
	
		<select name="quiz_id" id="quiz_id" class="inputbox" onchange="this.form.submit()">
			<option value=""><?php echo JText::_('COM_VQUIZ_ALL_QUIZZES'); ?></option>
			<?php    for ($i=0; $i <count($this->allQuizinresult); $i++)	
			{
			?>
			<option value="<?php echo $this->allQuizinresult[$i]->quizid;?>"  <?php  if($this->allQuizinresult[$i]->quizid == $this->lists['quiz_id']) echo 'selected="selected"'; ?>><?php echo $this->allQuizinresult[$i]->quizzes_title;?></option>		
		<?php
		}
		?>
		</select>

	</div>
	</div>
<div id="editcell">
	<table class="adminlist table table-striped table-hover">
	<thead>
		<tr>
        	<th width="5">
                 <?php echo JText::_('COM_VQUIZ_NUM'); ?>
			</th>
			<th width="20">
			<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
			</th>			
			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_QUIZ', 'i.quiztitle', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_QUESTIONS_QUIZ_TYPES', 'i.id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
		    <th>
                <?php echo JHTML::_('grid.sort', 'USER', 'i.userid', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
             <th>
              <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_TIME', 'i.created', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>

             <th>
             <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_QUIZZES_SHOW_FLAG', 'i.flagcount', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>

            <th width="5">
				 <?php echo JHTML::_('grid.sort', 'ID', 'i.id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
		</tr>
	</thead>
    <tfoot>
    <tr>
    <td colspan="11"> <?php echo $this->pagination->getListFooter(); ?></td>
    </tr>
    </tfoot>
	<?php

	$k = 0;
	for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
		$row = &$this->items[$i];
        $maxscore=$row->maxscore>0?$row->maxscore:1;
		$score=$row->score;
		$passed_score=$row->passed_score;
		$persentagescore=$score/$maxscore*100;
        
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		
		$link 		= JRoute::_( 'index.php?option=com_vquiz&view=quizresult&task=edit&cid[]='. $row->id);
		?>

		<tr class="<?php echo "row$k"; ?>">
			<td><?php echo $this->pagination->getRowOffset($i); ?></td>
			<td>
				<?php echo $checked; ?>
				<input  name="userid[]" value="<?php echo $row->userid;?>" type="hidden">
			</td>

			<td>
		    <a href="<?php echo $link; ?>"> <?php echo $row->quiztitle;  ?></a>
			</td> 
			<td align="center">
				 <?php if($row->quiztype==1) 
                        echo JText::_('COM_VQUIZ_TRIVIA');
					else if($row->quiztype==11)
                        echo JText::_('COM_VQUIZ_SIMULATION_QUIZ');					
                    else if($row->quiztype==2)
                        echo JText::_('COM_VQUIZ_PERSONALITY');
					else if($row->quiztype==22)
                        echo JText::_('COM_VQUIZ_MULTI_CATEGORY_PERSONALITY_QUIZ');
                    else if($row->quiztype==3)
					echo JText::_('COM_VQUIZ_SURVEY'); 
                    else echo JText::_('ELECTION'); 
				 ?> 
            </td>
			<td align="center" >
				<?php 					
                if($row->userid==0){
					
					if($row->lead_name!=''){
						echo $row->lead_name;
					}else{
						echo JText::_("COM_VQUIZ_GUEST");
					}
                }else{
					echo $row->username; 
				}
                ?>  
            </td>
			
            <td align="center"><?php echo $row->created.'&nbsp&nbsp'.$row->starttime;  ?></td>

            <td align="center"><?php echo $row->flagcount;  ?></td>
             <td class="rowresultid" rowresultid="<?php echo $row->id;?>">
				<?php echo $row->id; ?>
			</td>
		</tr>
		<?php
		$k = 1 - $k; 
	}
	?>

	</table>

</div>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="quizresult" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
</form>
</div>


