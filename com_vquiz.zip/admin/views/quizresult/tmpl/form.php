<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );

JHTML::_('behavior.tooltip');
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$document->addScript('components/com_vquiz/assets/js/script.js');


if($this->showresult->check_textarea_question==1){
	$score= array_sum($this->showresult->textarea_admin_score) + $this->item->score;
}else{
	$score=$this->item->score;
}

$maxscore=$this->item->maxscore;
$passed_score=$this->item->passed_score;

if($maxscore==0)
	$persentagescore=100;	
else
	$persentagescore=round($score/$maxscore*100,2)>100?100:round($score/$maxscore*100,2);
	
$persentagescore=$persentagescore>0?$persentagescore:0;

?>

<form class="vquiz_form" action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col101 result_table">

<div class="quiz_result">
	<div class="quizresult_detail">
		<legend><?php echo JText::_('COM_VQUIZ_QUIZ_DETAILS'); ?></legend>
		<table class="adminlist table table-striped table-hover">
			<tr><th><?php echo JText::_('COM_VQUIZ_TITLE'); ?></th><td><?php  echo $this->item->quiztitle;?></td></tr>
			<tr><th><?php echo JText::_('COM_VQUIZ_QUESTIONS_QUIZ_TYPES'); ?></th>
			<td>
			 <?php if($this->item->quiztype==1) 
                        echo JText::_('COM_VQUIZ_TRIVIA');
					else if($this->item->quiztype==11)
                        echo JText::_('COM_VQUIZ_SIMULATION_QUIZ');					
                    else if($this->item->quiztype==2)
                        echo JText::_('COM_VQUIZ_PERSONALITY');
					else if($this->item->quiztype==22)
                        echo JText::_('COM_VQUIZ_MULTI_CATEGORY_PERSONALITY_QUIZ');
                    else if($this->item->quiztype==3)
					echo JText::_('COM_VQUIZ_SURVEY'); 
                    else echo JText::_('ELECTION'); 
				 ?> 
			</td>
			</tr>
		</table>
	</div>
	
	<?php if(!empty($this->item->lead_name)){?>
		<div class="pull-left" style="margin-left:20px;width:48%">
			<legend><?php echo JText::_('COM_VQUIZ_LEAD_DETAILS'); ?></legend>
			<table class="adminlist table table-striped table-hover">
			
				<tr><th><?php echo JText::_('COM_VQUIZ_LEAD_NAME'); ?></th>
				<td><?php  echo $this->item->lead_name;?></td></tr>
				
				<tr><th><?php echo JText::_('COM_VQUIZ_LEAD_EMAIL'); ?></th>
				<td><?php  echo $this->item->lead_email;?></td></tr>
				
				<tr><th><?php echo JText::_('COM_VQUIZ_MOBILE'); ?></th>
				<td><?php  echo $this->item->lead_mobile;?></td></tr>

			</table>
		</div>
	<?php }?>
	
</div>
<div style="clear:both">
	<fieldset class="adminform">
		<legend><div style="text-align:center"><?php echo JText::_('COM_VQUIZ_QUIZ_RESULT_DETAILS'); ?></div></legend>
	
		<div align="center" class="personality_quiz"  style="<?php if($this->item->quiztype==1 OR $this->item->quiztype==11 OR $this->item->quiztype==3) echo 'display:none';?>">
			<table class="adminlist table table-striped table-hover">
				<tbody>
				<tr>
				<th width="50%"><?php echo JText::_('COM_VQUIZ_PERSONALITY_ANSWER'); ?></th>
				<td>
				
					<?php 
					if($this->showresult->personality_type==1 and $this->item->quiztype==2){
			
						$multi_w_personality=json_decode($this->item->multi_w_personality);
						$multi_w_persentage=json_decode($this->item->multi_w_persentage);
						$array_p_result=json_decode($multi_w_personality[0]);
						$array_p_color=json_decode($multi_w_personality[1]);
						
						$txt_p='<div class="p_answer_row" style="width:100%;display:inline-block;">';

						for($r=0;$r<count($multi_w_persentage);$r++){
					
							$txt_p  .='<p>';
							

							$txt_p .='<label style="color:'.@$array_p_color[$r].';float:left;width:50%" target="_blank">'.@$array_p_result[$r].'</label>';
							
							$txt_p .='<label class="answer_percentage_span" style="color:'.@$array_p_color[$r].';float:left;width:30%;">'.@$multi_w_persentage[$r].'%</label>';

							$txt_p .='</p>';
						}
						
						$txt_p .='</div>';
						
						echo $txt_p;
						
					}else{
						echo @$this->item->answer;
					}
					?>
					
					</td>
				</tr>
				<tr>
				<th><?php echo JText::_('COM_VQUIZ_MESSAGE'); ?></th>
				<td><?php  echo @$this->item->personality_desc;?></td>
				</tr>
				<tbody>							
			</table>
		</div>

		<div class="trivia_quiz">
			<table class="adminlist table table-striped table-hover">
				<tbody>
				<tr>
				<th><?php echo JText::_( 'COM_VQUIZ_USER_NAME' ); ?></th>
				<td>	
					<?php 					
					if($this->item->userid==0)
						echo JText::_('COM_VQUIZ_GUEST');
					else
						echo $this->item->username; 
					?> 
				</td>
				</tr>
				
				<tr style="<?php if($this->item->quiztype==2 OR $this->item->quiztype==3) echo 'display:none';?>">
				<th><?php echo JText::_( 'COM_VQUIZ_RESULT' ); ?></th>
				<td><?php echo $score ?> / <?php echo $this->item->maxscore ?></td>
				</tr>
				<?php if($this->showresult->answers_type!=2 and $this->item->quiztype==1 and $this->showresult->category_answer!=''){?>
				<tr>
					<th><?php echo JText::_('COM_VQUIZ_RESULTS_CATEGORY_SCORE');?></th>
					<td><?php echo $this->showresult->category_answer;?></td>
				</tr>
				<?php }?>
				
				<?php if($this->showresult->question_group_answer!=''){?>
				<tr>
					<th><?php echo JText::_('COM_VQUIZ_RESULTS_QUESTION_GROUP_SCORE');?></th>
					<td><?php echo $this->showresult->question_group_answer;?></td>
				</tr>
				<?php }?>
				
				<tr style="<?php if($this->item->quiztype==2 OR $this->item->quiztype==22 OR $this->item->quiztype==3) echo 'display:none';?>">
				<th><?php echo JText::_('COM_VQUIZ_PERCENTAGE'); ?></th>
				<td>
				<?php echo $persentagescore;?>%
				</td>
				</tr>
				
				<tr style="<?php if($this->item->quiztype==2 OR $this->item->quiztype==22 OR $this->item->quiztype==3) echo 'display:none';?>">
				<th><?php echo JText::_('COM_VQUIZ_STATUS'); ?></th>
				<td>           
					<?php if($persentagescore>=$passed_score)
						echo '<span style="color:green">'.JText::_('COM_VQUIZ_PASSED').'</span>';	
					else
						echo '<span style="color:red">'.JText::_('COM_VQUIZ_FAILED').'</span>'; ?>
				</td>
				</tr>
				
				<tr>
				<th><?php echo JText::_('COM_VQUIZ_RESULTS_STARTTIME');?></th>
				<td><?php echo $this->item->starttime; ?></td>
				</tr>
				
				<tr>
				<th><?php echo JText::_('COM_VQUIZ_RESULTS_ENDTIME');?></th>
				<td><?php echo $this->item->endtime ; ?></td>
				</tr>
				<tr>
				<th><?php echo JText::_('COM_VQUIZ_RESULTS_SPENT_TIME');?></th>
				<td>
					<?php 
					$stime=strtotime($this->item->endtime) - strtotime($this->item->starttime);
					$h=floor($stime/3600);
					$hr=$stime%3600;
					$m=floor($hr/60);
					$mr=$stime%60;
					$s=floor($mr); 
					$ht=$h>0?$h.'h':'';
					$mt=$m>0?$m.'m':'';
					$st=$s>0?$s.'s':'';
					$spenttime=$ht.'  ' .$mt.'  '.$st;
					echo $spenttime; 

					?>
				</td>
				</tr>
				<tr style="<?php if($this->item->quiztype==2 OR $this->item->quiztype==22 OR $this->item->quiztype==3 ) echo 'display:none';?>">
				<th><?php echo JText::_('COM_VQUIZ_PASSED_PERCENTAGE');?></th>
				<td><?php echo $this->item->passed_score;?>  %</td>
				</tr>
				
				
				<tr>
					<th><?php echo JText::_('COM_VQUIZ_TOTAL_QUESTIONS');?></th>
					<td><?php echo count($this->showresult->question_array);?></td>
				</tr>
				<tr>
					<th><?php echo JText::_('COM_VQUIZ_GIVEN_ANSWERS');?></th>
					<td><?php 
							$givenanswer=$this->showresult->givenanswer;
							$text_answer=$this->showresult->text_answer;
							$textarea_answer=$this->showresult->textarea_answer;
							$given_answer_count = array_values(array_filter($givenanswer, function($item){return $item != 0;}));
							$given_answer_textvalue_count = array_values(array_filter($text_answer, function($item){return $item !='';}));
							$given_answer_textareavalue_count = array_values(array_filter($textarea_answer, function($item){return $item !='';}));
							
							$givenanswers=count($given_answer_count)+count($given_answer_textvalue_count)+count($given_answer_textareavalue_count);
							echo $givenanswers;
							
						?></td>
				</tr>
				<?php if($this->showresult->answers_type==0 and $this->item->quiztype==1){?>
				<tr>
					<th><?php echo JText::_('COM_VQUIZ_CORRECT_ANSWER');?></th>
					<td><?php echo $this->showresult->correct_answers_count;?></td>
				</tr>
				<?php }?>
				
				<tr>
				<th><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_FLAG');?></th>
				<td><?php echo $this->item->flagcount;?></td>
				</tr>
				
				</tbody>
			</table>
		</div>
	</fieldset>


	<div class="all_quiz">
	
	<?php
		if($this->showresult->quiztype==1 and $this->showresult->correctans==3){ ?>
				
	<h1><?php echo $this->showresult->quiztitle?></h1>
	
	<div class="vq_desc"><?php echo $this->showresult->quizdescription?></div>
	
	<?php } ?>
	
		<?php 
		for( $i=0;$i<count($this->showresult->question_array);$i++){
			$given_answer=explode(',',$this->showresult->givenanswer[$i]);
			$user_comment=@$this->showresult->user_comment[$i];
			$user_comment_other=explode(',',$user_comment);

			if($user_comment_other[0]=='other'){
				$user_comment_value=1;
			}else{
				$user_comment_value=0;
			}
		?>

		<div class="result_quiz">
			<div class="result_quiz_data">
			
			<?php
				
				
				if($this->showresult->quiztype==1 and $this->showresult->correctans==3){ ?>  
					
					<div class="vq_col">
					
					<div class="vq_col_inner">
					<?php 		
					$right = 0;
					
					for($k=0;$k<count($this->showresult->options[$i]);$k++){
						
						if($this->showresult->options[$i][$k]->id==$this->showresult->givenanswer[$i]){
							
							$option_chosen = $this->showresult->options[$i][$k]->qoption;
							
							if($this->showresult->options[$i][$k]->correct_ans==1){
								$right = 1;break; 
							}
						}
					}
					
					?>
					<div class="vq_col_img">
					<?php

					if($right == 1){
								echo '<span class="icon-publish"></span>';
					}else{
						echo '<span class="icon-unpublish"></span>';
					}
					?>
					</div>
					
					<div class="vq_col_info">
					
					<div class="vq_col_title"><?php echo $this->showresult->question[$i]->qtitle;?></div>
					
					<div class="vq_col_value"><?php if(isset($option_chosen)){echo $option_chosen;}?></div>
					</div>
					
				</div>
				
				</div>
				<?php
				}				
				else{ ?>
				
				<span class="qbx"><?php echo JText::_('COM_VQUIZ_QUESTION').' - '.($i+1); ?></span>
				<h4><?php echo $this->showresult->question[$i]->qtitle;?> </h4>
				<?php
				}				
				
				?>
				<?php if($this->showresult->question[$i]->score!=0 and $this->showresult->question[$i]->optiontype==5){?>
					<label>
						 <?php echo JText::_('COM_VQUIZ_TEXT_AREA_ANSWER_LABEL');
							echo '<b>'.$this->showresult->textarea_answer[$i].'</b>';
						 ?>
					</label>
					
					<div style="border-top:1px solid #ccc;margin:10px 0;clear:both">
						<div style="float:left;">
							<label><?php echo JText::_('COM_VQUIZ_SCORE')?></label>
							<label>
							<input type="text" name="text_area_score[]" value="<?php echo $this->showresult->textarea_admin_score[$i];?>" style="width:100px;"/>
							</label>
						</div>
						<div style="float:left; margin:0 10px;text-align:center;">
							<label><?php echo JText::_('OUT_OF_SCORE')?></label>
							<label>
							<?php echo $this->showresult->question[$i]->score;?> 
							</label>
						</div>
					</div>
				<?php }elseif($this->showresult->question[$i]->optiontype==4){?>
					<label>
						<?php echo JText::_('COM_VQUIZ_TEXT_FIELD_ANSWER_LABEL');
							echo '<b>'.$this->showresult->text_answer[$i].'</b>';
						?>
					</label>
		
					<input type="hidden" name="text_area_score[]" value="0"/>
				<?php }else{?>
					<input type="hidden" name="text_area_score[]" value="0"/>
				<?php }?>
				
			</div>
			
		<?php if($this->showresult->question[$i]->optiontype!=5 and  $this->showresult->question[$i]->optiontype!=4 and $this->showresult->correctans!=3){?>	
		
		<table border="0" width="100%" cellpadding="5" cellspacing="0">
			<tr>
				<th><?php echo JText::_('COM_VQUIZ_COUNT');?></th>
				<th class="quiz_optns"><?php echo JText::_('COM_VQUIZ_OPTIONS');?></th>
				
				<?php if($this->showresult->correctans==0 OR $this->showresult->correctans==2){  ?>

				<th>
				<?php
				
				echo JText::_('COM_VQUIZ_YOUR_ANSWER');
				
				if($user_comment_value==0){
					
					if(!empty($user_comment)){
						
						echo '<label style="margin:5px opx;padding-left:9px;font-size:12px;display:block">(<b>'.JText::_('COM_VQUIZ_COMMENT').'</b>'.$user_comment.')</label>';
						
					}else{
						
						for($k=0;$k<count($given_answer);$k++){
							
							if($given_answer[$k]==0)
							echo '<label style="padding-left:10px;font-size:9px">('.JText::_('COM_VQUIZ_SKIP_QUESTION').')</label>';
						} 
					}
				}

				?>
				</th>
				<?php }?>
				
				<?php if($this->showresult->correctans==1 OR $this->showresult->correctans==2){  ?>    
					<th>
						<?php
						echo JText::_('COM_VQUIZ_CORRECT_ANSWER');				  
						?>
					</th>

				<?php }?>
			</tr>
			
			<?php  
			
			for( $j=0;$j<count($this->showresult->options[$i]);$j++){ 
			
			if($this->showresult->correctans==0){
				
				if(!array_search($this->showresult->givenanswer[$i], (array)$this->showresult->options[$i][$j])){
					continue;
				}
			}
			if($this->showresult->correctans==1){
				
				if($this->showresult->options[$i][$j]->correct_ans!=1){
					continue;
				}
			}
			
			
				
			?>

			
				<tr>
					<td><p><?php echo $j+1;?></p></td>
					<td class="quiz_optns">
						<p>
							<?php if(!empty($this->showresult->options[$i][$j]->imag) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->showresult->options[$i][$j]->imag)){ ?>
							
								<label style="max-width:20%;display:inline-block"><img src="<?php echo JURI::root().'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->showresult->options[$i][$j]->image;?>" alt="" /></label>
								
							<?php }?>
							
							<label style="vertical-align:center;display:inline-block"><?php echo $this->showresult->options[$i][$j]->qoption;?></label>
						</p>
					</td>
					<?php if($this->showresult->correctans==0 OR $this->showresult->correctans==2){  ?>
					<td>
					<p style="text-align:center;">
					<?php
					
					for($k=0;$k<count($given_answer);$k++){
						if($given_answer[$k]==$this->showresult->options[$i][$j]->id ){
								
							if($this->showresult->options[$i][$j]->correct_ans==1){
								echo '<span class="icon-publish"></span>';
							}else{
									echo '<span class="icon-unpublish"></span>';
							}
						}
					}
					/* if($this->showresult->quiztype==11 and $this->showresult->answers_type==1)
					{

						for($k=0;$k<count($given_answer);$k++){
							if ($given_answer[$k]==$this->showresult->options[$i][$j]->id and ($this->showresult->options[$i][$j]->correct_ans!=1) ){
								echo '<span class="icon-delete"></span>';
							}
							else if($given_answer[$k]==$this->showresult->options[$i][$j]->id and ($this->showresult->options[$i][$j]->correct_ans==1)){
								echo '<span class="icon-publish"></span>';
							}
						}

					}

					else//if($this->showresult->quiztype==2)
					{  
						for($k=0;$k<count($given_answer);$k++){
							if($this->showresult->options[$i][$j]->id==$given_answer[$k])
							echo '<span class="icon-publish"></span>';
						}

					} */
					?>

					</p>
					</td>
					<?php }?>
					
					<?php if($this->showresult->correctans==1 OR $this->showresult->correctans==2){  ?>
						<td>
						<p style="text-align:center;">
						<?php   
						if($this->showresult->options[$i][$j]->correct_ans==1){
						echo '<span class="icon-publish"></span>';
						$check_redudency=true;
						}?>

						</p>
						</td>
					<?php }?> 
				</tr> 
			<?php }?>

			<?php if($user_comment_value==1){?>
				<tr><td><p><?php echo $j+1;?></p></td><td><p><?php echo JText::_('COM_VQUIZ_OTHER_OPTION')?></p></td><td><p><?php if(!empty($user_comment_other[1])) echo $user_comment_other[1];?></p></td></tr>
			<?php }?>

		</table>    
		<?php }?>
		
		</div>    
		<?php }?>
	</div>

</div>
</div>
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="quizresult" />
<input type="hidden" name="id" value="<?php echo $this->item->id;?>" />
</form>
