<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );
class VquizViewQuizresult extends JViewLegacy
{ 
 
		function display($tpl = null)
 		{
			  $user = JFactory::getUser();
			  
			  if(!$user->authorise('core.userviews','com_vquiz')){
				jerror::raiseWarning('403', JText::_('UNAUTH_ACCESS'));
				return false;	 
			  }  
	          $mainframe =JFactory::getApplication();
		      $context	= 'com_vquiz.result.list.';
			  $layout = JRequest::getCmd('layout', '');
			  $search = $mainframe->getUserStateFromRequest( $context.'search', 'search', '',	'string' );
		      $search = JString::strtolower( $search );
			  $startdatesearch = $mainframe->getUserStateFromRequest( $context.'startdatesearch', 'startdatesearch', '',	'string' );
			  $enddatesearch = $mainframe->getUserStateFromRequest( $context.'enddatesearch', 'enddatesearch', '',	'string' );
			  $quiz_id= $mainframe->getUserStateFromRequest( $context.'quiz_id', 'quiz_id',	'quizid',	'string' );
			  
			  $filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
       		  $filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
				$this->config = $this->get('Config');	
				if($layout == 'form')
				{
 					$item =$this->get('Item');
					$this->assignRef( 'item', $item );
					$this->showresult=$this->get('Showresult');
					//$this->userLead=$this->get('UserLead');
					JToolBarHelper::title( JText::_('COM_VQUIZ_QUIZ_RESULT_DETAILS'), 'vcard.png' );	

					JToolBarHelper::cancel();
					
					
					$check_textarea=false;
					for( $i=0;$i<count($this->showresult->question);$i++){
						if($this->showresult->question[$i]->score!=0 and $this->showresult->question[$i]->optiontype==5){
							$check_textarea=true;
						}
					}
						
					if($user->authorise('core.edit','com_vquiz') and $check_textarea==true){
						JToolBarHelper::custom('save_textarea_answer', 'move', 'move', JText::_('COM_VQUIZ_QUIZ_RESULT_SAVE_TEXTFIELD_ANSWER'), false );
					}
					
					JToolBarHelper::help('help', true);

			}else{

				JToolBarHelper::title( JText::_('COM_VQUIZ_RESULT'), 'vcard.png' );
				$link=JURI::root().'administrator/index.php?option=com_vquiz&view=quizdraft';
				$bar = JToolBar::getInstance('toolbar');
				$bar->appendButton( 'Link', 'exit', 'DRAFT QUIZZES', $link);
				
					if(JFactory::getUser()->authorise('core.delete','com_vquiz')){
					JToolBarHelper::deleteList(JText::_('DO_YOU_WANT_DELETE_RECORD'));	
				}
				
					JToolBarHelper::custom('sendTemplate', 'out-2', 'send over', JText::_( 'COM_VQUIZ_RESULTS_SEND_CERTIFICATE'), false );
					
				if($user->authorise('core.export','com_vquiz')){
				  JToolBarHelper::custom( 'export', 'upload', 'download', JText::_( 'CSV_EXPORT_TITLE'), false );
				}
			
			JToolBarHelper::custom( 'Leadexport', 'upload', 'download', JText::_( 'LEAD_GENERATE_EXPORT'), false );	
			
  	            JToolBarHelper::help('help', true);
				if(JFactory::getUser()->authorise('core.admin','com_vquiz')){
					JToolBarHelper::preferences('com_vquiz','', '','ACL');
				}

				
				// Side bar 
				$version = new JVersion;
				$joomla = $version->getShortVersion();
				$jversion = substr($joomla,0,3);
				$this->sidebar ='';
				if($jversion>=3.0)
				{
				$this->sidebar = JHtmlSidebar::render();
				}
 				$items = $this->get('Items');
 				$this->assignRef( 'items', $items );
 				$this->pagination = $this->get('Pagination');
				$this->allQuizinresult = $this->get('AllQuizinresult');
 				$lists['search']= $search;
				$lists['startdatesearch']= $startdatesearch;
				$lists['enddatesearch']= $enddatesearch;
				$this->assignRef( 'lists', $lists );
				
				// Table ordering.
				$this->lists['order_Dir'] = $filter_order_Dir;
				$this->lists['order']     = $filter_order;
				$this->lists['quiz_id']     = $quiz_id;

  			   }
			 parent::display($tpl);
		 }
 
}

 