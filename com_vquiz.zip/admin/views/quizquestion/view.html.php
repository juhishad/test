<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
 
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );

class VquizViewQuizquestion extends JViewLegacy
{ 
	function display($tpl = null)
		{
			
		$user = JFactory::getUser();
		$mainframe =JFactory::getApplication();
		$context	= 'com_vquiz.question.list.';
		$layout = JRequest::getCmd('layout', '');
		$search = $mainframe->getUserStateFromRequest( $context.'search', 'search', '',	'string' );
		$search = JString::strtolower( $search );
		$quizid= $mainframe->getUserStateFromRequest( $context.'quizid', 'quizid',	'',	'string' );
		$publish_item= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );

		$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
		$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
			  
		$this->config = $this->get('Configuration');

		if(count($errors=$this->get('Errors'))){
		
			JError::raiseError(500,implode('<br />',$errors));
			return false;
		}
		
		
				if($layout == 'form')
 				{
					$item =$this->get('Item');
					$this->skills =$this->get('Skills');
					
					$isNew		= ($item->id < 1);
					$this->assignRef( 'item', $item );
					$this->optinscoretype = $this->get('Optinscoretype');
 					$this->options = $this->get('Options');
 					$this->quizes   = $this->get('Quizes');
					$this->personality_answers = $this->get('Personality_answers');
					$this->score_category  = $this->get('Score_category');
					$this->personality_category  = $this->get('personality_category');
					$this->questiongroup  = $this->get('Questiongroup');
 
					if($isNew)
						JToolBarHelper::title( JText::_( 'COM_VQUIZ_QUESTIONS_NEWQUESTION' ), 'question.png' );
 					else
						JToolBarHelper::title( JText::_( 'COM_VQUIZ_QUESTIONS_EDITQUESTION' ), 'question.png' );

					if($isNew)
					{
						if($isNew && JFactory::getUser()->authorise('core.create','com_vquiz'))
						{
							JToolBarHelper::apply();
							JToolBarHelper::save();	
							JToolbarHelper::save2new('save2new');
							
						}
						
					
					}
					else
					{
						if($user->authorise('core.edit','com_vquiz') OR ($user->authorise('core.edit.own','com_vquiz') and $this->item->created_by == $user->get('id')))
						{
							JToolBarHelper::apply();
							JToolBarHelper::save();		
						}
						if ( JFactory::getUser()->authorise('core.create','com_vquiz'))
						{
							JToolbarHelper::save2new('save2new');
							JToolbarHelper::save2copy('save2copy');
						}
					}
					
					
					JToolBarHelper::cancel('cancel','Close');
					JToolBarHelper::help('help', true);
 
			}else{
				JToolBarHelper::title( JText::_('COM_VQUIZ_QUESTIONS'), 'question.png' );
				if($user->authorise('core.create','com_vquiz')){
					JToolBarHelper::addNew();
				}
				
				if(JFactory::getUser()->authorise('core.edit','com_vquiz')){
					JToolBarHelper::editList();
				}
				if(JFactory::getUser()->authorise('core.edit.state','com_vquiz')){
					JToolBarHelper::publish();
					JToolBarHelper::unpublish();
				}
				if(JFactory::getUser()->authorise('core.delete','com_vquiz')){
					JToolBarHelper::deleteList(JText::_('DO_YOU_WANT_DELETE_RECORD'));	
				}
				
					JToolBarHelper::custom( 'copy', 'copy', 'copy', JText::_('COM_VQUIZ_COPY'), false );
					JToolBarHelper::custom( 'move', 'move', 'move', JText::_('COM_VQUIZ_MOVE'), false );
				
 				if(JFactory::getUser()->authorise('core.import','com_vquiz')){
					JToolBarHelper::custom( 'import', 'download', 'upload', JText::_('COM_VQUIZ_CSV_IMPORT'), false );
				}
				if(JFactory::getUser()->authorise('core.export','com_vquiz')){
									
					JToolBarHelper::custom( 'export', 'upload', 'download', JText::_( 'COM_VQUIZ_CSV_EXPORT'), false );
				}

 
				
				
				JToolBarHelper::help('help', true);
				$version = new JVersion;
					$joomla = $version->getShortVersion();
					$jversion = substr($joomla,0,3);
					$this->sidebar ='';
					if($jversion>=3.0)
					{
					$this->sidebar = JHtmlSidebar::render();
					}
				if(JFactory::getUser()->authorise('core.admin','com_vquiz')){
					JToolBarHelper::preferences('com_vquiz','', '','ACL');
				}
				
				$items = $this->get('Items');
				$this->assignRef( 'items', $items );
				$this->quizes   = $this->get('Quizes');
				$this->quiz   = $this->get('Quiz');
				//print_r($this->quizes);exit;
				$this->pagination = $this->get('Pagination');
				
				if(JRequest::getVar('msg_pc','0')!='0'){
					$msg=JText::_('COM_VQUIZ_QUESTIONS_NO_USED_ALLCATEGORY').implode(',',json_decode(JRequest::getVar('msg_pc','0')));
					JError::raiseWarning(100,$msg);
				}
				
				$lists['search']= $search;
				$lists['publish_item']= $publish_item;
				$lists['quizid']= $quizid;
				$this->assignRef( 'lists', $lists );

				// Table ordering.
				$this->lists['order_Dir'] = $filter_order_Dir;
				$this->lists['order']     = $filter_order;
			
			   }
 		 parent::display($tpl);

		 }
}
 