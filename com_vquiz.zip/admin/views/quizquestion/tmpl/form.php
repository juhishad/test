<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 www.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
$document = JFactory::getDocument();

$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$editor = JFactory::getEditor();

JHtml::_('behavior.tooltip');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');
//echo "<pre>"; print_r($this->optinscoretype);//exit;
//print_r($this->options);
//echo "<pre>";print_r($this->score_category);// exit;
?>


<script type="text/javascript">
		var jq=jQuery.noConflict();
		
		 /* function bindButton() { 
		  document.getElementById('upload_hotspot').addEventListener('click', function (event) {
			  alert(1);
			event.preventDefault();
			return false;
		  })
		}
		window.onload = function() {
		bindButton();
		}  */

		jq(document).ready(function(){
		
			jq( "#flagreset" ).click(function() {
				jq('input[name="flagcount"]').val(0);
				jq('input[name="flagcount_show"]').val(0);
			});

			var single=true;
			var multiple=false;
			var drag = false;

			var optiontype=jq('#optiontype').val();
			
			//variable for hotspot optiontype start
			var canvas;
			var ctx;
			//variable for hotspot optiontype end
			 
			jq('#addinput2').css('display','none');
			   
			if(optiontype==2){
				multiple=true;	
			}else if(optiontype==8){
				drag=true;
			}else{
				single=true;
			} 
			if(optiontype==1 || optiontype==2 || optiontype==3){
				jq('#addinput2').css('display','none');
			}
			
			if(optiontype==4){
				jq('.textfield_check_tr').css('display','');
				jq('#addinput').css('display','none');
				jq('#addinput2').css('display','none');
				  
				jq('#comment_box_row').css('display','none');
			}
			if(optiontype==9){
				jq('.hotspot_check_tr').css('display','');
				jq('.textfield_check_tr').css('display','none');
				jq('#addinput').css('display','none');
				jq('#comment_box_row').css('display','none');
				jq('#ajax_tr').replaceWith('<tr class="hotspot_check_tr" id="ajax_tr"><td class="key"></td><td><label><?php echo JText::_("COM_VQUIZ_HOTSPOTIMG_DESC")?></label><canvas id="canvas" width="700" height="400" style="border: 1px solid #ece8e8;"></canvas></td></tr>');
				canvas =  document.getElementById('canvas');
				ctx = canvas.getContext('2d');
				img = new Image;
				ctx.lineWidth = 3;
				ctx.strokeStyle = '#c00';
				ctx.lineCap = 'round';
				var hot_img = jq('#hotspot_img').val();
				img.onload = start;
				img.src = '<?php echo JURI::root()."/media/com_vquiz/vquiz/images/options/" ?>'+hot_img;
			}else{
				jq('.textfield_check_tr').css('display','none');
				jq('.hotspot_check_tr').css('display','none');
				if(optiontype==5){
					jq('#addinput').css('display','none');
					jq('#addinput2').css('display','none');
					 
					jq('#comment_box_row').css('display','none');
				}else{
					jq('#addinput').css('display','');
					jq('#comment_box_row').css('display','');
				}
			}
			if(optiontype==6 || optiontype==7){
					jq('#addinput').css('display','none');
					jq('#addinput2').css('display','');
					 
					jq('#comment_box_row').css('display','none');
				}
			 
			
			
			jq("#optiontype").on('change', function() { 
						if(jq(this).val()==1 || jq(this).val()==2 || jq(this).val()==3){
							jq('#addinput2').css('display','none');
							  
						}
					if(jq(this).val()==4){
						jq('.textfield_check_tr').css('display','');
						jq('.hotspot_check_tr').css('display','none');
						jq('#addinput').css('display','none');
						jq('#comment_box_row').css('display','none');
						jq('#user_comment').val(0);
					}else if(jq(this).val()==9){
						jq('.hotspot_check_tr').css('display','');
						jq('.textfield_check_tr').css('display','none');
						jq('#addinput').css('display','none');
						jq('#addinput2').css('display','none');
						 
						jq('#comment_box_row').css('display','none');
						jq('#user_comment').val(0);
					}else{ 
						jq('.textfield_check_tr').css('display','none');
						jq('.hotspot_check_tr').css('display','none');
						if(jq(this).val()==5){
							jq('#addinput').css('display','none');
							jq('#addinput2').css('display','none');
							  
							jq('#comment_box_row').css('display','none');
							jq('#user_comment').val(0);
						}else{
							jq('#addinput').css('display','');
							jq('#comment_box_row').css('display','');
						}
					}
					if(jq(this).val()!=8){
						drag=false;
						jq(".colA").replaceWith('<input type="file" name="image[]" id="option_images" class="option_images"/>');
						jq(".colAtextarea").replaceWith('');
						jq(".colB").replaceWith('<textarea style="width:96%; padding:1%; margin:1%;" type="text" id="qoption"  name="qoption[]" cols="40" rows="5" class="qoption"></textarea>');
						jq(".colBtextarea").replaceWith('');
						jq(".colBimg").replaceWith('');
					}
					if(jq(this).val()==2){	 
						multiple=true;
						single=false;
						drag=false; 
						jq(".options_answer").replaceWith('<input type="checkbox" name="correct_ans[]"  value="'+i+'" class="options_answer" />');
						jq('.options_answer').each(function(index, value){
						jq(this).attr('value',index);
						}); 
					}else if(jq(this).val()==8){
						single=true;
						multiple=false;
						drag=true;
						jq(".options_answer").replaceWith('<input type="number" name="correct_ans[]" class="options_answer" />');
						jq(".option_images").replaceWith('<input type="file" name="image[]" id="option_images" class="colA" /><textarea style="width:45%; padding:1%; margin:1%;" type="text" id="qoption"  name="qoption[]" cols="40" rows="5" class="colAtextarea"></textarea>');
						jq(".qoption").replaceWith('<input type="file" name="imageB[]" id="option_imagesB" class="colB" /><textarea style="width:45%; padding:1%; margin:1%;" type="text" id="qoptionB"  name="qoptionB[]" cols="40" rows="5" class="colBtextarea"></textarea>');

 
					}else{ 
						single=true;
						multiple=false;
						drag=false;
						
						jq(".options_answer").replaceWith('<input type="radio" name="correct_ans"  value="'+i+'" class="options_answer" />');
						jq('.options_answer').each(function(index, value){
							jq(this).attr('value',index); 
						});
					}
					if(jq(this).val()==6 || jq(this).val()==7){
							
							jq("#addinput2 .options_answer").replaceWith('<input type="radio" name="correct_ans2"  value="'+i+'" class="options_answer" />');
							
							jq('#addinput2 .options_answer').each(function(index, value){ 
								jq(this).attr('value',index); //alert(i);  
							});
						
							jq('#addinput').css('display','none');
							jq('#addinput2').css('display','');
							 
							jq('#comment_box_row').css('display','none');
						
						}
			  
			});			

			var singleoption_score=false;
			var deiifrentoption_score=false;
			var multi_text_option=false; 
			var category_score=false; 
			var dropdownvalue='<?php echo $this->optinscoretype->quiztype;?>';
			var answers_type='<?php echo $this->optinscoretype->answers_type;?>';
			var personality_type='<?php echo $this->optinscoretype->personality_type;?>';

			if(dropdownvalue==1){
				singleoption_score=true;
				jq('.penalitytype_tr').show();
				jq('.scoretype_tr').show();
				jq('.questiontyp_tr').show();
			}
			if(dropdownvalue==11){
			
				if(answers_type==1){ 
						multi_text_option=true;
						jq('.penalitytype_tr').hide();
						
				}else if(answers_type==2){ 
						category_score=true;
						jq('.penalitytype_tr').hide();
				}
				jq('.scoretype_tr').show();
				jq('.questiontyp_tr').show();
				
			}
			else if(dropdownvalue==2 || dropdownvalue==22){
			
				deiifrentoption_score=true;	
				jq('.scoretype_tr').hide();
				jq('.penalitytype_tr').hide();				
			}
			else if(dropdownvalue==3){
			
				singleoption_score=true;
				jq('.scoretype_tr').hide();
				jq('.penalitytype_tr').hide();
				
			}
 
 
			var addDiv = jq('#addinput');
			var i =<?php echo (int)count($this->options); ?>;
			var Maxoption=<?php echo !empty($this->personality_category->count_column)?(int)$this->personality_category->count_column:10 ?>;
						
			jq('#addNew').on('click', function() {

			    if(dropdownvalue==22 && personality_type==2){
					if(i>=Maxoption){
						alert('<?php echo JText::_('COM_VQUIZ_NO_MORE_ADD_OPTION');?>');
						return false;
					}
				}
				
				if(deiifrentoption_score==true){
					
				  var html = '<div class="personality_weight"><input type="text" name="multi_p_options_score[]"  value="'+i+'" style="width:80px;" /></div>';
					
			      html +='<select name="personality_optionid[]"  class="personality_optionid"><option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_ANSWERS');?></option>';
					<?php for($a=0;$a<count($this->personality_answers);$a++){?>
					html +='<option value="<?php echo $this->personality_answers[$a]->id?>"><?php echo htmlspecialchars($this->personality_answers[$a]->answer,ENT_QUOTES)?></option>';
					<?php }?>
			       html +='</select>';
				   
				}else if(singleoption_score==true){ 

					if(multiple==true)
					{
						var html = '<input type="checkbox" name="correct_ans[]"  value="'+i+'" class="options_answer" />';
					}
					else if(single==true)
					{
						var html = '<input type="radio" name="correct_ans"  value="'+i+'" class="options_answer"  />';
					}else{
						var html = '';
					}

				}else if(multi_text_option==true){ 
				
						var html = '<input type="text" name="options_score[]"  value="'+i+'" class="options_answers" style="width:50px" />';
						
				}else if(category_score==true){ 
				
						var score_category_count=jq('#score_category_count').val();
						var html='<table><tr>';
						for(var d=0;d<score_category_count;d++){
							html += '<td><input type="text" name="category_score'+d+'[]"  value=""  style="width:80px" />';
						}
						html +='</tr></table>';
					
				}else 
					var html ='';
				
				var add_to='<tr><td></td><td class="upimg"><input type="file" name="image[]" id="option_images" class="option_images"/></td><td valign="middle" align="center"><textarea style="width:96%; padding:1%; margin:1%;" type="text" id="qoption"  name="qoption[]" value="" cols="40" rows="5" class="qoption"></textarea></td>';
				
				if(dropdownvalue!=3){
					add_to +='<td valign="middle" align="center"><label class="sradio">'+html+'</label></td>';
				}
				
				
				add_to +='<td class="center" width="100"><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span><input type="hidden" name="oorder[]" value="'+i+'" /></td>';
				
				if(drag){
					add_to = '<tr><td></td><td class="upimg"><input type="file" name="image[]" id="option_images" class="colA" /><textarea style="width:45%; padding:1%; margin:1%;" type="text" id="qoption"  name="qoption[]" cols="40" rows="5" class="colAtextarea"></textarea></td><td class="upimg"><input type="file" name="imageB[]" id="option_imagesB" class="colB" /><textarea style="width:45%; padding:1%; margin:1%;" type="text" id="qoptionB"  name="qoptionB[]" cols="40" rows="5" class="colBtextarea"></textarea></td><td valign="middle" align="center"><label class="sradio"><input type="number" name="correct_ans[]" class="options_answer"></label></td>';
				}
				
				add_to +='<td valign="middle" align="center"><a href="javascript:void(0);" class="remNew btn btn-danger">-</a></td></tr>';
	
				jq(add_to).appendTo(addDiv);

				i++;

				return false;

			});
 
			jq('.remNew').on('click', function() {
				jq(this).parent().parent().remove();
				jq('#addinput>p').each(function(i){
					jq(this).find('input:radio').val(i);
				});
				i--;
				return false;
				

			});
			
			jq(document).on('click',".icon-uparrow,.icon-downarrow",function () { 
				
				var $element = this;
				
				var row = jq($element).parents("tr:first");
				if(jq(this).is('.icon-uparrow') && row.prevAll().length > 1){
							
					var x=row.insertBefore(row.prev());
					var lenghth_tr=jq.parseJSON(JSON.stringify(x.prev())).length;
						
				}else if(jq(this).is('.icon-downarrow')){
					row.insertAfter(row.next());
				}
				else{
					return false;
				}
				
				jq('#addinput .options_answer').each(function(index, value){ 
					jq(this).attr('value',index);   
				});
				
				jq('#addinput2 .options_answer').each(function(index, value){ 
					jq(this).attr('value',index); 
				});

			});

				var checktotaltime='<?php echo $this->optinscoretype->total_timelimit;?>'

				if(checktotaltime>0){
					 jq('.question_timetr').show();
					 jq('.expiredpenality_tr').show();
				}
				else{
					 jq('.question_timetr').hide();
					 jq('.expiredpenality_tr').hide();

				}
				
				/* jq('select[name="personality_optionid[]"]:not(.first_select)').on('click',function(){alert(2);
  					var first_selected_value=jq('select[name="personality_optionid[]"].first_select').find('option:selected').val();

					if(first_selected_value==0){
						alert('<?php echo JText::_('COM_VQUIZ_FIRST_DROPDOWN_SELECT')?>');
						jq(this).find('option[value="0"]').attr('selected', 'selected');
						return false;
					}
					
					jq('select[name="personality_optionid[]"].rest_select').each(function(){
						jq(this).find('option').attr('disabled', 'disabled');
					});


 
					jq('select[name="personality_optionid[]"]').each(function(){
					
						jq(this).find('option[value=' + value +']').closest('optgroup').each(function(index) {

							jq(this).children("option").each(function(){
								 if(jq(this).is(':disabled')){            
									jq(this).removeAttr('disabled');
								 }
							});
							
						jq(this).find('option[value=' + value +']').attr('disabled', 'disabled');

						});
					});
					 	jq('select').trigger('chosen:updated');
						jq('select').trigger("liszt:updated");

				});  */
				
				
				jq('select[name="personality_optionid[]"]').on('change',function(){
				
						var first_selected_value=jq('select[name="personality_optionid[]"].first_select').find('option:selected').val();
						
						if(first_selected_value==0){

							alert('<?php echo JText::_('COM_VQUIZ_FIRST_DROPDOWN_SELECT')?>');
							jq(this).find('option[value="0"]').attr('selected', 'selected');
							jq('select').trigger("liszt:updated");
							
							return false;
						}
						
						jq('select[name="personality_optionid[]"].rest_select').each(function(){
							jq(this).find('option').attr('disabled', 'disabled');
						});
						
						jq('select[name="personality_optionid[]"].first_select').each(function(){
							jq(this).find('option').removeAttr('disabled');
						});
						
						var value = jq(this).find('option:selected').val();
						
						jq('select[name="personality_optionid[]"]').each(function(){
						
							jq(this).find('option[value=' + value +']').closest('optgroup').each(function(index){
							
								jq(this).children("option").each(function(){
									 if(jq(this).is(':disabled')){            
										jq(this).removeAttr('disabled');
									 }
								});
							//jq(this).find('option[value=' + value +']').attr('disabled', 'disabled');
								
							});
							
						});
						
						if(jq(this).hasClass("first_select")){ 
							jq('select[name="personality_optionid[]"].rest_select').each(function(){
								jq('select[name="personality_optionid[]"].rest_select').find('option[value="0"]').attr('selected', 'selected');
							}); 
						} 
						jq('select').trigger("liszt:updated");
						
				}); 

			});  

		//for hotspot option type start				
				  jq(document).on('click','#upload_hotspot',function(e){
					
					event.preventDefault(); 					
					var file_data = jq('#hotspot_images')[0].files[0];
					var formData = new FormData();
					formData.append('hotspot_images',file_data);
					jq.ajax({
						url: "<?php echo JRoute::_(JURI::base().'index.php?option=com_vquiz&view=quizquestion&task=uploadHotspot')?>",
						type: "POST",
						data: formData,
						contentType: false,
						cache: false,
						processData:false,
						dataType: 'json',
						success: function(data){
							jq('#hotspot_img').val(data.img);
							jq('#ajax_tr').replaceWith(data.html);
							canvas =  document.getElementById('canvas');
							ctx = canvas.getContext('2d');
							img = new Image;
							ctx.lineWidth = 3;
							ctx.strokeStyle = '#c00';
							ctx.lineCap = 'round';

							img.onload = start;
							img.src = '<?php echo JURI::root()."/media/com_vquiz/vquiz/images/options/" ?>'+data.img;
						},
						error: function(){
						}
					});
				});
				
				function start() {
		
					var points = [],
						isDown = false,
						last;
					
					canvas.onmousedown = function(e) {
						ctx.clearRect(0, 0, 700, 400);
						var pos = getXY(e);
						last = pos;

						points = [];
						isDown = true;
						points.push(pos);

						bg();
					};

					canvas.onmousemove = function(e) {
					
						if (!isDown) return;
						
						var pos = getXY(e);
						points.push(pos);
						
						ctx.beginPath();
						ctx.moveTo(last.x, last.y);
						ctx.lineTo(pos.x, pos.y);
						ctx.stroke();
						
						last = pos;
					};

					canvas.onmouseup = function(e) {
						if (!isDown) return;
						
						isDown = false;
						
						minMax();
					};
					
					bg();

					function bg() { 
						canvas =  document.getElementById('canvas');
			ctx = canvas.getContext('2d');
						ctx.drawImage(img, 0, 0);
						
					}
					
					function minMax() {
						var minX = 1000000,
							minY = 1000000,
							maxX = -1000000,
							maxY = -1000000,
							i = 0, p,
							lw = ctx.lineWidth;
						
						for(; p = points[i++];) {
							if (p.x > maxX) maxX = p.x;
							if (p.y > maxY) maxY = p.y;
							if (p.x < minX) minX = p.x;
							if (p.y < minY) minY = p.y;
						}
						ctx.lineWidth = 3;
						ctx.strokeRect(minX, minY, maxX - minX, maxY - minY);
						jq("#rectangle").val(minX+","+minY+":"+maxX+","+maxY);
						ctx.lineWidth = lw;
					}
				}

				function getXY(e) {
					var rect = canvas.getBoundingClientRect();
					return {x: e.clientX - rect.left, y: e.clientY - rect.top}
				}
				//for hotspot option type end
			 
			
		Joomla.submitbutton = function(task) {
			if (task == 'cancel') {
				Joomla.submitform(task, document.getElementById('adminForm'));
			}else{
					 jq('select[name="personality_optionid[]"]').each(function(){
						jQuery(this).find('option:selected').prop('disabled', false);
					 });
				} 	
				Joomla.submitform(task, document.getElementById('adminForm'));
		} 
 
</script>

<script>
	//var jq=jQuery.noConflict();
	jq(window).load(function(){
		var rectangle=jq('#rectangle').val();
		if(jq('#optiontype').val()){
			canvas =  document.getElementById('canvas');
			if(canvas){
				ctx = canvas.getContext('2d');
				rectangle = rectangle.split(":");
				var p1 = rectangle[0].split(",");
				var p2 = rectangle[1].split(",");
				ctx.strokeRect(p1[0],p1[1],(p2[0]-p1[0]),(p2[1]-p1[1]));
			}
		}
	});
</script>

<style>	
.personality_weight{
	float:left;
	margin:0 10px;
}
</style>
		
<form class="vquiz_form" action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col101 qform">
	<fieldset class="adminform">
	<legend><?php echo JText::_('COM_VQUIZ_QUESTIONS_DETAILS'); ?></legend>
		<table class="adminform table table-striped">
			<tr>
				<td width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTIONS_FLAG_GIVEN_BY_USER_TOOLTIP'); ?>" ><?php echo JText::_('COM_VQUIZ_FLAGS'); ?></label></td>
				<td><input type="text" name="flagcount_show"  id="flagcount_show" value="<?php echo $this->item->flagcount;?>" disabled="disabled"/>
				<input type="hidden" name="flagcount"  id="flagcount" value="<?php echo $this->item->flagcount;?>"/>
				<input type="button" class="btn" id="flagreset" value="<?php echo JText::_('COM_VQUIZ_RESET'); ?>"/>
				</td>
			</tr>            

			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTIONS_QUIZCATEGORYTOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZ'); ?></label></td>
				<td><input type="hidden" name="quizid" id="quizid" value="<?php echo $this->optinscoretype->id;?>" />
				<label><?php echo $this->optinscoretype->title;?></label>
				</td>
			</tr>
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTIONS_QUIZ_TYPES_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTIONS_QUIZ_TYPES'); ?></label></td>
				<td><input type="hidden" name="quiztype" id="quiztype" value="<?php echo $this->optinscoretype->quiztype;?>" />
				<label><?php if($this->optinscoretype->quiztype==1){
								echo JText::_('COM_VQUIZ_TRIVIA');
							}elseif($this->optinscoretype->quiztype==11){
								echo JText::_('COM_VQUIZ_SIMULATION_QUIZ');
							}
							elseif($this->optinscoretype->quiztype==2){
								echo JText::_('COM_VQUIZ_PERSONALITY');
							}elseif($this->optinscoretype->quiztype==22){
								echo JText::_('COM_VQUIZ_MULTI_CATEGORY_PERSONALITY_QUIZ');
							}
							else{
								echo JText::_('COM_VQUIZ_SURVEY');
							}
					?></label>
				</td>
			</tr>


			<tr>
				<td class="key"><label class="hasTip" ><?php echo JText::_('COM_VQUIZ_STATUS'); ?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="published1" id="published1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?></label>
					<input type="radio" name="published" id="published1" value="1" <?php if($this->item->published ==1) echo 'checked="checked"';?>/>
					<label for="published0" id="published0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?></label>
					<input type="radio" name="published" id="published0" value="0" <?php if($this->item->published ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ORDETING_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_ORDERING'); ?></label></td>
				<td>
				<input type="number" name="ordering" id="ordering" value="<?php echo $this->item->ordering;?>" />
				</td>
			</tr>

			<!--Hide Total Time Quiz When Quiz Later Enable in Configuration OR Total Time 0-->
			<?php if($this->optinscoretype->total_timelimit>0 and $this->config->later_play==0){?>
			
			<tr class="question_timetr"> 
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_TIMELIMIT_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_TIMELIMIT'); ?></label>
				</td>
				<td class="question_timetd">                    
				<input type="text" name="question_timelimit"  id="question_timelimit" value="<?php echo $this->item->question_timelimit;?>" />
				<select  name="questiontime_parameter" id="questiontime_parameter" >
				<option value="seconds" <?php if($this->item->questiontime_parameter=='seconds') echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_SECONDS'); ?> </option>
				<option value="minutes" <?php if($this->item->questiontime_parameter=='minutes') echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_MINUTES'); ?> </option>
				</select>
				</td>
			</tr>
			
			<?php }?>
		
			<tr class="scoretype_tr">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_SCORE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_SCORE'); ?></label></td>
				<td>
				<input type="text" name="score" id="score" value="<?php echo $this->item->score?>" />
				</td>
			</tr>

			<tr class="penalitytype_tr">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_PENALTY_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_PENALTY'); ?></label></td>
				<td>
				<input type="text" name="penalty" id="penality" value="<?php echo $this->item->penalty?>" />
				</td>
			</tr>
	
			<?php if($this->optinscoretype->quiztype==1 or $this->optinscoretype->quiztype==11){ ?>
				<tr>
					<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_SKILLS_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_SKILLS'); ?></label></td>
					<td>
						<select name="skillid[]" id="skillid" class="inputbox" multiple>

						<option value="0"><?php echo JText::_('COM_VQUIZ_SKILLS_SKILL'); ?></option>
							<?php    
							$selectedid=$this->skills->selectedid;
							for ($i=0; $i <count($this->skills->skillid); $i++){	?>
							<option value="<?php echo $this->skills->skillid[$i]->id;?>" <?php  if(in_array($this->skills->skillid[$i]->id,$selectedid)) echo 'selected="selected"'; ?>>
								<?php echo $this->skills->skillid[$i]->title; ?>
							</option>		
							<?php	}?>
						</select>
					</td>
				</tr>
			<?php } ?>
		
			<tr class="questiontyp_tr">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_TYPE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_ANSWERS_TYPE'); ?></label></td>
				<td>
				<select  name="optiontype" id="optiontype" >
					<option value="1" <?php  if($this->item->optiontype==1) echo 'selected="selected"'; ?> class="radio_option"><?php echo JText::_('COM_VQUIZ_RADIO_BUTTON'); ?> </option>
					<option value="2" <?php  if($this->item->optiontype==2) echo 'selected="selected"'; ?> class="checkbox_option"><?php echo JText::_('COM_VQUIZ_RADIO_CHECKBOX'); ?> </option>
					<option value="3" <?php  if($this->item->optiontype==3) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_RADIO_DROPDOWN'); ?> </option>
					<option value="4" <?php  if($this->item->optiontype==4) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_TEXT_FIELD'); ?> </option>
					<option value="5" <?php  if($this->item->optiontype==5) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_TEXT_AREA'); ?> </option>
					<option value="6" <?php  if($this->item->optiontype==6) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_TRUE_FALSE'); ?> </option>
					<option value="7" <?php  if($this->item->optiontype==7) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_YES_NO'); ?> </option>
					<option value="8" <?php  if($this->item->optiontype==8) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_DRAG_DROP'); ?> </option>
					<option value="9" <?php  if($this->item->optiontype==9) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_HOTSPOT'); ?> </option>
				</select>
				</td>
			</tr>
			
			<tr class="textfield_check_tr">
			
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ANSWER_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_ANSWER'); ?></label></td>
				
				<td>
					<input type="text" name="text_field_ans" value="<?php echo trim($this->item->text_field_ans);?>"/>
				</td>
			</tr>
			
			<tr class="textfield_check_tr">
			
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_CASE_SENSITIVE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_CASE_SENSITIVE'); ?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="case_sensitive1" id="case_sensitive1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" name="case_sensitive" id="case_sensitive1" value="1" <?php if($this->item->case_sensitive ==1) echo 'checked="checked"';?>/>
					<label for="case_sensitive0" id="case_sensitive0-lbl" class="radio"><?php echo JText::_('NOS'); ?></label>
					<input type="radio" name="case_sensitive" id="case_sensitive0" value="0" <?php if($this->item->case_sensitive ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
				
			</tr>
			
			<tr class="hotspot_check_tr">
			
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_IMAGE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_IMAGE'); ?></label></td>
				
				<td>
					<input type="file" name="drag_field_ans" id="hotspot_images"/>
					<button id="upload_hotspot" class="btn"><?php echo JText::_('COM_VQUIZ_UPLOAD')?></button>
				</td>
			</tr>
			
			<tr id="ajax_tr">
			</tr>
			
			<tr id="comment_box_row">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_OTHER_OPTION_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_OTHER_OPTION'); ?></label></td>
					<td>
						<fieldset class="radio btn-group">
							<label for="other_option1" id="other_option1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_OTHER_OPTION_ENABLE'); ?></label>
							<input type="radio" name="other_option" id="other_option1" value="1" <?php if($this->item->other_option==1) echo 'checked="checked"';?>/>
							<label for="other_option0" id="other_option0-lbl" class="radio"><?php echo JText::_( 'COM_VQUIZ_OTHER_OPTION_DISABLE' ); ?></label>
							<input type="radio" name="other_option" id="other_option0" value="0" <?php if($this->item->other_option==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
			</tr>
			<?php if($this->optinscoretype->enable_questiongroup==1){?>
			<tr >
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_GROUP_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_GROUP'); ?></label></td>
				<td>
				
				<select name="questiongroup" id="questiongroup">
				
					<option value="0" ><?php echo JText::_('COM_VQUIZ_SELECT_QUESTION_GROUP')?></option>
					<?php 
					for($i=0;$i<count($this->questiongroup);$i++){?>
						<option value="<?php echo $this->questiongroup[$i]->qorder;?>" <?php if($this->questiongroup[$i]->qorder==$this->item->questiongroup) echo "selected='selected'";?> ><?php echo $this->questiongroup[$i]->title;?></option>
					<?php } ?>
				</select>
				
				</td>
			</tr>
			<?php }?>
			
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTIONS_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTIONS'); ?></label></td>
				<td>
				<?php 

				if($this->config->question_prepare_content==1){
					$qtitle = JHtml::_('content.prepare', $this->item->qtitle);
				}else{
					$qtitle = $this->item->qtitle;
				}

				echo $editor->display("qtitle",  $this->item->qtitle, "400", "200", "20", "5", true, null, null, null, array());

				?> 
				</td>
			</tr>
			<?php if($this->optinscoretype->explanation!=0) {?>
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_EXPLANATION_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_EXPLANATION'); ?></label></td>
				<td>
				<?php 

				$editor = JFactory::getEditor();
				if($this->config->question_prepare_content==1){
					$explanation = JHtml::_('content.prepare', $this->item->explanation);
				}else{
					$explanation = $this->item->explanation;
				}
				
				echo $editor->display("explanation",  $explanation, "400", "300", "20", "5",true, null, null, null, array());
				
				?> 
				</td>
			</tr>
			<?php }?>
			
			<?php if($this->optinscoretype->hint!=0){?>
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_HINT_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_HINT'); ?></label></td>
				<td>
				<?php 

				$editor = JFactory::getEditor();
				if($this->config->question_prepare_content==1){
					$hint = JHtml::_('content.prepare', $this->item->hint);
				}else{
					$hint = $this->item->hint;
				}
				
				echo $editor->display("hint",  $hint, "400", "300", "20", "5",true, null, null, null, array());
				
				?> 
				</td>
			</tr>
			<?php }?>
			
			<?php if($this->optinscoretype->transcript!=0){?>
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_TRANSCRIPT_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_TRANSCRIPT'); ?></label></td>
				<td>
				<?php 

				$editor = JFactory::getEditor();
				if($this->config->question_prepare_content==1){
					$transcript = JHtml::_('content.prepare', $this->item->transcript);
				}else{
					$transcript = $this->item->transcript;
				}
				
				echo $editor->display("transcript",  $transcript, "400", "300", "20", "5",true, null, null, null, array());
				
				?> 
				</td>
			</tr>
			<?php }?>
			
		</table>
 
 
		<table width="100%" id="addinput">
			<tr>
				
				<?php if($this->optinscoretype->quiztype==22 and $this->optinscoretype->personality_type==2){?>
					<th></th>
				<?php }else {?>
					<th><input type="button" name="addoption" id="addNew" value="+" class="btn btn-success" /></th>
				<?php }?>
				<th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_IMAGES_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_IMAGES'); ?></label></th>
				
				<th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS'); ?></label></th>
				
				<?php if($this->optinscoretype->quiztype!=3){?>
					<th valign="middle" align="center">
					<?php if($this->optinscoretype->quiztype==2){?>
					
					<?php if($this->optinscoretype->multi_p_score==1 and $this->optinscoretype->personality_type==1){?>
						<div class="hasTip personality_weight"  title="<?php echo JText::_('COM_VQUIZ_QUESTION_PERSONALITY_WEIGHT_TOOLTIP'); ?>">
						<?php echo JText::_('COM_VQUIZ_QUESTION_PERSONALITY_WEIGHT'); ?>
						</div>  
					<?php }?>
					
					<div class="hasTip <?php if($this->optinscoretype->personality_type==1) echo 'personality_weight';?>"  title="<?php echo JText::_('COM_VQUIZ_QUESTION_PERSONALITY_RESULT_TOOLTIP'); ?>">
					<?php echo JText::_('COM_VQUIZ_QUESTION_PERSONALITY_RESULT'); ?>
					</div>
					
					<?php }else if($this->optinscoretype->quiztype==11 or $this->optinscoretype->answers_type==1){?>
					<label class="hasTip"  title="<?php echo JText::_('COM_VQUIZ_QUESTION_SCORE_TOOLTIP'); ?>">
					<?php echo JText::_('COM_VQUIZ_QUESTION_SCORE'); ?>
					</label>
					
								 
					<?php } else if($this->optinscoretype->quiztype==11 and $this->optinscoretype->answers_type==2){?>
			  		
					<label class="hasTip"  title="<?php echo JText::_('COM_VQUIZ_QUESTION_CATEGORY_SCORE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_CATEGORY_SCORE'); ?></label>
					
					<table><tr>
					<?php for($b=0;$b<count($this->score_category);$b++){?>
						<th>
							<label style="width:95px;"><?php echo $this->score_category[$b]->category; ?></label>
						</th>
					<?php }?>
					</tr></table>
					
				<?php }else {?>
					<label class="hasTip"  title="<?php echo JText::_('COM_VQUIZ_QUESTION_CHOOSE_ANSWER_TOOLTIP'); ?>">
					<?php echo JText::_('COM_VQUIZ_ANSWER'); ?>
					</label>
					<?php }?>
					</th>
				 <?php }?>
				<th><label><?php echo JText::_('COM_VQUIZ_ORDERING'); ?></label></th>
				<th><label><?php echo JText::_('COM_VQUIZ_REMOVE'); ?></label></th>
			</tr>

			<?php
			
			
			if($this->optinscoretype->quiztype==22 and $this->optinscoretype->personality_type==2){
				$count_column = @$this->personality_category->count_column>0?$this->personality_category->count_column:1;
				$Maxoption=$count_column;
			}else{
				$Maxoption=count($this->options);
				
			}
			//true/false
			
				
			for($i=0;$i<$Maxoption;$i++){
			
			?>
			<tr>
				<td></td>
				
				<?php if($this->item->optiontype==8){?>
				<td class="upimg">
				
				
					<input type="file" name="image[]" id="option_images" class="colA"/>
						<?php
						if(!empty($this->options[$i]->image) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[$i]->image)){ 
						echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[$i]->image. '" alt="x" />'; 
						}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
						?>
						<textarea style="width:45%; padding:1%; margin:1%;" type="text" id="qoption"  name="qoption[]" cols="40" rows="5" class="colAtextarea"><?php echo $this->options[$i]->qoption; ?></textarea>
					</td>
					
					<td class="upimg">
					<input type="file" name="imageB[]" id="option_imagesB" class="colB" />
						<?php
						if(!empty($this->options[$i]->imageB) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[$i]->imageB)){ 
						echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[$i]->imageB. '" alt="x" class="colBimg"/>'; 
						}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" class="colBimg" />';} 
						?>
						<textarea style="width:45%; padding:1%; margin:1%;" type="text" id="qoptionB"  name="qoptionB[]" cols="40" rows="5" class="colBtextarea"><?php echo $this->options[$i]->qoptionB; ?></textarea>
						</td>
				<?php }
				else{?>
					
				<td class="upimg"><input type="file" name="image[]" id="option_images" />
					<?php 

					if(!empty($this->options[$i]->image) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[$i]->image)){ 
					echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[$i]->image. '" alt="x" />'; 
					}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
					?>	
					<input type="hidden" name="image_file[]" value="<?php echo $this->options[$i]->image;?>"/>
					
				</td>
				
				<td valign="middle" align="center">
				<input style="width:96%; padding:1%; margin:1%;" type="text" id="qoption"  name="qoption[]" value="<?php echo !empty($this->options[$i]->qoption)?$this->options[$i]->qoption:''; ?>"/>
				</td>
					
					
				<?php }?>
				
				
				
			 <?php if($this->optinscoretype->quiztype!=3){?>
			 
					<td valign="middle" align="center"> <!-- //answer -->
					<?php 
					if($this->optinscoretype->quiztype==1 and $this->optinscoretype->answers_type==0){
						
						if($this->item->optiontype==2){?>
						
							<label class="mcheckbox" >
							<input type="checkbox" name="correct_ans[]" class="options_answer" value="<?php echo $i; ?>" 
							<?php if(!empty($this->options[$i]->correct_ans) and $this->options[$i]->correct_ans==1) { echo 'checked="checked"'; } ?>/></label>
							
						<?php }else if($this->item->optiontype==4){?>
						<label></label>
						<?php }else if($this->item->optiontype==1 OR $this->item->optiontype==3 OR $this->item->optiontype==6 OR $this->item->optiontype==7){?>
						<label class="sradio"  ><input type="radio" name="correct_ans"  class="options_answer" value="<?php echo $i; ?>"
						<?php if(!empty($this->options[$i]->correct_ans) && $this->options[$i]->correct_ans==1) { echo 'checked="checked"'; } ?>/></label>
						<?php }else if($this->item->optiontype==8){?>
						<input type="number" name="correct_ans[]" class="options_answer" value="<?php echo $this->options[$i]->correct_ans;?>" />
						<?php }
						
					}else if($this->optinscoretype->quiztype==11 and $this->optinscoretype->answers_type==1){?>

					<input type="text" name="options_score[]" value="<?php echo !empty($this->options[$i]->options_score)?$this->options[$i]->options_score:''?>" style="width:50px;" />
					
					
					<?php }else if($this->optinscoretype->quiztype==11 and $this->optinscoretype->answers_type==2){?>
					
					    <input type="hidden" name="score_category_count" value="<?php echo count($this->score_category)?>"/>
						
						<?php $category_score=json_decode($this->options[$i]->category_score);?>
						
						<table><tr>
						<?php for($i=0;$i<count($this->score_category);$i++){?>
							<td><?php echo $this->score_category[$i]->category;?></td>
						<?php }?>
						</tr>
						<tr>
						<?php for($b=0;$b<count($this->score_category);$b++){?>
							<td>
												 
								<input type="text" name="category_score<?php echo $b;?>[]" value="<?php if(isset($category_score[$b])) echo $category_score[$b]; else echo '1';?>" style="width:80px;" />
								
							</td>
						<?php }?>
						</tr></table>
						
					<?php }else if($this->optinscoretype->quiztype==22){
							$p_cat= @json_decode($this->personality_category->category);

							$count_column = @$this->personality_category->count_column>0?$this->personality_category->count_column:1;

							$personality_category= @array_chunk($p_cat,$count_column);
						?>
					
	                <div class="personality_category">	
								<select name="personality_optionid[]" class="<?php if($i==0) echo 'first_select';else echo 'rest_select';?>">
								<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_ANSWERS');?></option>
								 <?php for($a=0;$a<count($personality_category);$a++)	{?>
								  <optgroup label="Category:<?php echo $a+1;?>">
									<?php for($b=0;$b<count($personality_category[$a]);$b++){?>
										<option value="<?php echo $personality_category[$a][$b];?>" <?php  if(!empty($this->options[$i]->personality_optionid) and $personality_category[$a][$b]==$this->options[$i]->personality_optionid) echo 'selected="selected"'; ?> readOnly="true"><?php echo $personality_category[$a][$b];?></option>
									 <?php }?>
								  </optgroup>
								 <?php }?>
								</select>
								
						
						</div>
					<?php }else if($this->optinscoretype->quiztype==2){?>
					
					
					    <?php if($this->optinscoretype->multi_p_score==1 and $this->optinscoretype->personality_type==1){?>
						 <div class="personality_weight"><input type="text" name="multi_p_options_score[]" value="<?php echo $this->options[$i]->multi_p_options_score?>" style="width:80px;" /></div>
						<?php   } ?>
						
						<?php /*<div class="personality_weight">*/?>	
							<select name="personality_optionid[]">
							<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_ANSWERS');?></option>
							<?php for($a=0;$a<count($this->personality_answers);$a++)	 {?>
							<option value="<?php echo $this->personality_answers[$a]->id?>" <?php  if($this->personality_answers[$a]->id==$this->options[$i]->personality_optionid) echo 'selected="selected"'; ?>><?php echo htmlspecialchars($this->personality_answers[$a]->answer,ENT_QUOTES)?></option>
							<?php }?>
							</select>
						<?php /*</div>*/?>

					<?php //}
					}
					?>
					</td> <!-- //answer -->
					
			   <?php }?>
			   
				<td width="100" class="center">
					<span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span>
					<input type="hidden" name="oorder[]" value="<?php echo $i+1;?>"/>
				</td>
				
				<td valign="middle" align="center">
				<a href="javascript:void(0);" class="remNew btn btn-danger">-</a></td>
			</tr>
			<?php 
			}?>

		</table>
		
		<?php  //if($this->item->optiontype==6 || $this->item->optiontype==7){  ?>
		<table width="100%" id="addinput2">
			<tr>			
					<th></th>	
				<th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_IMAGES_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_IMAGES'); ?></label></th>
				
				<th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS'); ?></label></th>		
					<th>
					<label class="hasTip"  title="<?php echo JText::_('COM_VQUIZ_QUESTION_CHOOSE_ANSWER_TOOLTIP'); ?>">
					<?php echo JText::_('COM_VQUIZ_ANSWER'); ?>
					</label>
					</th>
				<th><label><?php echo JText::_('COM_VQUIZ_ORDERING'); ?></label></th>
				<th><label><?php echo JText::_('COM_VQUIZ_REMOVE'); ?></label></th>
			</tr>
			<tr>
					<td></td>
					<td class="upimg"><input type="file" name="image2[]" id="option_images" />
					<?php 

					if(!empty($this->options[0]->image) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[0]->image)){ 
					echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[0]->image. '" alt="x" />'; 
					}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
					?>	
					
					<input type="hidden" name="image_file2[]" value="<?php if(!empty($this->options[0]->image)){echo $this->options[0]->image;}?>" />
					
					
				</td>
				
				<?php 
					 $jtext_true = JText::_('COM_VQUIZ_TRUE'); 
					 $jtext_false = JText::_('COM_VQUIZ_FALSE');
					
					 ?>
					 
					<td width="100" class="center"><input type="text" id="qoption_bottom1" name="qoption2[]" value="<?php echo (isset($this->options[0]->qoption) && in_array($this->options[0]->qoption,array($jtext_true,$jtext_false)))?$this->options[0]->qoption:$jtext_true; ?>" readOnly="readOnly" /></td>
					
						<td align="center"><input type="radio" name="correct_ans2" id="correct_ans_bottom1"  value="0" class="options_answer" <?php if(!empty($this->options[0]->correct_ans) and $this->options[0]->correct_ans==1) { echo 'checked="checked"'; } ?> /></td>
						
					<td width="100" class="center">
					<span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span>
					<input type="hidden" name="oorder2[]" value="1"/>
				   </td>
				
						<td></td>
					</tr>
				<tr>
					<td></td>
					<td class="upimg"><input type="file" name="image2[]" id="option_images" />
					<?php 

					if(!empty($this->options[1]->image) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[1]->image)){ 
					echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[1]->image. '" alt="x" />'; 
					}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
					?>	
					
					<input type="hidden" name="image_file2[]" value="<?php if(!empty($this->options[1]->image)){echo $this->options[1]->image;}?>" />
					
					</td>
					<td width="100" class="center"><input type="text" id="qoption_bottom2" name="qoption2[]" value="<?php echo (isset($this->options[1]->qoption) && in_array($this->options[1]->qoption,array($jtext_true,$jtext_false)))?$this->options[1]->qoption:$jtext_false; ?>" readOnly="readOnly" /></td>
					
					<td align="center"><input type="radio" name="correct_ans2" id="correct_ans_bottom2"  value="1" class="options_answer" <?php if(!empty($this->options[1]->correct_ans) and $this->options[1]->correct_ans==1) { echo 'checked="checked"'; } ?> />
				
					
					<td width="100" class="center">
					<span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span>
					<input type="hidden" name="oorder2[]" value="2"/>
					</td>
					
					<td></td>
				
			</tr>
	</table>
		<?php //} ?>
	</fieldset>
</div> 

<div class="clr"></div>
<?php echo JHTML::_( 'form.token' ); ?> 

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="quizquestion" />
<input type="hidden" name="quizid" value="<?php echo JRequest::getInt('quizid',0);?>" />
<input type="hidden" name="score_category" id="score_category" value="<?php echo count($this->score_category)?>" />
<input type="hidden" name="personalitytype" id="" value="<?php echo $this->optinscoretype->personality_type;?>" />
<input type="hidden" name="score_category_count" value="<?php echo count($this->score_category)?>" id="score_category_count"/>
<input type="hidden" name="hotspot_img" id="hotspot_img" value="<?php echo $this->item->hotspot_img?>" />
<input type="hidden" name="rectangle" id="rectangle" value="<?php echo $this->item->rectangle?>" />

</form>