<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );
class VquizViewQuizinvitation extends JViewLegacy
{ 
 
		function display($tpl = null)
 		{
			  $user = JFactory::getUser();
			  
			  if(!$user->authorise('core.userviews','com_vquiz')){
				jerror::raiseWarning('403', JText::_('UNAUTH_ACCESS'));
				return false;	 
			  }  
	          $mainframe =JFactory::getApplication();
		      $context	= 'com_vquiz.result.list.';
			 
			  $search = $mainframe->getUserStateFromRequest( $context.'search', 'search', '',	'string' );
		      $search = JString::strtolower( $search );
			  $quiz_id= $mainframe->getUserStateFromRequest( $context.'quiz_id', 'quiz_id',	'quizid',	'string' );
			  
			  $filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
       		  $filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
				$this->config = $this->get('Config');	
				

				 JToolBarHelper::title( JText::_('COM_VQUIZ_INVITATION_LIST'), 'vcard.png' );
				
				/*if($user->authorise('core.export','com_vquiz')){
				  JToolBarHelper::custom( 'export', 'upload', 'download', JText::_( 'CSV_EXPORT_TITLE'), false );
				} */
				
				if(JFactory::getUser()->authorise('core.delete','com_vquiz')){
					JToolBarHelper::deleteList(JText::_('DO_YOU_WANT_DELETE_RECORD'));	
				}

				
 
  	            JToolBarHelper::help('help', true);
				if(JFactory::getUser()->authorise('core.admin','com_vquiz')){
					JToolBarHelper::preferences('com_vquiz','', '','ACL');
				}
				
				// Side bar 
				$version = new JVersion;
				$joomla = $version->getShortVersion();
				$jversion = substr($joomla,0,3);
				$this->sidebar ='';
				if($jversion>=3.0)
				{
				$this->sidebar = JHtmlSidebar::render();
				}
 				$items = $this->get('Items');
 				$this->assignRef( 'items', $items );
 				$this->pagination = $this->get('Pagination');
				$this->allQuizinresult = $this->get('AllQuizinresult');
 				$lists['search']= $search;
				
				$this->assignRef( 'lists', $lists );
				
				// Table ordering.
				$this->lists['order_Dir'] = $filter_order_Dir;
				$this->lists['order']     = $filter_order;
				$this->lists['quiz_id']     = $quiz_id;

  			   
			 parent::display($tpl);
		 }
 
}

 