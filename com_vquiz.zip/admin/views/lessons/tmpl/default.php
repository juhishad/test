<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
JHtml::_('behavior.tooltip');
jimport( 'joomla.html.pagination');	
$document = JFactory::getDocument();
//$document->addScript('components/com_vquiz/assets/js/library.js');
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
//$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');
$selected_userlesson=JRequest::getVar('selected_userlesson',0);
$tmpl=JRequest::getVar('tmpl', 'index');
JHtml::_('formbehavior.chosen', 'select');
$app       = JFactory::getApplication();
$user      = JFactory::getUser();
$userId    = $user->get('id');
$listOrder = $this->lists['order'];
$listDirn  = $this->lists['order_Dir'];
$saveOrder = $listOrder == 'i.ordering';
$columns   = 10;


if ($saveOrder)
{
	$saveOrderingUrl = 'index.php?option=com_vquiz&task=saveOrderAjax&tmpl=component';
	JHtml::_('sortablelist.sortable', 'adminlist', 'adminForm', strtolower($listDirn), $saveOrderingUrl);
}

//$assoc = JLanguageAssociations::isEnabled();
$function = JFactory::getApplication()->input->getCmd('function', 'jSelectLessons');

$from_userview=JRequest::getInt('from_userview',0);
$script = array();
$script[] = " jQuery(function($){";
$script[] = " var selected_user='$selected_userlesson'.split(',')"; 
$script[] = " jQuery('#select_chk').click(function () {";
$script[] = " var ids=[]"; 
$script[] = " var title=[]"; 
$script[] = " $('input[type=checkbox]:checked').each(function(){";
$script[] = " ids.push($(this).val());";
$script[] = " title.push( $.trim($(this).closest('td').next('td').text()));";
$script[] = " });";
$script[] = " if(ids==''){ alert('Please Select Quiz')}else{";
$script[] = " if (window.parent) window.parent.jSelectLessons_jform_request_id(ids,title,null);";
$script[] = " }});";
$script[] = " $('input[type=checkbox]').each(function(){";
$script[] = " if(jQuery.inArray($(this).val(),selected_user)!== -1){";
$script[] = " if($(this).val()!='') this.disabled = true;}"; //this.checked = true;
$script[] = " });";
$script[] = " });";
JFactory::getDocument()->addScriptDeclaration(implode("\n", $script));
?>


<div class="poploadingbox">
<?php echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/loading.gif"/>' ?>
</div>
<form action="index.php?option=com_vquiz&view=lessons" method="post" name="adminForm" id="adminForm">
	<?php if($tmpl!='component'){?>
		<?php if (!empty( $this->sidebar)) : ?>   
			<div id="j-sidebar-container" class="span2">
			<?php echo $this->sidebar; ?>
			</div>
			<div id="j-main-container" class="span10">
			<?php else : ?>
			<div id="j-main-container">
			<?php endif;?>
			<div class="clr" style="clear:both;"></div>		

	<?php } ?>
	
		
	<?php if($from_userview==1){?>	
		<div style="margin: 10px 0;"><a href="#" id="select_chk" class="btn btn-small btn-primary d-inline-block"><?php echo JText::_('COM_VQUIZ_SELECT_ALL_SELECTED');?></a></div>
	<?php } ?>
		
		<div class="clr" style="clear:both;"></div>	
		
            <div class="search_buttons">
                <div class="btn-wrapper input-append">
                <input placeholder="Search" type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
                <button class="btn" onclick="this.form.submit();"><i class="icon-search"></i><span class="search_text"><?php echo JText::_('COM_VQUIZ_SEARCH'); ?></button>
                <button class="btn" onclick="document.getElementById('search').value='';this.form.submit();"><?php echo JText::_('COM_VQUIZ_RESET'); ?></button>
                </div>
            </div>
             
			<select name="publish_item" id="publish_item" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('COM_VQUIZ_ALL_STATES');?></option>
				<option value="p" <?php  if( 'p'== $this->lists['publish_item']) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PUBLISHED');?></option>
				<option value="u" <?php  if('u'== $this->lists['publish_item']) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_UNPUBLISHED');?></option>
			</select>

			<select name="catid" id="catid" class="inputbox" onchange="this.form.submit()">
			<option value=""><?php echo JText::_('COM_VQUIZ_ALL_CATEGORIES'); ?></option>
			<?php    for ($i=0; $i <count($this->cats); $i++){	?>
			<option value="<?php echo $this->cats[$i]->id;?>" <?php  if($this->cats[$i]->id == $this->lists['catid']) echo 'selected="selected"'; ?>>
				<?php echo str_repeat('- ', $this->cats[$i]->level).$this->cats[$i]->title; ?>
			</option>		
			<?php	}	?>
			</select>
			<div class="btn-group pull-right hidden-phone">
				<?php echo $this->pagination->getLimitBox(); ?>
			</div>
			

<div id="editcell">
	<table class="table table-striped" id="adminlist">
	<thead>
		<tr>
        	<th width="5">
                 <?php echo JText::_('NUM'); ?>
			</th>
			<th width="1%" class="nowrap center hidden-phone"><?php echo JHTML::_('grid.sort', 'Ord', 'i.ordering', @$this->lists['order_Dir'], @$this->lists['order'] ); ?></th>
			<th width="20">
			<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
			</th>			
			<th>
                 <?php echo JHTML::_('grid.sort', 'VQUIZ_LESSONS', 'i.title', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_CATEGORY', 'category', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_TYPE', 'i.type', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			<th>
				<?php echo JText::_( 'COM_VQUIZ_PUBLISHED' ); ?>
			</th>
            <th width="5">
				 <?php echo JHTML::_('grid.sort', 'ID', 'i.id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
		</tr>
	</thead>
    <tfoot>
    <tr>
    <td colspan="11"> <?php echo $this->pagination->getListFooter(); ?></td>
    </tr>
    </tfoot>
	<?php

	$k = 0;
	for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
		$row = &$this->items[$i];
        
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		$link 		= JRoute::_( 'index.php?option=com_vquiz&view=lessons&task=edit&cid[]='. $row->id );
		if(JFactory::getUser()->authorise('core.edit.state','com_vquiz'))
			$published  = JHTML::_( 'jgrid.published', $row->published, $i );
		else{
			if($row->published==1)
				$published  = JText::_('PUBLISHED');
			else
				$published  = JText::_('UNPUBLISHED');
		}
		?>

		<tr class="<?php echo "row$k"; ?>">
 		<td><?php echo $this->pagination->getRowOffset($i); ?></td>
		<?php $iconClass = '';
							if (!$saveOrder)
							{
								$iconClass = ' inactive tip-top hasTooltip" title="' . JHtml::tooltipText('JORDERINGDISABLED');
							}?>
			<td class="order nowrap center hidden-phone">
			<span class="sortable-handler<?php echo $iconClass ?>"><span class="icon-menu"></span></span>
				<?php if ($saveOrder) : ?>
					<input type="text" style="display:none" name="order[]" size="5" value="<?php echo $row->ordering; ?>" class="width-20 text-area-order " />
				<?php endif; ?></td>
				
			<td>
				<?php echo $checked; ?>
			</td>
			<td>
				<?php if($from_userview==1){?>
					<?php echo substr($row->title,0,50); ?>
				<?php }else{?>
					<a href="<?php echo $link; ?>" onclick="if (window.parent) window.parent.<?php echo $this->escape($function);?>('<?php echo $row->id; ?>','<?php echo $this->escape(addslashes($row->title)); ?>',null);"><?php echo substr($row->title,0,50); ?></a>
				<?php }?>
				
			</td> 
			
			<td><?php echo isset($row->category)?$row->category:'---'; ?></td>
			<td><?php echo JText::_($row->type); ?></td>
			<td class="center publish_unpublish">
				<?php if($tmpl!='component' and JFactory::getUser()->authorise('core.edit.state','com_vquiz')){echo $published;}else{
					echo $row->published==1?JText::_('COM_VQUIZ_PUBLISHED'):JText::_('COM_VQUIZ_UNPUBLISHED');
				}?>
			</td>
			<td><?php echo $row->id; ?></td>
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>

	</table>

</div>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="lessons" /> 
<input type="hidden" name="selected_userlesson" value="<?php echo JRequest::getVar('selected_userlesson', 0); ?>" />
<input type="hidden" name="tmpl" value="<?php echo JRequest::getVar('tmpl', 'index'); ?>" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
  </div>  

</form>



