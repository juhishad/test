<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access


defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');
$document = JFactory::getDocument();
$document->addScript('components/com_vquiz/assets/js/library.js');
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$document->addStyleSheet('components/com_vquiz/assets/css/jquery-ui.css');
$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');
//print_r($this->item);
?>
<script type="text/javascript">
	var $r=jQuery.noConflict();
	$r(document).ready(function(){ 
		 $r( "#tabs" ).tabs();
		 
		 if($r("#lessontype").val() =="slide"){ 
			$r(".desc").hide();
			$r(".filename").hide();
			$r(".filetype").show(); 
			$r(".all_container").hide();
			$r(".slide_container").show();
			$r("#sliderOption").show();
		  }else if($r("#lessontype").val() == "text"){  
			$r(".desc").show();
			$r(".filename").hide();
			$r(".all_container").hide();
			$r(".slide_container").hide();
			$r(".filetype").hide(); 
			$r("#sliderOption").hide();
		 }else if($r("#lessontype").val() == "video"){  
			$r(".desc").hide();
			$r(".filename").show();
			$r(".filetype").show(); 
			$r(".all_container").show();
			$r(".slide_container").hide(); 
			$r("#sliderOption").hide();
		 }else{
			$r(".desc").hide();
			$r(".filename").hide();
			$r(".filetype").show(); 
			$r(".all_container").show();
			$r(".slide_container").hide(); 
			$r("#sliderOption").hide();
		 }
		 
		$r("#lessontype").change(function(){
 
			if($r(this).val() =="slide"){ 
				$r(".desc").hide();
				$r(".filename").hide();
				$r(".filetype").show(); 
				$r(".all_container").hide();
				$r(".slide_container").show();
				$r("#sliderOption").show();
			  }else if($r(this).val() == "text"){  
				$r(".desc").show();
				$r(".filename").hide();
				$r(".all_container").hide();
				$r(".slide_container").hide();
				$r(".filetype").hide(); 
				$r("#sliderOption").hide();
			 }else if($r("#lessontype").val() == "video"){  
				$r(".desc").hide();
				$r(".filename").show();
				$r(".filetype").show(); 
				$r(".all_container").show();
				$r(".slide_container").hide(); 
				$r("#sliderOption").hide();
			 }else{
				$r(".desc").hide();
				$r(".filename").hide();
				$r(".filetype").show(); 
				$r(".all_container").show();
				$r(".slide_container").hide(); 
				$r("#sliderOption").hide();
			 }
				 
		});
		
		jQuery(document).on('click',".icon-uparrow,.icon-downarrow",function () { 
			
			var $element = this;
			var row = jQuery($element).parents("tr:first");

			if(jQuery(this).is('.icon-uparrow')){
				var x=row.insertBefore(row.prev());
				var lenghth_tr=jQuery.parseJSON(JSON.stringify(x.prev())).length;
			}else{
				row.insertAfter(row.next());
			}

		});
		
		jQuery(document).on('click','.slide_rimg',function() {
			var id=jQuery(this).attr("id");
			var img=jQuery(this).attr("img");
			var row = jQuery(this).parents("tr:first");
			deleteImg(img,id,row);

		});
		
	});
	
	
	function deleteImg(img,id,row) 
	{ 
			jQuery.ajax(
			{
				url: "index.php",
				type: "POST",
				dataType:"json",
				data: {'option':'com_vquiz', 'view':'lessons', 'task':'slidDeleteImg', 'tmpl':'component','img':img,'id':<?php echo $this->item->id; ?>,"<?php echo JSession::getFormToken(); ?>":1},

				success: function(data)	
				{
					if(data.result==1){
						jQuery('.'+id).remove();
						row.remove();
					}
				}
				
		});
	}
	
	Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
			
			var form = document.adminForm;
			var regex = /^[a-zA-Z]+$/;

			if(form.title.value == "")	{
				alert("<?php echo JText::_('QUESTION_TITLE_NOT_EMPTY'); ?>");
				return false;
			}
			if(!jQuery('select[name="catid"]').val()){
				alert('<?php echo JText::_('PLZ_SELECT_CATEGORY', true); ?>');
				document.adminForm.catid.focus();
				return false;
			}
			
			if(form.lessontype.value == "" || form.type.value == "SELECT_TYPE")	{
				alert("<?php echo JText::_('COM_VQUIZ_LESSONS_SELECT_TYPE'); ?>");
				return false;
			}
			
			
			//if(form.type.value=="document")  {
               // var allowedFiles = [".doc", ".docx", ".pdf"];
               // var fileUpload = $("#files");
               // var lblError = $("#lblError");
              //  var regex = new RegExp("([a-zA-Z0-9\s_\\.\-:])+(" + allowedFiles.join('|') + ")$");
              //  if (!regex.test(fileUpload.val().toLowerCase())) {
              //    lblError.html("Please upload files having extensions: <b>" + allowedFiles.join(', ') + "</b> only.");
               //   return false;
              // }
           // } 
		   
 
			if(form.lessontype.value != "slide" && form.files.value != "")	{
			   chkext=form.files.value.split('.').pop().toLowerCase() ;
			   
			   if (form.lessontype.value == "document") {
				  if(!(chkext == "pdf" || chkext == "docx" || chkext == "doc" || chkext == "txt")){
					 alert("<?php echo JText::_('COM_VQUIZ_LESSONS_SELECT_DOC'); ?>");
					 return false;
				  }
			   }
			   if (form.lessontype.value == "image") {
				  if(!(chkext == "jpeg" || chkext == "jpg" || chkext == "png")){
					 alert("<?php echo JText::_('COM_VQUIZ_LESSONS_SELECT_IMG'); ?>");
					 return false;
				  }
				}
				if (form.lessontype.value == "audio") {
				  if(!(chkext == "mp3" || chkext == "wav" || chkext == "avi")){
					 alert("<?php echo JText::_('COM_VQUIZ_LESSONS_SELECT_MPTHREE'); ?>");
					 return false;
				  }
				}
				if (form.lessontype.value == "video") {
				  if(!(chkext == "mp4" || chkext == "avi" || chkext == "mov")){
					 alert("<?php echo JText::_('COM_VQUIZ_LESSONS_SELECT_MPFOUR'); ?>");
					 return false;
				  }
				}
			}
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}
	
</script>
<style type="text/css">
.box{
	padding: 20px;
	display: none;
	margin-top: 20px;
}
 .filetype .pr_pv {
    display: inline-block;
    margin: 2% 1% 0;
    text-align: center;
}

 .filetype .pr_pv img {
    height: auto;
    max-width:100%;
 }
   .slideimg {
	max-width:100px;
	max-height:100px;
}

</style>
 
<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">

<div class="col101">
    <fieldset class="adminform">
    <legend><?php echo JText::_( 'VQUIZ_DETAILS' ); ?></legend>
		<div id="tabs">
        <ul>
			<li><a href="#main"><?php echo JText::_('COM_VQUIZ_QUIZZES_MAINSETTING'); ?></a></li>
			<li id="sliderOption"><a href="#slider_options"><?php echo JText::_('COM_VQUIZ_LESSONS_SLIDER_OPTIONS'); ?></a></li>
		</ul>
		<div id="main">
        <table class="adminform table table-striped">
	    <tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_LESSON_TITLE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_LESSON_TITLE'); ?></label></td>
			<td><input type="text"  name="title" id="title" class="title" value="<?php echo $this->item->title;?>"/></td>
        </tr>
		<tr>
			<td><label><?php echo JText::_('COM_VQUIZ_ALIAS'); ?></label></td>
			<td><input type="text" name="alias" id="alias"  value="<?php echo !empty($this->item->alias)?$this->item->alias:'';?>"  placeholder="Automatic Genarated"/></td>
		</tr>

		<tr>
			<td class="key"><label><?php echo JText::_('COM_VQUIZ_LESSONS_THUMBNAIL'); ?></label></td>

			<td class="upimg">
				<input type="file" name="thumbnail" id="thumbnail" />
			<?php 
			if(!empty($this->item->thumbnail) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/lessons/thumbs/'.'thumb_'.$this->item->thumbnail)){ 
			echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/photoupload/lessons/thumbs/'.'thumb_'.$this->item->thumbnail. '" alt="" />'; 
			}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
			?>
			</td>
		</tr>
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_WIDGET_ACCESS_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_WIDGET_ACCESS'); ?></label></td>
			<td><?php echo $this->lists['access']; ?></td>
        </tr>
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PUBLISHED'); ?>"><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?></label></td>
			<td>
			<select  name="published" id="published" >
			<option value="1" <?php if($this->item->published==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?> </option>
			<option value="0" <?php if($this->item->published==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?> </option>
			</select>
			</td>
       </tr>
       <tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_LANGUAGE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_LANGUAGE'); ?></label></td>
			<td colspan="2">
			<select name="language" id="language">
			<?php echo JHtml::_('select.options', JHtml::_('contentlanguage.existing', true, true), 'value', 'text', $this->item->language);?>
			</select>
			</td>
		</tr>
        <tr>
        <td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_CATEGORY_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_CATEGORY'); ?></label></td>
		<td>
			<select name="catid" id="catid" class="inputbox" required="true"> 
			<option value=""><?php echo JText::_('COM_VQUIZ_SELECT_CATEGORY'); ?></option>
			<?php    for ($i=0; $i <count($this->cats); $i++){	?>
			<option value="<?php echo $this->cats[$i]->id;?>" <?php  if($this->cats[$i]->id == $this->item->catid) echo 'selected="selected"'; ?>>
				<?php echo str_repeat('- ', $this->cats[$i]->level).$this->cats[$i]->title; ?>
			</option>		
			<?php	}	?>
			</select>
		</td>
        </tr>
        <tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_LESSON_TYPE_DESC'); ?>"><?php echo JText::_('COM_LESSON_TYPE'); ?></label></td>
			<td>
				<select name="type" id="lessontype" class="inputbox">
					<option value="text" <?php  if($this->item->type=="text") echo 'selected="selected"'; ?>>
						<?php echo JText::_('COM_VQUIZ_TEXT'); ?>
					</option>
					<option value="audio" <?php  if($this->item->type=="audio") echo 'selected="selected"'; ?>>
						<?php echo JText::_('COM_VQUIZ_AUDIO'); ?>
					</option>	
					<option value="document" <?php  if($this->item->type=="document") echo 'selected="selected"'; ?>>
						<?php echo JText::_('COM_VQUIZ_DOCUMENT'); ?>
					</option>
					<option value="image" <?php  if($this->item->type=="image") echo 'selected="selected"'; ?>>
						<?php echo JText::_('COM_VQUIZ_IMAGE'); ?>
					</option>
					
					<option value="video" <?php  if($this->item->type=="video") echo 'selected="selected"'; ?>>
						<?php echo JText::_('COM_VQUIZ_VIDEO'); ?>
					</option>	
					
					<option value="slide" <?php  if($this->item->type=="slide") echo 'selected="selected"'; ?>>
						<?php echo JText::_('COM_VQUIZ_SLIDE'); ?>
					</option>	
					
					<option value="file" <?php  if($this->item->type=="file") echo 'selected="selected"'; ?>>
						<?php echo JText::_('COM_VQUIZ_FILE'); ?>
					</option>	
					
				</select>
			</td>
        </tr>
		
		<tr>
        <td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_SKILLS_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_SKILLS'); ?></label></td>
		<td>
			<select name="skillid[]" id="skillid" class="inputbox" placeholder="<?php echo JText::_('COM_VQUIZ_SKILLS_SKILL'); ?>" multiple>

			
				<?php    
				$selectedid=$this->skills->selectedid;
				for ($i=0; $i <count($this->skills->skillid); $i++){	?>
				<option value="<?php echo $this->skills->skillid[$i]->id;?>" <?php  if(in_array($this->skills->skillid[$i]->id,$selectedid)) echo 'selected="selected"'; ?>>
					<?php echo $this->skills->skillid[$i]->title; ?>
				</option>		
				<?php	}?>
			</select>
		</td>
        </tr>
		
		<tr class="filetype">
		
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_CATEGORY_DESC'); ?>"><?php echo JText::_('FILE_UPLOAD'); ?></label></td>
			
			<td>
 
				<div class="all_container" style="<?php if($this->item->type == 'slide') echo "display:none;"?>">
					<?php 
					$imgsrc = JURI::root().'/media/com_vquiz/vquiz/images/files/'.$this->item->files;
					$filepath = JPATH_SITE.'/media/com_vquiz/vquiz/images/files/'.$this->item->files;
					?>
					<div id="fileinput">
						<input type="file" name="files"  id="files" class="inputbox" />
					</div>
					<?php 
					
					$imgext = array('jpg','jpeg','png','gif');
					$docext= array('doc','docx','txt','csv','xl');
					$pdfext= array('pdf','swf');
					$audext = array('mp3','wav','avi');
					$vidext = array('mp4','avi','mov');
					$lfile = array('zip','rar','exc');
					
					$filetype = JURI::root().'/media/com_vquiz/vquiz/images/files/'.$this->item->files;
					$ext = strtolower(pathinfo($filetype, PATHINFO_EXTENSION)); 
					
					if (in_array($ext, $imgext)) {				
					 if(!empty($this->item->files) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/files/'.$this->item->files)){ 
					   echo '<img height="50" width="50" src="'.JURI::root().'/media/com_vquiz/vquiz/images/files/'.$this->item->files. '" alt="" />'; 
					   }else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
				   }
					if (in_array($ext, $pdfext)) {				
					 if(!empty($this->item->files) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/files/'.$this->item->files)){ 
					   echo '<a class="prev" href="'.JURI::root().'/media/com_vquiz/vquiz/images/files/'.$this->item->files. '" target="_blank"> <img height="50" width="50" src="../media/com_vquiz/vquiz/images/pdf.png"/></a>'; 
					   echo $this->item->files; 
					   }
				   }
					if (in_array($ext, $docext)) {				
					 if(!empty($this->item->files) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/files/'.$this->item->files)){ 
					   echo '<a class="prev" href="'.JURI::root().'/media/com_vquiz/vquiz/images/files/'.$this->item->files. '" target="_blank"> <img height="50" width="50" src="../media/com_vquiz/vquiz/images/doc.png"/></a>'; 
					   echo $this->item->files; 
					   }
				   }
				   if (in_array($ext, $audext)) {				
					 if(!empty($this->item->files) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/files/'.$this->item->files)){ 
					  echo $this->item->files; 
					   }
				   }
				   
				   if (in_array($ext, $vidext)) {				
					 if(!empty($this->item->files) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/files/'.$this->item->files)){ 
					  echo $this->item->files; 
					   }
				   }
				   
				    if (in_array($ext, $lfile)) {				
					 if(!empty($this->item->files) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/files/'.$this->item->files)){ 
						echo $this->item->files; 
					   }
				   }
				   
				   ?>
				</div>  
 
				
				<div class="slide_container" style="<?php if($this->item->type !='slide') echo "display:none;"?>">
				
			   		<div id="fileinput_multiple">
						<input type="file" name="slide_img[]" id="files"  class="inputbox" size="50" multiple>
						<p><?php echo JText::_('COM_VQUIZ_UPLOAD_MULTI_SLIDER_IMAGE')?></p>
						<input type="hidden" name="files"  />
					</div>
					

					<div class="slideordering">			

						<table class="adminform table table-striped">
							<thead>
							<tr><th width="15"><?php echo JText::_("COM_VQUIZ_NUM");?></th><th><?php echo JText::_('COM_VQUIZ_SLIDE_IMAGE');?></th><th><?php echo JText::_('COM_VQUIZ_SLIDE_ORDERING');?></th><th width="15"><?php echo JText::_("COM_VQUIZ_REMOVE");?></th></tr>	
							</thead>
							
							<tbody id="selected_quizlist_table">
								<?php 
									$slide_img=json_decode($this->item->slide_img);
								if(!empty($slide_img)){
									foreach($slide_img as $key=>$pic){
									$slide_imgsrc = JURI::root().'/media/com_vquiz/vquiz/images/slide/'.$pic;
								?>
								<tr><td width="15"><b>&bull;</b></td>
								<td width="100">
									<div class="pr_p <?php echo 'slide_pics'.$key; ?>">
										<img src="<?php echo $slide_imgsrc; ?>" class="slideimg" width="100" height="100" onerror="this.style.display='none'" alt="<?php echo $pic;?>"/>
										<input type="hidden" name="slide_img_order[]" value="<?php echo $pic; ?>">
									</div>
								</td>
								
								<td width="100" class="center"><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span></td>
								
								<td width="15"><span><a class="btn btn-small btn-danger slide_rimg" href="javascript:void(0);" img="<?php echo $pic; ?>" id="<?php echo 'slide_pics'.$key; ?>"><i class="icon-delete"></a></td>
								
								</tr>
								<?php }
							}?>
							</tbody>
						</table>
					</div>		
				</div>		
 
			</td>
			
		</tr>
		<tr class="filename">
        <td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_FILE_NAME_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_FILE_NAME'); ?></label></td>
		<td>
			<label style="display: inline-block">\media\com_vquiz\vquiz\images\files\</label><input type="text"  name="filename" id="filename" class="filename" value="<?php echo $this->item->files;?>" />
		</td>
        </tr>
       <tr class="desc">
        <td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_LESSONS_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_LESSONS'); ?></label></td>
		<td>
			<?php 
				$editor = JFactory::getEditor();
				echo $editor->display("description",$this->item->description, "400", "300", "20", "5",true, null, null, null, array('mode' => 'simple'));
			?>
		</td>
        </tr>
        </table>
		</div>
		<div id="slider_options">
		    <table class="adminform table table-striped">
			<tr>
				<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_LESSONS_NUMBER_SLIDES_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_LESSONS_NUMBER_SLIDES'); ?></label></td>
				<td><input type="text"  name="num_carousel" id="num_carousel" class="title" value="<?php echo $this->item->num_carousel;?>"/></td>
			</tr>
			<tr>
				<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_LESSONS_MOVE_SLIDES_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_LESSONS_MOVE_SLIDES'); ?></label></td>
				<td><input type="text"  name="moveslides" id="moveslides" class="title" value="<?php echo $this->item->moveslides;?>"/></td>
			</tr>
			<tr>
				<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_LESSONS_CONTROL_SLIDES_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_LESSONS_CONTROL_SLIDES'); ?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="slide_control1" id="slide_control1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" name="slide_control" id="slide_control1" value="1" <?php if($this->item->slide_control ==1) echo 'checked="checked"';?>/>
					<label for="slide_control0" id="published0-lbl" class="radio"><?php echo JText::_('NO'); ?></label>
					<input type="radio" name="slide_control" id="slide_control0" value="0" <?php if($this->item->slide_control ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_LESSONS_AUTO_SLIDES_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_LESSONS_AUTO_SLIDES'); ?></label></td>
				<td>

					<fieldset class="radio btn-group">
					<label for="auto_slide1" id="auto_slide1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" name="auto_slide" id="auto_slide1" value="1" <?php if($this->item->auto_slide ==1) echo 'checked="checked"';?>/>
					<label for="auto_slide0" id="published0-lbl" class="radio"><?php echo JText::_('NO'); ?></label>
					<input type="radio" name="auto_slide" id="auto_slide0" value="0" <?php if($this->item->auto_slide ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_LESSONS_SLIDES_DELAY_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_LESSONS_SLIDES_DELAY'); ?></label></td>
				<td><input type="text"  name="slidesdelay" id="slidesdelay" class="title" value="<?php echo $this->item->slidesdelay;?>"/></td>
			</tr>
			</table>
		</div>
    </fieldset>

</div> 

<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="lessons" />
</form>