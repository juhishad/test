<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );
class VquizViewLearning extends JViewLegacy
{ 
 
	function display($tpl = null)
	{
		$user = JFactory::getUser();
		$mainframe =JFactory::getApplication();
		$context	= 'com_vquiz.learning.list.';
		$layout = JRequest::getCmd('layout', '');
		$search = $mainframe->getUserStateFromRequest( $context.'search', 'search', '',	'string' );
		$search = JString::strtolower( $search );

		$catid = $mainframe->getUserStateFromRequest( $context.'catid', 'catid', 0,	'int' );
		$publish_item= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );

		$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
		$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );

		$this->cats = $this->get('Cats');
		$this->form=$this->get('Form');

		if($layout == 'form')
		{
			$this->item =$this->get('Item');
			$this->access = $this->get('Access');
			$this->selectedQuizzes = $this->get('SelectedQuizzes');
			$this->quizids = $this->get('Quizids');
			$this->lessonids = $this->get('Lessonids');
			$this->configuration  = $this->get('Configuration');
 

			$this->lists['access'] = JHtml::_('access.assetgrouplist', 'access', $this->item->access,'size="5"',false);
			$isNew		= ($this->item->id < 1);
			JToolBarHelper::title( JText::_('LEARNING'), 'lightning.png' );
			if($isNew)	{
				JToolBarHelper::title( JText::_( 'NEW_LEARNING' ), 'lightning.png' );
				if(JFactory::getUser()->authorise('core.create','com_vquiz'))
				{
					JToolBarHelper::apply();
					JToolBarHelper::save();	
				}

			}else{
				JToolBarHelper::title( JText::_( 'EDIT_LEARNING' ), 'lightning.png' );
				if($user->authorise('core.edit','com_vquiz') OR ($user->authorise('core.edit.own','com_vquiz') and $this->item->created_by == $user->get('id'))){
					JToolBarHelper::apply();
					JToolBarHelper::save();		
				}
			}
			
			JToolBarHelper::cancel();
			JToolBarHelper::help('help', true);
			
		}else{
			
			
			$version = new JVersion;
			$joomla = $version->getShortVersion();
			$jversion = substr($joomla,0,3);
			$this->sidebar ='';
			if($jversion>=3.0)
			{
				$this->sidebar = JHtmlSidebar::render();
			}

			JToolBarHelper::title( JText::_('LEARNING'), 'lightning.png' );
			if($user->authorise('core.create','com_vquiz')){
				JToolBarHelper::addNew();
			}
			if(JFactory::getUser()->authorise('core.edit','com_vquiz')){
				JToolBarHelper::editList();
			}
			if(JFactory::getUser()->authorise('core.delete','com_vquiz')){
				JToolBarHelper::deleteList(JText::_('DO_YOU_WANT_DELETE_RECORD'));	
			}

			JToolBarHelper::help('help', true);

			if(JFactory::getUser()->authorise('core.admin','com_vquiz')){
				JToolBarHelper::preferences('com_vquiz','', '','ACL');
			}

			$this->items = $this->get('Items'); 
			$this->category  = $this->get('Category'); //print_r($this->category); exit;
			$this->pagination = $this->get('Pagination');

			$this->lists['search']= $search;
			$this->lists['publish_item']= $publish_item;
			$this->lists['catid']=$catid;

			// Table ordering.
			$this->lists['order_Dir'] = $filter_order_Dir;
			$this->lists['order']     = $filter_order;

		}

		 parent::display($tpl);

	}
 
}
 