<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');
JHTML::_('behavior.modal');

$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/select2.min.css');
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$document->addStyleSheet('components/com_vquiz/assets/css/jquery-ui.css');
$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');
$document->addScript('components/com_vquiz/assets/js/select2.min.js');

if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

$editor=JFactory::getEditor();
//print_r($this->configuration); 
//var_dump($this->item->ipaddress_allow);exit;
?>
			

<style type="text/css">
	.chzn-container-multi{
		display:none;
	}
	
</style>
<script type="text/javascript">
	var jq=jQuery.noConflict();
	
	SqueezeBox.loadModal = function(modalUrl,handler,x,y) {
		this.presets.size.x = 1024;
		this.initialize();      
		var options = {handler: handler, size: {x: x, y: y}
		};      

		this.setOptions(this.presets, options);
		this.assignOptions();
		this.setContent(handler,modalUrl);
	};	
	
	jq(document).ready(function(){
		//jq("#catid").chosen("destroy");
		jq( "#tabs" ).tabs();
		jq( "#tabs_certificate" ).tabs();
		jq( "#tabs_results" ).tabs();		
		jq(".js-example-tags").select2({
			tags: true
		})
		jq('.price').css("display","none");
		var set_price="<?php echo $this->item->set_price; ?>";
			
			if(set_price==1)
				{
					jq('.price').css("display","");
		 		}
		   
			 
		jq('.release_sequence').css("display","none");
		var release="<?php echo $this->item->level_release; ?>";
			
			if(release==='sequential')
				{
					jq('.release_sequence').css("display","contents");
				}
		
		
		jq(document).on('change',"#minimum_per",function () { 
			var value=jq(this).val();
			if(value==1){
				jq('#define_per').css('display','');
			}else{
				jq('#define_per').css('display','none');
			}
		});
		jq('#level_release').on('change',function(){
			var level_release=jQuery(this).val();
			//alert(level_release);
			if(level_release==='sequential')
				{
					jq('.release_sequence').css("display","contents");
				}
				else
				{
					jq('.release_sequence').css("display","none");
				}
			});
			
		jq('input[name="set_price"]').on('click',function(){
			if(jq(this).val()==0){
						jq('.price').css('display','none');
						
					}else{
						jq('.price').css('display','');
					}
			});
			
		jq(document).on('click',".icon-uparrow,.icon-downarrow",function () { 
			
			var $element = this;
			var row = jq($element).parents("tr:first");

			if(jq(this).is('.icon-uparrow')){
				var x=row.insertBefore(row.prev());
				var lenghth_tr=jq.parseJSON(JSON.stringify(x.prev())).length;
			}else{
				row.insertAfter(row.next());
			}

		});
		
		jq(document).on('click',".delete-lrow",function () {

			var selected_quiz_id=jq('#jform_request_quiz_id').val().split(',');
			var this_value=jq(this).attr('quizId');
 
			if(this_value!=0){
				if(jQuery.inArray(jq(this_value,selected_quiz_id)!== -1)){
					var index = selected_quiz_id.indexOf(this_value);
					if (index > -1) selected_quiz_id.splice(index, 1);
					jQuery('#jform_request_quiz_id').val(selected_quiz_id);
				} 
			}else{
				var selected_lessons_id=jq('#jform_request_lessons_id').val().split(',');
				var this_value=jq(this).parent('a').attr('lessonid');
				if(jQuery.inArray(jq(this_value,selected_lessons_id)!== -1)){
					var index = selected_lessons_id.indexOf(this_value);
					if (index > -1) selected_lessons_id.splice(index, 1);
					jQuery('#jform_request_lessons_id').val(selected_lessons_id);
				} 	
			}
			var row = jq(this).parents("tr:first");
			row.remove();
		});
		
				
		jq(document).on('click', '#quizzes_add_list',function(){
			var url = "<?php echo 'index.php?option=com_vquiz&view=quizmanager&tmpl=component&function=jSelectQuizzes_jform_request_id&from_userview=1&selected_lpath_userquiz='?>"+jQuery('#jform_request_quiz_id').val(); //&qtype=1
			SqueezeBox.initialize({});   
			SqueezeBox.loadModal(url,"iframe",1100,500);	
		}); 
		
		jq(document).on('click', '#lessons_add_list',function(){
			var url = "<?php echo 'index.php?option=com_vquiz&view=lessons&tmpl=component&function=jSelectLessons_jform_request_id&from_userview=1&selected_userlesson='?>"+jQuery('#jform_request_lessons_id').val();
			SqueezeBox.initialize({});   
			SqueezeBox.loadModal(url,"iframe",1100,500);	
		});

		jQuery('#display_result0').on('click',function(){ 								 
			jQuery('#tabs_results').css('display','none');
		});

		jQuery('#display_result1').on('click',function(){ 								 
			jQuery('#tabs_results').css('display','');
			
			jQuery('#tabs_results ul li a[href="#tabarticle"]').hide();
			jQuery('div#tabarticle').hide();
			
			jQuery('#tabs_results ul li a[href="#tabt"]').show();
			jQuery('div#tabt').show();
		});
		
		jQuery('#display_result2').on('click',function(){ 								 
			jQuery('#tabs_results').css('display','');
			
			jQuery('#tabs_results ul li a[href="#tabt"]').hide();
			jQuery('div#tabt').hide();
			
			jQuery('#tabs_results ul li a[href="#tabarticle"]').show();
			jQuery('div#tabarticle').show();
			
		});
		
		display_result=<?php echo isset($this->item->display_result)?$this->item->display_result:0?>;
		
		if(display_result==0){
			jQuery('#tabs_results').css('display','none');
		}else if(display_result==1){
			
			jQuery('#tabs_results').css('display','');
			
			jQuery('#tabs_results ul li a[href="#tabarticle"]').hide();
			jQuery('div#tabarticle').hide();
			
			jQuery('#tabs_results ul li a[href="#tabt"]').show();
			jQuery('div#tabt').show();
		}else if(display_result==2){
			
			jQuery('#tabs_results').css('display','');
			
			jQuery('#tabs_results ul li a[href="#tabt"]').hide();
			jQuery('div#tabt').hide();
			
			jQuery('#tabs_results ul li a[href="#tabarticle"]').show();
			jQuery('div#tabarticle').show();
		}
	
			//alert(jQuery('#display_result0').val());

	});
	
	
	function jSelectArticle_jform_request_id(id, title, object){
		jQuery('#selected_article_article_id').val(id);
		jQuery('#jform_request_selected_article').val(title);
		SqueezeBox.close();
	}
	
	function jSelectQuizzes_jform_request_id(id, title, object){
		
		
		if(jq('#jform_request_quiz_id').val()==''){
			var al_s_id=new Array();
		}else{
			var al_s_id=new Array(jq('#jform_request_quiz_id').val());
		}
		
		var al_id =new Array(id);
		for(var i=0;i<al_id.length;i++){
			if(jQuery.inArray(jq(al_id[i],al_s_id)== -1)){
				al_s_id.push(al_id[i]);
			} 
		}
		jQuery('#jform_request_quiz_id').val(al_s_id);
 
		var html='';
		var index=0;
		for(var i=0;i<id.length;i++){
			index=parseInt(i)+1;
			if(id[i]>0){
				html +='<tr><td><b>&bull;</b></td><td>'+title[i]+'<input type="hidden" value="'+id[i]+'" name="quizes_order[]"/><input type="hidden" value="0" name="lessons_order[]"/></td><td width="100"><?php echo JText::_('COM_VQUIZ_QUIZ')?></td><td class="center" width="100"><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span></td><td><span><a class="btn btn-small btn-danger delete-lrow" href="javascript:void(0);" quizId="'+id[i]+'" lessonid="0"><i class="icon-delete"></i></a></span></td></tr>';
			}
		}  
		jq('#selected_quizlist_table').append(html);
		SqueezeBox.close();
		
	}
	
	function jSelectLessons_jform_request_id(id, title, object){
 
		if(jq('#jform_request_lessons_id').val()==''){
			var al_s_id=new Array();
		}else{
			var al_s_id=new Array(jq('#jform_request_lessons_id').val());
		}
		
		var al_id =new Array(id);
		for(var i=0;i<al_id.length;i++){
			if(jQuery.inArray(jq(al_id[i],al_s_id)== -1)){
				al_s_id.push(al_id[i]);
			} 
		}
		jQuery('#jform_request_lessons_id').val(al_s_id);
		var html='';
		var index=0;
		for(var i=0;i<id.length;i++){
			index=parseInt(i)+1;
			if(id[i]>0){
				html +='<tr><td><b>&bull;</b></td><td>'+title[i]+'<input type="hidden" value="'+id[i]+'" name="lessons_order[]"/><input type="hidden" value="0" name="quizes_order[]"/></td><td width="100"><?php echo JText::_('COM_VQUIZ_LESSONS')?></td><td class="center" width="100"><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span></td><td><span><a class="btn btn-small delete-lrow quzid="0" lessonid="'+id[i]+'" btn-danger" href="javascript:void(0);" quizId="'+id[i]+'" ><i class="icon-delete"></i></a></span></td></tr>';
			}
		}  
		jq('#selected_quizlist_table').append(html);
		SqueezeBox.close();
				
	}
	
	
	
	
	Joomla.submitbutton = function(task) { //return true;
		
		if (task == 'cancel') {
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
 
			if(!jQuery('input[name="title"]').val()){
				alert('<?php echo JText::_('PLZ_ENTER_LEARNING_TITLE', true); ?>');
				document.adminForm.title.focus();
				return false;
			}
			
			if(!jQuery('select[name="catid"]').val()){
				alert('<?php echo JText::_('PLZ_SELECT_CATEGORY', true); ?>');
				//console.log(jQuery('input[name="catid"]').val());
				document.adminForm.catid.focus();
				return false;
			}
			
			
			
			var ipadd = jQuery('#select-choice').val();
			ipadd = ipadd+'';
			var split_ips = ipadd.split(',');
			var i;
			var ipformat = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/; 
     ipformat = /^(([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])\.){3}([0-9]|[1-9][0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])$/;
	       
			if(split_ips != 'null')	{
			for(i=0; i<split_ips.length; i++){
		
			if(!split_ips[i].match(ipformat)){ 
				alert('<?php echo JText::_('PLZ_ENTER_CORRECT_IP', true); ?>');
				document.adminForm.select-choice.focus();
				return false;
			}
				}
			}
			
			
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}
	
</script>

<style>
.selected_quizlist{
	overflow:auto;
	height:200px;
	width:100%
	display:inline-block;
	clear: both;
}
</style>

<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">

<div class="col101">

    <fieldset class="adminform">
		<legend><?php echo JText::_('LEARNINGPATH_DETAILS'); ?></legend>
	
	<div id="tabs">
	<ul>
		<li><a href="#b_t"><?php echo JText::_('COM_VQUIZ_LEARNING_BASIC'); ?></a></li>
		<li><a href="#a_t"><?php echo JText::_('COM_VQUIZ_LEARNING_ADVANCE'); ?></a></li>
		<li><a href="#lp_certificate"><?php echo JText::_('COM_VQUIZ_LEARNING_CERTIFICATE'); ?></a></li>
		<li><a href="#lp_results"><?php echo JText::_('COM_VQUIZ_LEARNING_RESULTS'); ?></a></li>
		<li><a href="#permissions"><?php echo JText::_('COM_VQUIZ_LEARNING_PERMISSIONS'); ?></a></li>
	</ul>
		
	<div id="b_t">
	
		<table class="adminform table table-striped">	
			<tr>
				<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('TT_LEARNINGTITLE'); ?>"><?php echo JText::_('LEARNINGTITLE'); ?></label></td>
				<td><input type="text"  name="title" id="title" class="title" value="<?php echo $this->item->title;?>"/></td>
			</tr>
			<tr>
				<td>
					<label><?php echo JText::_('ALIAS'); ?></label>
				</td>
				<td>
					<input type="text" name="alias" id="alias"  value="<?php echo !empty($this->item->alias)?$this->item->alias:'';?>"  placeholder="Automatic Genarated"/>
				</td>
			</tr>
			
			<tr>
				<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('TT_LEARNING_IMAGE_DESC'); ?>"><?php echo JText::_('TT_LEARNING_IMAGE'); ?></label></td>
				
				<td class="upimg">
					<input type="file" name="image" id="image">
					<?php 
						if(!empty($this->item->image) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/learning/thumbs/'.'thumb_'.$this->item->image)){ 
						echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/photoupload/learning/thumbs/'.'thumb_'.$this->item->image. '" alt="" />'; 
						}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
					?>
				</td>
			</tr>
			<?php if($this->configuration->payment_system==1){?>
			<tr class="set_lp_price">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LP_SET_PRICE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_LP_SET_PRICE'); ?></label></td>
				<td> 
					<fieldset class="radio btn-group" >
					<label for="set_price1" id="set_price1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" class="rbtn" name="set_price" id="set_price1" value="1" <?php if($this->item->set_price ==1) echo 'checked="checked"';?>/>
					<label for="set_price0" id="set_price0-lbl" class="radio"><?php echo JText::_('NOS'); ?></label>
					<input type="radio" class="rbtn" name="set_price" id="set_price0" value="0" <?php if($this->item->set_price ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
            </tr>

			<tr class="price">
						<td class="key" width="200"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_LP_PRICE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_LP_PRICE'); ?></label></td>
						<td><input type="text" name="price" id="price" class="price" value="<?php echo $this->item->price;?>">
						</td>
					</tr>
			<?php }?>
			 <tr>	
				<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_CATEGORY_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_CATEGORY'); ?></label></td>
				<td>
					<select name="catid" id="catid" class="inputbox" required="true">
					<option value=""><?php echo JText::_('COM_VQUIZ_SELECT_CATEGORY'); ?></option>
					<?php    for ($i=0; $i <count($this->cats); $i++){	?>
					<option value="<?php echo $this->cats[$i]->id;?>" <?php  if($this->cats[$i]->id == $this->item->catid) echo 'selected="selected"'; ?>>
						<?php echo str_repeat('- ', $this->cats[$i]->level).$this->cats[$i]->title; ?>
					</option>		
					<?php	}	?>
					</select>
				</td>
        </tr>
			<tr>
				<td class="key" width="200"><?php /*<label  class="hasTip" title="<?php echo JText::sprintf('LP_SELECT_QUIZZES_DESC'); ?>"><?php echo JText::_('LP_SELECT_QUIZZES'); ?></label>*/?></td>
				<td>
					<div class="quizzes_adds pull-left" >
					 <span class="input-append">
							
							<input type="hidden" value="<?php echo !empty($this->quizids)?implode(',',$this->quizids):'';?>" name="selected_quizzes_id" class="required modal-value" id="jform_request_quiz_id" aria-required="true" required="required">
							 				
							 <a  id="quizzes_add_list" href="javascript:void(0)" title="" class="btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_QUIZZES_DESC');?>"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_SELECT_QUIZZES");?></a>

					</span> 
					</div>
					
					<div class="lessons_adds pull-left offset1" >
						<span class="input-append">
						
							<input type="hidden" value="<?php echo !empty($this->lessonids)? implode(',',$this->lessonids):'';?>" name="selected_lessons_id" class="required modal-value" id="jform_request_lessons_id" aria-required="true" required="required">
							 
							<a  id="lessons_add_list" href="javascript:void(0)" title="" class="btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_LESSONS_DESC');?>"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_SELECT_LESSONS");?></a>
							
						</span> 
					</div>
					
					<div class="qnlordering">			
 
							<table class="adminform table table-striped">
								<thead>
								<tr><th width="15"><?php echo JText::_("COM_VQUIZ_NUM");?></th><th><?php echo JText::_('COM_VQUIZ_QUIZ_LESSONS');?></th><th width="100"><?php echo JText::_('COM_VQUIZ_TYPE');?></th><th width="100"><?php echo JText::_('COM_VQUIZ_QUIZ_PLAY_ORDERING');?></th><th width="15"><?php echo JText::_("COM_VQUIZ_REMOVE");?></th></tr>	
								</thead>	
								<tbody id="selected_quizlist_table">
								<?php 
								
								if(!empty($this->selectedQuizzes->quizids) OR !empty($this->selectedQuizzes->lessonids)){
									for($i=0;$i<count($this->selectedQuizzes->quizids);$i++){
										$index=$index_quiz=$index_lesson=-1;									
									?>
									<tr><td width="15"><b>&bull;</b></td>
									<td>
									<?php 
									if($this->selectedQuizzes->quizids[$i]!=0 ){ 
										$index_quiz=0;
										
										$index=array_search($this->selectedQuizzes->quizids[$i],$this->selectedQuizzes->quizdatacolumn);
										
										
										echo isset($this->selectedQuizzes->quizdata[$index]->quiztitle)?$this->selectedQuizzes->quizdata[$index]->quiztitle:'';?>
										
										<input style="width:20px;" type="hidden" value="<?php echo isset($this->selectedQuizzes->quizdata[$index]->id)?$this->selectedQuizzes->quizdata[$index]->id:0;?>" name="quizes_order[]"/>
										<input type="hidden" value="0" name="lessons_order[]"/>
										
									<?php } elseif($this->selectedQuizzes->lessonids[$i]!=0){ 
											$index_lesson=0;
											$index=array_search($this->selectedQuizzes->lessonids[$i],$this->selectedQuizzes->lessondatacolumn);

											echo isset($this->selectedQuizzes->lessondata[$index]->lessontitle)?$this->selectedQuizzes->lessondata[$index]->lessontitle:'';?>
											
											<input type="hidden" value="<?php echo $this->selectedQuizzes->lessondata[$index]->id;?>" name="lessons_order[]"/>
											<input type="hidden" value="0" name="quizes_order[]"/>
											
									<?php } ?>
									</td>
									<td width="100"><?php echo $index_quiz==0?JText::_('COM_VQUIZ_QUIZ'):JText::_('COM_VQUIZ_LESSONS') ?></td>
									<td width="100" class="center"><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span></td>
									
									<td width="15"><a class="btn btn-small btn-danger delete-lrow" href="javascript:void(0);" lessonid="<?php echo (($index_lesson!=-1)and isset($this->selectedQuizzes->lessondata[$index]->id))?$this->selectedQuizzes->lessondata[$index]->id:0?>" quizid="<?php echo (isset($this->selectedQuizzes->quizdata[$index]->id) and ($index_quiz!=-1))?$this->selectedQuizzes->quizdata[$index]->id:0?>"><i class="icon-delete"></a></td>
									
									</tr>
									<?php }
								}?>
								</tbody>
							</table>
					</div>
				</td>
			</tr>					
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LP_DESCRIPTION_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_LP_DESCRIPTION'); ?></label></td>
				<td> 
					<?php 
						echo $editor->display("description",  $this->item->description, "150", "150", "20", "5", 1, null, null, null, array());
						?>
				</td>
            </tr>

		</table>
	</div>
	
		<div id="a_t">
							
		<table class="adminform table table-striped">
		
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_STATUS_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_STATUS'); ?></label></td>
				<td> 
					<fieldset class="radio btn-group">
					<label for="published1" id="published1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?></label>
					<input type="radio" name="published" id="published1" value="1" <?php if($this->item->published ==1) echo 'checked="checked"';?>/>
					<label for="published0" id="published0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?></label>
					<input type="radio" name="published" id="published0" value="0" <?php if($this->item->published ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
            </tr>
			
			 <tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_PUBLISH_DATE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_STARTPUBLISHDATE'); ?></label>
					</td>
					
					<td>
					
					<?php 
						$startpublishStrtime=strtotime($this->item->startpublish_date);
						$startpublish_date=$startpublishStrtime>0?$startpublishStrtime:strtotime("now");
						echo JHTML::calendar(date('Y-m-d G:i:s', $startpublish_date),'startpublish_date', 'startpublish_date', '%Y-%m-%d %H:%M:%S',array('size'=>'8','maxlength'=>'19','placeholder'=>'start Publish date',));
					?>
					
					</td>
                </tr>
				
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_EPDATE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_ENDPUBLISHDATE'); ?></label></td>

					<td> 
					
						<?php 
						$endpublishStrtime=strtotime($this->item->endpublish_date);
						$endpublish_date=$endpublishStrtime>0?$endpublishStrtime:strtotime("+1 year");
						echo JHTML::calendar( date('Y-m-d G:i:s', $endpublish_date),'endpublish_date', 'endpublish_date', '%Y-%m-%d %H:%M:%S',array('size'=>'8','maxlength'=>'19','placeholder'=>'end Publish date',));
						?>	

					</td>
					
                </tr>
				<tr>
				<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('LEVEL_RELEASE_DESC'); ?>"><?php echo JText::_('LEVEL_RELEASE'); ?></label></td>
				<td>
					<select name="level_release" id="level_release">
						<option value="all" <?php if($this->item->level_release =='all') echo 'selected="selected"'; ?>><?php echo JText::_('ALL_AT_ONCE'); ?></option>
						<option value="sequential" <?php if($this->item->level_release =='sequential') echo 'selected="selected"'; ?>><?php echo JText::_('SEQUENTIAL'); ?></option>
							
					</select>
				</td>
			</tr>
			<tr class="release_sequence">
				<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('RELEASE_SEQUENCE_DESC'); ?>"><?php echo JText::_('RELEASE_SEQUENCE'); ?></label></td>
				<td>
					<label  class="hasTip" title="<?php echo JText::sprintf('QUIZ_LESSONS_DESC'); ?>" style="display: inline-block"><?php echo JText::_('QUIZ_LESSONS'); ?></label>
						<input type="text" name="quiz_lesson" id="quiz_lesson"   value="<?php echo $this->item->quiz_lesson?>"  style="width:50px" />
					<label  class="hasTip" title="<?php echo JText::sprintf('QUIZ_LESSONS_COUNT_DESC'); ?>" style="display: inline-block"><?php echo JText::_('QUIZ_LESSONS_COUNT'); ?></label>
						<input type="text" name="quiz_lesson_delay_count" id="quiz_lesson_delay_count"   value="<?php echo $this->item->quiz_lesson_delay_count?>"  style="width:50px" />
					
						<select  name="quiz_lesson_delay" id="quiz_lesson_delay" >
							<option value="hour" <?php if($this->item->quiz_lesson_delay=='hour') echo 'selected="selected"'; ?>><?php echo JText::_('HOURS'); ?> </option>
							<option value="days" <?php if($this->item->quiz_lesson_delay=='days') echo 'selected="selected"'; ?> ><?php echo JText::_('DAYS'); ?> </option>
							<option value="week" <?php if($this->item->quiz_lesson_delay=='week') echo 'selected="selected"'; ?> ><?php echo JText::_('WEEKS'); ?> </option>
							<option value="month" <?php if($this->item->quiz_lesson_delay=='month') echo 'selected="selected"'; ?> ><?php echo JText::_('MONTHS'); ?> </option>
						</select>
				</td>
			</tr>
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_ATTEMPTCOUNT_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_LEARNING_ATTEMPTCOUNT'); ?></label></td>
					<td>
						<input type="text" name="attempt_count" id="attempt_count" value="<?php echo $this->item->attempt_count?>" />
					</td>
				</tr>
				
				
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_DELAYBETWEENATTEMPT_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_DELAYBETWEENATTEMPT'); ?></label></td>
					<td>
						<input type="text" name="attempt_delay" id="attempt_delay"   value="<?php echo $this->item->attempt_delay?>"  style="width:50px" />
						
						<select  name="attempt_delay_param" id="attempt_delay_param" >
						<option value="hour" <?php if($this->item->attempt_delay_param=='hour') echo 'selected="selected"'; ?>><?php echo JText::_('HOURS'); ?> </option>
						<option value="days" <?php if($this->item->attempt_delay_param=='days') echo 'selected="selected"'; ?> ><?php echo JText::_('DAYS'); ?> </option>
						<option value="week" <?php if($this->item->attempt_delay_param=='week') echo 'selected="selected"'; ?> ><?php echo JText::_('WEEKS'); ?> </option>
						<option value="month" <?php if($this->item->attempt_delay_param=='month') echo 'selected="selected"'; ?> ><?php echo JText::_('MONTHS'); ?> </option>
						</select>
					</td>
				</tr>
			
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_CHECK_IP_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_CHECK_IP'); ?></label></td>
					<td>
						<select name="ipaddress_allow[]" id="select-choice" class="js-example-tags" multiple>
							<?php 
							
							

							 if(!empty($this->item->ipaddress_allow)){ //exit;
							 $ipaddress_allow=explode(',',$this->item->ipaddress_allow);
								for($j=0;$j<count($ipaddress_allow);$j++){?>
								<option value="<?php echo $ipaddress_allow[$j];?>" selected='selected'><?php echo $ipaddress_allow[$j];?></option>
							<?php 
								}
							} 
							?>
						</select>
					</td>
				</tr>
				<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LP_RESTRICTION_PATH_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_LP_RESTRICTION_PATH'); ?></label></td>
				<td> 
					<fieldset class="radio btn-group">
					<label for="urlrestriction1" id="urlrestriction1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" name="urlrestriction" id="urlrestriction1" value="1" <?php if($this->item->urlrestriction ==1) echo 'checked="checked"';?>/>
					<label for="urlrestriction0" id="urlrestriction0-lbl" class="radio"><?php echo JText::_('NOS'); ?></label>
					<input type="radio" name="urlrestriction" id="urlrestriction0" value="0" <?php if($this->item->urlrestriction ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
				
            </tr>
			
			<tr>
				<td valign="top" class="key" width="200">
				<label><?php echo JText::_( 'ACCESS_LEVEL' ); ?></label>
				</td>
				<td><label><?php echo  JHtml::_('access.assetgrouplist', 'access', $this->item->access,'size="5"',false); ?></label></td>
			</tr>
			<tr>
				<td class="key"><label><?php echo JText::_('COM_VQUIZ_LANGUAGE'); ?></label></td>
				<td colspan="2">
				<select name="language" id="language">
				<?php echo JHtml::_('select.options', JHtml::_('contentlanguage.existing', true, true), 'value', 'text', $this->item->language);?>
				</select>
				</td>
			</tr>

			<tr>
				<td><label class="hasTip" title="<?php echo JText::_('LP_MINIMUM_PERCENTAGE_DESC'); ?>"><?php echo JText::_('LP_MINIMUM_PERCENTAGE'); ?></label></td>
				<td>
					<select name="minimum_per" id="minimum_per"> 
						<option value="0" <?php if($this->item->minimum_per==0) echo "selected='selected'";?>><?php echo JText::_('LP_QUIZ_INHERIT')?></option>
						<option value="1" <?php if($this->item->minimum_per==1) echo "selected='selected'";?>><?php echo JText::_('LP_CUSTOM')?></option>
					</select>
				
				</td>
				</tr>
				
				
				<tr id="define_per" style="<?php echo $this->item->minimum_per==0?'display:none':'xx';?>">
				<td><label class="hasTip" title="<?php echo JText::_('LP_DEFINE_PERCENTAGE_DESC'); ?>"><?php echo JText::_('LP_DEFINE_PERCENTAGE'); ?></label></td>
				<td>
					<input type="text" name="minimum_custom_per" value="<?php echo $this->item->minimum_custom_per;?>"/>
				</td>
				</tr>	

				
					
				
			</table>
				
		</div>
		
		<div  id="lp_certificate">
				<fieldset class="adminform">   
					<legend>
					<div class="pull-left"><?php echo JText::_( 'COM_VQUIZ_LEARNING_PATH_CERTIFICATE'); ?></div>
						<div class="pull-left offset1">				
							<fieldset class="radio btn-group">

								<label for="display_certificate1" id="display_certificate1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_LEARNING_SHOW'); ?></label>
								<input type="radio" name="display_certificate" id="display_certificate1" value="1" <?php if($this->item->display_certificate ==1) echo 'checked="checked"';?>/>
								<label for="display_certificate0" id="display_certificate0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_LEARNING_HIDE'); ?></label>
								<input type="radio" name="display_certificate" id="display_certificate0" value="0" <?php if($this->item->display_certificate ==0) echo 'checked="checked"';?>/>
								
							</fieldset>
						</div>
					</legend>
					
			<div class="conf_left_panel">
			
				<?php /*<div id="tabs_certificate">
					<ul>
					<li><a href="#certificate_set"><?php echo JText::_('COM_VQUIZ_QUIZZES_CERTIFICATE_NUMBER'); ?></a></li>
					<li><a href="#certificate_tem"><?php echo JText::_('COM_VQUIZ_QUIZZES_CERTIFICATE_TEMPLATE'); ?></a></li>
					</ul>
					

					<div  id="certificate_set">
							<table class="adminform table table-striped" width="100%">
								<tbody>
									<tr>
										<td><label><?php echo JText::_('COM_VQUIZ_QUIZZES_START_WITH');?></label></td>
										<td><label ><input type="text" name="start_with" value="<?php echo $this->item->start_with?>"/></label></td>
									</tr>
									
									<tr>
										<td><label><?php echo JText::_('COM_VQUIZ_TYPES');?></label></td>
										<td><label>
											<select name="cet_type" id="cet_type">
											<option value="0" <?php if($this->item->cet_type==0) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_CET_SEQ');?></option>
											<option value="1" <?php if($this->item->cet_type==1) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_CET_RAND');?></option>
											</select>
											
										</label></td>
									</tr>
									<tr class="cet_format" style="<?php if($this->item->cet_type==0) echo 'display:none';?>">
										<td><label><?php echo JText::_('COM_VQUIZ_FORMAT');?></label></td>
										<td><label>
											<select name="cet_format" id="cet_format">
											<option value="0" <?php if($this->item->cet_format==0) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_NUMERIC');?></option>
											<option value="1" <?php if($this->item->cet_format==1) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_ALPHA_NUMERIC');?></option>
											<option value="2" <?php if($this->item->cet_format==2) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_ALPHABETIC');?></option>
											</select>
											
										</label></td>
									</tr>
									
									<tr>
										<td><label><?php echo JText::_('COM_VQUIZ_QUIZZES_NUMBER_OF_DIGITS');?></label></td>
										<td><label>
											<input type="text" name="cet_digits" value="<?php echo $this->item->cet_digits;?>"/>
										</label></td>
									</tr>
									
									<tr>
										<td><label ><?php echo JText::_('COM_VQUIZ_QUIZZES_END_WITH');?></label></td>
										<td><label ><input type="text" name="end_with" value="<?php echo $this->item->end_with?>"/></label></td>
									</tr>
									
									
								</tbody>
							</table>
					</div> 

					<div  id="certificate_tem">
						<h4><?php echo JText::_('COM_VQUIZ_QUIZZES_TEMPLATE')?></h4>
						<?php 
						echo $editor->display("certificate",  $this->item->certificate, "400", "400", "20", "5", 1, null, null, null, array('mode' => 'simple'));
						?>
					</div>

				</div>*/?>
				
				<div  id="certificate_tem">
					<h4><?php echo JText::_('COM_VQUIZ_QUIZZES_TEMPLATE')?></h4>
					<?php 
					echo $editor->display("certificate",  $this->item->certificate, "400", "400", "20", "5", 1, null, null, null, array());
					?>
				</div>
				<br />
				<div  id="certificate_tem_multi">
					<h4><?php echo JText::_('COM_VQUIZ_QUIZZES_TEMPLATE_CERTIFICATE_MULTI_ITEM')?></h4>
					<?php 
					echo $editor->display("certificate_multi_item",  $this->item->certificate_multi_item, "400", "400", "20", "5", 1, null, null, null, array());
					?>
				</div>
			</div>

				<div class="conf_right_panel"> 

					<div class="conf-para">
					<h3><?php echo JText::_("COM_VQUIZ_QUIZZES_PARAMETER");?></h3>

						<div class="">						
							 
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{firstname}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USER_FIRSTNAME')?>">{firstname}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{middlename}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USER_MIDDLENAME')?>" >{middlename}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{lastname}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USER_LASTNAME')?>" >{lastname}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{username}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERNAME')?>" >{username}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{email}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_EMAIL')?>" >{email}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{learningtitle}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LEARNING_TITLE')?>" >{learningtitle}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{total_quizzes}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_TOTAL_QUIZZES')?>" >{total_quizzes}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{articleid}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_ARTICLE_ID')?>" >{articleid}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{current_date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CURRENT_DATE')?>" >{current_date}</span></a>
							<br>
							
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{lesson_title}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_LESSON_TITLE')?>" >{lesson_title}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{lesson_hour}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_LESSON_HOUR')?>" >{lesson_hour}</span></a>
							<br>

							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{lesson_minute}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_LESSON_MINUTE')?>" >{lesson_minute}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{lesson_total_hour}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_LESSON_TOTAL_HOUR')?>" >{lesson_total_hour}</span></a>
							<br>

							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{lesson_total_minute}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_LESSON_TOTAL_MINUTE')?>" >{lesson_total_minute}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{passed_date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PASSED_DATE')?>" >{passed_date}</span></a>
							<br>
							
							
						</div>

					</div>

				</div>                 
				</fieldset>
			</div>
			<!-- Permissions tab-->
		<div id="permissions">
		<div id="jform_title">
			<tr>
				<td>
						<?php echo $this->form->getInput('rules'); ?>
				</td>
			</tr>
		</div>
		</div>	
			<!--Result Template Container-->

			<div  id="lp_results">    
					
					
				<fieldset class="adminform">   
				
					<legend>
					
					<div class="pull-left"><?php echo JText::_( 'COM_VQUIZ_LEARNING_PATH_FINAL_RESULTS'); ?></div>
						<div class="pull-left offset1">				

						<fieldset class="radio btn-group">
						
						<label for="display_result2" id="display_result1-lb2" class="radio"><?php echo JText::_('COM_VQUIZ_LEARNING_DISPLAY_ARTICLE'); ?></label>
						<input type="radio" name="display_result" id="display_result2" value="2" <?php if($this->item->display_result ==2) echo 'checked="checked"';?>/>
						
						<label for="display_result1" id="display_result1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_LEARNING_DISPLAY_TEMPLATE'); ?></label>
						<input type="radio" name="display_result" id="display_result1" value="1" <?php if($this->item->display_result ==1) echo 'checked="checked"';?>/>
						
						<label for="display_result0" id="display_result0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_LEARNING_HIDE'); ?></label>
						<input type="radio" name="display_result" id="display_result0" value="0" <?php if($this->item->display_result ==0) echo 'checked="checked"';?>/>
						
						</fieldset>
						
						
						</div>
					</legend>

					<div id="tabs_results">
						<ul>
							<li><a href="#tabt"><?php echo JText::_('COM_VQUIZ_TEMPLATE'); ?></a></li>
							<li><a href="#tabarticle"><?php echo JText::_('COM_VQUIZ_SELECT_ARTICLE'); ?></a></li>
						</ul>	
						
						<div id="tabt">
							<div class="conf_left_panel">
								<?php 
								echo $editor->display("trivia_results",  $this->item->trivia_results, "400", "400", "20", "5", 1, null, null, null, array());
								?>
							</div>
							
							<div class="conf_right_panel">
								<h3><?php echo JText::_("COM_VQUIZ_PARAMETER");?></h3>
										<div class="">						
											
											
											
											<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{username}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERNAME')?>" >{username}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{email}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_EMAIL')?>" >{email}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{learningtitle}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LEARNING_TITLE')?>" >{learningtitle}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{total_quizzes}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_TOTAL_QUIZE')?>" >{total_quizzes}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{articleid}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_ARTICLE_ID')?>" >{articleid}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{current_date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CURRENT_DATE')?>" >{current_date}</span></a>
							<br>

										</div>
									</div>
								</div> 
								
								<div  id="tabarticle">								
									
									<input type="text" size="80"  value="" id="jform_request_selected_article" name="selected_article" class="input-medium" />
								
									<input type="hidden" value="<?php echo $this->item->article_id;?>" name="article_id" class="required modal-value" id="selected_article_article_id" aria-required="true" required="required">

									<a currten_id="" rel="{handler: 'iframe', size: {x: 800, y: 450}}" href="index.php?option=com_content&view=articles&layout=modal&tmpl=component&function=jSelectArticle_jform_request_id&<?php echo JSession::getFormToken();?>=1" title="" class="modal btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_ARTICLE');?>"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_SELECT_ARTICLE");?></a> 
								 
									<input type="button" value="Reset" name="reset" currten_id="" id="reset_article" class="btn reset">
								
								</div>
							</div>
					</div> 
				</fieldset>
			</div>
		</div> 
	</fieldset>
</div> 

<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="learning" />
<input type="hidden" name="" id="learning_path_order" value="learning" />
</form>