<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.tooltip');
JHTML::_('behavior.modal');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$document->addStyleSheet('components/com_vquiz/assets/css/jquery-ui.css');
//$document->addScript('components/com_vquiz/assets/js/library.js');
$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');
?>

<script type="text/javascript">
var jq=jQuery.noConflict();
jq(document).ready(function(){
	jq( "#tabs" ).tabs();
	
	
	jq('#reset_category').click(function(){
		jQuery('#jform_request_category_id').val('');
		
		//jQuery('#selected_user_category_quiz').val('');
		
		jQuery('#jform_request_category_id_anchor').attr('href',"index.php?option=com_vquiz&view=quizcategory&tmpl=component&function=jSelectCategory_jform_request_id&from_userview=1&selected_usercategory=0");
				
		jQuery('#category_count').text('0');
		//jQuery('#jform_request_category_id_name').val('<?php echo JText::_('COM_VQUIZ_SELECT_CATEGORY');?>');	
	});
	
	jq('#reset_quiz').click(function(){
		jQuery('#jform_request_id_id').val('');
		
		jQuery('#jform_request_id_id_anchor').attr('href',"index.php?option=com_vquiz&view=quizmanager&tmpl=component&function=jSelectQuizzes_jform_request_id&from_userview=1&selected_userquiz=0&selected_usercategory=0");
		
		jQuery('#quiz_count').text('0');
		
		//jQuery('#jform_request_id_name').val('<?php echo JText::_('COM_VQUIZ_SELECT_QUIZ');?>');	
	});
	
	jq('#reset_users').click(function(){
		jQuery('#jform_request_user_id').val('');
		
		jQuery('#jform_request_user_id_anchor').attr('href',"index.php?option=com_vquiz&view=users&tmpl=component&function=jSelectUsers_jform_request_id&from_userview=1&selected_users=0");
		
		jQuery('#user_count').text('0');
		
		//jQuery('#jform_request_user_name').val('<?php echo JText::_('COM_VQUIZ_SELECT_USER');?>');	
	});
	

});
		
	function jSelectCategory_jform_request_id(id, title, object){
		jQuery('#jform_request_category_id').val(id);
		
		selected_usercategory = jQuery('#jform_request_category_id').val();
		jQuery('#jform_request_category_id_anchor').attr('href',"index.php?option=com_vquiz&view=quizcategory&tmpl=component&function=jSelectCategory_jform_request_id&from_userview=1&selected_usercategory="+selected_usercategory);
		
		//jQuery('#jform_request_category_id_name').val(title);	
		var obj_length = Object.keys(id).length;
		jQuery('#category_count').text(obj_length);
		
		//set quiz category in quiz section

		selected_userquiz = jQuery('#jform_request_id_id').val();
		selected_usercategory = jQuery('#jform_request_category_id').val();
			
		
		jQuery('#jform_request_id_id_anchor').attr('href',"index.php?option=com_vquiz&view=quizmanager&tmpl=component&function=jSelectQuizzes_jform_request_id&from_userview=1&selected_userquiz="+selected_userquiz+"&selected_usercategory="+selected_usercategory);
		
		
		SqueezeBox.close();
	}
	
	function jSelectQuizzes_jform_request_id(id, title, object){
		jQuery('#jform_request_id_id').val(id);		
			//console.log(2);	
		selected_userquiz = jQuery('#jform_request_id_id').val();
		selected_usercategory = jQuery('#jform_request_category_id').val();//get quiz category
		//console.log(selected_usercategory);
		jQuery('#jform_request_id_id_anchor').attr('href',"index.php?option=com_vquiz&view=quizmanager&tmpl=component&function=jSelectQuizzes_jform_request_id&from_userview=1&selected_userquiz="+selected_userquiz+"&selected_usercategory="+selected_usercategory);
		
		
		var obj_length = Object.keys(id).length;
		jQuery('#quiz_count').text(obj_length); 
		
		
		SqueezeBox.close();
	}
	
	function jSelectUsers_jform_request_id(id, title, object){
		jQuery('#jform_request_user_id').val(id);
		
		selected_users = jQuery('#jform_request_user_id').val();
		
		jQuery('#jform_request_user_id_anchor').attr('href',"index.php?option=com_vquiz&view=quizmanager&tmpl=component&function=jSelectQuizzes_jform_request_id&from_userview=1&selected_users="+selected_users);
		
		
		var obj_length = Object.keys(id).length;
		
		jQuery('#user_count').text(obj_length);
		
		SqueezeBox.close();
	}
	
	Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
			 
			if(!jQuery('input[name="name"]').val()){
				alert('<?php echo JText::_('PLZ_ENTER_NAME', true); ?>');
				document.adminForm.name.focus();
				return false;
			}
			if(!jQuery('input[name="username"]').val()){
				alert('<?php echo JText::_('PLZ_ENTER_USERNAME', true); ?>');
				document.adminForm.username.focus();
				return false;
			}
			if(!jQuery('input[name="email"]').val()){
				alert('<?php echo JText::_('PLZ_ENTER_EMAIL', true); ?>');
				 document.adminForm.email.focus();
				return false;
			}

			/* document.getElementById('jform_request_id_name').disabled = false;
			document.getElementById('jform_request_category_id_name').disabled = false;
			document.getElementById('jform_request_user_name').disabled = false; */
			Joomla.submitform(task, document.getElementById('adminForm'));
		}
	}
	
	
</script>

<div id="dabpanel">

<form action="index.php?option=com_vquiz&view=users" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col101 user_details">
<legend><?php echo JText::_('COM_VQUIZ_QUIZ_RESULT_DETAILS'); ?></legend>
	<div id="tabs">
	
        <ul>
        <li><a href="#general"><?php echo JText::_('COM_VQUIZ_USERS_MAINSETTING'); ?></a></li>
        <li><a href="#access"><?php echo JText::_('COM_VQUIZ_USERS_ACCESS_SETTING'); ?></a></li>
        </ul>
		
	<div id="general">
	<fieldset class="adminform">
		<legend><?php echo JText::_('COM_VQUIZ_DETAILS'); ?></legend>
		<table class="adminform table table-striped">
		  <tr>
			<td width="200"><label class="required"><?php echo JText::_('NAME'); ?></label></td>
			<td><input type="text" name="name" id="name" class="inputbox required" value="<?php echo $this->item->name; ?>" size="50" /></td>
		  </tr>
		  <tr>
			<td><label class="required"><?php echo JText::_('USERNAME'); ?></label></td>
			<td><input type="text" name="username" id="username" class="inputbox required" value="<?php echo $this->item->username; ?>" size="50" /></td>
		  </tr>
		  <tr>
			<td><label class="required"><?php echo JText::_('PASSWORD'); ?></label></td>
			<td><input type="password" class="inputbox" name="password" autocomplete="off" value="" cols="39" rows="5" /></td>
		  </tr>
		   <tr>
			<td><label class="required"><?php echo JText::_('EMAIL'); ?></label></td>
			<td><input type="text" class="inputbox required" name="email" maxlength="100" size="50" value="<?php echo $this->item->email;?>" /></td>
		  </tr>
			  <tr>
				<td><label class="required"><?php echo JText::_('BLOCK'); ?></label></td>
				<td>
				
				<fieldset class="radio btn-group">
							<label for="block1" id="block1-lbl" class="radio"><?php echo JText::_( 'YS' ); ?></label>
							<input type="radio" name="block" id="block1" value="1" <?php if($this->item->block==1) echo 'checked="checked"';?>/>
							<label for="block0" id="block0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
							<input type="radio" name="block" id="block0" value="0" <?php if($this->item->block==0) echo 'checked="checked"';?>/>
						</fieldset>
				
				
				<!--<select name="block" id="block" class="inputbox">
			 
					
					<option value="0" <?php if($this->item->block=="0") echo 'selected="selected"'; ?>><?php echo JText::_('No'); ?></option>
					<option value="1" <?php if($this->item->block == "1") echo 'selected="selected"'; ?>><?php echo JText::_('Yes'); ?></option>
				</select> -->
			   </td>
			  </tr>
				<tr>
					<td><label class="required"><?php echo JText::_('COUNTRY'); ?></label></td>
					<td><input type="text" class="inputbox required" name="country" maxlength="100" size="50" value="<?php echo $this->item->country;?>" /></td>
				</tr>
				
				<tr>
					<td><label class="required"><?php echo JText::_('GENDER'); ?></label></td>
					<td>
							<input type="radio" class="inputbox" name="gender"  value="0" <?php if($this->item->gender==0) echo 'checked="checked"';?> style="display:inline-block"/>
							<?php echo JText::_('MALE'); ?>
							<input type="radio" class="inputbox" name="gender"  value="1" <?php if($this->item->gender==1) echo'checked="checked"';?>  style="display:inline-block"/>
							<?php echo JText::_('FEMALE'); ?>
						</td>
				</tr>
				<tr>
					<td><label class="required"><?php echo JText::_('COMMENT_SECTION'); ?></label></td>
					<td>
							<textarea name="comment"><?php echo $this->item->comment;?></textarea>
						</td>
				</tr>
				
			  <tr>
				  <td><label class="hasTip" title="<?php echo JText::_('PROFILE_PICS'); ?>"><?php echo JText::_('PROFILE_PICS'); ?></label></td>
				  <td class="profile_picture"><input type="file" name="profile_pic" id="profile_pic" class="inputbox required" size="50" value=""/>
						<?php 
							if(!empty($this->item->profile_pic)){ 
							echo '<img src="'.JURI::root().'administrator/components/com_vquiz/assets/uploads/users/'.$this->item->profile_pic.'"/>'; 
							}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="'.JText::_('IMAGE_NOT_AVAILABLE').'" border="1" />';} 
						?>
					</td>
				</tr>
			</table>
		</fieldset>
		</div>
		<div id="access">
				<table class="adminform table table-striped">
				
					<tr>
					<td><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CATEGORY_MONITOR_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_CATEGORY')?></label>
					</td>
					<td>

					   <span class="input-append">
					   <?php 
					   
						   if(!empty($this->monitercategory)){
								$monitor_category=implode(',',$this->monitercategory);
						   }else{
								$monitor_category='';
						   }
						   
						   $monitorcategorytitle=!empty($monitor_category)?$monitor_category:JText::_('COM_VQUIZ_SELECT_CATEGORY');
						?>
						
							<?php /*<input type="text" size="80" disabled="disabled" value="<?php echo $monitorcategorytitle;?>" id="jform_request_category_id_name" name="monitor_category_title[]" class="input-medium" />*/?>
							
							<input type="hidden" value="<?php echo $monitor_category;?>" name="monitor_category" class="required modal-value" id="jform_request_category_id" aria-required="true" required="required">
													
							
							 <a id="jform_request_category_id_anchor" currten_id="" rel="{handler: 'iframe', size: {x: 800, y: 450}}" href="index.php?option=com_vquiz&amp;view=quizcategory&amp;tmpl=component&amp;function=jSelectCategory_jform_request_id&from_userview=1&selected_usercategory=<?php echo $monitor_category;?>" title="" class="modal btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_CATEGORY');?>"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_VIEW_OR_EDIT");?></a> 
							 
							<input type="button" value="Reset" name="reset" currten_id="" id="reset_category" class="btn reset">
														
						</span>
						<span id="category_count"><?php if($this->monitercategory[0]!=0){echo count($this->monitercategory);}else{echo 0;} ?></span> <?php echo " category selected.";?>
						
				</td>
				</tr>
				
				<tr>
				<td><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZ_MONITOR_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZ')?></label>
					
				</td>
				<td>
				
					
					
					   <span class="input-append">
					   <?php 
						   
						   if(!empty($this->moniterquiz)){
								$monitor_quiz=implode(',',$this->moniterquiz);
						   }else{
								$monitor_quiz='';
						   }
						   
						   $monitor_quiz_title=!empty($monitor_quiz)?$monitor_quiz:JText::_('COM_VQUIZ_SELECT_QUIZ');
						?>
						
						
							<?php /*<input type="text" size="80" disabled="disabled" value="<?php echo $monitor_quiz_title;?>" id="jform_request_id_name" name="monitor_quiz_title" class="input-medium" />*/?>
							
							<input type="hidden" value="<?php echo $monitor_quiz;?>" name="monitor_quiz" class="required modal-value" id="jform_request_id_id" aria-required="true" required="required">

							 <a id="jform_request_id_id_anchor" currten_id="" rel="{handler: 'iframe', size: {x: 800, y: 450}}" href="index.php?option=com_vquiz&amp;view=quizmanager&amp;tmpl=component&amp;function=jSelectQuizzes_jform_request_id&from_userview=1&selected_userquiz=<?php echo $monitor_quiz;?>&selected_usercategory=<?php echo $monitor_category;?>" title="" class="modal btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_QUIZ');?>"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_VIEW_OR_EDIT");?></a> 
							 
							<input type="button" value="Reset" name="reset" currten_id="" id="reset_quiz" class="btn reset">
							
						</span>
						
						<span id="quiz_count"><?php if($this->moniterquiz[0]!=0){echo count($this->moniterquiz);}else{echo 0;} ?></span> <?php echo " quiz selected.";?>
						
				</td>
				</tr>
				
				<tr>
				<td><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_USER_MONITOR_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_USER')?></label>
					
				</td>
				<td>

					   <span class="input-append">
					   <?php 
						    if(!empty($this->moniteruser)){
								$monitor_user=implode(',',$this->moniteruser); 
						   }else{
								$monitor_user='';
						   }
						   $monitor_user_name=!empty($monitor_user)?$monitor_user:JText::_('COM_VQUIZ_SELECT_USER');
						?>
						
							<?php /*<input type="text" size="80" disabled="disabled" value="<?php echo $monitor_user_name;?>" id="jform_request_user_name" name="monitor_user_name" class="input-medium" />*/?>
							
							<input type="hidden" value="<?php echo $monitor_user;?>" name="monitor_user_id" class="required modal-value" id="jform_request_user_id" aria-required="true" required="required">

							 <a id="jform_request_user_id_anchor" currten_id="" rel="{handler: 'iframe', size: {x: 800, y: 450}}" href="index.php?option=com_vquiz&amp;view=users&amp;tmpl=component&amp;function=jSelectUsers_jform_request_id&from_userview=1&selected_users=<?php echo $monitor_user;?>" title="" class="modal btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_USERS');?>"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_VIEW_OR_EDIT");?></a> 
							 
							<input type="button" value="Reset" name="reset" currten_id="" id="reset_users" class="btn reset">
							
						</span>
						
						<span id="user_count"><?php if($this->moniteruser[0]!=0){echo count($this->moniteruser);}else{echo 0;} ?></span> <?php echo " user selected.";?>
				</td>
				</tr>
				</table>
				
		</div>
	</div>
</div>


<div class="clr"></div>
<?php echo JHTML::_( 'form.token' ); ?>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="users" />

</form>
</div>
