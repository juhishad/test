<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');

$function = JFactory::getApplication()->input->getCmd('function', 'jSelectUsers');
$tmpl=JRequest::getVar('tmpl', 'index');
$from_userview=JRequest::getInt('from_userview',0);
$selected_users=JRequest::getVar('selected_users',0);
if($from_userview == 1){
$script = array();

$script[] = " jQuery(function($){";
$script[] = "var selected_user='$selected_users'.split(',')"; 
$script[] = " $('input[type=checkbox]').each(function(){";
$script[] = " if(jQuery.inArray($(this).val(),selected_user)!== -1){";
$script[] = " if($(this).val()!='') this.checked = true;}";
$script[] = " });";
$script[] = " jQuery('#select_chk').click(function () {";
$script[] = " var ids=[]"; 
$script[] = " var title=[]"; 
$script[] = " $('input[type=checkbox]:checked').each(function(){";
$script[] = " ids.push($(this).val());";
$script[] = " title.push( $.trim($(this).closest('td').next('td').text()));";
$script[] = " });";
$script[] = " if(ids==''){ alert('Please Select Users')}else{";
$script[] = " if (window.parent) window.parent.jSelectUsers_jform_request_id(ids,title,null);";
$script[] = " }});";
$script[] = " });";
JFactory::getDocument()->addScriptDeclaration(implode("\n", $script));
}
$function = JFactory::getApplication()->input->getCmd('function', 'jQuizCreator_jform_request_id');
$from_creatorview=JRequest::getInt('from_creatorview',0);
$quiz_creator=JRequest::getVar('quiz_creator',0);
if($from_creatorview == 1){
$script_creator = array();
$script_creator[] = " jQuery(function($){";
$script_creator[] = "var quiz_creator='$quiz_creator'.split(',')"; 
$script_creator[] = " $('input[type=checkbox]').each(function(){";
$script_creator[] = " if(jQuery.inArray($(this).val(),quiz_creator)!== -1){";
$script_creator[] = " if($(this).val()!='') this.checked = true;}";
$script_creator[] = " });";
$script_creator[] = " jQuery('.userclass').click(function () { ";
$script_creator[] = " var id=''"; 
$script_creator[] = " var title=''"; 

$script_creator[] = " id=jQuery(this).attr('data-id');";
$script_creator[] = " title=jQuery(this).attr('data-title');";

$script_creator[] = " if(id == '' ){ alert('Please select user')}else{";
$script_creator[] = " if (window.parent) window.parent.jQuizCreator_jform_request_id(id,title,null);";
$script_creator[] = " }});";
$script_creator[] = " });";
JFactory::getDocument()->addScriptDeclaration(implode("\n", $script_creator));
}
?>

<form action="index.php?option=com_vquiz&view=users" method="post" name="adminForm" id="adminForm">


		<?php 
		if($from_creatorview != 1){
		if($tmpl=='component'){?>	
			<a href="#" id="select_chk" class="btn btn-small btn-primary"><?php echo JText::_('COM_VQUIZ_SELECT_ALL_SELECTED');?></a>
		<?php } } ?>
	<?php if($tmpl!='component'){?>
		<?php if (!empty( $this->sidebar) AND $from_userview==0) {?>   
		<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
		</div> 
		<div id="j-main-container" class="span10">
		<?php }else {?>
		<div id="j-main-container">
		<?php }
	;}?>
		
		<div class="clr" style="clear:both;"></div>	
		<legend><?php echo JText::_('COM_VQUIZ_USERS'); ?></legend>


	
<div class="work_sheet">
<table class="adminlist filter">
<tr>
<td class="filter_sheet" >
	<div class="search_buttons">
		<div class="btn-wrapper input-append">
			<input placeholder="Search" type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
			<button class="btn" onclick="this.form.submit();"><i class="icon-search"></i><span class="search_text"><?php echo JText::_('COM_VQUIZ_SEARCH'); ?></button>
			<button class="btn" onclick="document.getElementById('search').value='';this.form.submit(); "><?php echo JText::_('COM_VQUIZ_RESET'); ?></button>
		</div>
	</div>
</td>

</tr>
</table>
<div id="editcell">
    <table class="adminlist table table-striped table-hover">
    <thead>
			<tr>
				<th width="5" align="left">
					<?php echo JText::_('NUM'); ?>
				</th>
				<?php if($from_creatorview != 1){ ?>
				<th width="3%">
					<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
				</th>
				
				<th nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JText::_('NAME'), 'name', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
				</th>
                <th nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JText::_('USERNAME'), 'username', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
				</th>
  				
                <th nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JText::_('EMAIL'), 'email', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
				</th>
                <th nowrap="nowrap" class="center">
					<?php echo JHTML::_('grid.sort', JText::_('ENABLED'), 'block', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
				</th>
                 <th nowrap="nowrap" class="center">
					<?php echo JHTML::_('grid.sort', JText::_('LAST_VISITED'), 'lastvisitDate', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
				</th>
                 <th nowrap="nowrap" class="center">
					<?php echo JHTML::_('grid.sort', JText::_('REG_DATE'), 'registerDate', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
				</th>
                <th width="5" nowrap="nowrap">
					<?php echo JHTML::_('grid.sort', JText::_('ID'), 'id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
				</th>
				<?php }else{ ?>
				<th nowrap="nowrap">
					<?php echo JText::_('NAME'); ?>
				</th>
                <th nowrap="nowrap">
					<?php echo JText::_('USERNAME'); ?>
				</th>
  				
                <th nowrap="nowrap">
					<?php echo JText::_('EMAIL'); ?>
				</th>
                <th nowrap="nowrap" class="center">
					<?php echo JText::_('ENABLED'); ?>
				</th>
                 <th nowrap="nowrap" class="center">
					<?php echo JText::_('LAST_VISITED'); ?>
				</th>
                 <th nowrap="nowrap" class="center">
					<?php echo JText::_('REG_DATE'); ?>
				</th>
                <th width="5" nowrap="nowrap">
					<?php echo JText::_('ID'); ?>
				</th>
				<?php } ?>
			</tr>
		</thead>

	<tfoot>
    <tr>
      <td colspan="9"><?php echo $this->pagination->getListFooter(); ?></td>
    </tr>
  	</tfoot>

    <?php
    $k = 0;
		
    for ($i=0, $n=count( $this->items ); $i < $n; $i++)
    {
        $row = $this->items[$i];
		$checked    = JHTML::_( 'grid.id', $i, $row->id );
				
        ?>
        <tr class="<?php echo "row$k"; ?>">
            <td><?php echo $this->pagination->getRowOffset($i); ?></td>
			
			<?php if($from_creatorview != 1){ ?><td align="center"><?php echo $checked; ?></td><?php } ?>

            <td>
					<?php if($from_userview==1){
						echo $row->name; 
					
					}elseif($from_creatorview == 1){ ?> 
					<a href="#" class="userclass" data-title="<?php	echo $row->name;?>" data-id="<?php	echo $row->id;?>"><?php	echo $row->name;?></a>
					<?php }else{ ?>
				
					<a href="index.php?option=com_vquiz&view=users&task=edit&cid[]=<?php echo $row->id; ?>"><?php	echo $row->name;?></a>
					
				<?php }?>
			</td>
				
            <td><?php echo $row->username; ?></td>
            <td><?php echo $row->email; ?></td>
            
            <td class="center enabled_disabled">
					<?php 
					$icon = $row->block?'<span class="disable">'.JText::_('COM_VQUIZ_DISABLE').'</span>':'<span class="enable">'.JText::_('COM_VQUIZ_ENABLE').'</span>'; 
					echo $icon;
					?>
            		<?php /*<img src="components/com_vquiz/assets/images/<?php echo $icon; ?>" alt="<?php echo JText::_($row->block ? 'JNO' : 'JYES'); ?>" width="16" />*/?>
            </td>
            <td class="center"><?php if ($row->lastvisitDate != '0000-00-00 00:00:00'):?>
						<?php echo JHtml::_('date', $row->lastvisitDate, 'Y-m-d H:i:s'); ?>
					<?php else:?>
						<?php echo JText::_('JNEVER'); ?>
					<?php endif;?></td>
            <td class="center"><?php echo JHtml::_('date', $row->registerDate, 'Y-m-d H:i:s'); ?></td>
            <td><?php echo $row->id; ?></td>
            
        </tr>
        <?php
        $k = 1 - $k;
    }
    ?>
    </table>
</div>
</div>
 <?php echo JHTML::_( 'form.token' ); ?>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="tmpl" value="<?php echo JRequest::getVar('tmpl', 'index'); ?>" />
<input type="hidden" name="from_userview" value="<?php echo JRequest::getInt('from_userview',0); ?>" />
<input type="hidden" name="from_creatorview" value="<?php echo JRequest::getInt('from_creatorview',0); ?>" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="users" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
</div>
</form>
