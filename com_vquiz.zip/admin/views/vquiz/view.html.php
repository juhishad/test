<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );
class VquizViewVquiz extends JViewLegacy
{ 

    function display($tpl = null)
    {
		$user = JFactory::getUser();
		
		$document =  JFactory::getDocument();
		JToolBarHelper::title( JText::_( 'vQuiz' ), 'dashboard.png' );
		$layout = JRequest::getCmd('layout', '');
		

		
		if($layout != 'information'){
			JToolBarHelper::help('help', true);
			if(JFactory::getUser()->authorise('core.admin','com_vquiz')){
				JToolBarHelper::preferences('com_vquiz','', '','ACL');
			}
				$version = new JVersion;
				$joomla = $version->getShortVersion();
				$jversion = substr($joomla,0,3);
				$this->sidebar ='';
				if($jversion>=3.0)
				{
				$this->sidebar = JHtmlSidebar::render();
				}
				
				if(JFactory::getUser()->authorise('core.addwidget','com_vquiz')){
					JToolBarHelper::addNew('insert', JText::_( 'COM_VQUIZ_ADD_WIDGET' ), false );
				}
		}
		
		$this->category = $this->get('Category');
		$this->profiles = $this->get('Profiles');
		$this->configuration = $this->get('Configuration');
		
		parent::display($tpl);
		


 
    }

  

}
 