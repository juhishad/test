<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access'); 
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$document->addStyleSheet('components/com_vquiz/assets/css/popup.css');
//$document->addScript('components/com_vquiz/assets/js/jquery1.4.1.js');

$document->addScript('components/com_vquiz/assets/js/popup.js');

JHtml::_('behavior.tooltip');
JHtml::_('behavior.multiselect');
jimport( 'joomla.html.pagination' );
JHTML::_('behavior.modal');

if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

$user = JFactory::getUser();
$listOrder = $this->lists['order']; 
$listDirn = $this->lists['order_Dir'];
$canOrder	= $user->authorise('core.edit.state', 'com_vquiz.questionpool');
$saveOrder	= $listOrder == 'ordering';
$saveOrder 	= ($listOrder == 'ordering' && strtolower($listDirn) == 'asc');
?>

<script type="text/javascript">
/* jQuery(document).ready(function(){
jQuery( "#search" ).autocomplete({
		minLength: 2,
		source: function( request, response )
		{ 
			  var term = request.term;
			 jQuery.ajax({
			url:'index.php',
			type:'post',
			dataType:'json',
			data: {'option':'com_vquiz', 'view':'questionpool', 'task':'Question_search', 'tmpl':'component','search':term,"<?php echo JSession::getFormToken(); ?>":1},
			// data:{'option':'com_vquiz','task':'questionSearch','qsearch':term,'tmpl':'component'},
					 
			success:function(data){
					
					 
						 if(data.result=='success')
						 response( data.html );
					 }
			   });
			 	  
		},
		select:function(event, ui){
		jQuery('#search').val(ui.item.label);
		}
});
}); */
Joomla.submitbutton = function(task) {
	
     var x=jQuery('#questioncsv').val();	

				if (task == 'cancel') {
				Joomla.submitform(task, document.getElementById('adminForm'));
				} 
				else if(task=='import') {
					lightbox_import();
					var form = document.adminForm;
					if(x == "")  {
					alert("<?php echo JText::_('COM_VQUIZ_PLZ_CHOSE_CSV'); ?>");
					return false;
					}
				}

				  else if(task=='export') {
					var form = document.adminForm;
					if (document.adminForm.boxchecked.value==0)  {
					alert("<?php echo JText::_('COM_VQUIZ_PLZCHOOSEQUESTION'); ?>");
					return false;
					}
				}

					else if(task=='copy') {
					var form = document.adminForm;
					if (document.adminForm.boxchecked.value==0)  {
					alert("<?php echo JText::_('COM_VQUIZ_PLZCHOOSEQUESTION'); ?>");
					return false;
					}

					else{
					lightbox_copy();
					return false;
					}

				}

					else if(task=='move') {
					var form = document.adminForm;
					if (document.adminForm.boxchecked.value==0)  {
					alert("<?php echo JText::_('COM_VQUIZ_PLZCHOOSEQUESTION'); ?>");
					return false;
					}

					else{
					lightbox_move();
					return false;
					}

				}

				Joomla.submitform(task, document.getElementById('adminForm'));

}

</script>

<form action="index.php?option=com_vquiz&view=questionpool" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data" >

<?php if (!empty( $this->sidebar)) : ?>   
		<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
		</div>
		<div id="j-main-container" class="span10">
		<?php else : ?>
		<div id="j-main-container">
		<?php endif;?>

		<div class="clr" style="clear:both;"></div>
		<legend><?php echo JText::_('COM_VQUIZ_QUESTION'); ?></legend>		
		<div class="filter-select fltrt" style="float:right;">

            <input type="hidden" name="quizid" id="quizid" value="<?php echo $this->lists['quizid'];?>" class="text_area" onchange="document.adminForm.submit();" />
           <?php if(!empty($this->lists['quizid'])):?>
		   
		   <?php echo JText::_('COM_VQUIZ_QUIZZESID').$this->lists['quizid'];?>
		
			<?php endif?>
			<select name="publish_item" id="publish_item" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('COM_VQUIZ_ALL_STATE');?></option>
				<option value="p" <?php  if( 'p'== $this->lists['publish_item']) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PUBLISHED');?></option>
				<option value="u" <?php  if('u'== $this->lists['publish_item']) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_UNPUBLISHED');?></option>
			</select>
			<div class="btn-group pull-right hidden-phone">
				<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
				<?php echo $this->pagination->getLimitBox(); ?>
			</div>
</div>
        <div class="search_buttons">
        <div class="btn-wrapper input-append">
			<input placeholder="Search" type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
			<button class="btn" onclick="this.form.submit();"><i class="icon-search"></i><span class="search_text"><?php echo JText::_('COM_VQUIZ_SEARCH'); ?></button>
			<button class="btn" onclick="document.getElementById('search').value='';this.form.submit();"><?php echo JText::_('COM_VQUIZ_RESET'); ?></button>
            </div></div>


    <div id="editcell">
        <table class="adminlist table table-striped table-hover">
                <thead>
                <tr>
                <th width="5">
                 <?php echo JText::_('COM_VQUIZ_NUM'); ?>
                </th>
                <th width="5">
                <input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
                </th>			
                <th>
                  <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_QUESTION', 'i.qtitle', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
                </th>
                <th>
                <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_QUIZ', 'u.title', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			   </th>
                 <th width="90" class="center">
                  <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_QUESTIONTYPE', 'i.optiontype', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
                </th>
                <th class="center">
				<?php echo JText::_('COM_VQUIZ_FLAGS'); ?>
			   </th>
               <th class="center">
				<?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?>
			   </th>
                <th class="center">
                <?php echo JHTML::_('grid.sort', 'JGRID_HEADING_ORDERING', 'ordering', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
                <?php if ($canOrder && $saveOrder) :?>
                <?php echo JHtml::_('grid.order',  $this->items, 'filesave.png', 'saveorder'); ?>
                <?php endif; ?>
                </th>
				<th>
                 <?php echo JText::_( 'COM_VQUIZ_STATISTICS' ); ?>
                </th>
                <th width="5">
                <?php echo JHTML::_('grid.sort', 'ID', 'i.id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
                </th>
                </tr>
                </thead>

                <tfoot>
                <tr>
                <td colspan="10"><?php echo $this->pagination->getListFooter(); ?></td>
                </tr>
                </tfoot>

                <?php
				$k = 0;
				for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
				$row = &$this->items[$i];
				$checked 	= JHTML::_('grid.id',   $i, $row->id );
				$published    = JHTML::_( 'jgrid.published', $row->published, $i );
				$link 		= JRoute::_( 'index.php?option=com_vquiz&view=questionpool&task=edit&cid[]='. $row->id );
				
				$ordering	= ($listOrder == 'ordering');
				$canCreate	= $user->authorise('core.create',		'com_vquiz.questionpool.'.$row->id);
				$canEdit	= $user->authorise('core.edit',			'com_vquiz.questionpool.'.$row->id);
				$canCheckin	= $user->authorise('core.manage',		'com_checkin') || @$row->checked_out == $user->get('id') || @$row->checked_out == 0;
				$canEditOwn	= true; //$user->authorise('core.edit.own',		'com_djimageslider.category.'.$item->catid) && $item->created_by == $userId;
				$canChange	= $user->authorise('core.edit.state',	'com_vquiz.questionpool.'.$row->id) && $canCheckin;

				?>                
                

                <tr class="<?php echo "row$k"; ?>">
               <td><?php echo $this->pagination->getRowOffset($i); ?></td>

                <td>
                <?php echo $checked; ?>
                </td>
                <?php /*<td>
                <a href="<?php echo $link; ?>"><?php echo substr(strip_tags($row->qtitle),0,50); ?></a>
                </td> */?>
				<td>
					
					<a href="<?php echo $link; ?>" onclick='if (window.parent) window.parent.<?php echo $this->escape($function);?>("<?php echo $row->id; ?>","<?php echo htmlspecialchars(strip_tags(addslashes($row->qtitle)),ENT_QUOTES);?>",null);'><?php echo substr(strip_tags($row->qtitle),0,50); ?></a>
				
				</td> 
                 <td>
                <?php echo $row->quizname; ?> 
                </td> 
                <td class="center">
                 <?php
					if($row->optiontype==1)
						echo JText::_('COM_VQUIZ_RADIO_BUTTON');
					elseif($row->optiontype==2)
						echo JText::_('COM_VQUIZ_RADIO_CHECKBOX');
					elseif($row->optiontype==3)
						echo JText::_('COM_VQUIZ_RADIO_DROPDOWN');
					elseif($row->optiontype==4)
						echo JText::_('COM_VQUIZ_TEXT_FIELD');
					elseif($row->optiontype==5)
						echo JText::_('COM_VQUIZ_TEXT_AREA');
					elseif($row->optiontype==6)
						echo JText::_('COM_VQUIZ_TRUE_FALSE');
					elseif($row->optiontype==7)
						echo JText::_('COM_VQUIZ_YES_NO');
				 ?> 
                </td> 
                <td class="center"><?php echo $row->flagcount; ?></td>
                <td class="center publish_unpublish"><?php echo $published; ?></td>
                <td class="order" nowrap="nowrap">
					<?php if ($canChange) : ?>

						<?php if ($saveOrder) :?>

							<?php if ($listDirn == 'asc') : ?>

								<span><?php echo $this->pagination->orderUpIcon($i, (@$item->catid == @$this->items[$i-1]->catid),'orderup', 'JLIB_HTML_MOVE_UP', $ordering); ?></span>

								<span><?php echo $this->pagination->orderDownIcon($i, $n, (@$item->catid  == @$this->items[$i+1]->catid), 'orderdown', 'JLIB_HTML_MOVE_DOWN', $ordering); ?></span>

							<?php elseif ($listDirn == 'desc') : ?>

								<span><?php echo $this->pagination->orderUpIcon($i, (@$item->catid  == @$this->items[$i-1]->catid),'questionpool.orderdown', 'JLIB_HTML_MOVE_UP', $ordering); ?></span>

								<span><?php echo $this->pagination->orderDownIcon($i, $n, (@$item->catid == @$this->items[$i+1]->catid), 'questionpool.orderup', 'JLIB_HTML_MOVE_DOWN', $ordering); ?></span>

							<?php endif; ?>

						<?php endif; ?>

						<?php $disabled = $saveOrder ?  '' : 'disabled="disabled"'; ?>


						<input  style="width:20px;" type="text" name="order[]" size="5" value="<?php echo $row->ordering;?>" <?php echo $disabled ?> class="text-area-order input-mini" />

					<?php else : ?>

						<?php echo $row->ordering; ?>

					<?php endif; ?>

				</td>
				<td>

				<a class="modal" id="modal" title="Select" href="<?php echo 'index.php?option=com_vquiz&view=questionpool&layout=chartview&tmpl=component&id='.$row->id;?>" rel="{handler: 'iframe', size: {x: 950, y: 600}}"><input class="btn btn-small" type="button" value="<?php echo JText::_('COM_VQUIZ_VIEW')?>" /></a>

				</td>
                <td>
                <?php echo $row->id; ?>
                </td>
                </tr>
                <?php
                $k = 1 - $k;
                }
                ?>
        </table>
    </div>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="questionpool" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
 
<div id="light_import">
<a href="javascript:void(0);"  onclick="lightbox_close();" class="closepop"><?php echo JText::_('X')?></a>
	<div style="text-align:center;">
    <p><input type="file" name="questioncsv" id="questioncsv"></p>
    <p> <input type="button" value="<?php echo JText::_('COM_VQUIZ_IMPORT')?>" name="submitcsv" id="submitcsv" onclick="Joomla.submitform('importquestioncsv');"></p>
    </div>
</div>

<div id="light_move">
<a href="javascript:void(0);"  onclick="lightbox_close();" class="closepop"><?php echo JText::_('X')?></a>
<div style="text-align:center;">
<p><?php echo JText::_('COM_VQUIZ_SELECT_QUIZ'); ?></p>
  <p><select name="quizzesmoveid">

            <?php    for ($i=0; $i <count($this->quizes); $i++)	
            {
            ?>
            <option value="<?php echo $this->quizes[$i]->id;?>"  <?php  if($this->quizes[$i]->id == !empty($this->item->quizid)?$this->item->quizid:0) echo 'selected="selected"'; ?> ><?php echo $this->quizes[$i]->title;?></option>		
            <?php
            }
            ?>
            </select>
            </p>
            <p> <input type="button" value="<?php echo JText::_('COM_VQUIZ_MOVE'); ?>" name="move"  class="btn btn-small"  onclick="Joomla.submitform('movequestion');"></p>

  </div>          

</div>

<div id="light_copy">
<a href="javascript:void(0);"  onclick="lightbox_close();" class="closepop"><?php echo JText::_('X'); ?></a>
<div style="text-align:center;">
<p><?php echo JText::_('COM_QUIZ_SELECT_QUIZ'); ?></p>
  <p><select name="quizzescopyid">

  
            <?php    for ($i=0; $i <count($this->quizes); $i++)	
            {
            ?>
            <option value="<?php echo $this->quizes[$i]->id;?>"  <?php  if($this->quizes[$i]->id == !empty($this->item->quizid)?$this->item->quizid:0) echo 'selected="selected"'; ?> ><?php echo $this->quizes[$i]->title;?></option>		
            <?php
            }
            ?>
            </select>
            </p>
            <p> <input type="button" value="<?php echo JText::_('COM_VQUIZ_COPY');?>" name="copy"  class="btn btn-small"  onclick="Joomla.submitform('copyquestion');"></p>
  </div>          
</div>
<div id="fade" onClick="lightbox_close();"></div> 
</div>
</form>