<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
$document = JFactory::getDocument();

$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$editor = JFactory::getEditor();

JHtml::_('behavior.tooltip');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

?>
<script type="text/javascript">
		var jq=jQuery.noConflict();
		
		jq(document).ready(function(){
		
			jq( "#flagreset" ).click(function() {
				jq('input[name="flagcount"]').val(0);
				jq('input[name="flagcount_show"]').val(0);
			});

			var single=true;
			var multiple=false;

			var optiontype=jq('#optiontype').val();
			jq('#addinput2').css('display','none');
			if(optiontype==2){
				multiple=true;	
			}else{
				single=true;
			}
			if(optiontype==1 || optiontype==2 || optiontype==3){
				jq('#addinput2').css('display','none');
			}
			
			if(optiontype==4){
				jq('.textfield_check_tr').css('display','');
				jq('#addinput').css('display','none');
				jq('#addinput2').css('display','none');
				jq('#comment_box_row').css('display','none');
			}else{
				jq('.textfield_check_tr').css('display','none');
				if(optiontype==5){
					jq('#addinput').css('display','none');
					jq('#addinput2').css('display','none');
					jq('#comment_box_row').css('display','none');
				}else{
					jq('#addinput').css('display','');
					jq('#comment_box_row').css('display','');
				}
			}
			if(optiontype==6 || optiontype==7){
					jq('#addinput').css('display','none');
					jq('#addinput2').css('display','');
					jq('#comment_box_row').css('display','none');
				}
			
			jq("#optiontype").live('change', function() { 
						if(jq(this).val()==1 || jq(this).val()==2 || jq(this).val()==3){
							jq('#addinput2').css('display','none');
						}
					if(jq(this).val()==4){
						jq('.textfield_check_tr').css('display','');
						jq('#addinput').css('display','none');
						jq('#addinput2').css('display','none');
						jq('#comment_box_row').css('display','none');
						jq('#user_comment').val(0);
					}else{
						jq('.textfield_check_tr').css('display','none');
						if(jq(this).val()==5){
							jq('#addinput').css('display','none');
							jq('#addinput2').css('display','none');
							jq('#comment_box_row').css('display','none');
							jq('#user_comment').val(0);
						}else{
							jq('#addinput').css('display','');
							jq('#comment_box_row').css('display','');
						}
					}

					if(jq(this).val()==2){	 
						multiple=true;
						single=false;
						jq(".options_answer").replaceWith('<input type="checkbox" name="correct_ans[]"  value="'+i+'" class="options_answer" />');
						jq('.options_answer').each(function(index, value){
						jq(this).attr('value',index);
						});

 
					}else{
						single=true;
						multiple=false;
						
						jq(".options_answer").replaceWith('<input type="radio" name="correct_ans"  value="'+i+'" class="options_answer" />');
						jq('.options_answer').each(function(index, value){
							jq(this).attr('value',index);
						});
					}
					if(jq(this).val()==6 || jq(this).val()==7){
							jq('#addinput').css('display','none');
							jq('#addinput2').css('display','');
							jq('#comment_box_row').css('display','none');
						
						}
			  
			});			

			
 
 
			var addDiv = jq('#addinput');
			var i =<?php echo (int)count($this->options); ?>;
			var Maxoption=<?php echo !empty($this->personality_category->count_column)?(int)$this->personality_category->count_column:10 ?>;
						
			jq('#addNew').live('click', function() {

			     if(optiontype==1 || optiontype==3){
					 var html = '<input type="radio" name="correct_ans"  value="'+i+'" class="options_answer"  />';
				 }
				 else if(optiontype===2)
				 {
					 var html = '<input type="checkbox" name="correct_ans[]"  value="'+i+'" class="options_answer" />';
				 }
				
				var add_to='<tr><td></td><td class="upimg"><input type="file" name="image[]" id="option_images" /></td><td valign="middle" align="center"><input style="width:96%; padding:1%; margin:1%;" type="text" id="qoption"  name="qoption[]" value=""  /><input type="hidden" name="image_file[]" value=""/></td>';
				
				add_to +='<td valign="middle" align="center"><label class="sradio">'+html+'</label></td>';	
				
				add_to +='<td class="center" width="100"><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span><input type="hidden" name="oorder[]" value="'+i+'" /></td>';
				
				add_to +='<td valign="middle" align="center"><a href="javascript:void(0);" class="remNew btn btn-danger">-</a></td></tr>';
	
				jq(add_to).appendTo(addDiv);

				i++;
				alert(html);
				return false;

			});
 
			jq('.remNew').live('click', function() {
				jq(this).parent().parent().remove();
				jq('#addinput>p').each(function(i){
					jq(this).find('input:radio').val(i);
				});
				i--;
				return false;
				

			});
			
			jq(document).on('click',".icon-uparrow,.icon-downarrow",function () { 
				var $element = this;
				
				var row = jq($element).parents("tr:first");
				if(jq(this).is('.icon-uparrow') && row.prevAll().length > 1){
							
					var x=row.insertBefore(row.prev());
					var lenghth_tr=jq.parseJSON(JSON.stringify(x.prev())).length;
						
				}else if(jq(this).is('.icon-downarrow')){
					row.insertAfter(row.next());
				}
				else{
					return false;
				}

			});

			
				
				jq('select[name="personality_optionid[]"]').on('change',function(){
				
						var first_selected_value=jq('select[name="personality_optionid[]"].first_select').find('option:selected').val();
						
						if(first_selected_value==0){

							alert('<?php echo JText::_('COM_VQUIZ_FIRST_DROPDOWN_SELECT')?>');
							jq(this).find('option[value="0"]').attr('selected', 'selected');
							jq('select').trigger("liszt:updated");
							
							return false;
						}
						
						jq('select[name="personality_optionid[]"].rest_select').each(function(){
							jq(this).find('option').attr('disabled', 'disabled');
						});
						
						jq('select[name="personality_optionid[]"].first_select').each(function(){
							jq(this).find('option').removeAttr('disabled');
						});
						
						var value = jq(this).find('option:selected').val();
						
						jq('select[name="personality_optionid[]"]').each(function(){
						
							jq(this).find('option[value=' + value +']').closest('optgroup').each(function(index){
							
								jq(this).children("option").each(function(){
									 if(jq(this).is(':disabled')){            
										jq(this).removeAttr('disabled');
									 }
								});
							//jq(this).find('option[value=' + value +']').attr('disabled', 'disabled');
								
							});
							
						});
						
						if(jq(this).hasClass("first_select")){ 
							jq('select[name="personality_optionid[]"].rest_select').each(function(){
								jq('select[name="personality_optionid[]"].rest_select').find('option[value="0"]').attr('selected', 'selected');
							}); 
						} 
						jq('select').trigger("liszt:updated");
						
				}); 

			}); 

		Joomla.submitbutton = function(task) {
			if (task == 'cancel') {
				Joomla.submitform(task, document.getElementById('adminForm'));
			}else{
					 jq('select[name="personality_optionid[]"]').each(function(){
						jQuery(this).find('option:selected').prop('disabled', false);
					 });
				} 	
				Joomla.submitform(task, document.getElementById('adminForm'));
		} 
 
</script>

<style>	
.personality_weight{
	float:left;
	margin:0 10px;
}
</style>
		
<form class="vquiz_form" action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col101 qform">
	<fieldset class="adminform">
	<legend><?php echo JText::_('COM_VQUIZ_QUESTIONS_DETAILS'); ?></legend>
		<table class="adminform table table-striped">
			<tr>
				<td width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTIONS_FLAG_GIVEN_BY_USER_TOOLTIP'); ?>" ><?php echo JText::_('COM_VQUIZ_FLAGS'); ?></label></td>
				<td><input type="text" name="flagcount_show"  id="flagcount_show" value="<?php echo $this->item->flagcount;?>" disabled="disabled"/>
				<input type="hidden" name="flagcount"  id="flagcount" value="<?php echo $this->item->flagcount;?>"/>
				<input type="button" class="btn" id="flagreset" value="<?php echo JText::_('COM_VQUIZ_RESET'); ?>"/>
				</td>
			</tr>            
		<tr>
				
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CATEGORY_TITLE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_CATEGORY'); ?></label></td>
					<td>
						<select name="catid" id="catid">
						<?php    for ($i=0; $i <count($this->category); $i++)	
						{
						?>
						<option value="<?php echo $this->category[$i]->id;?>"   >
						<?php
						if($this->category[$i]->level>0){
							echo str_repeat('-', $this->category[$i]->level-1);	
						}
						echo $this->category[$i]->title;
						
						?> 
						</option>		
						<?php
						}
						?>
						</select>
					</td>
                </tr>
							
				<tr>
			

			<tr>
				<td class="key"><label class="hasTip" ><?php echo JText::_('COM_VQUIZ_STATUS'); ?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="published1" id="published1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?></label>
					<input type="radio" name="published" id="published1" value="1" <?php if($this->item->published ==1) echo 'checked="checked"';?>/>
					<label for="published0" id="published0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?></label>
					<input type="radio" name="published" id="published0" value="0" <?php if($this->item->published ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ORDETING_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_ORDERING'); ?></label></td>
				<td>
				<input type="number" name="ordering" id="ordering" value="<?php echo $this->item->ordering;?>" />
				</td>
			</tr>

			<!--Hide Total Time Quiz When Quiz Later Enable in Configuration OR Total Time 0-->
			
			<tr class="scoretype_tr">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_SCORE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_SCORE'); ?></label></td>
				<td>
				<input type="text" name="score" id="score" value="<?php echo $this->item->score?>" />
				</td>
			</tr>

			<tr class="penalitytype_tr">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_PENALTY_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_PENALTY'); ?></label></td>
				<td>
				<input type="text" name="penality" id="penality" value="<?php echo $this->item->penalty?>" />
				</td>
			</tr>
	
		
		
			<tr class="questiontyp_tr">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_TYPE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_ANSWERS_TYPE'); ?></label></td>
				<td>
				<select  name="optiontype" id="optiontype" >
					<option value="1" <?php  if($this->item->optiontype==1) echo 'selected="selected"'; ?> class="radio_option"><?php echo JText::_('COM_VQUIZ_RADIO_BUTTON'); ?> </option>
					<option value="2" <?php  if($this->item->optiontype==2) echo 'selected="selected"'; ?> class="checkbox_option"><?php echo JText::_('COM_VQUIZ_RADIO_CHECKBOX'); ?> </option>
					<option value="3" <?php  if($this->item->optiontype==3) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_RADIO_DROPDOWN'); ?> </option>
					<option value="4" <?php  if($this->item->optiontype==4) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_TEXT_FIELD'); ?> </option>
					<option value="5" <?php  if($this->item->optiontype==5) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_TEXT_AREA'); ?> </option>
					<option value="6" <?php  if($this->item->optiontype==6) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_TRUE_FALSE'); ?> </option>
					<option value="7" <?php  if($this->item->optiontype==7) echo 'selected="selected"'; ?> class="dropdown_option"><?php echo JText::_('COM_VQUIZ_YES_NO'); ?> </option>
				</select>
				</td>
			</tr>
			
			<tr class="textfield_check_tr">
			
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ANSWER_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_ANSWER'); ?></label></td>
				
				<td>
					<input type="text" name="text_field_ans" value="<?php echo trim($this->item->text_field_ans);?>"/>
				</td>
			</tr>
			
			<tr class="textfield_check_tr">
			
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_CASE_SENSITIVE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_CASE_SENSITIVE'); ?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="case_sensitive1" id="case_sensitive1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" name="case_sensitive" id="case_sensitive1" value="1" <?php if($this->item->case_sensitive ==1) echo 'checked="checked"';?>/>
					<label for="case_sensitive0" id="case_sensitive0-lbl" class="radio"><?php echo JText::_('NOS'); ?></label>
					<input type="radio" name="case_sensitive" id="case_sensitive0" value="0" <?php if($this->item->case_sensitive ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
				
			</tr>
		
			<tr id="comment_box_row">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_OTHER_OPTION_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_OTHER_OPTION'); ?></label></td>
					<td>
						<fieldset class="radio btn-group">
							<label for="other_option1" id="other_option1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_OTHER_OPTION_ENABLE'); ?></label>
							<input type="radio" name="other_option" id="other_option1" value="1" <?php if($this->item->other_option==1) echo 'checked="checked"';?>/>
							<label for="other_option0" id="other_option0-lbl" class="radio"><?php echo JText::_( 'COM_VQUIZ_OTHER_OPTION_DISABLE' ); ?></label>
							<input type="radio" name="other_option" id="other_option0" value="0" <?php if($this->item->other_option==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
			</tr>
		
			
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTIONS_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTIONS'); ?></label></td>
				<td>
				<?php 

				if($this->config->question_prepare_content==1){
					$qtitle = JHtml::_('content.prepare', $this->item->qtitle);
				}else{
					$qtitle = $this->item->qtitle;
				}

				echo $editor->display("qtitle",  $this->item->qtitle, "400", "200", "20", "5", true, null, null, null, array());

				?> 
				</td>
			</tr>
			
		</table>
 
		<table width="100%" id="addinput">
			<tr>
				
				
					<th><input type="button" name="addoption" id="addNew" value="+" class="btn btn-success" /></th>
				
				<th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_IMAGES_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_IMAGES'); ?></label></th>
				
				<th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS'); ?></label></th>
				
				<th>
					<label class="hasTip"  title="<?php echo JText::_('COM_VQUIZ_QUESTION_CHOOSE_ANSWER_TOOLTIP'); ?>">
					<?php echo JText::_('COM_VQUIZ_ANSWER'); ?>
					</label>
					
					</th>
				
				<th><label><?php echo JText::_('COM_VQUIZ_ORDERING'); ?></label></th>
				<th><label><?php echo JText::_('COM_VQUIZ_REMOVE'); ?></label></th>
			</tr>

			<?php
			
			
			
				$Maxoption=count($this->options);
				
			
			//true/false
			
				
			for($i=0;$i<$Maxoption;$i++){
			
			?>
			<tr>
				<td></td>
				
				<td class="upimg"><input type="file" name="image[]" id="option_images" />
					<?php 

					if(!empty($this->options[$i]->image) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[$i]->image)){ 
					echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[$i]->image. '" alt="x" />'; 
					}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
					?>	
					<input type="hidden" name="image_file[]" value="<?php echo $this->options[$i]->image;?>"/>
					
				</td>
				
				<td valign="middle" align="center">
				<?php if($this->item->optiontype==1 OR $this->item->optiontype==3){?>
						<label class="sradio"  ><input type="radio" name="correct_ans"  class="options_answer" value="<?php echo $i; ?>"
						<?php if(!empty($this->options[$i]->correct_ans) and $this->options[$i]->correct_ans==1) { echo 'checked="checked"'; } ?>/></label>
						<?php } if($this->item->optiontype==2){?>
						<input type="checkbox" name="correct_ans[]" class="options_answer" value="<?php echo $i; ?>" 
							<?php if(!empty($this->options[$i]->correct_ans) and $this->options[$i]->correct_ans==1) { echo 'checked="checked"'; } ?>/></label>
							
						<?php }?>
			   </td>
				<td width="100" class="center">
					<span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span>
					<input type="hidden" name="oorder[]" value="<?php echo $i+1;?>"/>
				</td>
				
				<td valign="middle" align="center">
				<a href="javascript:void(0);" class="remNew btn btn-danger">-</a></td>
			</tr>
			<?php 
			}?>

		</table>
		<table width="100%" id="addinput2">
			<tr>			
					<th></th>	
				<th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_IMAGES_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_IMAGES'); ?></label></th>
				
				<th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUESTION_OPTIONS'); ?></label></th>		
					<th>
					<label class="hasTip"  title="<?php echo JText::_('COM_VQUIZ_QUESTION_CHOOSE_ANSWER_TOOLTIP'); ?>">
					<?php echo JText::_('COM_VQUIZ_ANSWER'); ?>
					</label>
					</th>
				<th><label><?php echo JText::_('COM_VQUIZ_ORDERING'); ?></label></th>
				<th><label><?php echo JText::_('COM_VQUIZ_REMOVE'); ?></label></th>
			</tr>
			<tr>
					<td></td>
					<td class="upimg"><input type="file" name="image[]" id="option_images" />
					<?php 

					if(!empty($this->options[0]->image) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[0]->image)){ 
					echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[0]->image. '" alt="x" />'; 
					}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
					?>	
					
				</td>
					<td width="100" class="center"><label id="qoption"  name="qoption[]"><?php echo JText::_('TRUE'); ?></label></td>
					
						<td align="center"><input type="radio" name="correct_ans"  value="" class="options_answer" <?php if(!empty($this->options[0]->correct_ans) and $this->options[0]->correct_ans==1) { echo 'checked="checked"'; } ?>/></td>
						
					<td>
					</td>
				
						<td></td>
					</tr>
				<tr>
					<td></td>
					<td class="upimg"><input type="file" name="image[]" id="option_images" />
					<?php 

					if(!empty($this->options[1]->image) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[1]->image)){ 
					echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$this->options[1]->image. '" alt="x" />'; 
					}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
					?>	
					
					</td>
					<td width="100" class="center"><label id="qoption"  name="qoption[]"><?php echo JText::_('FALSE'); ?></label></td>
					
					<td align="center"><input type="radio" name="correct_ans"  value="" class="options_answer" <?php if(!empty($this->options[1]->correct_ans) and $this->options[1]->correct_ans==1) { echo 'checked="checked"'; } ?>/>
				
					<td>
					</td>
					<td></td>
				
			</tr>
	</table>
	</fieldset>
</div> 

<div class="clr"></div>
<?php echo JHTML::_( 'form.token' ); ?> 

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="questionpool" />

<input type="hidden" name="score_category" id="score_category" value="<?php echo count($this->score_category)?>" />
<input type="hidden" name="score_category_count" value="<?php echo count($this->score_category)?>" id="score_category_count"/>

</form>