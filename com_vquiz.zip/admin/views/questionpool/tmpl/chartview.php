<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.framework');
JHtml::_('behavior.tooltip');
JHTML::_('behavior.modal');

$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$id = JRequest::getInt('id');
 ?>
<script type="text/javascript" 
src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization','version':'1','packages':['corechart'],'language':'ru'}]}">
</script>
   
 <script type="text/javascript">
    
jQuery(function(){
	
    if(typeof google !== "undefined"){   
	    google.setOnLoadCallback(drawChart);		
	}
	
	function mouseEventHandler(event)  {
		document.getElementById('chart').innerHTML += "You clicked " + event.region + "<br/>";
	}

    
    function drawChart() 
	{
		var id = jQuery('input[name="id"]').val();
 		
		jQuery.ajax(
		{
			url: "index.php",
			type: "POST",
			dataType:"json",
			data: {'option':'com_vquiz','view':'questionpool', 'task':'drawChart','questionid':id,'tmpl':'component',"<?php echo JSession::getFormToken(); ?>":1},
			beforeSend: function()	{
				jQuery(".poploadingbox").show();
			},
			complete: function()	{
				jQuery(".poploadingbox").hide();
			},
			
			success: function(data)	
			{ 
				if(data.result == "success")
				{
					var responce=data.responce;					 
					 var data = google.visualization.arrayToDataTable(responce);
					 var options = {
						width: 800,
						//height: 1000,
						title: '<?php echo JText::_('COM_VQUIZ_QUIZMANAGER_CHOOSED_OPTION_BY_USER'); ?>',
						hAxis: {title: '<?php echo JText::_('COM_VQUIZ_USERS'); ?>', titleTextStyle: {color: 'red'},gridlines:{color: '#FFFFF', count: 0}},
						vAxis: {title: '<?php echo JText::_('COM_VQUIZ_QUESTIONS'); ?>',titleTextStyle: {color: 'red'}},

						//chartArea: {width: '60%',height:'100%'},
						legend: {position: 'top',textStyle: {color: 'blue', fontSize: 16}, maxLines: 5 },
						bar: { groupWidth: '100%' },
						isStacked: true
					}; 
					var chart = new google.visualization.BarChart(document.getElementById("chart2"));
					function errorHandler(errorMessage) {
					console.log(errorMessage);
					google.visualization.errors.removeError(errorMessage.id);
					}
					google.visualization.events.addListener(chart, 'error', errorHandler);
					chart.draw(data, options);
 						
				 }
 
			}
		});
    }
	
});
</script>
 

<div class="poploadingbox">
<?php echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/loading.gif"   />' ?>
</div>

	<div class="cpanel-left">
	
	<h3><?php echo JText::_('COM_VQUIZ_MOST_OPTION_CHOOSED')?></h3>
	<div class="chart2" style="text-align:center">
		<div id="chart2" style="display:inline-block;height:500px;position:relative;" ></div>
	</div>
	
   </div>
   
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="questionpool" />
<input type="hidden" name="id" value="<?php echo $id; ?>" />
