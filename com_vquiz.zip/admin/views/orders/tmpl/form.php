<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 www.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');

if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

$config = QuizHelper::getConfiguration();

//error_reporting(0);
//echo "<pre>";print_r($this); exit;
?>
<script type="text/javascript">

var jq=jQuery.noConflict();

Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
			      
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}
function discount_apply(){	
	   var subscription_id = <?php echo JRequest::getInt('subscr_id');?>;
	   jQuery.ajax({
			  url: "index.php",
			  type: "POST",
			   data: {"option":"com_vquiz", "view":"orders", "task":"applycoupon", "subscription_id":subscription_id, "couponkey":jQuery('#app_discount_code_id').val()},
			   beforeSend: function()	{ 
						jQuery(".vmap_overlay").show();
						},
			   complete: function()	{ 
						jQuery(".vmap_overlay").hide();
						}
		}).done(function( resp ) { 
			 var obj = jQuery.parseJSON(resp); //alert(obj.message);
		  jQuery('#pp-discount-spinner').text(obj.message); 
		});	
   }	
</script>
<?php //$user = JFactory::getUser();?>
<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="row-fluid">
<div class="span6">
    <fieldset class="adminform">
    <legend><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_DETAILS' ); ?> 
			</legend>
        <table class="adminform table table-striped">
	    
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_EDIT_TOOLTIP_ORDER_ID'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_ORDER_ID'); ?></label></td>
			
			<td>
				<?php echo $this->item->order_id; ?> </td>			
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_EDIT_TOOLTIP_APP_TYPE'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_GRID_APP_TYPE'); ?></label></td>
			
			<td>
				<?php  $app_detail = QuizHelper::getPaymenPluginDetail($this->item->app_id);
					     if(isset($app_detail->title)){echo $app_detail->title;}
					?>
				</td>
			 
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_EDIT_TOOLTIP_BUYER'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_BUYER'); ?></label></td>
			
			<td><?php 
					$user  = JFactory::getUser($this->item->buyer_id);
					echo "<span class='hidden-phone hidden-tablet'>#".$this->item->buyer_id.": ".$user->name."</span>";?>
				    	<?php echo '('.$user->username.')';?></td>
			
        </tr>
		
		
		
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_EDIT_TOOLTIP_SUBTOTAL'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_SUBTOTAL'); ?></label></td>
			
			<td>
				<?php
                      $discount = 0;//print_r($this->item);
					  $session = JFactory::getSession();
					   $coupon = $session->get('coupon_data', ''); 
					    $total = $this->item->total; 
						if( !empty($coupon) ) {
						if( $coupon['type_offer'] == 1 ) { // DISCOUNT IN AMOUNT
						$discount = $coupon['offer'];
						}
						if( $coupon['type_offer'] == 0 ) { // DISCOUNT IN PERCENTAGE
						$discount = ($coupon['offer']*$total)/100;
						}

						}
						elseif(!empty($this->item->coupon_code)){
						$coupon_code = explode(';;', $this->item->coupon_code);
                                                if( $coupon_code[2] == 1 ) { // DISCOUNT IN AMOUNT
						$discount = $coupon_code[1];
						}
						if( $coupon_code[2] == 0 ) { // DISCOUNT IN PERCENTAGE
						$discount = ($coupon_code[1]*$total)/100;
						}						
						}
					  ?>
					  
				<?php echo QuizHelper::priceformat($this->item->subtotal); ?>
			</td>
			
        </tr>
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_EDIT_TOOLTIP_DISCOUNT'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_DISCOUNT'); ?></label></td>
			
			<td>
					<?php echo QuizHelper::priceformat($this->item->discount_amount);?>
					
					
					</td>
			
        </tr>
		
		<?php if($config->tax_enable) { ?>
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_EDIT_TOOLTIP_TAX'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_TAX'); ?></label></td>
			
			<td>
					<?php echo $config->tax_in=='percent'?$config->tax_value.'%':$config->tax_value; ?></td>
			
        </tr>
		<?php } ?>
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_EDIT_TOOLTIP_TOTAL'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_TOTAL'); ?></label></td>
			
			<td>
					<?php echo QuizHelper::priceformat($this->item->total); ?>	
					
					
					</td>
			
        </tr>
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_EDIT_TOOLTIP_STATUS'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_STATUS'); ?></label></td>
			
			<td>
			
				<select name="status" id="status">
				
				<option value=""><?php echo JText::_('COM_VQUIZ_SELECT_STATUS'); ?></option>								
				<option value="30" <?php if($this->item->status==30) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_NONE'); ?> </option>
				<option value="31" <?php if($this->item->status==31) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_PAID'); ?> </option>
				<option value="32" <?php if($this->item->status==32) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_HOLD'); ?> </option>
				<option value="33" <?php if($this->item->status==33) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_EXPIRED'); ?> </option>				
				<option value="34" <?php if($this->item->status==34) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_CANCEL'); ?> </option>
				<option value="35" <?php if($this->item->status==35) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_REFUND'); ?> </option>
				
				</select>
					
					
					</td>
			
        </tr>	
		
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_EDIT_TOOLTIP_CREATED_DATE'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_CREATED_DATE'); ?></label></td>
			
			<td> <?php echo $this->item->created_date; ?> </td>
			
        </tr>
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ORDER_EDIT_TOOLTIP_PAID_DATE'); ?>"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_PAID_DATE'); ?></label></td>
			
			<td> <?php echo $this->item->paid_date; ?> </td>
			
        </tr>
		
		<tr>
			
			<td class="key" width="200" colspan="2"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_PARAMETERS'); ?></td>
			
        </tr>	
		
		
		
		<?php
		if(empty($this->item->params)){
		$param = new stdclass();
		$param->expirationtype = 'forever';
		$param->expiration = '000000000000';
		$param->price = '0.00';
		$param->title = '';		
		}
		else
		{
		$param = json_decode($this->item->params);	//print_r($param); jexit();
		
		}
		
		?>
		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_QUIZ_PLANS_TITLE'); ?>"><?php echo JText::_('COM_QUIZ_PLANS_TITLE'); ?></label> </td>
			
			<td><input type="text" name="params[title]" id="title" value="<?php echo $param->title;?>" /></td>	
		</tr>
		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_QUIZ_PLAN_TIME_EXPIRATION_TYPE_DESC'); ?>"><?php echo JText::_('COM_QUIZ_PLAN_TIME_EXPIRATION_TYPE_LABEL'); ?></label> </td>
			
			<td>
				<select name="params[expirationtype]" id="expirationtype">
				 
				 <option value="forever" <?php if($param->expirationtype=='forever') echo ' selected="selected"';?>><?php echo JText::_('COM_QUIZ_PLAN_TIME_EXPIRATION_FOREVER'); ?></option>
				 
				 <option value="fixed" <?php if($param->expirationtype=='fixed') echo ' selected="selected"';?>><?php echo JText::_('COM_QUIZ_PLAN_TIME_EXPIRATION_FIXED'); ?></option>
				
				 </select>
			</td>
								
		</tr>
		   <tr>
			   
			   <td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_QUIZ_PLAN_PAYMENT_PRICE_DESC'); ?>"><?php echo JText::_('COM_QUIZ_PLAN_PAYMENT_PRICE_LABEL'); ?></label> </td>
			   
			   <td>
			   
			   <input name="params[price]" type="text" class="number"  size="30" value="<?php echo $param->price;?>" />
			   
			   </td>
		   </tr>
		   
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_QUIZ_PLAN_TIME_EXPIRATION_DESC'); ?>"><?php echo JText::_('COM_QUIZ_PLAN_TIME_EXPIRATION_LABEL'); ?></label> </td>
			
			<td>
			 
			 <div class="controls exp_time">
				
				
				<?php $expiration_arr = str_split($param->expiration, 2); ?>
				
				<?php echo JText::_('COM_VQUIZ_PLANS_Y'); ?> <select name="expiration_year" style="width:15%">
				 <?php for($i=0 ; $i<=10 ; $i++){ ?>					 
				 
				 <option value="<?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?>" <?php if(isset($expiration_arr[0])&&$expiration_arr[0]==$i) echo ' selected="selected"';?>><?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?></option>
				 
				 <?php } ?> 
				
				 </select>
				 
				 <?php echo JText::_('COM_VQUIZ_PLANS_M'); ?> <select name="expiration_month" style="width:15%">
				 <?php for($i=0 ; $i<=11 ; $i++){ ?>					 
				 
				 <option value="<?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?>" <?php if(isset($expiration_arr[1])&&$expiration_arr[1]==$i) echo ' selected="selected"';?>><?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?></option>
				 
				 <?php } ?> 
				
				 </select>
				 
				 <?php echo JText::_('COM_VQUIZ_PLANS_D'); ?> <select name="expiration_day" style="width:15%">
				 <?php for($i=0 ; $i<=30 ; $i++){ ?>					 
				 
				 <option value="<?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?>" <?php if(isset($expiration_arr[2])&&$expiration_arr[2]==$i) echo ' selected="selected"';?>><?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?></option>
				 
				 <?php } ?> 
				
				 </select>
				 
			</div>
			
		   </td>
		   
	   </tr>
	   
	   </table>
	   </div>
	   
	   <div class="span6">
	  
	   <div class="pp-position clearfix">
		<fieldset class="form-horizontal">
	  		
			
		<legend> <?php echo JText::_('COM_VQUIZ_SM_PRODISCOUNT') ?> </legend>
			<div class="control-group">		
				<span>
					<input id="app_discount_code_id" name="app_discount_code" class="input-large" placeholder="<?php echo JText::_('COM_VQUIZ_PRODISCOUNT_ENTER_DISCOUNT_CODE_OR_AMOUNT') ?>" value="" />
					&nbsp;&nbsp;&nbsp;<a  id="app_discount_code_submit" onClick="discount_apply();"><?php echo JText::_("COM_VQUIZ_PRODISCOUNT_APPLY");?></a>
					<span id="pp-discount-spinner" style="height:12px;">&nbsp;&nbsp;</span>
				</span>
				</br></br>
				<span id="app-discount-apply-error" class="error">&nbsp;</span>
			</div>							   
	   
       
    </fieldset>
	</div>
	</div>
</div> 

<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="order_id" value="<?php echo $this->item->order_id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="orders" />
<input type="hidden" name="total" value="<?php echo $this->item->total; ?>" />
<input type="hidden" name="subtotal" value="<?php echo $this->item->subtotal; ?>" />
<input type="hidden" name="subscr_id" value="<?php echo JRequest::getInt('subscr_id');?>" />
</form>







