<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.html.pagination');	
JHtml::_('behavior.tooltip');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
//$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');

//echo '<pre>'; print_r($this->lists);//exit;

		
		
?>
												
<div class="poploadingbox">
<?php echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/loading.gif"/>' ?>
</div>
<form action="index.php?option=com_vquiz&view=orders" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<?php if (!empty( $this->sidebar)) : ?>   
		<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
		</div>
		<div id="j-main-container" class="span10">
		<?php else : ?>
		<div id="j-main-container">
		<?php endif;?>
		
            <div class="search_buttons span4">
                <div class="btn-wrapper input-append">
                <input placeholder="Search" type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
                <button class="btn" onclick="this.form.submit();"><i class="icon-search"></i><span class="search_text"><?php echo JText::_('COM_VQUIZ_SEARCH'); ?></button>
                <button class="btn" onclick="document.getElementById('search').value='';this.form.submit();"><?php echo JText::_('COM_VQUIZ_RESET'); ?></button>
                </div>
            </div>
			
			
					
			
			
				
			<div class="btn-group pull-right hidden-phone order_select">				<select name="status" id="status" class="inputbox" onchange="this.form.submit()">								<option value=""><?php echo JText::_('COM_VQUIZ_SELECT_STATUS'); ?></option>
			<option value="30" <?php if($this->lists['status']==30) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_NONE'); ?> </option>
			<option value="31" <?php if($this->lists['status']==31) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_PAID'); ?> </option>
			<option value="32" <?php if($this->lists['status']==32) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_HOLD'); ?> </option>
			<option value="33" <?php if($this->lists['status']==33) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_EXPIRED'); ?> </option>
			<option value="34" <?php if($this->lists['status']==34) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_CANCEL'); ?> </option>
	        <option value="35" <?php if($this->lists['status']==35) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_ORDER_REFUND'); ?> </option>								</select>
				
				<select name="planid" id="planid" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('COM_VQUIZ_ALL_PLANS'); ?></option>
				<?php    for ($i=0; $i <count($this->plans); $i++)	
				{ 
				?>
				<option value="<?php echo $this->plans[$i]->id;?>"  <?php  if($this->plans[$i]->id == $this->lists['planid']) echo 'selected="selected"'; ?> ><?php echo $this->plans[$i]->title;?></option>		
				<?php
				}
				?>
				</select>

				<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
				<?php echo $this->pagination->getLimitBox(); ?>
			</div>			<div class="paid_date"><label><strong><?php echo JText::_('COM_VQUIZ_ORDER_GRID_PAID_DATE');?></strong></label>									 			<?php					echo JHtml::_('calendar', (isset($this->lists['paid_date'][0])?$this->lists['paid_date'][0]:''), 'paid_date[0]', 'paid_date_0', '%Y-%m-%d', array('size'=>'10', 'maxlength'=>'19', 'placeholder'=>JText::_('COM_VQUIZ_FILTERS_FROM'))); ?>											<?php					echo JHtml::_('calendar', (isset($this->lists['paid_date'][1])?$this->lists['paid_date'][1]:''), 'paid_date[1]', 'paid_date_1', '%Y-%m-%d', array('size'=>'10', 'maxlength'=>'19', 'placeholder'=>JText::_('COM_VQUIZ_FILTERS_TO'))); ?>					</div>
			
<div id="editcell">
	<table class="adminlist table table-striped table-hover">
	<thead>
		<tr>
        	<th width="5">
                 <?php echo JText::_('COM_VQUIZ_SUBSCRIPTIONS_GRID_NUM'); ?>
			</th>
			
			<th width="20">
			<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
			</th>

			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_ORDER_ID', 'i.order_id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_ORDER_BUYER_ID', 'i.buyer_id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_ORDER_GATEWAY_TYPE', 'i.app_id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
				<?php echo JHTML::_('grid.sort', 'COM_VQUIZ_ORDER_SUBTOTAL', 'i.subtotal', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
				<?php echo JHTML::_('grid.sort', 'COM_VQUIZ_ORDER_TOTAL', 'i.total', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
				 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_ORDER_STATUS', 'i.status', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>	
			</th>
			
            <th>
				  <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_ORDER_CREATE_DATE', 'i.create_date', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
				  <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_ORDER_PAID_DATE', 'i.paid_date', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
		</tr>
	</thead>
    
	<?php

	$k = 0;
	for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
		
		$row = &$this->items[$i];
        
		$checked 	= JHTML::_('grid.id',   $i, $row->order_id );
		
		$link 		= JRoute::_( 'index.php?option=com_vquiz&view=orders&subscr_id='.$row->subscr_id.'&task=edit&cid[]='. $row->order_id );		
				
		$users = JFactory::getUser($row->buyer_id);

		if($row->status==30){
				$status  = JText::_('COM_VQUIZ_STATUS_ORDER_NONE'); 
		}
		elseif($row->status==31){
				$status  = JText::_('COM_VQUIZ_STATUS_ORDER_PAID'); 
		}
		elseif($row->status==32){
				$status  = JText::_('COM_VQUIZ_STATUS_ORDER_HOLD'); 
		}
		elseif($row->status==33){
				$status  = JText::_('COM_VQUIZ_STATUS_ORDER_EXPIRED'); 
		}		
		elseif($row->status==34){
				$status  = JText::_('COM_VQUIZ_STATUS_ORDER_CANCEL'); 
		}
		elseif($row->status==35){
				$status  = JText::_('COM_VQUIZ_STATUS_ORDER_REFUND'); 
		}
		else{
				$status  = JText::_('COM_VQUIZ_STATUS_ORDER_NONE'); 
		}
		
			
		?>

		<tr class="<?php echo "row$k"; ?>">
			
			<td><?php echo $this->pagination->getRowOffset($i); ?></td>
			
			<td>
				<?php echo $checked; ?>
			</td>
			
			<td><a href="<?php echo $link; ?>"> <?php echo $row->order_id;  ?></a></td>

			<td>
		    <?php echo "<span class='hidden-phone hidden-tablet'>#".$row->buyer_id.": ".$users->name."</span>";?>
				    	<?php echo '('.$users->username.')';?>
			</td>
			
			<td align="center">
				<?php  $app_detail = QuizHelper::getPaymenPluginDetail($row->app_id);
					     if(isset($app_detail->title)){echo $app_detail->title;}
					?>
			</td>
			
			<td><?php echo QuizHelper::priceformat($row->subtotal);?></td> 
			
			<td><?php echo QuizHelper::priceformat($row->total);?></td> 
					
			<td>
					 <?php echo $status;?>
					</td> 
			
			
			
			<td align="center">
				<?php echo $row->created_date; ?>
			</td> 
			
			<td align="center">
				<?php  
				if($row->paid_date=='1000-01-01 00:00:00' || $row->paid_date=='0000-00-00 00:00:00'){
					echo 'Never';
				}else{
					echo $row->paid_date;
				}					
			?>
			</td>
				
			
			
			
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	
	<tfoot>
    <tr>
    <td colspan="11"> <?php echo $this->pagination->getListFooter(); ?></td>
    </tr>
    </tfoot>
	
	</table>

</div>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="orders" />
<input type="hidden" name="tmpl" value="<?php echo JRequest::getVar('tmpl', 'index'); ?>" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />

</div>  
</form>



