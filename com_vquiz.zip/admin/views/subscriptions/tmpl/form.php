<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');
$document = JFactory::getDocument();$document->addStyleSheet('components/com_vquiz/assets/css/style.css');

if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

//error_reporting(0);
//echo "<pre>";print_r($this->item); exit;
?>
<script type="text/javascript">
Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
			
			if(jQuery('#user_id').val()==''){
				alert('<?php echo JText::_("COM_VQUIZ_SUBSCRIPTIONS_PLZ_SELECT_USER");?>');
				document.adminForm.users.focus();
				return false;
			}
                        if(jQuery('#plan_id').val()==''){
				alert('<?php echo JText::_("COM_VQUIZ_SUBSCRIPTIONS_PLZ_SELECT_PLAN");?>');
				document.adminForm.plan_id.focus();
				return false;
			}	
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}
</script>
<?php //$user = JFactory::getUser();?>
<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">

<div class="col101">

<div class="span6 pp-word-wrap vquiz">
    <fieldset class="adminform">
    <legend><?php echo JText::_('COM_VQUIZ_SUBSCRIPTION_EDIT_DETAILS' ); ?> 
			</legend>
        <table class="adminform table table-striped">
	    
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_SUBSCRIPTION_EDIT_TOOLTIP_USER'); ?>"><?php echo JText::_('COM_VQUIZ_SUBSCRIPTION_EDIT_TOOLTIP_USER'); ?></label></td>
			
			<td>
				<select name="user_id" id="user_id">
					<option value=""><?php echo JText::_('Select User'); ?> 
					<?php    for ($i=0; $i <count($this->users); $i++)	
					{	
					?>
					<option value="<?php echo $this->users[$i]->id;?>"  <?php  if($this->users[$i]->id == $this->item->user_id) echo 'selected="selected"'; ?> >
					<?php
					echo $this->users[$i]->name.'('.$this->users[$i]->username.')';
					?> 
					</option>		
					<?php
					}
					?>
				</select>
			
			
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_SUBSCRIPTION_EDIT_TOOLTIP_PLAN'); ?>"><?php echo JText::_('COM_VQUIZ_SUBSCRIPTION_EDIT_PLAN'); ?></label></td>
			
			<td>
				<select name="plan_id" id="plan_id">
					<option value=""><?php echo JText::_('COM_VQUIZ_ALL_PLANS'); ?> 
						<?php    for ($i=0; $i <count($this->plans); $i++)	
						{	
						?>
						<option value="<?php echo $this->plans[$i]->id;?>"  <?php  if($this->plans[$i]->id == $this->item->plan_id) echo 'selected="selected"'; ?> >
						<?php
						echo $this->plans[$i]->title;
						?> 
						</option>		
						<?php
						}
						?>
						</select>
				</td>
			 
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_SUBSCRIPTION_EDIT_TOOLTIP_ORDER_TOTAL'); ?>"><?php echo JText::_('COM_VQUIZ_SUBSCRIPTION_EDIT_ORDER_TOTAL'); ?></label></td>
			
			<td><?php echo QuizHelper::priceformat($this->item->total);  ?></td>
			
        </tr>
		
		 <tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_SUBSCRIPTION_EDIT_TOOLTIP_STATUS'); ?>"><?php echo JText::_('COM_VQUIZ_SUBSCRIPTION_EDIT_STATUS'); ?></label></td>
			
			<td>
				<select  name="status" id="status" >
				<option value="1" <?php if($this->item->status==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_SUBSCRIPTION_ACTIVE'); ?> </option>
				<option value="2" <?php if($this->item->status==2) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_SUBSCRIPTION_HOLD'); ?> </option>
				<option value="3" <?php if($this->item->status==3) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_SUBSCRIPTION_EXPIRED'); ?> </option>
				<option value="4" <?php if($this->item->status==4) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_STATUS_SUBSCRIPTION_NONE'); ?> </option>
				</select>
			</td>
			
        </tr>
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_SUBSCRIPTION_EDIT_TOOLTIP_DATE'); ?>"><?php echo JText::_('COM_PAYPLANS_SUBSCRIPTION_EDIT_SUBSCRIPTION_DATE'); ?></label></td>
			
			<td>
					<?php
					echo isset($this->item->subscription_date)?JHtml::_('calendar', $this->item->subscription_date, 'subscription_date', 'subscription_date', '%Y-%m-%d %H:%M:%S', ''):JText::_('COM_VQUIZ_SUBSCRIPTION_EDIT_EXPIRATION_DATE_NEVER'); ?>
			</td>
			
        </tr>
		
		<tr>
			
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_SUBSCRIPTION_EDIT_TOOLTIP_EXPIRATION_DATE'); ?>"><?php echo JText::_('COM_VQUIZ_SUBSCRIPTION_EDIT_EXPIRATION_DATE'); ?></label></td>
			
			<td>
					<?php echo isset($this->item->expiration_date)? JHtml::_('calendar', $this->item->expiration_date, 'expiration_date', 'expiration_date', '%Y-%m-%d %H:%M:%S', ''):JText::_('COM_VQUIZ_SUBSCRIPTION_EDIT_EXPIRATION_DATE_NEVER'); ?>
					
			</td>
			
        </tr>
		
		
	   
       </table>
    </fieldset>

</div> 

<div class="span6 pp-word-wrap">	
	<div class="pp-invoice-details">
	<fieldset class="form-horizontal">
		<legend>
			<?php echo JText::_('COM_VQUIZ_ORDER_EDIT_INVOICE' ); ?>
		</legend>
		
		<div class="pull-right">
				<a href="<?php echo JRoute::_('index.php?option=com_vquiz&view=orders&task=createOrder&subscr_id='.$this->item->id, false);?>" onclick="this.onclick=function(){return false;}" class="btn btn-info"><i class="icon-plus icon-white"></i>
				<strong><?php echo ' '.JText::_('COM_VQUIZ_ORDER_ADD_ORDER');?></strong></a>
                </div>

		<div class="pp-order-edit-invoice">
			<?php if(is_array($this->invoice_records) && !empty($this->invoice_records)) : ?>
				<table class="table table-striped">
	              <thead>
	<!-- TABLE HEADER START -->
		<tr>
			<th><?php echo JText::_('COM_VQUIZ_ORDER_ID');?></th>			
			<th><?php echo JText::_('COM_VQUIZ_ORDER_BUYER_ID');?></th>
			<th><?php echo JText::_('COM_VQUIZ_ORDER_APP_TYPE');?></th>
			<th><?php echo JText::_('COM_VQUIZ_ORDER_SUBTOTAL');?></th>
			<th><?php echo JText::_('COM_VQUIZ_ORDER_TOTAL');?></th>
			<th><?php echo JText::_('COM_VQUIZ_ORDER_STATUS');?></th>    
		</tr>
	<!-- TABLE HEADER END -->
	</thead>
	
	<tbody>
	<!-- TABLE BODY START -->		 
		<?php $count = 0;?> 
		
		<?php foreach($this->invoice_records as $invoice) : ?>
			<tr class="<?php echo "row".$count%2; ?>">
				<td><?php echo $invoice->order_id;?></td>
				<td><?php echo $invoice->buyer_id;?></td>
				<td><?php $app_detail = QuizHelper::getPaymenPluginDetail($invoice->app_id);
					     if(isset($app_detail->title)){echo $app_detail->title;}?></td>
				<td><?php echo QuizHelper::priceformat($invoice->subtotal);  ?></td>	
				<td><?php echo QuizHelper::priceformat($invoice->total);  ?></td>
				<td><?php echo $invoice->status;?></td>
			</tr>		
		<?php $count++;?> 
		<?php endforeach;?>		
	<!-- TABLE BODY END -->
	</tbody>
	
	<tfoot>
		<tr>
			<td colspan="7">

			</td>
		</tr>
	</tfoot>
</table>
			<?php else :?>
				<div>
					<p class="center"><big><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_NO_INVOICE');?></big></p>
					<p class="center muted"><?php echo JText::_('COM_VQUIZ_ORDER_EDIT_NO_INVOICE_DESC');?></p>
				</div>
			<?php endif;?>
		</div>
	</fieldset>
</div></div>

<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="subscriptions" />
</div>
</form>