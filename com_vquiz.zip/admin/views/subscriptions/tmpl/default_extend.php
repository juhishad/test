<?php
/**
* @copyright	Copyright (C) 2009 - 2011 Ready Bytes Software Labs Pvt. Ltd. All rights reserved.
* @license		https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @package		PayPlans
* @subpackage	Frontend
* @contact 		shyam@readybytes.in
* website		https://www.jpayplans.com
* Technical Support : Forum -	https://www.jpayplans.com/support/support-forum.html
*/
if(defined('_JEXEC')===false) die();
?>
<script>
var quizplans = {};
	(function($){
			// if elements not defined already
			
			quizplans.element = {};
			quizplans.element.timer = {
				elems : Array('year', 'month', 'day', 'hour', 'minute', 'second'),
			
				// get value from selects and combine into string
				getValue : function(elem_class)
				{
					var prefix	= elem_class+'_';
	        		var timer 	= '';
					for(var i=0; i<this.elems.length ; i++)
					{
							var value= parseInt(jQuery('#' + prefix + this.elems[i]).val());
							if(10 > value){
								value = '0' + value;
							}
		
							timer += value;
					}
					
					return timer;
				},
				
				// set given string to different timer selects
				setValue : function(elem_class, value){
					var prefix	= elem_class+'_';
					if(value == null || value.trim().length <=0){
						value = '000000000000';
					}
					 
					value = value.replace(/NaN/g, '00'); 
		 			for(var i =0; i < this.elems.length ; i++){
					
		 				jQuery('#' + prefix+ this.elems[i]).val(parseInt(value.substr(i*2, 2), 10)).trigger('chosen:updated');
		 			}
				},
				
				
				format : function(elem_class){
					var prefix	= elem_class+'_';
					
					var data = {timer:{}};
	 				for(var i =0; i < this.elems.length ; i++){
	 					var value = jQuery('#' + prefix + this.elems[i]).val();
	 					if(typeof(value) == 'undefined' || value == null){
	 						value = 0;
	 					}
	 					data.timer[this.elems[i]]=parseInt(value);
					}
					
					data['domObject'] = 'timer-warp-'+elem_class+' .readable span.pp-content';
					var url='index.php?option=com_vquiz&task=format&object=timer&headerFooter=0';
					//jQuery.post(url, data);
					jQuery.ajax({
						url: url,
						method: 'POST',
                        data: data
                       })
					  .done(function( res ) {
						 jQuery('#timer-warp-expiration span.pp-content').html(res);
					  });
				},
			
				onchange : function(elem_class){
					jQuery('#' + elem_class).attr('value', this.getValue(elem_class));
					this.format(elem_class);
				},
				
				setup : function(elem_class, value){
	
		 			this.setValue(elem_class, value);
		 						   		
			   		// show readble
			   		this.format(elem_class);
			   		
					
					var hoverClass='pp-mouse-hover';    		        
			       
			        jQuery('#timer-warp-'+elem_class+' .editable').hide();
					jQuery('#timer-warp-'+elem_class+' .readable').click(function(){
							jQuery('#timer-warp-'+elem_class+' .editable').fadeToggle(200);
						});
					
					// setup onchange functionality
		    		jQuery('select.'+elem_class).on('change' , function(){ 
		    				quizplans.element.timer.onchange(elem_class);
		    			});  
				}
			}
		})(quizplans.jQuery);
</script>
<div class="pp-subscription-extend">
<form action="index.php?option=com_vquiz&view=subscription&task=extend" method="post" name="select-extend-time" id="select-extend-time" class="form-horizontal">
	<div class="muted">
		<?php echo JText::_('COM_VQUIZ_SUBSCRIPTION_GRID_EXTEND_MESSAGE')?>
	</div>
	
	<div class="control-group">
		<div class="control-label">
			<?php echo JText::_('COM_VQUIZ_AJAX_SUBSCRIPTION_SELECT_EXTEND_TIME')?>
		</div>
		<div class="controls">
		<?php  echo QuizHelper::edit('expiration','000000000000','expiration'); ?>
		
		</div>
	</div>
	<div class="pp-time">
		
	</div>
	<input type="hidden" id="subscrip_id" name="subscrip_id" value="" />

</form>
</div>
<?php 
if(!empty($this->tmpl))
jexit();