<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.html.pagination');	
JHtml::_('behavior.tooltip');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
//$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');

$activeSub   		= QuizHelper::getTotalSubscription(QuizHelper::SUBSCRIPTION_ACTIVE);
$holdSub   			= QuizHelper::getTotalSubscription(QuizHelper::SUBSCRIPTION_HOLD);
$expiredSub   		= QuizHelper::getTotalSubscription(QuizHelper::SUBSCRIPTION_EXPIRED);
$nostatusSub   		= QuizHelper::getTotalSubscription(QuizHelper::SUBSCRIPTION_NONE);

$subscriptionStats	= QuizHelper::getSubscriptionStats($activeSub, $expiredSub, $holdSub, $nostatusSub);

	
//echo '<pre>';print_r($this->lists); //exit;

		
		
?>
												
<div class="poploadingbox">
<?php echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/loading.gif"/>' ?>
</div>
<form action="index.php?option=com_vquiz&view=subscriptions" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<?php if (!empty( $this->sidebar)) : ?>   
		<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
		</div>
		<div id="j-main-container" class="span10">
		<?php else : ?>
		<div id="j-main-container">
		<?php endif;?>
		
            <div class="search_buttons subscription_buttons span12">
			
			  <div class="span5 hidden-phone">
		       <?php if(!empty($subscriptionStats)){ ?>
	                 <div class="span5"><label class="t_title"><?php echo JText::_('COM_VQUIZ_TOTAL_SUBSCRIPTIONS')?></label></div>
				<!-- Bar for color codings-->
				<div class="span7">				<div class="progress">
					<?php // Available Subscription status
				  		  $statu = array("0"=>JText::_('COM_VQUIZ_SUBSCRIPTION_NONE'),"1"=>JText::_('COM_VQUIZ_SUBSCRIPTION_ACTIVE'),"2"=>JText::_('COM_VQUIZ_SUBSCRIPTION_HOLD'),"3"=>JText::_('COM_VQUIZ_SUBSCRIPTION_EXPIRED'));						  	
				  		  
				  		  // Process Subscription stats according to status
				  		  foreach($statu as $key=>$status) { ?>
				  		  						
							  <div class="bar hasTooltip <?php echo isset($subscriptionStats['class'][$key]) 	? $subscriptionStats['class'][$key] : '';?>"
							  	   title="<?php echo isset($subscriptionStats['message'][$key]) 		? $subscriptionStats['count'][$key]." ".$subscriptionStats['message'][$key] : '';?>"
							  	   style="width: <?php echo isset($subscriptionStats['width'][$key]) ? $subscriptionStats['width'][$key] : '';?>%;">
							  	   		
				  	   			<b><?php echo isset($subscriptionStats['count'][$key]) ? $subscriptionStats['count'][$key] : "";?></b>
							  </div>
			   <?php }?>
				</div>				</div>
			   <?php }?>
		   </div>
		   
                <div class="span7 search_area"><div class="btn-wrapper input-append">
                <input placeholder="Search" type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
                <button class="btn" onclick="this.form.submit();"><i class="icon-search"></i><span class="search_text"><?php echo JText::_('COM_VQUIZ_SEARCH'); ?></button>
                <button class="btn" onclick="document.getElementById('search').value='';this.form.submit();"><?php echo JText::_('COM_VQUIZ_RESET'); ?></button>
                </div>				<select name="planid" id="planid" class="inputbox" onchange="this.form.submit()">				<option value=""><?php echo JText::_('COM_VQUIZ_ALL_PLANS'); ?></option>				<?php    for ($i=0; $i <count($this->plans); $i++)					{ 				?>				<option value="<?php echo $this->plans[$i]->id;?>"  <?php  if($this->plans[$i]->id == $this->lists['planid']) echo 'selected="selected"'; ?> ><?php echo $this->plans[$i]->title;?></option>						<?php				}				?>				</select>							<div class="btn-group pull-right hidden-phone">								<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>				<?php echo $this->pagination->getLimitBox(); ?>			</div>                </div>
            </div>
			<div class="span12 subscription_date_plan"><div class="span6 subscription_date">
						<label><strong><?php echo JText::_('COM_VQUIZ_SUBSCRIPTION_GRID_SUBSCRIPTION_DATE');?></strong></label>
			
			 
			<?php
					echo JHtml::_('calendar', (isset($this->lists['subscription_date'][0])?$this->lists['subscription_date'][0]:''), 'subscription_date[0]', 'subscription_date_0', '%Y-%m-%d', array('size'=>'10', 'maxlength'=>'19', 'placeholder'=>JText::_('COM_VQUIZ_FILTERS_FROM'))); ?>
					
			
					
			<?php
					echo JHtml::_('calendar', (isset($this->lists['subscription_date'][1])?$this->lists['subscription_date'][1]:''), 'subscription_date[1]', 'subscription_date_1', '%Y-%m-%d', array('size'=>'10', 'maxlength'=>'19', 'placeholder'=>JText::_('COM_VQUIZ_FILTERS_TO'))); ?>					</div>
					
					
					
					<div class="span6 expiration_date">
			<label><strong><?php echo JText::_('COM_VQUIZ_SUBSCRIPTION_GRID_EXPIRATION_DATE');?></strong></label>
			
			
			 
			<?php
					echo JHtml::_('calendar', (isset($this->lists['expiration_date'][0])?$this->lists['expiration_date'][0]:''), 'expiration_date[0]', 'expiration_date_0', '%Y-%m-%d', array('size'=>'10', 'maxlength'=>'19', 'placeholder'=>JText::_('COM_VQUIZ_FILTERS_FROM'))); ?>
			
					
			<?php
					echo JHtml::_('calendar', (isset($this->lists['expiration_date'][1])?$this->lists['expiration_date'][1]:''), 'expiration_date[1]', 'expiration_date_1', '%Y-%m-%d', array('size'=>'10', 'maxlength'=>'19', 'placeholder'=>JText::_('COM_VQUIZ_FILTERS_TO'))); ?>
	</div>					</div>				
			
<div id="editcell">
	<table class="adminlist table table-striped table-hover">
	<thead>
		<tr>
        	<th width="5">
                 <?php echo JText::_('COM_VQUIZ_SUBSCRIPTIONS_GRID_NUM'); ?>
			</th>
			
			<th width="20">
			<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
			</th>
			
			<th width="5">
				  <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_SUBSCRIPTIONS_GRID_ID', 'i.id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>

			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_SUBSCRIPTIONS_GRID_USER', 'u.id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_SUBSCRIPTIONS_GRID_PLAN', 'i.plan_id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_SUBSCRIPTIONS_GRID_AMOUNT', 'i.total', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
				<?php echo JHTML::_('grid.sort', 'COM_VQUIZ_SUBSCRIPTIONS_GRID_STATUS', 'i.status', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
				 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_SUBSCRIPTIONS_GRID_SUBSCRIPTION_DATE', 'i.subscription_date', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>	
			</th>
			
			<th>
				<?php echo JHTML::_('grid.sort', 'COM_VQUIZ_SUBSCRIPTIONS_GRID_EXPIRATION_DATE', 'i.expiration_date', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
		
			
            
		</tr>
	</thead>
    
	<?php

	$k = 0;
	for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
		
		$row = &$this->items[$i];
        
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		
		$link 		= JRoute::_( 'index.php?option=com_vquiz&view=subscriptions&task=edit&cid[]='. $row->id );		
				
		$users = JFactory::getUser($row->user_id);
		
		$plan = QuizHelper::planDetails($row->id);
		
		if($row->status==1){
				$status  = JText::_('COM_VQUIZ_STATUS_SUBSCRIPTION_ACTIVE'); 
		}
		elseif($row->status==2){
				$status  = JText::_('COM_VQUIZ_STATUS_SUBSCRIPTION_HOLD'); 
		}
		elseif($row->status==3){
				$status  = JText::_('COM_VQUIZ_STATUS_SUBSCRIPTION_EXPIRED'); 
		}
		elseif($row->status==4){
				$status  = JText::_('COM_VQUIZ_STATUS_SUBSCRIPTION_NONE'); 
		}
		else{
				$status  = JText::_('COM_VQUIZ_STATUS_SUBSCRIPTION_NONE'); 
		}
		
		?>

		<tr class="<?php echo "row$k"; ?>">
			
			<td><?php echo $this->pagination->getRowOffset($i); ?></td>
			
			<td>
				<?php echo $checked; ?>
			</td>
			
			<td><a href="<?php echo $link; ?>"> <?php echo $row->id;  ?></a></td>

			<td>
		    <?php echo "<span class='hidden-phone hidden-tablet'>#".$row->user_id.": ".$users->name."</span>";?>
				    	<?php echo '('.$users->username.')';?>
			</td>
			
			<td align="center">
				<?php 
				$params_detail = json_decode($row->params);
				echo $params_detail->title;
				?>  
			</td>
			
			<td align="center">
				<?php 
					  echo QuizHelper::priceformat($row->total); 
			    ?>
			</td>
			
			<td align="center">
				<?php echo $status; ?>
			</td>
			
			<td align="center">
				<?php echo $row->subscription_date; ?>
			</td> 
			
			<td align="center">
			<?php  
				if($row->expiration_date=='1000-01-01 00:00:00' || $row->expiration_date=='0000-00-00 00:00:00'){
					echo 'Never';
				}else{
					echo $row->expiration_date;
				}					
			?>
			</td>
				
			
			
			
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	
	<tfoot>
    <tr>
    <td colspan="11"> <?php echo $this->pagination->getListFooter(); ?></td>
    </tr>
    </tfoot>
	
	</table>

</div>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="subscriptions" />
<input type="hidden" name="tmpl" value="<?php echo JRequest::getVar('tmpl', 'index'); ?>" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
</div>  
</form>



