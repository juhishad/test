<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');
JHtml::_('formbehavior.chosen', 'select');


$user = JFactory::getUser();
$userId = $user->id;
$groups = $user->getAuthorisedGroups();

?>
<script type="text/javascript">
	
	Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
			var form = document.adminForm;
		
			if(form.tax_name.value == "")	{
				alert("<?php echo JText::_('PLZ_ENTER_TAX_NAME'); ?>");
				return false;
			}
			if(form.tax_value.value == "")	{
				alert("<?php echo JText::_('PLZ_ENTER_TAX_VAL'); ?>");
				return false;
			}
			
			if(typeof(validateit) == 'function')	{
				if(!validateit())
					return false;
			}
			Joomla.submitform(task, document.getElementById('adminForm'));
		}
	}
</script>

<form action="<?php echo JRoute::_('index.php?option=com_vquiz&view=tax'); ?>" method="post" name="adminForm" id="adminForm">


<div class="col100">

	<fieldset class="adminform">
	<legend>
		<?php if($this->tax->id) echo JText::_( 'Details' ); else echo JText::_( 'Add New Record' ); ?>
	</legend>
	
		<table class="adminform table table-striped">
			<tbody>
				<tr>
					<th width="200"><label class="hasTip" title="<?php echo JText::_('TAX_NAME'); ?>">
						<?php echo JText::_('TAX_NAME'); ?><?php echo JText::_('<span style="color:Red;">'.'*  '.'</span>');?></label>
					</th>
					<td><input class="text_area" type="text" name="tax_name" id="tax_name" size="32" maxlength="50" value="<?php echo $this->tax->tax_name;?>"/></td>
				</tr>

				<tr>
					<th width="200"><label class="hasTip" title="<?php echo JText::_('TAX_VALUE'); ?>">
						<?php echo JText::_('TAX_VALUE'); ?><?php echo JText::_('<span style="color:Red;">'.'*  '.'</span>');?></label>
					</th>
					<td><input class="text_area" type="number" name="tax_value" id="tax_value" size="32" maxlength="50" value="<?php echo $this->tax->tax_value;?>"/></td>
				</tr>

				<tr>
					<th><label class="hasTip" title="<?php echo JText::_('DESCRIPTION'); ?>"><?php echo JText::_('DESCRIPTION'); ?></label></th>
					<td><textarea class="text_area" name="tax_desc" id="tax_desc" rows="4" cols="50"><?php echo $this->tax->tax_desc;?></textarea></td>
				</tr>

			</tbody>
		</table>
	
	</fieldset>

</div>

<div class="clr"></div>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->tax->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="tax" />
</form>
