<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
$editor = JFactory::getEditor();
//echo "<pre>";print_r($this->score_category); exit;
?>
<style>
 #select_choice_chzn{
	display:none;
} 
.p_category_input{
width:100px;
}
#toolbar-exit{
	font-size: 16px; font-weight: bold;display: inline-block;
	float:right;
}
.conf_left_panel .conf_left_panel_buttons #mflip2, .conf_left_panel .conf_left_panel_buttons #certificate_flip {
    width: 50%;
}
</style>

<?php  
JHTML::_('behavior.tooltip');
JHTML::_('behavior.modal');
$document = JFactory::getDocument();
//$document->addScript('components/com_vquiz/assets/js/library.js');
$document->addScript('components/com_vquiz/assets/js/select2.min.js');
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$document->addStyleSheet('components/com_vquiz/assets/css/jquery-ui.css');
$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');
$document->addStyleSheet('components/com_vquiz/assets/css/dialog.css');
$document->addStyleSheet('components/com_vquiz/assets/css/select2.min.css');
$document->addScript(JURI::root().'/media/editors/tinymce/tinymce.min.js');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select'); 

JHTML::_('behavior.calendar');
?>
<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
<script>
 function  tinymce_init(){
	  
 	tinymce.init({
		  selector: ".group_desc",
		  relative_urls : false,
		 // menubar : false,
		  remove_script_host : true,
		  document_base_url :"<?php echo JURI::root();?>",
		  plugins: [
			  "advlist autolink lists link image charmap print preview anchor",
			  "searchreplace visualblocks code fullscreen",
			  "insertdatetime media table contextmenu paste"
		  ],
		  toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
	  });
  }
	
tinymce_init();

function jSelectQuestion_jform_request_id(id, title, object){
	jQuery('#jform_request_id').val(id);
	jQuery('#jform_request_name').val(title);	
	SqueezeBox.close();
}

var jq=jQuery.noConflict();
jq(document).ready(function(){

		SqueezeBox.loadModal = function(modalUrl,handler,x,y) {
			this.presets.size.x = 1024;
			this.initialize();      
			var options = {handler: handler, size: {x: x, y: y}
			};      

			this.setOptions(this.presets, options);
			this.assignOptions();
			this.setContent(handler,modalUrl);
		};	
	
			jq( "#tabs" ).tabs();
			jq( "#tabs_certificate" ).tabs();
				
			jq(".js-example-tags").select2({
				tags: true
			})
			
			jq("#certificate_flip").click(function(){
				jq("#certificate_flip").css("background-color","#999999");
				jq("#mflip2").css("background-color","#cccccc");	
				jq("#mpanel2").slideUp("slow");
				
			});	
			
			jq("#mflip2").click(function(){
				jq("#mflip2").css("background-color","#999999");
				jq("#mpanel2").css("background-color","#999999");
				jq("#certificate_flip").css("background-color","#cccccc");
				jq("#mpanel1").slideUp("slow");
			});
			
			 jq('#cet_type').on('change',function(){
			 
				  var cet_type=jQuery(this).val();
				  if(cet_type==0){
					  jq('.cet_format').css("display","none");
				  }else{
					  jq('.cet_format').css("display","");
				  }
			  });
			  jq('#later_play').on('change',function(){
				
				  var later_play=jQuery(this).val();
				  if(later_play==1){
						jq('.total_time_row').css('display','none');
				  }
				  else{
					  jq('.total_time_row').css('display','');
				  }
			  });
			  
			  //show hide price
			  jq('.price').css("display","none");
				var set_price="<?php echo $this->item->set_price; ?>";
			
				if(set_price==1)
				{
					jq('.price').css("display","");
		 		}
				
				jq('input[name="set_price"]').on('click',function(){
				if(jq(this).val()==0){
							jq('.price').css('display','none');
							
						}else{
							jq('.price').css('display','');
						}
				});
				
				//show hide buttons under Force correct answer
			  jq('.force_correct_answer').css("display","none");
				var force_correct_answer="<?php echo $this->item->force_correct_answer; ?>";
			
				if(force_correct_answer==1)
				{
					jq('.force_correct_answer').css("display","");
		 		}
				
				jq('input[name="force_correct_answer"]').on('click',function(){
				if(jq(this).val()==0){
							jq('.force_correct_answer').css('display','none');
							
						}else{
							jq('.force_correct_answer').css('display','');
						}
				});
			  
			 /*---on Previous button Click--*/
			if(jq('input[name="prev_button"]:checked').val()==0){ 
                jq('.questionreview_answer_prev').css('display','none');
                jq('.questionreview_answer_noprev').css('display','');
			}
			else{ 
                jq('.questionreview_answer_prev').css('display','');
                jq('.questionreview_answer_noprev').css('display','none');
			}
			    
            jQuery('input[name="prev_button"]').on('click',function(){
					if(jq(this).val()==1){
					jq('.questionreview_answer_prev').css('display','');
					jq('.questionreview_answer_noprev').css('display','none');
					}
					else{
                        jq('.questionreview_answer_prev').css('display','none');
						jq('.questionreview_answer_noprev').css('display','');
					}
					
			});

			/* -- Skip button  --*/
			if(jq('input[name="skip_button"]:checked').val()==0){ 
                jq('.questionreview_question').css('display','none');
			}
			else{ 
				jq('.questionreview_question').css('display','');
			}
			    
            jQuery('input[name="skip_button"]').on('click',function(){
					if(jq(this).val()==1){
                        jq('.questionreview_question').css('display','');
					}else{
						jq('.questionreview_question').css('display','none');
					}
			});
			
						
			/* ---on Question review all Question Display-- */
			if(jq('input[name="questionreview"]:checked').val()==0){ 
                jq('.questionreview_question').css('display','none');
			}
			else{ 
				jq('.questionreview_question').css('display','');
			}
			    
            jQuery('input[name="questionreview"]').on('click',function(){ 
				if(jq(this).val()==1){
					jq('.questionreview_question').css('display','');
						/* if(jq('input[name="skip_button"]:checked').val()==0){ 
							jq('.questionreview_question').css('display','none');
						}
						else{ 
							jq('.questionreview_question').css('display','');
						} */
				}else{
					jq('.questionreview_question').css('display','none');
				}
			}); 
			
			

			/* var show_correctans_value=jq('input[name="prev_answer"]:checked').val();
			
			if(show_correctans_value==1 && jq('input[name="prev_button"]:checked').val()==0){
				jq('.show_explanation_tr').css('display','');
			}else{ 
				jq('.show_explanation_tr').css('display','none');
			}

			jq('input[name="prev_answer"]').on( "click", function() { 
			
				if(jq(this).val()==1){
					jq('.show_explanation_tr').css('display','');
				}else{
					jq('.show_explanation_tr').css('display','none');
				}
						
			}); */
 
			 
				if(jq('#quiztype').val()==1){ 
						jq('.trivia_messages').css('display','inline-block');
						jq('.answers_type').css('display','none');
						jq('.personality_messages').css('display','none');
						jq('.multi_personality_messages').css('display','none');
						jq('.multi_p_percentage').css('display','none');
						jq('#multi_personality_category').css('display','none');
						jq('.multi_personality_category').css('display','none');
						jq('#skills_rows').css('display','');

						if(jq('input[name="show_graph"]:checked').val()==0){  
							jq('#graph_type').parent().parent().hide();
							jq('#userscore').parent().parent().hide();
						}else{
							jq('#userscore').parent().parent().show();
							jq('#graph_type').parent().parent().show();	
						}

						jq('.flag').parent().parent().show();
						jq('.livescore').parent().parent().show();
						jq('.penality').parent().parent().show();
						jq('#passed_score').parent().parent().show();
						jq('#total_timelimit').parent().parent().show();
						
						
							jq('.add_score_category').css('display','none');
						
						jq('input[name="show_graph"]').parent().parent().parent().show();
						jq('.display_correctans_tr').css('display','');
						jq('.trivia_personality_none').css('display','');
						jq('.dynamic_group_modal_add').parent().parent().show();
						jq('#qgroup_msg_heading').show();
						jq('.user_select_graph_tr').css('display','');
						jq('.graph_type_tr').css('display','');
						jq('.show_hide_graph_tr').css('display','');
						jq('.live_score_tr').css('display','');
						 
					}
						else if(jq('#quiztype').val()==11){ 
						
						jq('.trivia_messages label').removeAttr("title"); 
						jq('.trivia_messages label').attr('title',"<?php echo JText::_('COM_VQUIZ_SET_SIMULATION_MESSAGE_TOOLTIP'); ?>");
						console.log(jq('.trivia_messages label').attr('title'));
						jq('.trivia_messages').css('display','inline-block');
						
						jq('.personality_messages').css('display','none');
						jq('.multi_personality_messages').css('display','none');
						jq('.multi_p_percentage').css('display','none');
						jq('#multi_personality_category').css('display','none');
						jq('.multi_personality_category').css('display','none');
						jq('#skills_rows').css('display','');

						if(jq('input[name="show_graph"]:checked').val()==0){  
							jq('#graph_type').parent().parent().hide();
							jq('#userscore').parent().parent().hide();
						}else{
							jq('#userscore').parent().parent().show();
							jq('#graph_type').parent().parent().show();	
						}

						jq('.flag').parent().parent().show();
						jq('.livescore').parent().parent().show();
						jq('.penality').parent().parent().show();
						jq('#passed_score').parent().parent().show();
						jq('#total_timelimit').parent().parent().show();
						jq('.answers_type').css('display','');
						if(jq('select[name="answers_type"]').val()==2){ 
							jq('#add_score_category').css('display','');
							jq('.add_score_category').css('display','');
						}else{
							jq('.add_score_category').css('display','none');
						}
						jq('input[name="show_graph"]').parent().parent().parent().show();
						jq('.display_correctans_tr').css('display','none');
						jq('.trivia_personality_none').css('display','');
						jq('.dynamic_group_modal_add').parent().parent().show();
						jq('#qgroup_msg_heading').show();
						jq('.user_select_graph_tr').css('display','');
						jq('.graph_type_tr').css('display','');
						 jq('.show_hide_graph_tr').css('display','');
						 jq('.live_score_tr').css('display','');
					}
					else if(jq('#quiztype').val()==2){ 
						
					   jq('.personality_messages').css('display','inline-block');
					   jq('.multi_personality_messages').css('display','none');
					   jq('#skills_rows').css('display','none');						
						if(jq('#personality_type').val()==0){
							jq('.multi_p_percentage').css('display','none');
							jq('#multi_personality_category').css('display','none');
							jq('.multi_personality_category').css('display','none');
						}else if(jq('#personality_type').val()==1){
							jq('.multi_p_percentage').css('display','');
							jq('#multi_personality_category').css('display','none');
							jq('.multi_personality_category').css('display','none');
						}

					   jq('.trivia_messages').css('display','none');
						/*--Hide Some Option if Choose Personality Type Quiz--*/
							if(jq('input[name="show_graph"]:checked').val()==0){  
							jq('#graph_type').parent().parent().hide();
							}else{
								jq('#graph_type').parent().parent().show();	
							}
							jq('.flag').parent().parent().hide();
							jq('.livescore').parent().parent().hide();
							jq('.answers_type').css('display','none');
							jq('.penality').parent().parent().hide();
							jq('#add_score_category').css('display','none');
							jq('.add_score_category').css('display','none');
							jq('#userscore').parent().parent().hide();
							jq('#passed_score').parent().parent().hide();
							jq('#total_timelimit').parent().parent().show();
							jq('.display_correctans_tr').css('display','none');
							jq('.trivia_personality_none').css('display','');
							jq('.dynamic_group_modal_add').parent().parent().show();
							jq('#qgroup_msg_heading').show();
                            jq('input[name="correctans"]').val(0);
							jq('input[name="show_graph"]').parent().parent().parent().show();
							jq('.user_select_graph_tr').css('display','');
							jq('.graph_type_tr').css('display','');
							jq('.show_hide_graph_tr').css('display','');
							jq('.live_score_tr').css('display','none');
						/*--end--*/
						
					}
					else if(jq('#quiztype').val()==22){
						
						 jq('.multi_personality_messages').css('display','inline-block');
						 jq('.multi_personality_messages a').attr('title',"<?php echo JText::_('COM_VQUIZ_SET_MBTI_MESSAGE_TOOLTIP'); ?>");
						 jq('.personality_messages').css('display','none');
						 jq('#skills_rows').css('display','none');						
						
							jq('#multi_personality_category').css('display','');
							jq('.multi_personality_category').css('display','');
							jq('.multi_p_percentage').css('display','none');
						

					   jq('.trivia_messages').css('display','none');
						/*--Hide Some Option if Choose Personality Type Quiz--*/
							if(jq('input[name="show_graph"]:checked').val()==0){  
							jq('#graph_type').parent().parent().hide();
							}else{
								jq('#graph_type').parent().parent().show();	
							}
							jq('.flag').parent().parent().hide();
							jq('.livescore').parent().parent().hide();
							jq('.answers_type').css('display','none');
							jq('.penality').parent().parent().hide();
							jq('#add_score_category').css('display','none');
							jq('.add_score_category').css('display','none');
							jq('#userscore').parent().parent().hide();
							jq('#passed_score').parent().parent().hide();
							jq('#total_timelimit').parent().parent().show();
							jq('.display_correctans_tr').css('display','none');
							jq('.trivia_personality_none').css('display','');
							jq('.dynamic_group_modal_add').parent().parent().show();
							jq('#qgroup_msg_heading').show();
                            jq('input[name="correctans"]').val(0);
							jq('input[name="show_graph"]').parent().parent().parent().show();
							jq('.user_select_graph_tr').css('display','');
							jq('.graph_type_tr').css('display','');
							jq('.show_hide_graph_tr').css('display','');
							jq('.live_score_tr').css('display','none');
					}
					else{
					
						jq('.trivia_messages').css('display','none');
						jq('#skills_rows').css('display','none');
						jq('.personality_messages').css('display','none');
						jq('.multi_personality_messages').css('display','none');
						jq('.multi_p_percentage').css('display','none');
						jq('.flag').parent().parent().hide();
						jq('.livescore').parent().parent().hide();
						jq('.penality').parent().parent().hide();
						jq('#userscore').parent().parent().hide();
						jq('#passed_score').parent().parent().hide();
						jq('#graph_type').parent().parent().hide();
						jq('#total_timelimit').parent().parent().hide();
						jq('.display_correctans_tr').css('display','none');
                        jq('input[name="correctans"]').val(0);
						jq('.answers_type').css('display','none');
						jq('#add_score_category').css('display','none');
						jq('.add_score_category').css('display','none');
						jq('#multi_personality_category').css('display','none');
						jq('.multi_personality_category').css('display','none');
						jq('.trivia_personality_none').css('display','none');
						jq('.dynamic_group_modal_add').parent().parent().hide();
						jq('#qgroup_msg_heading').hide();
						jq('.user_select_graph_tr').css('display','none');
						jq('.graph_type_tr').css('display','none');
						jq('.show_hide_graph_tr').css('display','none');
						jq('.live_score_tr').css('display','none');
						
						
						
					}
			
			  jq('#quiztype').on('change',function(){
			  
				   var values=jq(this).val(); //alert(values);
				   
						 // for survey only all user score will be used
						 
						jq('#userscore_td').html('');
				
						var html_uscore ='<select name="userscore" id="userscore" >';
							html_uscore +='<option value="0"><?php echo JText::_('WITH_ALL_USER'); ?> </option>';
						if(values!=3){ 
							html_uscore +='<option value="1"><?php echo JText::_('SINGLE_USER'); ?> </option>';
						}
                        html_uscore +='</select>';
						
                        jq('#userscore_td').html(html_uscore);
						
						
						<?php if(version_compare(JVERSION, '3.0', '>=')) {?> 
						jQuery('select').chosen({disable_search_threshold: 10});		
						<?php }?>
						
				   if(values==1){ 
						if(jq('input[name="show_graph"]:checked').val()==0){  
						jq('#graph_type').parent().parent().hide();
						jq('#userscore').parent().parent().hide();
						}else{
							jq('#userscore').parent().parent().show();
							jq('#graph_type').parent().parent().show();	
						}
						jq('.answers_type').css('display','none');
						jq('#skills_rows').css('display','');
						jq('.trivia_messages').css('display','inline-block');
						jq('.personality_messages').css('display','none');
						jq('.multi_personality_messages').css('display','none');
						jq('.multi_p_percentage').css('display','none');
						jq('.flag').parent().parent().show();
						jq('.livescore').parent().parent().show();
						jq('.penality').parent().parent().show();
						jq('#passed_score').parent().parent().show();
						jq('#total_timelimit').parent().parent().show();
						
						

						jq('.display_correctans_tr').css('display','');
						jq('#multi_personality_category').css('display','none');
						jq('.multi_personality_category').css('display','none');
						jq('.trivia_personality_none').css('display','');
						jq('.dynamic_group_modal_add').parent().parent().show();
						jq('#qgroup_msg_heading').show();
						jq('.live_score_tr').css('display','');
					
					}	
					else if(values==11){ //alert();
						if(jq('input[name="show_graph"]:checked').val()==0){  
						jq('#graph_type').parent().parent().hide();
						jq('#userscore').parent().parent().hide();
						}else{
							jq('#userscore').parent().parent().show();
							jq('#graph_type').parent().parent().show();	
						}
						jq('#skills_rows').css('display','');
						jq('.trivia_messages').css('display','inline-block');
						jq('.trivia_messages label').removeAttr("title");
						jq('.trivia_messages label').attr('title',"<?php echo JText::_('COM_VQUIZ_SET_SIMULATION_MESSAGE_TOOLTIP'); ?>");
						jq('.personality_messages').css('display','none');
						jq('.multi_personality_messages').css('display','none');
						jq('.multi_p_percentage').css('display','none');
						jq('.flag').parent().parent().show();
						jq('.livescore').parent().parent().show();
						jq('.penality').parent().parent().show();
						jq('#passed_score').parent().parent().show();
						jq('#total_timelimit').parent().parent().show();
						jq('.answers_type').css('display','');
						if(jq('select[name="answers_type"]').val()==2){ 
							jq('#add_score_category').css('display','');
							jq('.add_score_category').css('display','');
						}else{
							jq('.add_score_category').css('display','none');
						}

						jq('.display_correctans_tr').css('display','none');
						jq('#multi_personality_category').css('display','none');
						jq('.multi_personality_category').css('display','none');
						jq('.trivia_personality_none').css('display','');
						jq('.dynamic_group_modal_add').parent().parent().show();
						jq('#qgroup_msg_heading').show();
						jq('.live_score_tr').css('display','');
					
					}	
					/*--Hide Some Option if Choose Personality Type Quiz--*/
					else if(values==2){ 
					
						jq('#skills_rows').css('display','none');
						if(jq('input[name="show_graph"]:checked').val()==0){  
							jq('#graph_type').parent().parent().hide();
							}else{
								jq('#graph_type').parent().parent().show();	
							}
						jq('.personality_messages').css('display','inline-block');
						jq('.multi_personality_messages').css('display','none');
						
						if(jq('#personality_type').val()==0){
							jq('.multi_p_percentage').css('display','none');
							jq('#multi_personality_category').css('display','none');
							jq('.multi_personality_category').css('display','none');
						}else if(jq('#personality_type').val()==1){
							jq('.multi_p_percentage').css('display','');
							jq('#multi_personality_category').css('display','none');
							jq('.multi_personality_category').css('display','none');
						}
				
						jq('.trivia_messages').css('display','none');
						jq('.flag').parent().parent().hide();
						jq('.livescore').parent().parent().hide();
						jq('.penality').parent().parent().hide();
						jq('#userscore').parent().parent().hide();
						jq('#passed_score').parent().parent().hide();
						jq('#total_timelimit').parent().parent().show();
						jq('.display_correctans_tr').css('display','none');
                        jq('input[name="correctans"]').val(0);
						jq('#add_score_category').css('display','none');
						jq('.add_score_category').css('display','none');
						jq('.answers_type').css('display','none');
						jq('.trivia_personality_none').css('display','');
						jq('.dynamic_group_modal_add').parent().parent().show();
						jq('#qgroup_msg_heading').show();
						jq('.live_score_tr').css('display','none');
						}
						else if(values==22){ 
					
						jq('#skills_rows').css('display','none');
						if(jq('input[name="show_graph"]:checked').val()==0){  
							jq('#graph_type').parent().parent().hide();
							}else{
								jq('#graph_type').parent().parent().show();	
							}
						jq('.multi_personality_messages').css('display','inline-block');
						jq('.multi_personality_messages a').attr('title',"<?php echo JText::_('COM_VQUIZ_SET_MBTI_MESSAGE_TOOLTIP'); ?>");
						jq('.personality_messages').css('display','none');
						
							jq('#multi_personality_category').css('display','');
							jq('.multi_personality_category').css('display','');
							jq('.multi_p_percentage').css('display','none');
					
				
						jq('.trivia_messages').css('display','none');
						jq('.flag').parent().parent().hide();
						jq('.livescore').parent().parent().hide();
						jq('.penality').parent().parent().hide();
						jq('#userscore').parent().parent().hide();
						jq('#passed_score').parent().parent().hide();
						jq('#total_timelimit').parent().parent().show();
						jq('.display_correctans_tr').css('display','none');
                        jq('input[name="correctans"]').val(0);
						jq('#add_score_category').css('display','none');
						jq('.add_score_category').css('display','none');
						jq('.answers_type').css('display','none');
						jq('.trivia_personality_none').css('display','');
						jq('.dynamic_group_modal_add').parent().parent().show();
						jq('#qgroup_msg_heading').show();
						jq('.live_score_tr').css('display','none');
						
						}
						/*--Hide Some Option if Choose Survey Type Quiz--*/
					else{
						
						jq('#skills_rows').css('display','none');
						jq('.trivia_messages').css('display','none');
						jq('.personality_messages').css('display','none');
						jq('.multi_personality_messages').css('display','none');
						jq('.multi_p_percentage').css('display','none');
						jq('.flag').parent().parent().hide();
						jq('.livescore').parent().parent().hide();
						jq('.penality').parent().parent().hide();
						jq('#userscore').parent().parent().hide();
						jq('#passed_score').parent().parent().hide();
						jq('#total_timelimit').parent().parent().hide();
						jq('#graph_type').parent().parent().hide();
						jq('.display_correctans_tr').css('display','none');
                        jq('input[name="correctans"]').val(0);
						jq('.answers_type').css('display','none');
						jq('#add_score_category').css('display','none');
						jq('.add_score_category').css('display','none');
						//jq('input[name="show_graph"]').parent().parent().parent().hide();
						jq('#multi_personality_category').css('display','none');
						jq('.multi_personality_category').css('display','none');
						jq('.trivia_personality_none').css('display','none');
						jq('.dynamic_group_modal_add').parent().parent().hide();
						jq('#qgroup_msg_heading').hide();
						jq('.user_select_graph_tr').css('display','none');
						jq('.graph_type_tr').css('display','none');
						jq('.show_hide_graph_tr').css('display','none');
						jq('.live_score_tr').css('display','none');
						
					}
					 
 			  });
			  
				/*-----when Choose Answer sheet show/hide-------*/

				if(jQuery('input[name="answer_sheet"]:checked').val()==0){
					jq('.display_sheet_options_tr').css('display','none');
					jq('.display_correctans_tr').css('display','none');
				}else{
					jq('.display_sheet_options_tr').css('display','');
					if(jq('#quiztype').val()==1){//alert();
						jq('.display_correctans_tr').css('display','');
					}
				}  

				jQuery('input[name="answer_sheet"]').on('click',function(){
				
					if(jq(this).val()==0){
						jq('.display_sheet_options_tr').css('display','none');
						jq('.display_correctans_tr').css('display','none');
					}else{
						jq('.display_sheet_options_tr').css('display','');
						if(jq('#quiztype').val()==1){
						jq('.display_correctans_tr').css('display','');
						}
					}
					
				}); 
					  
			/*-- Hide Branching when more than one Question show in listing --*/
			
			 if(jq("#paging").val()==3){
				 jq('#tabs ul li a[href="#branching"]').css('display','none'); 
				 jq('.question_limit_tr ').css('display','none');
			 }else if(jq("#paging").val()==1 || jq("#paging_limit").val()==1){
				 jq('#paging_limit').val(1);
				 jq('#tabs ul li a[href="#branching"]').css('display','block');
				 jq('.question_limit_tr ').css('display','none');
			 }else{
				 jq('.question_limit_tr ').css('display','contents');
				 jq('#tabs ul li a[href="#branching"]').css('display','none');
			 }

			  jq('#paging').on('change',function(){
				  
				 var paging=jq(this).val();
				 if(paging==3){ 
					 jq('#tabs ul li a[href="#branching"]').css('display','none'); 
					 jq('.question_limit_tr ').css('display','none');
				 }else if(paging==1){ 
					 jq('#paging_limit').val(1);
					 jq('#tabs ul li a[href="#branching"]').css('display','block');
					 jq('.question_limit_tr ').css('display','none');
				 }else{ 
					 jq('.question_limit_tr ').css('display','contents');
					 jq('#tabs ul li a[href="#branching"]').css('display','none');
				 }
			 
 			  });
			  
			/*-- Hide Question group enable off --*/
			  var enable_questiongroup=<?php echo $this->item->enable_questiongroup ;?>;
		 
			  if( enable_questiongroup==1){				 
				 jq('.qgroup_rows').css('display','');
			  }else{				
				jq('.qgroup_rows').css('display','none');
			  }

			  
			  jq('input[name="enable_questiongroup"]').on('click',function(){
				  
				var paging=jq(this).val();
				
					var html ='<select name="paging" id="paging"class="chzn-done">';
					html +='<option value="1"><?php echo JText::_('ONEQUESTION_PERPAGE'); ?></option>';
					html +='<option value="2"><?php echo JText::_('ALLQUESTION_PERPAGE'); ?></option>';

					  if(paging==1){
						  jq('.qgroup_rows').css('display','');
							html +='<option value="3"><?php echo JText::_('QUESTION_GROUP_PERPAGE'); ?></option>';					  
					  }else{
						 jq('.qgroup_rows').css('display','none');
					  }
				  
					html +='</select>';
					jQuery('.paginglimitbox').html(html);

					<?php if(version_compare(JVERSION, '3.0', '>=')) {?>
						jQuery('select').chosen({
						disable_search_threshold : 10,
						allow_single_deselect : true
						});
					<?php }?>

			 
 			  });
			  
			   /*-- Hide Graphp if Choose no whre show graphe --*/
			   
				jQuery('input[name="show_graph"]').on('click',function(){
					if(jq(this).val()==0)
					{
						jq('#graph_type').parent().parent().hide();
						jq('#userscore').parent().parent().hide();
					}else{
						if(jq('#quiztype').val()==1 || jq('#quiztype').val()==11){ 
						jq('#graph_type').parent().parent().show();
						jq('#userscore').parent().parent().show();
						}else if(jq('#quiztype').val()==2 || jq('#quiztype').val()==22){
							jq('#graph_type').parent().parent().show();
							jq('#userscore').parent().parent().hide();
						}
					}
					 
				});
			 			  
  				/* jQuery('#userscore').on('change',function(){
					if(jq(this).val()==1)
					{
				
                    var html ='<select  name="graph_type" id="graph_type">';
                        html +='<option value="1"><?php echo JText::_('COM_VQUIZ_QUIZZES_COLUMN_CHART'); ?></option>';
                        html +='</select>';
                        jq('.graph_type_td').html(html);
						
					}else{
                        var html='<select  name="graph_type" id="graph_type">';
                            html +='<option value="1"><?php echo JText::_('COM_VQUIZ_QUIZZES_COLUMN_CHART'); ?></option>';
                            html +='<option value="2"><?php echo JText::_('COM_VQUIZ_QUIZZES_PIE_CHART'); ?></option>';
                            html +='<option value="3"><?php echo JText::_('COM_VQUIZ_QUIZZES_LINE_CHART'); ?></option>';
                        html +='</select>';
                        jq('.graph_type_td').html(html);
					}
				     
				    <?php if(version_compare(JVERSION, '3.0', '>=')) {?> 
						jQuery('select').chosen({
						disable_search_threshold : 10,
						allow_single_deselect : true
						});		
					<?php }?>
					
				}); */
    
              /* if(jq('#userscore').val()==1){
                    var html ='<select  name="graph_type" id="graph_type">';
                    html +='<option value="1"><?php echo JText::_('COM_VQUIZ_QUIZZES_COLUMN_CHART'); ?></option>';
                    html +='</select>';
                    jq('.graph_type_td').html(html);
              } */
			  
				
			/*-----when Choose show result in end of the quiz-------*/
	
			 if(jQuery('select[name="display_result"]').val()==0){
					if(jq('#quiztype').val()==1 || jq('#quiztype').val()==2 || jq('#quiztype').val()==11 || jq('#quiztype').val()==22){ 
						jq('.user_select_graph_tr').css('display','');
						jq('.graph_type_tr').css('display','');
						jq('.show_hide_graph_tr').css('display','');
					}else{
						jq('.user_select_graph_tr').css('display','none');
						jq('.graph_type_tr').css('display','none');
						jq('.show_hide_graph_tr').css('display','none');
					}
					//jq('.show_hide_graph_tr').css('display','');
			}else{
					jq('.user_select_graph_tr').css('display','none');
					jq('.graph_type_tr').css('display','none');
					jq('.show_hide_graph_tr').css('display','none');
					
			 }  
			 
			 jQuery('select[name="display_result"]').on('change',function(){

					if(jq(this).val()==0){
						if(jq('#quiztype').val()==1 || jq('#quiztype').val()==2 || jq('#quiztype').val()==11 || jq('#quiztype').val()==22){ 
							jq('.user_select_graph_tr').css('display','');
							jq('.graph_type_tr').css('display','');
							jq('.show_hide_graph_tr').css('display','');
						}else{
							jq('.user_select_graph_tr').css('display','none');
							jq('.graph_type_tr').css('display','none');
							jq('.show_hide_graph_tr').css('display','none');
						}
						//jq('.show_hide_graph_tr').css('display','');
						
						jq('.take_snapshot').css('display','');
						jq('.answrs_sheet_show').css('display','');
						jq('.display_correctans_tr').css('display','');
						
					}else if(jq(this).val()==1){
						jq('.take_snapshot').css('display','none');
						jq('.answrs_sheet_show').css('display','none');
						jq('.display_correctans_tr').css('display','none');
					}else{
						jq('.user_select_graph_tr').css('display','none');
						jq('.graph_type_tr').css('display','none');
						jq('.show_hide_graph_tr').css('display','none');
						
						jq('.take_snapshot').css('display','');
						jq('.answrs_sheet_show').css('display','');
						jq('.display_correctans_tr').css('display','');
					}
			  });
			  
 
			<?php if(version_compare(JVERSION, '3.0', '>=')) {?> 
				jQuery('select').chosen({
				disable_search_threshold : 10,
				allow_single_deselect : true
				});		
			<?php }?>
			
			var addDiv_scorecate = jq('#add_score_category');
			var i =<?php echo (int)count($this->score_category ); ?>;
			  
			  jq('#addNew').on('click', function() {
				  var html = '<tr><td><b>&bull;</b></td><td valign="middle" align="center"><input type="text" name="score_category_label[]"  value="" class="" /></td><td valign="middle" align="center"><input type="radio" name="score_depend[]" value="'+i+'"></td><td valign="middle" align="center"><a href="javascript:void(0);" class="remNew btn btn-danger">-</a></td></tr>';
				  
				  jq(html).appendTo(addDiv_scorecate);
				  i++;
				  return false;
			  });
			  
			  jq(document).on('click','.remNew',function() {
					jq(this).parent().parent().remove();
			  });
			
			if(jq('#quiztype').val()==11){
				if(jq('select[name="answers_type"]').val()==2){ 
					jq('#add_score_category').css('display','');
					jq('.add_score_category').css('display','');
				}
				else{ 
					jq('#add_score_category').css('display','none');
					jq('.add_score_category').css('display','none');
				}
			}
			
			jQuery('select[name="answers_type"]').on('change',function(){
					var value=jq(this).val();
					if(value==2){
						jq('#add_score_category').css('display','');
						jq('.add_score_category').css('display','');
					}else{
						jq('#add_score_category').css('display','none');
						jq('.add_score_category').css('display','none');
					}
			});

			
			if(jq('#quiztype').val()==2){ 
				if(jq('#personality_type').val()==0){
					jq('.multi_p_percentage').css('display','none');
					jq('#multi_personality_category').css('display','none');
					jq('.multi_personality_category').css('display','none');
					jq('.total_time_row').css('display','');
				}else if(jq('#personality_type').val()==1){
					jq('.multi_p_percentage').css('display','');
					jq('#multi_personality_category').css('display','none');
					jq('.multi_personality_category').css('display','none');
					jq('.total_time_row').css('display','');
				}
			}
			
			if(jq('#quiztype').val()==22){ 
					jq('#multi_personality_category').css('display','');
					jq('.multi_personality_category').css('display','');
					jq('.total_time_row').css('display','none');
					jq('input[name="total_timelimit"]').val(0);
				}
				
				jQuery('#personality_type').on('change',function(){

					var link_p='<?php echo 'index.php?option=com_vquiz&view=quizmanager&layout=personality_messages&id='.$this->item->id;?>'+'&p_type='+jq(this).val()+'&tmpl=component';
					jq('.personality_setmsg').attr('href',link_p);

					if(jq(this).val()==0){
						jq('.multi_p_percentage').css('display','none');
						jq('#multi_personality_category').css('display','none');
						jq('.multi_personality_category').css('display','none');
						jq('.total_time_row').css('display','');
					}else if(jq(this).val()==1){
						jq('.multi_p_percentage').css('display','');
						jq('#multi_personality_category').css('display','none');
						jq('.multi_personality_category').css('display','none');
						jq('.total_time_row').css('display','');
					}else if(jq(this).val()==2){
						jq('#multi_personality_category').css('display','');
						jq('.multi_personality_category').css('display','');
						jq('.multi_p_percentage').css('display','none');
						jq('.total_time_row').css('display','none');
						jq('input[name="total_timelimit"]').val(0);
					}

				});
				
				
				/*--add multi personality filed--*/
				
				var addDiv = jq('#multi_personality_category');
				var colm=jq('#personality_category_column_count').val()>0?jq('#personality_category_column_count').val():0;
				var rowm=jq('#p_category_r_count').val()>0?jq('#p_category_r_count').val():0;
				//alert(rowm);
				  jq('#add_m_p_row').on('click', function() {
						rowm++;
						var html = '<tr><td valign="middle"><b>&#8226;</b></td>';
					   
					    for(var c=0;c<colm;c++){
							html +='<td valign="middle" align="center"><input type="text" name="personality_category[]"  value="" class="p_category_input" /></td>';
						}
						
						html +='<td valign="middle" align="center" class="p_category_remove"><a href="javascript:void(0);" class="remNew_per_c_column btn btn-danger">-</a></td></tr>';
					  
					   jq(html).appendTo(addDiv);
					  
					  if(rowm>0 ){
						jq('#add_m_p_column').attr("disabled", false);
						if(colm>0){
						jq('#remove_m_p_column').attr("disabled", false);
						}
						
					  }else{
						jq('#add_m_p_column').attr("disabled", true);
						jq('#remove_m_p_column').attr("disabled", true);
						colm=0;
					  }
					  jq('#personality_category_column_count').val(colm);
					  jq('#p_category_r_count').val(rowm);
					  jq('#mpbutton').attr('colspan',colm);
					  
					  
					  return false;
					  
				  });
				  
				  jq(document).on('click','.remNew_per_c_column',function() { 
				  
					jq(this).parent().parent().remove();
					rowm--;
					jq('#p_category_r_count').val(rowm);
					
					if(rowm <2){
						
						jq('#add_m_p_column').attr("disabled", true);
						jq('#remove_m_p_column').attr("disabled", true);
					  }else{
						jq('#add_m_p_column').attr("disabled", false);
						jq('#remove_m_p_column').attr("disabled", false);
					  }
					
				  });
				  
				  jq('#add_m_p_column').on('click', function() {
				  
					  var html_p_col = '<td valign="middle" align="center"><input type="text" name="personality_category[]" value="" class="p_category_input" /></td><td valign="middle" align="center" class="p_category_remove"><a href="javascript:void(0);" class="remNew_per_c_column btn btn-danger">-</a></td>';
					  
						jq('#multi_personality_category tr').each(function(){
							jq(this).find('td:last').remove();
							jq(this).find('td:last').after(html_p_col);
						});
						
						jq('#mpbutton').attr('colspan',colm);
						colm++
						if(colm>0){
					
								jq('#remove_m_p_column').attr("disabled", false);
							}
						jq('#personality_category_column_count').val(colm);
						
						return false;
					  
				  });
				  
			  jq('#remove_m_p_column').on('click', function() { 

				jq('#multi_personality_category tr').each(function(){
					
					var total = jq('#personality_category_column_count').val();
					//alert(total);
					jq(this).find("td").eq(-2).remove();
				});
				jq('#mpbutton').attr('colspan',colm);
				colm--
				if(colm==0){
					//alert('sero');
					jq('#remove_m_p_column').attr("disabled", true);
				}
				jq('#personality_category_column_count').val(colm);
				
				return false;
				  
			  });
				  
		   <!-- Branching Rule -->	
				
			var add_rule_href='index.php?option=com_vquiz&view=quizmanager&layout=branching&tmpl=component&skip_enable=<?php echo $this->item->skip_button;?>&quizid=<?php echo $this->item->id;?>&quiztype=<?php echo $this->item->quiztype;?>&count_row='+jQuery('#count_branch_row').val();
			
			jq(document).on('click', '#add_rule',function(){
			
				jQuery('#add_rules').attr('href',add_rule_href);
				jQuery('#add_rules').simulateClick('click');
				
			});
 
			jq(document).on('click', '.click_edit',function(){
				jQuery(function($) {
						SqueezeBox.initialize({});
						SqueezeBox.assign($('a.modal').get(), {
							parse: 'rel'
						});
					});
				jQuery('#click_simulate').simulateClick('click');
				
			});
 			
			jq(document).on('click','.remrule',function() {
				jq(this).parent().parent().remove();
			});
			
			jq('#reset_users').click(function(){
				jQuery('#jform_request_user_id').val('');
				jQuery('#jform_request_user_name').val('<?php echo JText::_('COM_VQUIZ_SELECT_USER');?>');	
			});
			jq('#reset_quiz_creator').click(function(){
				jQuery('#jform_request_created_by').val('');
				jQuery('#jform_request_created_by_name').val('<?php echo JText::_('COM_VQUIZ_SELECT_QUIZ_CREATOR');?>');	
			});
			
			jq(document).on('click',".icon-uparrow,.icon-downarrow",function () { 
				
				var $element = this;
				var row = jq($element).parents("tr:first");

				if(jq(this).is('.icon-uparrow')){
					var x=row.insertBefore(row.prev());
					var lenghth_tr=jq.parseJSON(JSON.stringify(x.prev())).length;
				}else{
					row.insertAfter(row.next());
				}

			});
			
				var addDiv_questiongruoup_body = jq('#questiongruoup_body');
				
				jq('#addquestiongroup').on('click', function() {	  
				 var html_qgroup ='<tr><td></td><td><input type="text" value="" name="questiongroup_title[]"/><input type="hidden" name="questiongroup_order[]" value=""/></td><td ><textarea rows="5" cols="5" name="questiongroup_description[]" class="group_desc"></textarea> </td><td><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span></td><td><span><a  class="dynamic_group_modal_add btn modal" href="javascript:void(0)"><?php echo JText::_('COM_VQUIZ_SETMESSAGES_SETTING');?></a></span></td><td><span><a class="btn btn-danger btn-small" href="javascript:void(0);"><i class="icon-delete qgroup_canceal"></i></a></span></td></tr>';
				  
				  jq(html_qgroup).appendTo(addDiv_questiongruoup_body);
				 
					if(jq('#quiztype').val()==3){
						 jq('.dynamic_group_modal_add').parent().parent().hide();
						 jq('#qgroup_msg_heading').hide();
					}
	
				 tinymce_init();
				  return false;
				});

				jq(document).on('click','.qgroup_canceal',function() {
					jq(this).parents('tr:first').remove();
				});
			
			  jq(document).on('click','.generate_token',function() {
					var token = randomString();
					jQuery('.access_token').val(token);	
					jQuery('.access_token_hidden').val(token);	
					var link =
					'<?php echo JURI::root().'index.php?option=com_vquiz&view=quizmanager&layout=description&id='.$this->item->id.'&access='?>'+token;
					jQuery('#access_link').val(link);	
			  });
			  
			  
			
			  jq( "#access_token_reset" ).click(function() {
				jQuery('.access_token').val('');	
					jQuery('.access_token_hidden').val('');	
			});			  
			  jq(document).on('click','#copy_acess_link',function() {
					copyToClipboard('#access_link');
			  }); 
 
			 			  
			jq(document).on('click', '.dynamic_group_modal_add',function(){
				
				var url = "<?php echo 'index.php?option=com_vquiz&view=quizmanager&layout=qgroup_messages&qorder=0&id='.$this->item->id.'&tmpl=component';?>"; 
				
				SqueezeBox.initialize({});   
				SqueezeBox.loadModal(url,"iframe",1100,500);	
				
			}); 
			
			jq('#published1').on('click',function(){ //alert();
								 
				  jq('#start_publish_date_row').css('display','');
				  jq('#end_publish_date_row').css('display','');
				 
			  });
			  
			  jq('#published0').on('click',function(){
				
				  jq('#start_publish_date_row').css('display','none');
				  jq('#end_publish_date_row').css('display','none');
				 
			  });
			  
			jq( "#article_link_id" ).on('change', function(e) {//console.log(jq(this));
						
				if(parseInt(jq(this).val())!=0){	
					jq(".quiz_result_section").hide();
					jq(".display_correctans_tr").hide();
				}else{
					jq(".quiz_result_section").show();
					if(jq('#quiztype').val()==1){
						jq(".display_correctans_tr").show();
					}
					
				}
					
			});				
			
			var article_link_id_value = jq( "#article_link_id" ).val();		
			if(parseInt(article_link_id_value)!=0){	
				jq(".quiz_result_section").hide();
				jq(".display_correctans_tr").hide();
			}else{
				jq(".quiz_result_section").show();
				if(jq('#quiztype').val()==1){
						jq(".display_correctans_tr").show();
				}
			}
					
			
			//remove single user score in case of survey
			if(jq('#quiztype').val()==3){  //alert(1);
			
			jq('#userscore_td').html('');
				
			 var html_uscore ='<select name="userscore" id="userscore" >';
                        html_uscore +='<option value="0"><?php echo JText::_('WITH_ALL_USER'); ?> </option>';
                        html_uscore +='</select>';
						
                        jq('#userscore_td').html(html_uscore); 
						
						<?php if(version_compare(JVERSION, '3.0', '>=')) {?> 
						jQuery('select').chosen({disable_search_threshold: 10});		
						<?php }?>
			
			}
			
			
//end of ready			
});


		jQuery.fn.simulateClick = function() {
		   return this.each(function() {
			   if('createEvent' in document) {
				   var doc = this.ownerDocument,
					   evt = doc.createEvent('MouseEvents');
				   evt.initMouseEvent('click', true, true, doc.defaultView, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
				   this.dispatchEvent(evt);
			   } else {
				   this.click(); // IE
			   }
		   });
		   
		}	
		
		function copyToClipboard(element) {
		  var $temp = jq("<input>");
		  jq("body").append($temp);
		  $temp.val(jq(element).val()).select();
		  document.execCommand("copy");
		  $temp.remove();
		}

		function randomString(len=12) {
			var charSet ='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
			var randomString = '';
			for (var i = 0; i < len; i++) {
				var randomPoz = Math.floor(Math.random() * charSet.length);
				randomString += charSet.substring(randomPoz,randomPoz+1);
			}
			return randomString;
		}
			 
	function jSelectUsers_jform_request_id(id, title, object){
		jQuery('#jform_request_user_id').val(id);
		jQuery('#jform_request_user_name').val(title);	
		SqueezeBox.close();
	}
	function jQuizCreator_jform_request_id(id, title, object){
		
		jQuery('#jform_request_created_by').val(id);
		jQuery('#jform_request_created_by_name').val(title);	
		SqueezeBox.close();
	}
	Joomla.submitbutton = function(task) {
	
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		} else {
			
			if(!jQuery('input[name="title"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_PLZ_ENTER_QUIZ_TITLE', true); ?>');
				document.adminForm.title.focus();
				return false;
			}
			if(!jQuery('select[name="catid"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_PLZ_ENTER_QUIZ_CATEGORY', true); ?>');
				document.adminForm.catid.focus(); 
				return false;
			}	
			document.getElementById('jform_request_user_name').disabled = false;
			Joomla.submitform(task, document.getElementById('adminForm'));
		}
		
	}
</script>

<form class="vquiz_form" action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="col101">
<legend><?php echo JText::_('COM_VQUIZ_QUESTIONS_DETAILS'); ?></legend>

	<div id="tabs">
        <ul>
			<li><a href="#main"><?php echo JText::_('COM_VQUIZ_QUIZZES_MAINSETTING'); ?></a></li>
			
			<li><a href="#display"><?php echo JText::_('COM_VQUIZ_QUIZZES_DISPLAY'); ?></a></li>
			
			<li><a href="#quiztext"><?php echo JText::_('COM_VQUIZ_RESULT'); ?></a></li>
			
			<li><a href="#certificates"><?php echo JText::_('COM_VQUIZ_QUIZZES_CERTIFICATE'); ?></a></li>
			
			<li><a href="#questiongroup"><?php echo JText::_('COM_VQUIZ_QUESTION_GROUP'); ?></a></li>  
			
			<li><a href="#qrpanel"><?php echo JText::_('COM_VQUIZ_QUESTION_REVIEW_PANEL'); ?></a></li>
			
			<li><a href="#branching"><?php echo JText::_('COM_VQUIZ_CONDITIONAL_BRANCHING'); ?></a></li> 
			
			<li><a href="#access"><?php echo JText::_('COM_VQUIZ_QUIZZES_ACCESS_SETTING'); ?></a></li>	
			
			<li><a href="#l_generation"><?php echo JText::_('COM_VQUIZ_LEAD_GENERATION'); ?></a></li> 
			
			<li><a href="#meta_key"><?php echo JText::_('COM_VQUIZ_QUIZZES_META_KEY'); ?></a></li>
			        
			<li><a href="#permissions"><?php echo JText::_('COM_VQUIZ_QUIZZES_PERMISSIONS'); ?></a></li>  
     
		</ul>

    <div id="main">
                <table class="adminform table table-striped">
					<tr>
						<td class="key" width="200"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_TITLE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_TITLE'); ?></label></td>
						<td><input type="text" name="title" id="title" class="title" value="<?php echo $this->item->title;?>">
						</td>
					</tr>
					<tr>
						<td>
							<label><?php echo JText::_( 'ALIAS' ); ?></label>
						</td>
						<td>
							<input type="text" name="alias" id="alias"  value="<?php echo !empty($this->item->alias)?$this->item->alias:'';?>"  placeholder="Automatic Genarated"/>
						</td>
					</tr>
					
					
					
			 <tr>	
				<tr>
				
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CATEGORY_TITLE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_CATEGORY'); ?></label></td>
					<td>
						<select name="catid" id="catid">
						<?php    for ($i=0; $i <count($this->category); $i++)	
						{
						?>
						<option value="<?php echo $this->category[$i]->id;?>"  <?php  if($this->category[$i]->id == $this->item->catid) echo 'selected="selected"'; ?> >
						<?php
						if($this->category[$i]->level>0){
							echo str_repeat('-', $this->category[$i]->level-1);	
						}
						echo $this->category[$i]->title;
						
						?> 
						</option>		
						<?php
						}
						?>
						</select>
					</td>
                </tr>
							
				<tr>
						<td class="key">
							<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_TYPE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_TYPE'); ?></label>
						</td>
						<td>
							<select  name="quiztype" id="quiztype" >
								<option value="1" <?php  if($this->item->quiztype==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_TRIVIA_QUIZ'); ?> </option>
								<option value="11" <?php  if($this->item->quiztype==11) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_SIMULATION_QUIZ'); ?> </option>
								<option value="2" <?php  if($this->item->quiztype==2) echo 'selected="selected"'; ?> ><?php echo JText::_('COM_VQUIZ_PERSONALITY_QUIZ'); ?> </option>
								<option value="22" <?php  if($this->item->quiztype==22) echo 'selected="selected"'; ?> ><?php echo JText::_('COM_VQUIZ_MULTI_CATEGORY_PERSONALITY_QUIZ'); ?> </option>
								<option value="3" <?php  if($this->item->quiztype==3) echo 'selected="selected"'; ?> ><?php echo JText::_('COM_VQUIZ_SURVEY_QUIZ'); ?> </option>
								 
							</select>
						</td>
					</tr>
					
					
					<tr class="multi_p_percentage" style="display:none">
						<td><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_MULTIPLE_SCORE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_MULTIPLE_SCORE'); ?></label></td>
						<td>
								<fieldset class="radio btn-group">
								<label for="multi_p_score1" id="multi_p_score1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
								<input type="radio" name="multi_p_score" id="multi_p_score1" value="1" <?php if($this->item->multi_p_score ==1) echo 'checked="checked"';?>/>
								<label for="multi_p_score0" id="multi_p_score0-lbl" class="radio"><?php echo JText::_('NO'); ?></label>
								<input type="radio" name="multi_p_score" id="multi_p_score0" value="0" <?php if($this->item->multi_p_score ==0) echo 'checked="checked"';?>/>
								</fieldset>
						</td>
					</tr>
					<tr class="multi_p_percentage" style="display:none">
						<td><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_MULTI_PE_PERCENTAGE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_MULTI_PE_PERCENTAGE'); ?></label></td>
						<td>
							<input type="text" name="multi_p_percentage" id="" value="<?php echo $this->item->multi_p_percentage?>"/><?php echo JText::_('%');?>
						</td>
					</tr>
					
					<tr class="multi_personality_category" style="display:none;">
						<td></td>
						<td>
						<table id="multi_personality_category" style="display:none;">
							<tr>
								 <th id="mpbutton" colspan="0">
									<input type="button" name="addoption" id="add_m_p_row" value="+Row" class="btn btn-success" />
									<input type="button" name="addoption" id="add_m_p_column" value="+Col" class="btn btn-success" <?php if(@$this->personality_category->count_column==0) echo 'disabled';?>/>
									<input type="button" name="removeoption" id="remove_m_p_column" value="-Col" class="btn btn-danger" <?php if(@$this->personality_category->count_column==0) echo 'disabled';?>/>
									</th>
							</tr>	
							<?php 
								if(!empty($this->personality_category->category)){
									$p_cat=json_decode($this->personality_category->category);
									$count_column =$this->personality_category->count_column>0?$this->personality_category->count_column:1;
									$personality_category=array_chunk($p_cat,$count_column);
								}else{
									$personality_category=null;
								 }
								
							    for($i=0;$i<count($personality_category);$i++){ ?>
								 
								<tr>
								<td valign="middle"><b>&#8226;</b></td>
								
								<?php for($j=0;$j<count($personality_category[$i]);$j++){ ?>
									<td valign="middle" align="center"><input type="text" name="personality_category[]"  value="<?php echo $personality_category[$i][$j];?>" class="p_category_input" /></td>
								<?php }?>
							 
								<td valign="middle" align="center"><a href="javascript:void(0);" class="remNew_per_c_column btn btn-danger">-</a></td></tr>
								
								<?php } ?>
								
							 
						</table>
						</td>
					</tr>
		
				 <tr class="answers_type">
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SIMULATION_CATEGORY_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SIMULATION_CATEGORY'); ?></label></td>
					
					<td>
						<select name="answers_type" id="answers_type">
							<option value="1" <?php  if($this->item->answers_type==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_QUIZZES_SINGLE_CATEGORY'); ?></option>
							<option value="2" <?php  if($this->item->answers_type==2) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_QUIZZES_MULTIPLE_CATEGORY'); ?></option>
						</select>
					</td>
                </tr>
				
			<tr class="add_score_category">
			<td></td>
			<td>
				<table  id="add_score_category">
					 <tr>
						 <th><input type="button" name="addoption" id="addNew" value="+" class="btn btn-success" /></th>
						 <th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_ENABLE_SCORE_CATEGORY_LABEL_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_CATEGORY'); ?></label></th><th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_RESULT_DEPEND_ON_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_RESULT_DEPEND_ON'); ?></label></th><th><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_REMOVE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_REMOVE'); ?></label></th>
					</tr>
					 <?php for($i=0;$i<count($this->score_category);$i++){?>
						 
						<tr><td><b>&bull;</b></td><td valign="middle" align="center"><input type="text" name="score_category_label[]"  value="<?php echo $this->score_category[$i]->category;?>" class="" /></td><td valign="middle" align="center"><input type="radio" name="score_depend[]" value="<?php echo $i; ?>" <?php if($this->score_category[$i]->score_depend ==1) echo 'checked="checked"';?>/></td><td valign="middle" align="center"><a href="javascript:void(0);" class="remNew btn btn-danger">-</a></td></tr>
					 
					 <?php }?>
					</table>
					</td>
				</tr>
			<?php if($this->configuration->payment_system==1){?>	
			<tr class="set_quiz_price">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZ_SET_PRICE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZ_SET_PRICE'); ?></label></td>
				<td> 
					<fieldset class="radio btn-group" >
					<label for="set_price1" id="set_price1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" name="set_price" id="set_price1" value="1" <?php if($this->item->set_price ==1) echo 'checked="checked"';?>/>
					<label for="set_price0" id="set_price0-lbl" class="radio"><?php echo JText::_('NOS'); ?></label>
					<input type="radio" name="set_price" id="set_price0" value="0" <?php if($this->item->set_price ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
            </tr>

			<tr class="price">
						<td class="key" width="200"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_QUIZ_PRICE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZ_PRICE'); ?></label></td>
						<td><input type="text" name="price" id="price" class="price" value="<?php echo $this->item->price;?>">
						</td>
			</tr>
			 <?php }?>
			
			<tr id="skills_rows">
					<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_SKILLS_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_SKILLS'); ?></label></td>
					<td>
						<select name="skillid[]" id="skillid" class="inputbox" placeholder="<?php echo JText::_('COM_VQUIZ_SKILLS_SKILL'); ?>" multiple>
						
						
							<?php    
							$selectedid=$this->skills->selectedid;
							for ($i=0; $i <count($this->skills->skillid); $i++){	?>
							<option value="<?php echo $this->skills->skillid[$i]->id;?>" <?php  if(in_array($this->skills->skillid[$i]->id,$selectedid)) echo 'selected="selected"'; ?>>
								<?php echo $this->skills->skillid[$i]->title; ?>
							</option>		
							<?php	}?>
						</select>
					</td>
				</tr>
            
					
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ORDETING_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_ORDERING'); ?></label></td>
				<td>
					<input type="number" name="ordering" id="ordering" value="<?php echo $this->item->ordering;?>" />
				</td>
			</tr>
			
 			
                
			<tr>
				<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_FEATURED_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_FEATURED');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="featured1" id="featured1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" name="featured" id="featured1" value="1" <?php if($this->item->featured ==1) echo 'checked="checked"';?>/>
					<label for="featured0" id="featured0-lbl" class="radio"><?php echo JText::_('NOS'); ?></label>
					<input type="radio" name="featured" id="featured0" value="0" <?php if($this->item->featured ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
              
			<tr>
				<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_RANDOM_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_RANDOM_QUESTION');?></label></td>
				<td>
					
					<fieldset class="radio btn-group">
					<label for="random_question1" id="random_question1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" name="random_question" id="random_question1" value="1" <?php if($this->item->random_question ==1) echo 'checked="checked"';?>/>
					<label for="random_question0" id="random_question0-lbl" class="radio"><?php echo JText::_('NOS'); ?></label>
					<input type="radio" name="random_question" id="random_question0" value="0" <?php if($this->item->random_question ==0) echo 'checked="checked"';?>/>
					</fieldset>
					
				</td>
			</tr>
			
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_RANDOM_OPTIONS_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_RANDOM_OPTIONS'); ?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="random_option1" id="random_option1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" name="random_option" id="random_option1" value="1" <?php if($this->item->random_option ==1) echo 'checked="checked"';?>/>
					<label for="random_option0" id="random_option0-lbl" class="radio"><?php echo JText::_('NO'); ?></label>
					<input type="radio" name="random_option" id="random_option0" value="0" <?php if($this->item->random_option ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_QUESTION_LIMIT_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_QUESTION_LIMIT'); ?></label></td>
				<td>
					<input type="text" name="question_limit" id="question_limit" value=" <?php echo $this->item->question_limit; ?>" />
				</td>
			</tr>
			  
			<tr>
				<td class="key"><label  class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_PASSED_SCORE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_PASSED_SCORE'); ?></label></td>
				<td>
					<input type="text" name="passed_score"  id="passed_score" value="<?php echo $this->item->passed_score;?>" />
					<?php echo JText::_('%'); ?>
				</td>
			</tr>
			
		<!--Hide Total Time Quiz When Quiz Later Enable in Configuration-->
       <tr class="later_play">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LATER_QUIZ_PLAY_DESC');?>"><?php echo JText::_('COM_VQUIZ_LATER_QUIZ_PLAY');?></label></td>
			<td>
				
					<select  name="later_play" id="later_play">
					
					<option value="0" <?php if($this->item->later_play==0) echo 'selected="selected"'; ?>><?php echo JText::_('USE_GLOBAL'); ?> </option>
					
					<option value="1" <?php if($this->item->later_play==1) echo 'selected="selected"'; ?>><?php echo JText::_('YS'); ?> </option>
					
					<option value="2" <?php if($this->item->later_play==2) echo 'selected="selected"'; ?>><?php echo JText::_('NOS'); ?> </option>
					
					</select>
					
			</td>
		</tr>
		<?php 
			$show_time_tr=0;
			if( $this->item->later_play==0 and $this->configuration->later_play==0)
				{
					$show_time_tr=1;
				}	
			if($this->item->later_play==2)
				{
					$show_time_tr=1;
				}
				
			?>
		<!--Hide Total Time Quiz When Quiz Later Enable in Configuration-->
        <?php if($show_time_tr==1){?>
			<tr class="total_time_row">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_TOTAL_TIME_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_TOTAL_TIME'); ?></label>

				</td>
				<td>
					<input type="text" name="total_timelimit"  id="total_timelimit" value="<?php echo $this->item->total_timelimit;?>" />
					<select  name="totaltime_parameter" id="totaltime_parameter" >
					<option value="seconds" <?php if($this->item->totaltime_parameter =='seconds') echo 'selected="selected"'; ?>><?php echo JText::_('SECONDS'); ?> </option>
					<option value="minutes" <?php if($this->item->totaltime_parameter =='minutes') echo 'selected="selected"'; ?>><?php echo JText::_('MINUTES'); ?> </option>
					</select>
				</td>
			</tr>
		<?php }?>
		
		<tr>
			<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SUBMIT_BUTTON');?>"><?php echo JText::_('COM_VQUIZ_SUBMIT_BUTTON');?></label></td>
			
			<td>
				<fieldset class="radio btn-group">
				<label for="submit_button1" id="submit_button1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
				<input type="radio" name="submit_button" id="submit_button1" value="1" <?php if($this->item->submit_button ==1) echo 'checked="checked"';?>/>
				<label for="submit_button0" id="submit_button0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
				<input type="radio" name="submit_button" id="submit_button0" value="0" <?php if($this->item->submit_button ==0) echo 'checked="checked"';?>/>
				</fieldset>
			</td>
			
			<td>
				
			</td>
		</tr>
		
		<tr>
			<td class="key" width="250"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_FORCE_CORRECT_ANSWER');?>"><?php echo JText::_('COM_VQUIZ_FORCE_CORRECT_ANSWER');?></label></td>
			
			<td>
				<fieldset class="radio btn-group">
				<label for="force_correct_answer1" id="force_correct_answer1-lbl" class="radio"><?php echo JText::_( 'YS'); ?></label>
				<input type="radio" name="force_correct_answer" id="force_correct_answer1" value="1" <?php if($this->item->force_correct_answer ==1) echo 'checked="checked"';?>/>
				<label for="force_correct_answer0" id="force_correct_answer0-lbl" class="radio"><?php echo JText::_( 'NOS'); ?></label>
				<input type="radio" name="force_correct_answer" id="force_correct_answer0" value="0" <?php if($this->item->force_correct_answer ==0) echo 'checked="checked"';?>/>
				</fieldset>
			</td>
			
			<td>
				
			</td>
		</tr>
		
		<tr class="force_correct_answer">
				<td class="key"><label  class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_CORRECT_ANSWER_MSG_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_CORRECT_ANSWER_MSG'); ?></label></td>
				<td>
					<input type="text" name="correct_answer_msg"  id="correct_answer_msg" value="<?php echo $this->item->correct_answer_msg;?>" style="width:500px" />
					
				</td>
		</tr>
		
		<tr class="force_correct_answer">
				<td class="key"><label  class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_CORRECT_ANSWER_COLOR_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_CORRECT_ANSWER_COLOR'); ?></label></td>
				<td>
					<input type="color" name="correct_answer_color"  id="correct_answer_color" value="<?php echo $this->item->correct_answer_color;?>" />
					
				</td>
		</tr>
		
		<tr class="force_correct_answer">
				<td class="key"><label  class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_WRONG_ANSWER_MSG_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_WRONG_ANSWER_MSG'); ?></label></td>
				<td>
					<input type="text" name="wrong_answer_msg"  id="wrong_answer_msg" value="<?php echo $this->item->wrong_answer_msg;?>" style="width:500px" />
					
				</td>
		</tr>
		
		<tr class="force_correct_answer">
				<td class="key"><label  class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_WRONG_ANSWER_COLOR_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_WRONG_ANSWER_COLOR'); ?></label></td>
				<td>
					<input type="color" name="wrong_answer_color"  id="wrong_answer_color" value="<?php echo $this->item->wrong_answer_color;?>" />
					
				</td>
		</tr>
		
		<tr class="force_correct_answer">
				<td class="key"><label  class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_INSTRUCTION_MSG_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_INSTRUCTION_MSG'); ?></label></td>
				<td>
					<input type="text" name="instruction_msg"  id="instruction_msg" value="<?php echo $this->item->instruction_msg;?>" style="width:500px" />
					
				</td>
		</tr>
		
		<tr class="force_correct_answer">
				<td class="key"><label  class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_INSTRUCTION_MSG_COLOR_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_INSTRUCTION_MSG_COLOR'); ?></label></td>
				<td>
					<input type="color" name="instruction_msg_color"  id="instruction_msg_color" value="<?php echo $this->item->instruction_msg_color;?>" />
					
				</td>
		</tr>
		
			<tr>
				<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SKIPBUTTON_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SKIPBUTTON');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="skip_button1" id="skip_button1-lbl" class="radio"><?php echo JText::_( 'SHOW' ); ?></label>
					<input type="radio" name="skip_button" id="skip_button1" value="1" <?php if($this->item->skip_button ==1) echo 'checked="checked"';?>/>
					<label for="skip_button0" id="skip_button0-lbl" class="radio"><?php echo JText::_( 'HIDE' ); ?></label>
					<input type="radio" name="skip_button" id="skip_button0" value="0" <?php if($this->item->skip_button ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
		 
                     
		   <tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_PREVIOUS_BUTTON_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_PREVIOUS_BUTTON');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="prev_button1" id="prev_button1-lbl" class="radio"><?php echo JText::_( 'SHOW' ); ?></label>
					<input type="radio" name="prev_button" id="prev_button1" value="1" <?php if($this->item->prev_button ==1) echo 'checked="checked"';?>/>
					<label for="prev_button0" id="prev_button0-lbl" class="radio"><?php echo JText::_( 'HIDE' ); ?></label>
					<input type="radio" name="prev_button" id="prev_button0" value="0" <?php if($this->item->prev_button ==0) echo 'checked="checked"';?>/>
					</fieldset>
					
				</td>
			</tr>
					
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOWEXPLANATION_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOWEXPLANATION');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="show_explanation1" id="show_explanation1-lbl" class="radio"><?php echo JText::_('SHOW'); ?></label>
					<input type="radio" name="explanation" id="show_explanation1" value="1" <?php if($this->item->explanation ==1) echo 'checked="checked"';?> />
					<label for="show_explanation2" id="show_explanation2-lbl" class="radio"><?php echo JText::_('SHOW_ON_RETAKE'); ?></label>
					<input type="radio" name="explanation" id="show_explanation2" value="2" <?php if($this->item->explanation ==2) echo 'checked="checked"';?> />
					<label for="show_explanation0" id="show_explanation0-lbl" class="radio"><?php echo JText::_('HIDE'); ?></label>
					<input type="radio" name="explanation" id="show_explanation0" value="0" <?php if($this->item->explanation ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOWHINT_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOWHINT');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					
					<label for="show_hint1" id="show_hint1-lbl" class="radio"><?php echo JText::_('SHOW'); ?></label>
					<input type="radio" name="hint" id="show_hint1" value="1" <?php if($this->item->hint ==1) echo 'checked="checked"';?> />
					
					<label for="show_hint2" id="show_hint2-lbl" class="radio"><?php echo JText::_('SHOW_ON_RETAKE'); ?></label>
					<input type="radio" name="hint" id="show_hint2" value="2" <?php if($this->item->hint ==2) echo 'checked="checked"';?> />
					
					<label for="show_hint0" id="show_hint0-lbl" class="radio"><?php echo JText::_('HIDE'); ?></label>
					<input type="radio" name="hint" id="show_hint0" value="0" <?php if($this->item->hint ==0) echo 'checked="checked"';?>/>
					
					</fieldset>
				</td>
			</tr>
			
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOWTRANSCRIPT_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOWTRANSCRIPT');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					
					<label for="show_transcript1" id="show_transcript1-lbl" class="radio"><?php echo JText::_('SHOW'); ?></label>
					<input type="radio" name="transcript" id="show_transcript1" value="1" <?php if($this->item->transcript ==1) echo 'checked="checked"';?> />
					
					<label for="show_transcript2" id="show_transcript2-lbl" class="radio"><?php echo JText::_('SHOW_ON_RETAKE'); ?></label>
					<input type="radio" name="transcript" id="show_transcript2" value="2" <?php if($this->item->transcript ==2) echo 'checked="checked"';?> />
					
					<label for="show_transcript0" id="show_transcript0-lbl" class="radio"><?php echo JText::_('HIDE'); ?></label>
					<input type="radio" name="transcript" id="show_transcript0" value="0" <?php if($this->item->transcript ==0) echo 'checked="checked"';?>/>
					
					</fieldset>
				</td>
			</tr>
		
		
		
		
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_FLAG_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_FLAG');?></label></td>
			<td>
				<fieldset class="radio btn-group flag">
				<label for="show_flag1" id="show_flag1-lbl" class="radio"><?php echo JText::_( 'SHOW'); ?></label>
				<input type="radio" name="flag" id="show_flag1" value="1" <?php if($this->item->flag ==1) echo 'checked="checked"';?>/>
				<label for="show_flag0" id="show_flag0-lbl" class="radio"><?php echo JText::_( 'HIDE'); ?></label>
				<input type="radio" name="flag" id="show_flag0" value="0" <?php if($this->item->flag ==0) echo 'checked="checked"';?>/>
				</fieldset>
			</td>
		</tr>
 
 
       
		
      
		<!-- kkk -->
		
		
	
		<tr class="continuous_question">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CONTINUOUS_QUESTION_DESC');?>"><?php echo JText::_('COM_VQUIZ_CONTINUOUS_QUESTION');?></label></td>
			<td>
				<select  name="continuous_question" id="continuous_question">
					<option value="0" <?php if($this->item->continuous_question==0) echo 'selected="selected"'; ?>><?php echo JText::_('USE_GLOBAL'); ?> </option>
					
					<option value="1" <?php if($this->item->continuous_question==1) echo 'selected="selected"'; ?>><?php echo JText::_('YS'); ?> </option>
					
					<option value="2" <?php if($this->item->continuous_question==2) echo 'selected="selected"'; ?>><?php echo JText::_('NOS'); ?> </option>
					
				</select>
				
			</td>
		</tr>
		
		
		<tr class="invite">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SENT_INVITATION_DESC');?>"><?php echo JText::_('COM_VQUIZ_SENT_INVITATION');?></label></td>
			<td>
				<select  name="invite" id="invite">
					
					<option value="0" <?php if($this->item->invite==0) echo 'selected="selected"'; ?>><?php echo JText::_('USE_GLOBAL'); ?> </option>
					
					<option value="1" <?php if($this->item->invite==1) echo 'selected="selected"'; ?>><?php echo JText::_('YS'); ?> </option>
					
					<option value="2" <?php if($this->item->invite==2) echo 'selected="selected"'; ?>><?php echo JText::_('NOS'); ?> </option>
					
				</select>
				
			</td>
		</tr>
		
		<tr class="disable_print_copy_result">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_DISABLE_COPY_PRINT_RESULT_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_DISABLE_COPY_PRINT_RESULT');?></label></td>
			<td>
				<select  name="disable_print_copy_result" id="disable_print_copy_result">
					
					<option value="0" <?php if($this->item->disable_print_copy_result==0) echo 'selected="selected"'; ?>><?php echo JText::_('USE_GLOBAL'); ?> </option>
					
					<option value="1" <?php if($this->item->disable_print_copy_result==1) echo 'selected="selected"'; ?>><?php echo JText::_('YS'); ?> </option>
					
					<option value="2" <?php if($this->item->disable_print_copy_result==2) echo 'selected="selected"'; ?>><?php echo JText::_('NOS'); ?> </option>
					
				</select>
				
			</td>
		</tr>
		
		
		
		
		<tr>
					<td class="key"><label><?php echo JText::_('COM_VQUIZ_LANGUAGE'); ?></label></td>
					<td colspan="2">
					<select name="language" id="language">
					<?php echo JHtml::_('select.options', JHtml::_('contentlanguage.existing', true, true), 'value', 'text', $this->item->language);?>
					</select>
					</td>
		</tr>
		
		
		
		
		<tr>
						 <td class="key"><label  class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_IMAGE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_IMAGE'); ?></label></td>
						<td class="upimg"><input type="file" name="image" id="image" />
						<?php 
						if(!empty($this->item->image) and file_exists(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/thumbs/'.'thumb_'.$this->item->image)){ 
						echo '<img src="'.JURI::root().'/media/com_vquiz/vquiz/images/photoupload/quizzes/thumbs/'.'thumb_'.$this->item->image. '" alt="" />'; 
						}else { echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/no_image.png" alt="Image Not available" border="1" />';} 
						?>
						</td>
					</tr>	
					
        <tr>
            <td class="key hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_DESCRIPTION_TOOLTIP'); ?>">
				<label><?php echo JText::_('COM_VQUIZ_QUIZZES_DESCRIPTION'); ?></label>
			</td>
            <td>
				<?php 
				
				if($this->config->quiz_prepare_content==1){
					$description = JHtml::_('content.prepare', $this->item->description);
				}else{
					$description = $this->item->description;
				}
				
				echo $editor->display("description",  $description, "400", "300", "20", "5",true, null, null, null, array());
				?> 
            </td>
        </tr>
		
      </table>

     </div>

      

		<div id="qrpanel">
			<table class="adminform table table-striped">
			
			<tr class="question_key">
			
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUESTION_KEY_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUESTION_KEY');?></label></td>
			<td>
				<select  name="question_key" id="question_key">
					<option value="0" <?php if($this->item->question_key==0) echo 'selected="selected"'; ?>><?php echo JText::_('USE_GLOBAL'); ?> </option>
					
					<option value="1" <?php if($this->item->question_key==1) echo 'selected="selected"'; ?>><?php echo JText::_('YS'); ?> </option>
					
					<option value="2" <?php if($this->item->question_key==2) echo 'selected="selected"'; ?>><?php echo JText::_('NOS'); ?> </option>
					
				</select>
				
				
			</td>
		</tr>
		
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_BOX_SHOW_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_BOX_SHOW');?></label></td>
					<td>
					<select name="questionreview_box" id="questionreview_box">
						<option value="0" <?php if($this->item->questionreview_box==0) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_BOX_SHOW_EACH_QUESTION');?></option>
						<option value="1" <?php if($this->item->questionreview_box==1) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_BOX_SHOW_LAST_QUESTION');?></option>
					</select>
					</td>
				</tr>
				
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_QUESTIONS_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_QUESTIONS');?></label></td>
					<td>
						<fieldset class="radio btn-group">
						<label for="questionreview1" id="questionreview1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_JUSTPREV'); ?></label>
						<input type="radio" name="questionreview" id="questionreview1" value="0" <?php if($this->item->questionreview ==0) echo 'checked="checked"';?>>
						<label for="questionreview0" id="questionreview0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_All'); ?></label>
						<input type="radio" name="questionreview" id="questionreview0" value="1" <?php if($this->item->questionreview ==1) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>
				
							
				<tr  class="questionreview_question" <?php if($this->item->questionreview ==1 OR $this->item->skip_button ==1) echo 'style="display:none"';?>>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_QUESTIONS_DISPLAY_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_QUESTIONS_DISPLAY');?></label></td>
					<td>
						<fieldset class="radio btn-group btn-group-yesno" id="jform_veg_nonveg">
							<input type="radio" class="required" value="0" name="questionreview_question" id="questionreview_question0" <?php if($this->item->questionreview_question ==0) echo 'checked="checked"';?>>
							<label class="required btn" for="questionreview_question0"><?php echo JText::_('SKIPPED'); ?></label>
							<input type="radio" class="required" value="1" name="questionreview_question" id="questionreview_question1" <?php if($this->item->questionreview_question ==1) echo 'checked="checked"';?>>
							<label class="required btn " for="questionreview_question1"><?php echo JText::_('ANSWERED'); ?></label>
							<input type="radio" class="required" value="2" name="questionreview_question" id="questionreview_question2" <?php if($this->item->questionreview_question ==2) echo 'checked="checked"';?>>
							<label class="required btn" for="questionreview_question2"><?php echo JText::_('COM_VQUIZ_All'); ?></label>
						</fieldset> 
					</td>
				</tr>
				
				
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_OPTIONS_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_OPTIONS');?></label></td>
					<td>
						<fieldset class="radio btn-group">
						<label for="questionreview_option1" id="questionreview_option1-lbl" class="radio"><?php echo JText::_('HIDE'); ?></label>
						<input type="radio" name="questionreview_option" id="questionreview_option1" value="0" <?php if($this->item->questionreview_option ==0) echo 'checked="checked"';?>>
						<label for="questionreview_option0" id="questionreview_option0-lbl" class="radio"><?php echo JText::_('SHOW'); ?></label>
						<input type="radio" name="questionreview_option" id="questionreview_option0" value="1" <?php if($this->item->questionreview_option ==1) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>
			
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_DISPLAY_REVIEW_ANSWER_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_DISPLAY_REVIEW_ANSWER');?></label></td>
					
					<td class="questionreview_answer_noprev" <?php if($this->item->prev_button ==1) echo 'style="display:none"';?>>
						<fieldset class="radio btn-group btn-group-yesno" id="jform_veg_nonveg">
							<input type="radio" class="required" value="0" name="questionreview_answer" id="questionreview_answer0" <?php if($this->item->questionreview_answer ==0) echo 'checked="checked"';?>>
							<label class="required btn" for="questionreview_answer0"><?php echo JText::_('CORRECT'); ?></label>
							<input type="radio" class="required" value="1" name="questionreview_answer" id="questionreview_answer1" <?php if($this->item->questionreview_answer ==1) echo 'checked="checked"';?>>
							<label class="required btn " for="questionreview_answer1"><?php echo JText::_('CHOSEN'); ?></label>
							<input type="radio" class="required" value="2" name="questionreview_answer" id="questionreview_answer2" <?php if($this->item->questionreview_answer ==2) echo 'checked="checked"';?>>
							<label class="required btn" for="questionreview_answer2"><?php echo JText::_('BOTH'); ?></label>
						</fieldset> 
					</td>
					
					<td class="questionreview_answer_prev" <?php if($this->item->prev_button ==0) echo 'style="display:none"';?>>
						<fieldset class="radio btn-group">
						<label for="questionreview_answer0" id="questionreview_answer0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_NO'); ?></label>
						<input type="radio" name="questionreview_answer" id="questionreview_answer0" value="0" <?php if($this->item->questionreview_answer ==0) echo 'checked="checked"';?> />
						<label for="questionreview_answer1" id="questionreview_answer1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_YES'); ?></label>
						<input type="radio" name="questionreview_answer" id="questionreview_answer1" value="1" <?php if($this->item->questionreview_answer ==1) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
					
				</tr>
				
				<?php /*<tr class="show_prev_answer_tr" <?php if($this->item->prev_button ==1) echo 'style="display:none"';?>>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOWCORRECTANS_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOWCORRECTANS');?></label></td>
					<td>
						<fieldset class="radio btn-group">
						<label for="prev_answer1" id="prev_answer1-lbl" class="radio"><?php echo JText::_('SHOW'); ?></label>
						<input type="radio" name="prev_answer" id="prev_answer1" value="1" <?php if($this->item->prev_answer ==1) echo 'checked="checked"';?>/>
						<label for="prev_answer0" id="prev_answer0-lbl" class="radio"><?php echo JText::_('HIDE'); ?></label>
						<input type="radio" name="prev_answer" id="prev_answer0" value="0" <?php if($this->item->prev_answer ==0) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>*/?>
				
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_QUESTION_CLICKABLE_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_REVIEW_QUESTION_CLICKABLE');?></label></td>
					<td>
						<fieldset class="radio btn-group">
						<label for="questionreview_qlink0" id="questionreview_qlink0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_NO'); ?></label>
						<input type="radio" name="questionreview_qlink" id="questionreview_qlink0" value="0" <?php if($this->item->questionreview_qlink ==0) echo 'checked="checked"';?> />
						<label for="questionreview_qlink1" id="questionreview_qlink1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_YES'); ?></label>
						<input type="radio" name="questionreview_qlink" id="questionreview_qlink1" value="1" <?php if($this->item->questionreview_qlink ==1) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
				</tr>
				
			</table>
		</div>
		
		<div id="meta_key">
			<table class="adminform table table-striped">
				
			<tr class="share_button">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SHARE_BUTTON_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_SHARE_BUTTON');?></label></td>
			<td>
				<select  name="share_button" id="share_button">
					
					<option value="0" <?php if($this->item->share_button==0) echo 'selected="selected"'; ?>><?php echo JText::_('USE_GLOBAL'); ?> </option>
					
					<option value="1" <?php if($this->item->share_button==1) echo 'selected="selected"'; ?>><?php echo JText::_('YS'); ?> </option>
					
					<option value="2" <?php if($this->item->share_button==2) echo 'selected="selected"'; ?>><?php echo JText::_('NOS'); ?> </option>
					
				</select>
				
				<?php $share_btn_choosed=explode(',',$this->item->share_btn_choosed);?>
				
				<div class="radio btn-group showButton" data-toggle="buttons" style="<?php if($this->item->share_button==2) echo "display:none;"?>">
							
					 <label class="btn btn-success">
						<input type="checkbox" name="share_btn_choosed[]" value="1" <?php if(in_array(1,$share_btn_choosed)==true) echo 'checked="checked"';?>>
						<span>Facebook</span>
					  </label>
					  <label class="btn btn-success">
						<input type="checkbox" name="share_btn_choosed[]" value="2" <?php if(in_array(2,$share_btn_choosed)==true) echo 'checked="checked"';?>>
						<span>Twitter</span>
					  </label>
					  <label class="btn btn-success">
						<input type="checkbox" name="share_btn_choosed[]" value="3" <?php if(in_array(3,$share_btn_choosed)==true) echo 'checked="checked"';?>>
						<span>Gmail</span>
					  </label><label class="btn btn-success">
						<input type="checkbox" name="share_btn_choosed[]" value="0" <?php if(in_array(0,$share_btn_choosed)==true) echo 'checked="checked"';?>>
						<span>Others</span>
					  </label>
				</div>
							
			</td>
		</tr>
		
				<tr>
					<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_META_DES_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_META_DESCRIPTION'); ?></label></td>
					<td><textarea name="meta_desc" id="meta_desc" cols="150" rows="5"><?php echo $this->item->meta_desc;?></textarea></td>
				</tr>
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_META_KEY_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_META_KEYWORD'); ?></label></td>
					<td><textarea name="meta_keyword" id="meta_keyword" cols="150" rows="5"><?php echo $this->item->meta_keyword;?></textarea></td>
				</tr>
			</table>
		</div>
		
		<div id="display">
			<table class="adminform table table-striped">
			
			<tr class="live_score_tr">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_LIVESCORE_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_LIVE_SCORE');?></label></td>
			<td>
				<fieldset class="radio btn-group livescore">
				<label for="show_livescore1" id="show_livescore1-lbl" class="radio"><?php echo JText::_('SHOW'); ?></label>
				<input type="radio" name="livescore" id="show_livescore1" value="1" <?php if($this->item->livescore ==1) echo 'checked="checked"';?>/>
				<label for="show_livescore0" id="show_livescore0-lbl" class="radio"><?php echo JText::_('HIDE'); ?></label>
				<input type="radio" name="livescore" id="show_livescore0" value="0" <?php if($this->item->livescore ==0) echo 'checked="checked"';?>/>
				</fieldset>
			</td>
		</tr>
		
			<tr>
				<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_SLIDER_BAR_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_SLIDER_BAR');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="slider_bar1" id="slider_bar1-lbl" class="radio"><?php echo JText::_( 'SHOW' ); ?></label>
					<input type="radio" name="slider_bar" id="slider_bar1" value="1" <?php if($this->item->slider_bar ==1) echo 'checked="checked"';?>/>
					<label for="slider_bar0" id="slider_bar0-lbl" class="radio"><?php echo JText::_( 'HIDE' ); ?></label>
					<input type="radio" name="slider_bar" id="slider_bar0" value="0" <?php if($this->item->slider_bar ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_QUESTION_NUMBER_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_QUESTION_NUMBER');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="ques_no_button1" id="ques_no_button1-lbl" class="radio"><?php echo JText::_( 'SHOW' ); ?></label>
					<input type="radio" name="question_number" id="ques_no_button1" value="1" <?php if($this->item->question_number ==1) echo 'checked="checked"';?>/>
					<label for="ques_no_button0" id="ques_no_button0-lbl" class="radio"><?php echo JText::_( 'HIDE' ); ?></label>
					<input type="radio" name="question_number" id="ques_no_button0" value="0" <?php if($this->item->question_number ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			<tr>
				<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_COMPLETION_LEVEL_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_COMPLETION_LEVEL');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="completion_level1" id="completion_level1-lbl" class="radio"><?php echo JText::_( 'SHOW' ); ?></label>
					<input type="radio" name="completion_level" id="completion_level1" value="1" <?php if($this->item->completion_level ==1) echo 'checked="checked"';?>/>
					<label for="completion_level0" id="completion_level0-lbl" class="radio"><?php echo JText::_( 'HIDE' ); ?></label>
					<input type="radio" name="completion_level" id="completion_level0" value="0" <?php if($this->item->completion_level ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			 <tr class="question_paging">
		
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_PAGING_TOOLTIP'); ?>" ><?php echo JText::_('COM_VQUIZ_QUIZZES_PAGING'); ?></label></td>
			<td>
				<div class="paginglimitbox">
					<select  name="paging" id="paging" >
						<option value="1" <?php if($this->item->paging==1) echo 'selected="selected"'; ?>><?php echo JText::_('ONEQUESTION_PERPAGE'); ?> </option>
						<option value="2" <?php if($this->item->paging ==2 and $this->item->paging_limit>1) echo 'selected="selected"'; ?>><?php echo JText::_('ALLQUESTION_PERPAGE'); ?> </option>
						
						<?php if($this->item->enable_questiongroup==1){?>
							<option value="3" <?php if($this->item->paging ==3) echo 'selected="selected"'; ?>><?php echo JText::_('QUESTION_GROUP_PERPAGE'); ?> </option>
						<?php }?>
					</select>
				</div>
			</td>
        </tr>
		  <tr class="question_limit_tr" style="display:hidden">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_QUESTIONS_LIMIT_TOOLTIP'); ?>"  ><?php echo JText::_('COM_VQUIZ_QUIZZES_QLIMIT_PAGING'); ?></label></td>
			<td>
				<input type="text" name="paging_limit" id="paging_limit" value="<?php echo $this->item->paging_limit>1?$this->item->paging_limit:1 ;?>" />
			</td>
        </tr>
		
			</table>
		</div>
			
        <div id="access">
		
			<table class="adminform table table-striped">
			
			<tr>
				<td valign="top" class="key" width="200">
					<label><?php echo JText::_( 'COM_VQUIZ_ACCESS_TOKEN_KEY' ); ?></label>
				</td>
				<td>
					<label class="pull-left"><input type="text" name="" value="<?php echo $this->item->access_token ?>" disabled  class="access_token_hidden"/><a href="javascript:void(0)" class="btn btn-sucess generate_token"><?php echo JText::_( 'COM_VQUIZ_GENERATE_ACCESS_TOKEN' ); ?></a>
					<input type="hidden" name="access_token" value="<?php echo $this->item->access_token ?>" class="access_token">
					<input type="button" class="btn" id="access_token_reset" value="<?php echo JText::_('COM_VQUIZ_RESET'); ?>"/>
					</label>
				 
					<label class="pull-right">
					<input type="text" name="" value="<?php if(!empty($this->item->access_token)) echo JURI::root().'index.php?option=com_vquiz&view=quizmanager&layout=description&id='.$this->item->id.'&access='.$this->item->access_token;?>" disabled id="access_link"  style="width:300px;" /><a href="javascript:void(0)" class="btn btn-primary" id="copy_acess_link"><?php echo JText::_( 'COM_VQUIZ_COPY' ); ?></a>
					</label>
				</td>
			<tr>
				<td valign="top" class="key" width="200">
				<label><?php echo JText::_( 'ACCESS_LEVEL' ); ?></label>
				</td>
				<td><label><?php echo $this->lists['access']; ?></label></td>
			</tr>
			
			<tr>
				<td>
				<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SELECT_USER_TO_PLAY_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_SELECT_USER_TO_PLAY')?></label>
				</td>
				
				<td>
					<span class="input-append">
					<?php 

					if(!empty($this->item->play_user_ids)){
						$play_user_name=$this->item->play_user_name;		
						$play_user_ids=$this->item->play_user_ids;
					}else{
						$play_user_ids ='';
						$play_user_name =JText::_('COM_VQUIZ_SELECT_USER');
					}


					?>

					<input type="text" size="80" disabled="disabled" value="<?php echo $play_user_name;?>" id="jform_request_user_name" name="play_user_name[]" class="input-medium" />

					<input type="hidden" value="<?php echo $play_user_ids;?>" name="play_user_ids[]" class="required modal-value" id="jform_request_user_id" aria-required="true" required="required">

					<a currten_id="" rel="{handler: 'iframe', size: {x: 800, y: 450}}" href="index.php?option=com_vquiz&amp;view=users&amp;tmpl=component&amp;function=jSelectUsers_jform_request_id&from_userview=1&selected_users=<?php echo $play_user_ids;?>" title="" class="modal btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_USERS');?>" id="active_selecteduser"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_SELECT");?></a> 
					
					<a href="javascript:void(0);" title="" class="btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_USERS');?>" id="deactive_selecteduser" style="display:none;"><i class="icon-file" disabled="true"></i><?php echo JText::_("COM_VQUIZ_SELECT");?></a> 

					<input type="button" value="Reset" name="reset" currten_id="" id="reset_users" class="btn reset">

					</span> 
				</td>
				</tr>
				<tr>
<td>
<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SELECT_QUIZ_CREATOR_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_SELECT_QUIZ_CREATOR')?></label>
</td>

<td>
<span class="input-append">
<?php 

if($this->item->created_by > 0){
$created_by_name=$this->item->name;		
$created_by=$this->item->created_by;
}else{
$created_by =0;
$created_by_name =JText::_('COM_VQUIZ_SELECT_QUIZ_CREATOR');
}


?>

<input type="text" size="80" disabled="disabled" value="<?php echo $created_by_name; ?>" id="jform_request_created_by_name" name="created_by_name" class="input-medium" />

<input type="hidden" value="<?php echo $created_by;?>" name="created_by" class="required modal-value" id="jform_request_created_by" aria-required="true" required="required">

<a currten_id="" rel="{handler: 'iframe', size: {x: 800, y: 450}}" href="index.php?option=com_vquiz&amp;view=users&amp;tmpl=component&amp;function=jQuizCreator_jform_request_id&from_creatorview=1&quiz_creator=<?php echo $created_by;?>" title="" class="modal btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_QUIZ_CREATOR');?>" id="active_selecteduser"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_SELECT");?></a> 

<a href="javascript:void(0);" title="" class="btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_QUIZ_CREATOR');?>" id="deactive_selecteduser" style="display:none;"><i class="icon-file" disabled="true"></i><?php echo JText::_("COM_VQUIZ_SELECT");?></a> 

<input type="button" value="Reset" name="reset" currten_id="" id="reset_quiz_creator" class="btn reset">

</span> 
</td>
</tr>

				<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_STATUS_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_STATUS'); ?></label></td>
				<td> 
					<fieldset class="radio btn-group">
					<label for="published1" id="published1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?></label>
					<input type="radio" name="published" id="published1" value="1" <?php if($this->item->published ==1) echo 'checked="checked"';?>/>
					<label for="published0" id="published0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?></label>
					<input type="radio" name="published" id="published0" value="0" <?php if($this->item->published ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
            </tr>
			
			   <tr id="start_publish_date_row" <?php if($this->item->published == 0) echo 'style="display:none"';?>>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_PUBLISH_DATE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_STARTPUBLISHDATE'); ?></label>
					</td>
					
					<td>
					
					
					<?php 
						$startpublishStrtime=strtotime($this->item->startpublish_date);
						$startpublish_date=$startpublishStrtime>0?$startpublishStrtime:strtotime("now");
						echo JHTML::calendar(date('Y-m-d G:i:s', $startpublish_date),'startpublish_date', 'startpublish_date', '%Y-%m-%d %H:%M:%S',array('size'=>'8','maxlength'=>'19','placeholder'=>'Start Publish date',));
					?>
					
					</td>
                </tr>
				<tr id="end_publish_date_row" <?php if($this->item->published == 0) echo 'style="display:none"';?>> 
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_EPDATE_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_ENDPUBLISHDATE'); ?></label></td>

					<td> 
						<?php 

						$endpublishStrtime=strtotime($this->item->endpublish_date);
						$endpublish_date=$endpublishStrtime>0?$endpublishStrtime:strtotime("+1 year");
						echo JHTML::calendar( date('Y-m-d G:i:s', $endpublish_date),'endpublish_date', 'endpublish_date', '%Y-%m-%d %H:%M:%S',array('size'=>'8','maxlength'=>'19','placeholder'=>'end Publish date',));
						?>	

					</td>
					
                </tr>
				
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_ATTEMPTCOUNT_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_ATTEMPTCOUNT'); ?></label></td>
				<td>
					<input type="text" name="attempt_count" id="attempt_count" value="<?php echo $this->item->attempt_count ?>" />
				</td>
			</tr>
			<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_CONSIDER_IP_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_CONSIDER_IP'); ?></label></td>	
					<td>
						<fieldset class="radio btn-group">
						<label for="count_ipaddress0" id="count_ipaddress0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_NO'); ?></label>
						<input type="radio" name="count_ipaddress" id="count_ipaddress0" value="0" <?php if($this->item->count_ipaddress ==0) echo 'checked="checked"';?> />
						<label for="count_ipaddress1" id="count_ipaddress1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_YES'); ?></label>
						<input type="radio" name="count_ipaddress" id="count_ipaddress1" value="1" <?php if($this->item->count_ipaddress ==1) echo 'checked="checked"';?>/>
						</fieldset>
					</td>
			</tr>
			<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_DELAYBETWEENATTEMPT_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_DELAYBETWEENATTEMPT'); ?></label></td>
				<td>
					<input type="text" name="attempt_delay" id="attempt_delay"   value="<?php echo $this->item->attempt_delay?>"  style="width:50px" />
					<select  name="delay_periods" id="delay_periods" >
					<option value="hour" <?php if($this->item->delay_periods=='hour') echo 'selected="selected"'; ?>><?php echo JText::_('HOURS'); ?> </option>
					<option value="days" <?php if($this->item->delay_periods=='days') echo 'selected="selected"'; ?> ><?php echo JText::_('DAYS'); ?> </option>
					<option value="week" <?php if($this->item->delay_periods=='week') echo 'selected="selected"'; ?> ><?php echo JText::_('WEEKS'); ?> </option>
					<option value="month" <?php if($this->item->delay_periods=='month') echo 'selected="selected"'; ?> ><?php echo JText::_('MONTHS'); ?> </option>
					</select>
				</td>
			</tr>
			
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_CHECK_IP_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_CHECK_IP'); ?></label></td>
					<td>
						<select name="ipaddress_allow[]" id="select-choice" class="js-example-tags" multiple>
							<?php 
							$ipaddress_allow=json_decode($this->item->ipaddress_allow);
							if(!empty($ipaddress_allow)){
								for($j=0;$j<count($ipaddress_allow);$j++){?>
								<option value="<?php echo $ipaddress_allow[$j];?>" selected='selected'><?php echo $ipaddress_allow[$j];?></option>
							<?php 
								}
							}
							?>
						</select>
					</td>
				</tr>
				

			</table>
        </div>
		
		<!--Result Template Container-->

		<div  id="quiztext"> 


		<table class="adminform table table-striped">
		
		<tr>
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_MENU_ITEM_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_MENU_ITEM'); ?></label></td>
				<td>
					<select  name="article_link_id" id="article_link_id">
					<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_MENUITEM');?></option>
					<?php for($b=0;$b<count($this->menuItems);$b++){?>
						<option value="<?php echo $this->menuItems[$b]->id; ?>" <?php if($this->item->article_link_id==$this->menuItems[$b]->id) echo "selected='selected';"?> ><?php echo addslashes($this->menuItems[$b]->title); ?></option>
					<?php }?>
					</select>	
				</td>
			</tr>
			
		<tr class="quiz_result_section">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_DISPLAY_QUIZ_RESULT_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_DISPLAY_QUIZ_RESULT'); ?></label></td>
			<td class="">
				<select  name="display_result" id="">
				<option value="0" <?php if($this->item->display_result==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_END_OF_THE_QUIZ'); ?> </option>
				<option value="1" <?php if($this->item->display_result ==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_DISCLOSE_LATER_BY_EMAIL'); ?> </option>
				<option value="2" <?php if($this->item->display_result ==2) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_RESULT_SECTION'); ?> </option>
				</select>
			</td>
		</tr>
		
		<tr class="take_snapshot quiz_result_section">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_TAKE_SNAPSHOT_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_TAKE_SNAPSHOT');?></label></td>
			<td>
				<select  name="take_snapshot" id="take_snapshot">
					
					<option value="0" <?php if($this->item->take_snapshot==0) echo 'selected="selected"'; ?>><?php echo JText::_('USE_GLOBAL'); ?> </option>
					
					<option value="1" <?php if($this->item->take_snapshot==1) echo 'selected="selected"'; ?>><?php echo JText::_('YS'); ?> </option>
					
					<option value="2" <?php if($this->item->take_snapshot==2) echo 'selected="selected"'; ?>><?php echo JText::_('NOS'); ?> </option>
					
				</select>
				
			</td>
		</tr>
		
		<tr class="answrs_sheet_show quiz_result_section">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_ANSWER_SHEET_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_ANSWER_SHEET');?></label></td>
			<td>
				<fieldset class="radio btn-group">
				<label for="answer_sheet1" id="answer_sheet1-lbl" class="radio"><?php echo JText::_('SHOW'); ?></label>
				<input type="radio" name="answer_sheet" id="answer_sheet1" value="1" <?php if($this->item->answer_sheet ==1) echo 'checked="checked"';?>/>
				<label for="answer_sheet0" id="answer_sheet0-lbl" class="radio"><?php echo JText::_('HIDE'); ?></label>
				<input type="radio" name="answer_sheet" id="answer_sheet0" value="0" <?php if($this->item->answer_sheet ==0) echo 'checked="checked"';?>/>
				</fieldset>
			</td>
		</tr>
		
    
		<tr class="display_correctans_tr">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_ANSWER_SHEET_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_DISPLAY_THE_CORRECT_ANS');?></label></td>
			<td>
				<fieldset class="radio btn-group btn-group-yesno" id="jform_veg_nonveg">
					<input type="radio" class="required" value="0" name="correctans" id="display_correctans0" <?php if($this->item->correctans ==0) echo 'checked="checked"';?>>
					<label class="required btn" for="display_correctans0"><?php echo JText::_('CHOSEN'); ?></label>
					<input type="radio" class="required" value="1" name="correctans" id="display_correctans1" <?php if($this->item->correctans ==1) echo 'checked="checked"';?>>
					<label class="required btn " for="display_correctans1"><?php echo JText::_('CORRECT'); ?></label>
					<input type="radio" class="required" value="2" name="correctans" id="display_correctans2" <?php if($this->item->correctans ==2) echo 'checked="checked"';?>>
					<label class="required btn" for="display_correctans2"><?php echo JText::_('BOTH'); ?></label>
					
					<input type="radio" class="required" value="3" name="correctans" id="display_correctans3" <?php if($this->item->correctans ==3) echo 'checked="checked"';?>>
					<label class="required btn" for="display_correctans3"><?php echo JText::_('COM_VQUIZ_NONE'); ?></label>
					
				</fieldset> 
				
				
			</td>
		</tr>
		
		

		<tr class="display_answershet_explanation quiz_result_section">
		
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_DISPLAY_THE_EXPLANATION_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_DISPLAY_THE_EXPLANATION');?></label></td>
			<td>
				<fieldset class="radio btn-group">
					<label for="answersheet_explanation1" id="answersheet_explanation1-lbl" class="radio" ><?php echo JText::_( 'SHOW'); ?>
						<input type="radio" name="answersheet_explanation" id="answersheet_explanation1" value="1" <?php if($this->item->answersheet_explanation ==1) echo 'checked="checked"';?> />
					</label>
					<label for="answersheet_explanation0" id="answersheet_explanation0-lbl" class="radio"><?php echo JText::_( 'HIDE'); ?>
						<input type="radio" name="answersheet_explanation" id="answersheet_explanation0" value="0" <?php if($this->item->answersheet_explanation ==0) echo 'checked="checked"';?>/>
					</label>
				</fieldset>
			</td>
			
		</tr>
	 
 		
		
		
		 <tr class="show_hide_graph_tr quiz_result_section">
				<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_GRAPH_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_GRAPH');?></label></td>
				<td>
				
					<fieldset class="radio btn-group">
						<label for="show_graph1" id="show_graph1-lbl" class="radio" ><?php echo JText::_( 'SHOW'); ?>
							<input type="radio" name="show_graph" id="show_graph1" value="1" <?php if($this->item->show_graph ==1) echo 'checked="checked"';?> />
						</label>
						<label for="show_graph0" id="show_graph0-lbl" class="radio"><?php echo JText::_( 'HIDE'); ?>
							<input type="radio" name="show_graph" id="show_graph0" value="0" <?php if($this->item->show_graph ==0) echo 'checked="checked"';?>/>
						</label>
					</fieldset>
					
				</td>
		</tr>


		<tr class="user_select_graph_tr quiz_result_section">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SCORE_DISPLAY_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SCORE_DISPLAY'); ?></label></td>
			<td id="userscore_td">
				<select  name="userscore" id="userscore" >
				<option value="0" <?php if($this->item->userscore ==0) echo 'selected="selected"'; ?>><?php echo JText::_('WITH_ALL_USER'); ?></option>
				<option value="1" <?php if($this->item->userscore==1) echo 'selected="selected"'; ?>><?php echo JText::_('SINGLE_USER'); ?> </option>
				</select>
			</td>
		</tr>
 
		<tr class="graph_type_tr quiz_result_section">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_CHOSEGRAPH_TOOLTIP'); ?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_CHOSEGRAPH'); ?></label></td>
			<td class="graph_type_td">
				<select  name="graph_type" id="graph_type">
				<option value="1" <?php if($this->item->graph_type==1) echo 'selected="selected"'; ?>><?php echo JText::_('COLUMN_CHART'); ?> </option>
				<option value="2" <?php if($this->item->graph_type ==2) echo 'selected="selected"'; ?>><?php echo JText::_('PIE_CHART'); ?> </option>
				<option value="3" <?php if($this->item->graph_type ==3) echo 'selected="selected"'; ?>><?php echo JText::_('LINE_CHART'); ?> </option>
				</select>
			</td>
		</tr>
		
		<tr class="trivia_personality_none quiz_result_section">
						<td><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SET_QUIZ_RESULT_MESSAGE'); ?>"><?php echo JText::_('COM_VQUIZ_SET_QUIZ_RESULT_MESSAGE'); ?></label> 
						</td>
						<td>
							<div class="trivia_messages" style="display:none">
								<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SET_TRIVIA_MESSAGE_TOOLTIP'); ?>">
								
								<a  class="modal trivia_setmsg" href="<?php echo 'index.php?option=com_vquiz&view=quizmanager&layout=trivia_messages&id='.$this->item->id.'&tmpl=component';?>'" rel="{handler: 'iframe', size: {x: 1000, y: 500}}">
								
								<input class="btn" type="button" value="<?php echo JText::_('COM_VQUIZ_SET_TRIVIA_MESSAGE'); ?>" />
								</a>
								
								</label> 
							</div>
							
							<div class="personality_messages" style="display:none">
							
								<select  name="personality_type" id="personality_type" >
									<option value="0" <?php  if($this->item->personality_type==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_SINGLE_PERSONALITY'); ?></option>
									<option value="1" <?php  if($this->item->personality_type==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_MULTI_PERSONALITY'); ?></option>
									</select>
								
								<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SET_PERSONALITY_MESSAGE_TOOLTIP'); ?>">
								
								<a  class="modal personality_setmsg"  href="<?php echo 'index.php?option=com_vquiz&view=quizmanager&layout=personality_messages&id='.$this->item->id.'&p_type='.$this->item->personality_type.'&tmpl=component';?>'" rel="{handler: 'iframe', size: {x:1100, y: 600}}">
								<input class="btn" type="button" value="<?php echo JText::_('COM_VQUIZ_SET_TRIVIA_MESSAGE'); ?>" />
								</a>
								
								</label> 
								
							</div>
							<div class="multi_personality_messages" style="display:none">
							
								
								<label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SET_PERSONALITY_MESSAGE_TOOLTIP'); ?>">	
								
								<a  class="modal personality_setmsg" href="<?php echo 'index.php?option=com_vquiz&view=quizmanager&layout=personality_messages&id='.$this->item->id.'&p_type='.$this->item->personality_type.'&tmpl=component';?>'" rel="{handler: 'iframe', size: {x:1100, y: 600}}">
								<input class="btn" type="button" value="<?php echo JText::_('COM_VQUIZ_SET_TRIVIA_MESSAGE'); ?>" />
								</a>
								
								</label> 
								
							</div>
						</td>
					</tr>
					
		
			
		
		</table>
<br />		

			<fieldset class="adminform">   
				<legend><?php echo JText::_( 'COM_VQUIZ_QUIZ_RESULT_TEMPLATE'); ?></legend>
			<div class="conf_left_panel">
			
							<?php 
							echo $editor->display("textformat",  $this->item->textformat, "400", "400", "20", "5", 1, null, null, null, array());
							?>
					
				</div>

				<div class="conf_right_panel">

					<div class="conf-para">
						<h3><?php echo JText::_("COM_VQUIZ_PARAMETER");?></h3>
						
						<div class="">
						
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{certificate_number}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CERTIFICATE_NUMBER')?>">{certificate_number}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{username}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERNAME')?>">{username}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{spenttime}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_SPENTTIME')?>">{spenttime}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{quizname}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUIZNAME')?>">{quizname}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{startdate}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_STARTTIME')?>">{startdate}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{enddate}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_ENDTIME')?>">{enddate}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{maxscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_MAXSCORE')?>">{maxscore}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{userscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERSCORE')?>">{userscore}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{percentscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERCENTSCORE')?>">{percentscore}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{passedscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERCENTSCORE')?>">{passedscore}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{passed}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PASSED')?>">{passed}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{email}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_EMAIL')?>">{email}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{flag}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_FLAG')?>">{flag}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{trivia_mesCOM_VQUIZ_KEYWORD_TRIVIA_MESSAGEsage}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('')?>">{trivia_message}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{questiongroup_score}', 'params_Value');return false;" href="javascript:void(0);"><span class="class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUESTIONGROUP_SCORE')?>">{questiongroup_score}</span></a>
							<br>	
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{categoryscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CATEGORY_MESSAGE')?>">{categoryscore}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{personality_message}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERSONALITY_MESSAGE')?>">{personality_message}</span></a>
							
							<br>
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{personality_score}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PERSONALITY_SCORE')?>">{personality_score}</span></a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{total_questions}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_TOTAL_QUESTIONS')?>">{total_questions}</span></a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{given_answers}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_GIVEN_ANSWERS')?>">{given_answers}</span></a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{correct_answers}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CORRECT_ANSWERS')?>">{correct_answers}</span></a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{catid}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CORRECT_CATID')?>">{catid}</span></a>

							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{articleid}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_ARTICLE_ID')?>">{articleid}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{play_date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_DATE')?>">{play_date}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CURRENT_DATE')?>">{date}</span></a>
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{answersheet}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ANSWERSHEET')?>">{answersheet}</span></a>
							
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{quizurl}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUIZURL')?>">{quizurl}</span></a>

						</div>
					</div>
				</div>
				</fieldset>
		</div>
		
		<div id="certificates">
		
			<div id="emailtext">

			<fieldset class="adminform"> 

			<div class="conf_left_panel">
			
				<div id="tabs_certificate">
					<ul>
					<li><a href="#mpanel1"><?php echo JText::_('COM_VQUIZ_QUIZZES_CERTIFICATE_NUMBER'); ?></a></li>
					<li><a href="#mpanel2"><?php echo JText::_('COM_VQUIZ_QUIZZES_CERTIFICATE_TEMPLATE'); ?></a></li>
					</ul>
					

					<div  id="mpanel1">
							<table class="adminform table table-striped" width="100%">
								<tbody>
								
								<tr class="quiz_certificate">
			<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_CERTIFICATE_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_CERTIFICATE');?></label></td>
			<td>
				
				<select  name="quiz_certificate" id="quiz_certificate">
				
				<option value="0" <?php if($this->item->quiz_certificate==0) echo 'selected="selected"'; ?>><?php echo JText::_('USE_GLOBAL'); ?> </option>
				<option value="1" <?php if($this->item->quiz_certificate==1) echo 'selected="selected"';?>><?php echo JText::_("COM_VQUIZ_DOWNLOAD_BUTTON")?></option>
				<option value="2" <?php if($this->item->quiz_certificate==2) echo 'selected="selected"';?>><?php echo JText::_("COM_VQUIZ_EMAIL_BUTTON")?></option>
				<option value="3" <?php if($this->item->quiz_certificate==3) echo 'selected="selected"';?>><?php echo JText::_("COM_VQUIZ_AUTOMATIC_EMAIL")?></option>
				<option value="4" <?php if($this->item->quiz_certificate==4) echo 'selected="selected"';?>><?php echo JText::_("COM_VQUIZ_EMAIL_BY_ADMIN")?></option>
				
				</select>
				
				
			</td>
		</tr>
		
		<tr>
										<td><label ><?php echo JText::_('COM_VQUIZ_SAVE_CERTIFICATE');?></label></td>
										<td>
											<fieldset class="radio btn-group">
												<label for="save_certificate1" id="save_certificate1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
												<input type="radio" name="save_certificate" id="save_certificate1" value="1" <?php if($this->item->save_certificate==1) echo 'checked="checked"';?>/>
												<label for="save_certificate0" id="save_certificate0-lbl" class="radio"><?php echo JText::_( 'NOS' ); ?></label>
												<input type="radio" name="save_certificate" id="save_certificate0" value="0" <?php if($this->item->save_certificate==0) echo 'checked="checked"';?>/>
											</fieldset>
										</td>
									</tr>
		
									<tr>
										<td><label><?php echo JText::_('COM_VQUIZ_QUIZZES_START_WITH');?></label></td>
										<td><label ><input type="text" name="start_with" value="<?php echo $this->item->start_with?>"/></label></td>
									</tr>
									
									<tr>
										<td><label><?php echo JText::_('COM_VQUIZ_TYPES');?></label></td>
										<td><label>
											<select name="cet_type" id="cet_type">
											<option value="0" <?php if($this->item->cet_type==0) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_CET_SEQ');?></option>
											<option value="1" <?php if($this->item->cet_type==1) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_CET_RAND');?></option>
											</select>
											
										</label></td>
									</tr>
									<tr class="cet_format" style="<?php if($this->item->cet_type==0) echo 'display:none';?>">
										<td><label><?php echo JText::_('COM_VQUIZ_FORMAT');?></label></td>
										<td><label>
											<select name="cet_format" id="cet_format">
											<option value="0" <?php if($this->item->cet_format==0) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_NUMERIC');?></option>
											<option value="1" <?php if($this->item->cet_format==1) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_ALPHA_NUMERIC');?></option>
											<option value="2" <?php if($this->item->cet_format==2) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_QUIZZES_ALPHABETIC');?></option>
											</select>
											
										</label></td>
									</tr>
									
									<tr>
										<td><label><?php echo JText::_('COM_VQUIZ_QUIZZES_NUMBER_OF_DIGITS');?></label></td>
										<td><label>
											<input type="text" name="cet_digits" value="<?php echo $this->item->cet_digits;?>"/>
										</label></td>
									</tr>
									
									<tr>
										<td><label ><?php echo JText::_('COM_VQUIZ_QUIZZES_END_WITH');?></label></td>
										<td><label ><input type="text" name="end_with" value="<?php echo $this->item->end_with?>"/></label></td>
									</tr>
									
									<tr>
										<td><label><?php echo JText::_('COM_VQUIZ_CERTIFICATE_NAME');?></label></td>
										<td><label>
											<input type="text" name="cet_name" value="<?php echo $this->item->cet_name;?>"/><?php echo JText::_('COM_VQUIZ_CERTIFICATE_NAME_SUFFIX');?>
										</label></td>
									</tr>
									
								</tbody>
							</table>
					</div> 

					<div  id="mpanel2">
						<h4><?php echo JText::_('COM_VQUIZ_QUIZZES_TEMPLATE')?></h4>
						<?php 
						echo $editor->display("certificate",  $this->item->certificate, "400", "400", "20", "5", 1, null, null, null, array());
						?>
					</div>

				</div>
			</div>

				<div class="conf_right_panel"> 

					<div class="conf-para">
					<h3><?php echo JText::_("COM_VQUIZ_QUIZZES_PARAMETER");?></h3>

						<div class="">						
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{certificate_number}', 'params_Value');return false;" href="">{certificate_number}</a>
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{username}', 'params_Value');return false;" href="javascript:void(0);">{username}</a>
							<br>
							

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{spenttime}', 'params_Value');return false;" href="javascript:void(0);">{spenttime}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{quizname}', 'params_Value');return false;" href="javascript:void(0);">{quizname}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{startdate}', 'params_Value');return false;" href="javascript:void(0);">{starttime}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{enddate}', 'params_Value');return false;" href="javascript:void(0);">{endtime}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{maxscore}', 'params_Value');return false;" href="javascript:void(0);">{maxscore}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{userscore}', 'params_Value');return false;" href="javascript:void(0);">{userscore}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{percentscore}', 'params_Value');return false;" href="javascript:void(0);">{percentscore}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{passedscore}', 'params_Value');return false;" href="javascript:void(0);">{passedscore}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{passed}', 'params_Value');return false;" href="javascript:void(0);">{passed}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{email}', 'params_Value');return false;" href="javascript:void(0);">{email}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{resultslink}', 'params_Value');return false;" href="javascript:void(0);">{flag}</a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{trivia_message}', 'params_Value');return false;" href="javascript:void(0);">{trivia_message}</a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{categoryscore}', 'params_Value');return false;" href="javascript:void(0);">{categoryscore}</a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{personality_message}', 'params_Value');return false;" href="javascript:void(0);">{personality_message}</a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{personality_score}', 'params_Value');return false;" href="javascript:void(0);">{personality_score}</a>
							
							<br>
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{total_questions}', 'params_Value');return false;" href="javascript:void(0);">{total_questions}</a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{given_answers}', 'params_Value');return false;" href="javascript:void(0);">{given_answers}</a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{correct_answers}', 'params_Value');return false;" href="javascript:void(0);">{correct_answers}</a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{catid}', 'params_Value');return false;" href="javascript:void(0);">{catid}</a>

							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{articleid}', 'params_Value');return false;" href="javascript:void(0);">{articleid}</a>
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{play_date}', 'params_Value');return false;" href="javascript:void(0);">{date}</a>
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{questiongroup_score}', 'params_Value');return false;" href="javascript:void(0);">{questiongroup_score}</a>							
							
							<br>	
								
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{date}', 'params_Value');return false;" href="javascript:void(0);">{current_date}</a>
							
						</div>

					</div>

				</div>                 

			</fieldset>

			</div> 
		</div>
		
		<!--Lead Generation--->
			<div id="l_generation">
			
				<table class="adminform table table-striped">
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_LEAD_GENERATE_BOX_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_LEAD_GENERATE_BOX_SHOWS');?></label></td>
					<td>
					<select name="lead_generate" id="lead_generate">
						<option value="0" <?php if($this->item->lead_generate==0) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_LEAD_GENERATE_BOX_NONE');?></option>
						<option value="1" <?php if($this->item->lead_generate==1) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_LEAD_GENERATE_BOX_BEGINING');?></option>
						<option value="2" <?php if($this->item->lead_generate==2) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_LEAD_GENERATE_BOX_END_QUIZ');?></option>
					</select>
					</td>
				</tr>
								
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LEAD_GENERATE_BOX_MANDATORY_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_LEAD_GENERATE_BOX_MANDATORY_TOOLTIP');?></label></td>
					<td>
					
						<fieldset class="radio btn-group">
							<label for="lead_generate_mandatory1" id="lead_generate_mandatory1-lbl" class="radio" ><?php echo JText::_( 'YS'); ?>
								<input type="radio" name="lead_generate_mandatory" id="lead_generate_mandatory1" value="1" <?php if($this->item->lead_generate_mandatory ==1) echo 'checked="checked"';?> />
							</label>
							<label for="lead_generate_mandatory0" id="lead_generate_mandatory0-lbl" class="radio"><?php echo JText::_( 'NO'); ?>
								<input type="radio" name="lead_generate_mandatory" id="lead_generate_mandatory0" value="0" <?php if($this->item->lead_generate_mandatory ==0) echo 'checked="checked"';?>/>
							</label>
						</fieldset>
					</td>
				</tr>
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_FIRST_NAME_BEFOR_PLAY_QUIZ_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_FIRST_NAME_BEFOR_PLAY_QUIZ');?></label></td>
					<td>
					
						<fieldset class="radio btn-group">
							<label for="input_first_name1" id="input_first_name1-lbl" class="radio" ><?php echo JText::_( 'SHOW'); ?>
								<input type="radio" name="input_first_name" id="input_first_name1" value="1" <?php if($this->item->input_first_name ==1) echo 'checked="checked"';?> />
							</label>
							<label for="input_first_name0" id="input_first_name0-lbl" class="radio"><?php echo JText::_( 'HIDE'); ?>
								<input type="radio" name="input_first_name" id="input_first_name0" value="0" <?php if($this->item->input_first_name ==0) echo 'checked="checked"';?>/>
							</label>
						</fieldset>
					</td>
				</tr>
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_LAST_NAME_BEFOR_PLAY_QUIZ_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_LAST_NAME_BEFOR_PLAY_QUIZ');?></label></td>
					<td>
					
						<fieldset class="radio btn-group">
							<label for="input_last_name1" id="input_last_name1-lbl" class="radio" ><?php echo JText::_( 'SHOW'); ?>
								<input type="radio" name="input_last_name" id="input_last_name1" value="1" <?php if($this->item->input_last_name ==1) echo 'checked="checked"';?> />
							</label>
							<label for="input_last_name0" id="input_last_name0-lbl" class="radio"><?php echo JText::_( 'HIDE'); ?>
								<input type="radio" name="input_last_name" id="input_last_name0" value="0" <?php if($this->item->input_last_name ==0) echo 'checked="checked"';?>/>
							</label>
						</fieldset>
					</td>
				</tr>
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_COMPANY_BEFOR_PLAY_QUIZ_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_COMPANY_BEFOR_PLAY_QUIZ');?></label></td>
					<td>
					
						<fieldset class="radio btn-group">
							<label for="input_company1" id="input_company1-lbl" class="radio" ><?php echo JText::_( 'SHOW'); ?>
								<input type="radio" name="input_company" id="input_company1" value="1" <?php if($this->item->input_company ==1) echo 'checked="checked"';?> />
							</label>
							<label for="input_company0" id="input_company0-lbl" class="radio"><?php echo JText::_( 'HIDE'); ?>
								<input type="radio" name="input_company" id="input_company0" value="0" <?php if($this->item->input_company ==0) echo 'checked="checked"';?>/>
							</label>
						</fieldset>
					</td>
				</tr>
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_TITLE_BEFOR_PLAY_QUIZ_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_TITLE_BEFOR_PLAY_QUIZ');?></label></td>
					<td>
					
						<fieldset class="radio btn-group">
							<label for="input_title1" id="input_title1-lbl" class="radio" ><?php echo JText::_( 'SHOW'); ?>
								<input type="radio" name="input_title" id="input_title1" value="1" <?php if($this->item->input_title ==1) echo 'checked="checked"';?> />
							</label>
							<label for="input_title0" id="input_title0-lbl" class="radio"><?php echo JText::_( 'HIDE'); ?>
								<input type="radio" name="input_title" id="input_title0" value="0" <?php if($this->item->input_title ==0) echo 'checked="checked"';?>/>
							</label>
						</fieldset>
					</td>
				</tr>
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_EMAIL_BEFOR_PLAY_QUIZ_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_EMAIL_BEFOR_PLAY_QUIZ');?></label></td>
					<td>
					
						<fieldset class="radio btn-group">
							<label for="input_email1" id="input_email1-lbl" class="radio" ><?php echo JText::_( 'SHOW'); ?>
								<input type="radio" name="input_email" id="input_email1" value="1" <?php if($this->item->input_email ==1) echo 'checked="checked"';?> />
							</label>
							<label for="input_email0" id="input_email0-lbl" class="radio"><?php echo JText::_( 'HIDE'); ?>
								<input type="radio" name="input_email" id="input_email0" value="0" <?php if($this->item->input_email ==0) echo 'checked="checked"';?>/>
							</label>
						</fieldset>
					</td>
				</tr>
				<tr>
					<td class="key"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_MOBILE_BEFOR_PLAY_QUIZ_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_QUIZZES_SHOW_MOBILE_BEFOR_PLAY_QUIZ');?></label></td>
					<td>
					
						<fieldset class="radio btn-group">
							<label for="input_mobile1" id="input_mobile1-lbl" class="radio" ><?php echo JText::_( 'SHOW'); ?>
								<input type="radio" name="input_mobile" id="input_mobile1" value="1" <?php if($this->item->input_mobile ==1) echo 'checked="checked"';?> />
							</label>
							<label for="input_mobile0" id="input_mobile0-lbl" class="radio"><?php echo JText::_( 'HIDE'); ?>
								<input type="radio" name="input_mobile" id="input_mobile0" value="0" <?php if($this->item->input_mobile ==0) echo 'checked="checked"';?>/>
							</label>
						</fieldset>
					</td>
				</tr>

			</table>
		</div>
		
		
		<!--Conditional Branching --->
		<div id="branching">
		
		<?php if($this->totalQuestion==0){?>
		
			<div class="alert alert-error" style="margin:10px;">
				<h4 class="alert-heading">Warning</h4>
				<div class="alert-message"><?php echo JText::_('COM_VQUIZ _BRANCHING_FIRST_CREATE_QUESTION') ?></div>
			</div>
			
		<?php } else {?>
		
			
			<a class="modal" id="add_rules" title="Select" href="<?php echo 'index.php?option=com_vquiz&view=quizmanager&layout=branching&tmpl=component&skip_enable='.$this->item->skip_button.'&quizid='.$this->item->id.'&quiztype='.$this->item->quiztype;?>" rel="{handler: 'iframe', size: {x: 1200, y: 600}}"></a>
			
			<p><input type="button" class="btn btn-success" value="<?php echo JText::_('COM_VQUIZ _BRANCHING_ADD_RULE')?>" id="add_rule"></a></p>
			
			
			
			<table class="adminform table table-striped" width="100%" id="add_rule_table">	
			
			<tr>
				<th align="middle"><?php echo JText::_('COM_VQUIZ _BRANCHING_RULE'); ?></th>
				<th align="middle"><?php echo JText::_('COM_VQUIZ _BRANCHING_VIEW'); ?></th>
				<th align="middle"><?php echo JText::_('COM_VQUIZ _REMOVE'); ?></th>
			</tr>
			
			<?php for($i=0;$i<count($this->branching_rule);$i++){ ?>
			<tr id="row_id<?php echo $i+1;?>">
			<td>
				
				<?php
					echo $this->branching_rule[$i]->apply_text ;
					$ruleid=$this->branching_rule[$i]->ruleid;
					$rule_questionid=$this->branching_rule[$i]->rule_questionid;
					$rule_optionid=$this->branching_rule[$i]->rule_optionid;
					$rule_questiontitle=$this->branching_rule[$i]->rule_questiontitle;
					$rule_weight=$this->branching_rule[$i]->rule_weight;
					$rule_weight_check=$this->branching_rule[$i]->rule_weight_check;
					$rule_scorepercentile=$this->branching_rule[$i]->rule_scorepercentile;
					$applyid=$this->branching_rule[$i]->applyid;
					$apply_questionid=$this->branching_rule[$i]->apply_questionid;
					$apply_weight=$this->branching_rule[$i]->apply_weight;
					$apply_weight_check=$this->branching_rule[$i]->apply_weight_check;
					$apply_questiontitle=$this->branching_rule[$i]->apply_questiontitle;
					$rule_wno_question=$this->branching_rule[$i]->rule_wno_question;
					$rule_specific_select=$this->branching_rule[$i]->rule_specific_select;
				?>
				<input type="hidden" value="<?php echo $this->branching_rule[$i]->apply_text;?>" name="apply_text[]">
				<input type="hidden" value="<?php echo $ruleid?>" name="branching_ruleid[]">
				<input type="hidden" value="<?php echo $rule_questiontitle?>" name="rule_questiontitle[]">
				<input type="hidden" value="<?php echo $rule_questionid?>" name="branching_rulequestionid[]">
				<input type="hidden" value="<?php echo $rule_optionid?>" name="branching_ruleoptionid[]">
				<input type="hidden" value="<?php echo $rule_weight?>" name="rule_weight[]">
				<input type="hidden" value="<?php echo $rule_weight_check?>" name="rule_weight_check[]">
				<input type="hidden" value="<?php echo $rule_scorepercentile?>" name="score_percentile[]">
				<input type="hidden" value="<?php echo $applyid?>" name="branching_applyid[]">
				<input type="hidden" value="<?php echo $apply_questionid?>" name="branching_applyquestionid[]">
				<input type="hidden" value="<?php echo $apply_weight?>" name="apply_weight[]">
				<input type="hidden" value="<?php echo $apply_weight_check?>" name="apply_weight_check[]">
				<input type="hidden" value="<?php echo $apply_questiontitle?>" name="apply_questiontitle[]">
				<input type="hidden" value="<?php echo $rule_specific_select;?>" name="rule_specific_select[]">
				<input type="hidden" value="<?php echo $rule_wno_question?>" name="rule_wno_question[]">
			</td>	
			
			<td>
			<?php 
			
			$add_parameters='index.php?option=com_vquiz&view=quizmanager&layout=branching&tmpl=component&b_ruleid='.$ruleid.'&b_rulequestionid='.$rule_questionid.'&b_ruleoptionid='.$rule_optionid.'&rule_weight='.$rule_weight.'&rule_weight_check='.$rule_weight_check.'&rule_question_title='.$rule_questiontitle.'&score_percentile='.$rule_scorepercentile.'&rule_wno_question='.$rule_wno_question.'&specific_sel='.$rule_specific_select.'&b_applyid='.$applyid.'&b_applyquestionid='.$apply_questionid.'&apply_question_title='.$apply_questiontitle.'&apply_weight='.$apply_weight.'&apply_weight_check='.$apply_weight_check.'&count_row='.($i+1).'&quizid='.$this->item->id.'&skip_enable='.$this->item->skip_button.'&quiztype='.$this->item->quiztype;
			
			?>
			<a class="modal" id="" title="" href="<?php echo $add_parameters;?>" rel="{handler: 'iframe', size: {x: 1200, y: 600}}" ><input type="button" class="btn btn-success" value="Edit/Views" id=""></a></td>
			
			<td valign="middle" align="center"><a href="javascript:void(0);" class="btn btn-danger remrule">-</a></td>
			
			</tr>
			<?php } ?>
			</table>
		
		<?php }?>
		</div>
		
		<!-- Question Group-->
		<div id="questiongroup">
		
		<table class="adminform table table-striped">
			<tr>
				<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_ENABLE_QUESTION_GROUP_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_ENABLE_QUESTION_GROUP');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="enable_questiongroup1" id="enable_questiongroup1-lbl" class="radio"><?php echo JText::_('YS'); ?></label>
					<input type="radio" name="enable_questiongroup" id="enable_questiongroup1" value="1" <?php if($this->item->enable_questiongroup ==1) echo 'checked="checked"';?>/>
					<label for="enable_questiongroup0" id="enable_questiongroup0-lbl" class="radio"><?php echo JText::_('NOS'); ?></label>
					<input type="radio" name="enable_questiongroup" id="enable_questiongroup0" value="0" <?php if($this->item->enable_questiongroup ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			
			<tr class="qgroup_rows">
				<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SHOW_QUESTION_GROUP_TITLE_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_SHOW_QUESTION_GROUP_TITLE');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="show_qgroup_title1" id="show_qgroup_title1-lbl" class="radio"><?php echo JText::_('SHOW'); ?></label>
					<input type="radio" name="show_qgroup_title" id="show_qgroup_title1" value="1" <?php if($this->item->show_qgroup_title ==1) echo 'checked="checked"';?>/>
					<label for="show_qgroup_title0" id="show_qgroup_title0-lbl" class="radio"><?php echo JText::_('HIDE'); ?></label>
					<input type="radio" name="show_qgroup_title" id="show_qgroup_title0" value="0" <?php if($this->item->show_qgroup_title ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
			
			<tr class="qgroup_rows">
				<td class="key" width="200"><label class="hasTip" title="<?php echo JText::_('COM_VQUIZ_SHOW_QUESTION_GROUP_DESCRIPTION_TOOLTIP');?>"><?php echo JText::_('COM_VQUIZ_SHOW_QUESTION_GROUP_DESCRIPTION');?></label></td>
				<td>
					<fieldset class="radio btn-group">
					<label for="show_qgroup_description1" id="show_qgroup_description1-lbl" class="radio"><?php echo JText::_('SHOW'); ?></label>
					<input type="radio" name="show_qgroup_description" id="show_qgroup_description1" value="1" <?php if($this->item->show_qgroup_description ==1) echo 'checked="checked"';?>/>
					<label for="show_qgroup_description0" id="show_qgroup_description0-lbl" class="radio"><?php echo JText::_('HIDE'); ?></label>
					<input type="radio" name="show_qgroup_description" id="show_qgroup_description0" value="0" <?php if($this->item->show_qgroup_description ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>
			</tr>
		</table>
		<br />
				<div class="question-group">
				
					<a  class="modal dynamic_group_modal_link"  href="<?php echo 'index.php?option=com_vquiz&view=quizmanager&layout=qgroup_messages&qorder=0&id='.$this->item->id.'&tmpl=component';?>'" rel="{handler: 'iframe', size: {x: 1000, y: 500}}"></a>
					
				<div class="selected_quizlist" id="questiongroup_desc">	
					<table class="adminform table table-striped" id="selected_quizlist_table">
						<thead><tr><th width="5"><input name="addquestiongroup" id="addquestiongroup" value="+" class="btn btn-success" type="button"></th><th><?php echo JText::_('COM_VQUIZ_QUESTION_GROUP');?></th><th><?php echo JText::_('COM_VQUIZ_QUESTION_GROUP_DESCRIPTION');?></th><th width="15"><?php echo JText::_('COM_VQUIZ_ORDERING');?></th><th width="25" id="qgroup_msg_heading"><?php echo JText::_("COM_VQUIZ_SETMESSAGES");?></th><th width="5"><?php echo JText::_("COM_VQUIZ_REMOVE");?></th></tr></thead>
						<tbody id="questiongruoup_body">
						
						<?php for($i=0;$i<count($this->questiongroup);$i++){?>
						<tr><td width="5"></td><td><input type="text" value="<?php echo $this->questiongroup[$i]->title;?>" name="questiongroup_title[]"/><input type="hidden" name="questiongroup_order[]" value="<?php echo $this->questiongroup[$i]->qorder;?>"/> </td><td><textarea rows="5" cols="5" name="questiongroup_description[]" class="group_desc"><?php echo $this->questiongroup[$i]->description;?></textarea></td><td><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-uparrow"></i></a></span><span><a class="btn btn-micro" href="javascript:void(0);"><i class="icon-downarrow"></i></a></span></td><td><span><a  class="modal btn" href="<?php echo 'index.php?option=com_vquiz&view=quizmanager&layout=qgroup_messages&qorder='.$this->questiongroup[$i]->qorder.'&id='.$this->item->id.'&tmpl=component';?>'" rel="{handler: 'iframe', size: {x: 1000, y: 500}}"><?php echo JText::_('COM_VQUIZ_SETMESSAGES_SETTING');?></a></span></td><td><span><a class="btn btn-danger btn-small" href="javascript:void(0);"><i class="icon-delete qgroup_canceal"></td></tr>
						
						<?php }?>
						
						</tbody>
					</table>
					
				</div>
			</div>
		</div>
		<!-- Permissions tab-->
		<div id="permissions">
		<div id="jform_title">
			<tr>
				<td>
						<?php echo $this->form->getInput('rules'); ?>
				</td>
			</tr>
		</div>
		</div>
 </div>    
</div> 
<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="quizmanager" />
<input type="hidden" name="p_category_c_count" id="personality_category_column_count" value="<?php if(!empty($this->personality_category->count_column)) echo $this->personality_category->count_column;?>" />
<input type="hidden" name="" id="count_branch_row" value="<?php echo count($this->branching_rule);?>" />

<?php 
if(!empty($this->personality_category->category)){
	$p_cat=json_decode($this->personality_category->category);
	$count_column =$this->personality_category->count_column>0?$this->personality_category->count_column:1;
	$personalitycategory=array_chunk($p_cat,$count_column);
}else{
	$personalitycategory=0;
}	
?>
<input type="hidden" name="p_category_r_count" id="p_category_r_count" value="<?php echo count($personalitycategory);?>"/>

</form>
