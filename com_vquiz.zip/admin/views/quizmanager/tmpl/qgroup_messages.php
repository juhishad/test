<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
$document = JFactory::getDocument();
JHTML::_('behavior.modal');
//$document->addScript('components/com_vquiz/assets/js/library.js');
$document->addStyleSheet(JURI::root().'/administrator/components/com_vquiz/assets/css/style.css');
$document->addScript(JURI::root().'/administrator/components/com_vquiz/assets/js/jquery-ui.js');
$document->addScript(JURI::root().'/media/editors/tinymce/tinymce.min.js');
$session=JFactory::getSession();
$app=JFactory::getApplication();
//echo 2;
?>
 <script>
  
  function  tinymce_init(){
	  
 	tinymce.init({
		  selector: "textarea",
		  relative_urls : false,
		 // menubar : false,
		  remove_script_host : true,
		  document_base_url :"<?php echo JURI::root();?>",
		  plugins: [
			  "advlist autolink lists link image charmap print preview anchor",
			  "searchreplace visualblocks code fullscreen",
			  "insertdatetime media table contextmenu paste"
		  ],
		  toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image"
	  });
  }
	
tinymce_init();
	
	var jq=jQuery.noConflict();
	
    jq(document).ready(function() {
 		
		var max_fields      = 20;  
		var wrapper         = jq(".input_fields_wrap");  
		var add_button      = jq(".add_field_button");  
		
		var x = 0;  
		jq(add_button).click(function(e){
			e.preventDefault();
			x=parseInt(jq(".count_row").val());
			if(x < max_fields){  
				x++; 

				    var html ='<tr><td><input type="text" name="qgroup_score[]" class="score_range" value="" /></td>';
					
					html +='<td><input type="text" name="qgroup_rating[]" class="score_range" value="" /></td>';	
					
					html +='<td><textarea class="" rows="5" cols="5"  name="qgroup_message[]" class="message"></textarea></td>';
					html +='<td>';
					
					
					html +='<select name="qgroup_article_id[]">';
					html +='<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_MENUITEM');?></option>';
					<?php for($b=0;$b<count($this->menuItems);$b++){?>
						html +='<option value="<?php echo $this->menuItems[$b]->id; ?>"><?php echo addslashes($this->menuItems[$b]->title); ?></option>';
					<?php }?>
					html +='</select>';
					html +='</td>';
					html +='<td><a href="javascript:void(0);" class="remove_field btn btn-danger">-</a></td></tr>';
					
	
					jq(wrapper).append(html);
					
					SqueezeBox.assign(jq('a.modal').get(), {
						parse: 'rel'
					});
					
					tinymce_init();
					
					jq(".count_row").val(x);
	 
			}
		}); 
		
	
		
		jq(wrapper).on("click",".remove_field", function(e){  
			e.preventDefault();
			jq(this).parent().parent().remove();
			x--;
			jq(".count_row").val(x);
			//tinymce_init();
		})
		
		
		jq('.modal').on("click", function(e){ 
			currten_id=jq(this).attr('currten_id');
			jq('#currten_id').val(currten_id);
		});
			
		jq(document).on("click",".reset", function(e){  
				currten_id=jq(this).attr('currten_id');
				jq('#jform_request_id_id'+currten_id).val('');
				jq('#jform_request_id_name'+currten_id).val('<?php echo JText::_('COM_VQUIZ_SELECT_AN_ARTICLE')?>');
		});
		   
	 
		});
		
		var currten_id=jq('#currten_id').val();
 
		function myFunction(currten_id) {
			currten_id=currten_id;
			jq('#currten_id').val(currten_id);
		}

		function jSelectArticle_jform_request_id(id, title, object){
			var currten_id=jQuery('#currten_id').val();
			jQuery('#jform_request_id_id'+currten_id).val(id);
			jQuery('#jform_request_id_name'+currten_id).val(title);
			SqueezeBox.close();
		}
		

    </script>
	
<div id="toolbar" class="btn-toolbar">

	<div id="toolbar-apply" class="btn-wrapper">
		<button class="btn btn-small btn-success" onclick="Joomla.submitbutton('qgroup_message')">
		<span class="icon-apply icon-white"></span><?php echo JText::_('COM_VQUIZ_SAVE')?></button>
	</div>

</div>

<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<div class="cpanel-left">
<fieldset class="adminform">
	
		<label style="float:right">
			<input type="button" class="btn btn-success add_field_button" value="+">
		</label>
		
		<label><?php echo JText::_('COM_VQUIZ_QUIZZES_QGROUP_MESSAGE'); ?></label>	   
		
		<legend></legend>

		<table class="adminlist table table-striped table-hover message_table group_message_table">
			<thead>
				<tr>
				<th><label><?php echo JText::_('COM_VQUIZ_QUIZZES_SCORE_UPTO') ?></label></th>
				<th><label><?php echo JText::_('COM_VQUIZ_QUIZZES_RATING') ?></label></th>
				
				<th><label><?php echo JText::_('COM_VQUIZ_MESSAGE') ?></label></th>
				<th><label><?php echo JText::_('COM_VQUIZ_QUIZZES_MENU_ITEM') ?></label></th>
				</tr>
			</thead>
	
 
		<tbody class="input_fields_wrap">

			<?php 
			if(!empty($this->qgroup_messages)){?>
				
			<input type="hidden" class="count_row" value="<?php echo count($this->qgroup_messages); ?>">
			<?php for($i=0;$i<count($this->qgroup_messages);$i++){
			?>
			<tr>
			<td><input type="text" name="qgroup_score[]" class="score_range" value="<?php echo $this->qgroup_messages[$i]->score?>" /></td>
			
			<td><input type="text" name="qgroup_rating[]" class="score_range" value="<?php echo $this->qgroup_messages[$i]->rating?>" /></td>
			
			<td><textarea rows="5" cols="5"  name="qgroup_message[]" class="message"><?php echo $this->qgroup_messages[$i]->message?></textarea></td>

				<td class="">	
				
					<select  name="qgroup_article_id[]>" >
						<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_MENUITEM');?></option>
						<?php for($b=0;$b<count($this->menuItems);$b++){?>
							<option value="<?php echo $this->menuItems[$b]->id; ?>" <?php if($this->qgroup_messages[$i]->article_id==$this->menuItems[$b]->id) echo "selected='selected';"?>><?php echo $this->menuItems[$b]->title; ?></option>
						<?php }?>
					</select>
				
				</td>
				
				<td valign="middle" align="center">
					<a href="javascript:void(0);" class="remove_field btn btn-danger">-</a>
				</td>
			</tr>
			
			<?php }
			
			} elseif($session->has('qgroup_message_session')){
				//print_r($session->get('qgroup_message_session'));
			$qgroup_messagescore=$session->get('qgroup_message_session');
			$qgroup_score=$qgroup_messagescore['qgroup_score'][0];
			$qgroup_message=$qgroup_messagescore['qgroup_message'][0];
			$qgroup_article_id=$qgroup_messagescore['qgroup_article_id'][0];
			$qgroup_rating=$qgroup_messagescore['qgroup_rating'][0];
			
			
			for($i=0;$i<count($qgroup_message);$i++){ 
				if(!empty($qgroup_message[$i])){?>
				<tr>
					<td>
					<input type="text" name="qgroup_score[]" class="score_range" value="<?php echo $qgroup_score[$i];?>" />
					</td>
					<td><input type="text" name="qgroup_rating[]" class="score_range" value="<?php echo $qgroup_rating[$i]?>" /></td>
			
					
			
					<td>
					<textarea rows="5" cols="5"  name="qgroup_message[]" class="message"><?php echo $qgroup_message[$i];?></textarea>
					</td>

					<td class="">
					
					<select  name="qgroup_article_id[]>" >
						<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_MENUITEM');?></option>
						<?php for($b=0;$b<count($this->menuItems);$b++){?>
							<option value="<?php echo $this->menuItems[$b]->id; ?>" <?php if($qgroup_article_id[$i]==$this->menuItems[$b]->id) echo "selected='selected';"?> ><?php echo addslashes($this->menuItems[$b]->title); ?></option>
						<?php }?>
					</select>
					
					</td>
					
					<td valign="middle" align="center">
						<a href="javascript:void(0);" class="remove_field btn btn-danger">-</a>
					</td>
				</tr>
			<?php }}?>
			
			<?php } else {?>
				<input type="hidden" class="count_row" value="0">
			<?php }?>
			</tbody>
			</table>

    </fieldset>
 
</div>
   
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="quizmanager" />
<input type="hidden" name="quizid" value="<?php echo $app->input->get('id',0)?>" />
<input type="hidden" name="qorder" value="<?php echo $app->input->get('qorder',0)?>" id="qorder" />
</form>