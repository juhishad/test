<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access'); 
JHtml::_('behavior.framework');	
JHtml::_('behavior.tooltip');
JHTML::_('behavior.modal');

$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$document->addStyleSheet('components/com_vquiz/assets/css/popup.css');
//$document->addScript('components/com_vquiz/assets/js/library.js');
$document->addScript('components/com_vquiz/assets/js/popup.js');

$function = JFactory::getApplication()->input->getCmd('function', 'jSelectQuizzes');
$from_userview=JRequest::getInt('from_userview',0);

if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');
$user = JFactory::getUser();
$listOrder = $this->lists['order']; 
$listDirn = $this->lists['order_Dir'];
$canOrder	= $user->authorise('core.edit.state', 'com_vquiz.quizmanager');
$saveOrder	= $listOrder == 'ordering';
$saveOrder 	= ($listOrder == 'ordering' && strtolower($listDirn) == 'asc');
$quizid_from_chart=JRequest::getInt('quid',0);
$selected_userquiz=JRequest::getVar('selected_userquiz',0);
$selected_lpath_userquiz=JRequest::getVar('selected_lpath_userquiz',0);// FROM LEARNING PATH

//get cat id and find quizzes to disable them
$selected_usercategory = JRequest::getVar('selected_usercategory',0); // FROM RESULT MONITOR
$selected_user_category_quiz=QuizHelper::find_quizzes($selected_usercategory); 

$tmpl=JRequest::getVar('tmpl', 'index');
$script = array();
$script[] = " jQuery(function($){";
$script[] = " var selected_user='$selected_userquiz'.split(',')";
$script[] = " var selected_lpath_userquiz='$selected_lpath_userquiz'.split(',')";  
$script[] = " var selected_user_category_quiz='$selected_user_category_quiz'.split(',')";
$script[] = " jQuery('#select_chk').click(function () {";
$script[] = " var ids=[]"; 
$script[] = " var title=[]"; 
$script[] = " $('input[type=checkbox]:checked').each(function(){";
$script[] = " ids.push($(this).val());";
$script[] = " title.push( $.trim($(this).closest('td').next('td').text()));";
$script[] = " });";
$script[] = " if(ids==''){ alert('Please Select Quiz')}else{";
$script[] = " if (window.parent) window.parent.jSelectQuizzes_jform_request_id(ids,title,null);";
$script[] = " }});";
$script[] = " $('input[type=checkbox]').each(function(){";

$script[] = " if(jQuery.inArray($(this).val(),selected_user)!== -1){";
$script[] = " if($(this).val()!='') this.checked = true;}";

$script[] = " if(jQuery.inArray($(this).val(),selected_lpath_userquiz)!== -1){";
$script[] = " if($(this).val()!='') this.disabled = true;}";

$script[] = " if(jQuery.inArray($(this).val(),selected_user_category_quiz)!== -1){";
$script[] = " if($(this).val()!='') this.checked = true;}"; //this.disabled = true;

$script[] = " });";
$script[] = " });";
JFactory::getDocument()->addScriptDeclaration(implode("\n", $script));

?>
<script type="text/javascript">
var jq=jQuery.noConflict();
jq( document ).ready(function() {
	if(<?php echo $quizid_from_chart?>){
		jQuery('input[name="search"]').val(<?php echo $quizid_from_chart;?>);
		document.adminForm.submit();
	}
});

Joomla.submitbutton = function(task) {
			var x=jQuery('#quizcsv').val();	

			if (task == 'cancel') {
			Joomla.submitform(task, document.getElementById('adminForm'));
			} 
			else if(task=='import') {
				lightbox_import();
				var form = document.adminForm;
				if(x == "")  {
				alert("<?php echo JText::_('COM_VQUIZ_PLZ_CHOSE_CSV'); ?>");
				return false;
				}	
			}

			  else if(task=='export') {
				var form = document.adminForm;
				if (document.adminForm.boxchecked.value==0)  {
				alert("<?php echo JText::_('COM_VQUIZ_PLZ_CHOOSE_QUIZ'); ?>");
				return false;
				}
			}
			
			else if(task=='copy') {
			var form = document.adminForm;
			if (document.adminForm.boxchecked.value==0)  {
			alert("<?php echo JText::_('COM_VQUIZ_PLZ_MAKE_SELECTION'); ?>");
			return false;
			}
			else{
			lightbox_copy();
			return false;
			}
		}
			else if(task=='move') {
			var form = document.adminForm;
			if (document.adminForm.boxchecked.value==0)  {
			alert("<?php echo JText::_('COM_VQUIZ_PLZ_MAKE_SELECTION'); ?>");
			return false;
			}
			else{
			lightbox_move();
			return false;
			}
			
		}
		Joomla.submitform(task, document.getElementById('adminForm'));
			
}
</script>
<?php jimport( 'joomla.html.pagination');	?>
<form action="index.php?option=com_vquiz&view=quizmanager" method="post" name="adminForm" id="adminForm"  enctype="multipart/form-data">

	<?php if($tmpl!='component'){?>
		<?php if (!empty( $this->sidebar)) : ?>   
			<div id="j-sidebar-container" class="span2">
			<?php echo $this->sidebar; ?>
			</div>
			<div id="j-main-container" class="span10">
			<?php else : ?>
			<div id="j-main-container">
			<?php endif;?>
			<div class="clr" style="clear:both;"></div>		

	<?php } ?>
	
	<?php /* <a href="#" id="select_chk" onclick="if (window.parent) window.parent.<?php echo $this->escape($function);?>('','',null);">select</a> */?>
	
	<legend class="pull-left"><?php echo JText::_('COM_VQUIZ_QUIZZES'); ?></legend>
	<?php if($tmpl=='component'){?>	
		<div style="margin: 10px 0;"><a href="#" id="select_chk" class="btn btn-small btn-primary d-inline-block"><?php echo JText::_('COM_VQUIZ_SELECT_ALL_SELECTED');?></a></div>
	<?php } ?>
		
				
 
			<div class="clr" style="clear:both;"></div>	
			<div class="search_buttons">
				<div class="btn-wrapper input-append">
				<input placeholder="Search" type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
				<button class="btn" onclick="this.form.submit();"><i class="icon-search"></i><span class="search_text"><?php echo JText::_('COM_VQUIZ_SEARCH'); ?></button>
				<button class="btn" onclick="document.getElementById('search').value='';this.form.submit();"><?php echo JText::_('COM_VQUIZ_RESET'); ?></button>
				</div>
			</div>
			
			<select name="categorysearch" id="categorysearch" class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('COM_VQUIZ_ALL_CATEGORY'); ?></option>
				<?php    for ($i=0; $i <count($this->category); $i++)	
				{
				?>
				<option value="<?php echo $this->category[$i]->id;?>"  <?php  if($this->category[$i]->id == $this->lists['categorysearch']) echo 'selected="selected"'; ?> ><?php echo $this->category[$i]->title;?></option>		
				<?php
				}
				?>
				</select>
             <input type="hidden" name="qcategoryid" id="qcategoryid" value="" class="text_area" onchange="document.adminForm.submit();" />
             
				<select name="publish_item" id="publish_item"class="inputbox" onchange="this.form.submit()">
				<option value=""><?php echo JText::_('COM_VQUIZ_ALL_STATE');?></option>
				<option value="p" <?php  if( 'p'== $this->lists['publish_item']) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PUBLISHED');?></option>
				<option value="u" <?php  if('u'== $this->lists['publish_item']) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_UNPUBLISHED');?></option>
				</select>
				
			<div class="btn-group pull-right hidden-phone">
				<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
				<?php echo $this->pagination->getLimitBox(); ?>
			</div>
            
			
<div id="editcell">
	<table class="adminlist table table-striped table-hover">
	<thead>
		<tr>
			<th width="5">
				<?php echo JText::_('COM_VQUIZ_NUM'); ?>
			</th>
			<th width="20">
			<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
			</th>			
			<th>
                <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_TITLE', 'i.title', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			<th class="center">
                <?php echo JTEXT::_('COM_VQUIZ_PREVIEW'); ?>
			</th>
            <th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_CATEGORY', 'q.title', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
             <th  >
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_TYPE', 'i.quiztype', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>

			</th>
			
             <th width="10%" class="center">
            
            <?php echo JHTML::_('grid.sort', 'JGRID_HEADING_ORDERING', 'ordering', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
            
            <?php if ($canOrder && $saveOrder) :?>
            
            <?php echo JHtml::_('grid.order',  $this->items, 'filesave.png', 'saveorder'); ?>
            
            <?php endif; ?>
            
            </th>

            <th class="center">
            
            <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_QUESTIONS', 'totalquestion', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
 
			</th>

		    	<th class="center">

				<?php echo JText::_( 'COM_VQUIZ_PUBLISHED' ); ?>

			</th>
              <th class="center">
                   <?php echo JText::_( 'COM_VQUIZ_FEATURED' ); ?>
			</th>
            
			<th class="center">
			 <?php echo JText::_( 'COM_VQUIZ_STATISTICS' ); ?>
			</th>
                
            <th width="5">
           
            <?php echo JHTML::_('grid.sort', 'ID', 'i.id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
            </th>

			</th>
		</tr>

	</thead>
    
    

	<?php

	$k = 0;

	for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{

		$row = &$this->items[$i]; //print_r($row); echo "<br/>";
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
 
		$published    = JHTML::_( 'jgrid.published', $row->published, $i );
		$link 		= JRoute::_( 'index.php?option=com_vquiz&view=quizmanager&task=edit&id='.$row->id.'&cid[]='. $row->id );
		
		if($row->access_token<>""){
			$preview = ' <a class="btn btn-micro active hasTooltip" target="_blank" href="'.JURI::root( true ).'/index.php?option=com_vquiz&view=quizmanager&layout=description&id='.$row->id.'&access='.$row->access_token.'"><i class="icon-eye"></i></a>'; 
		}else{
			$preview = ' <a class="btn btn-micro active hasTooltip" target="_blank" href="'.JURI::root( true ).'/index.php?option=com_vquiz&view=quizmanager&layout=description&id='.$row->id.'"><i class="icon-eye"></i></a>'; 
		}
			$ordering	= ($listOrder == 'ordering');
			$canCreate	= $user->authorise('core.create',		'com_vquiz.quizmanager.'.$row->id);
			$canEdit	= $user->authorise('core.edit',			'com_vquiz.quizmanager.'.$row->id);
			$canCheckin	= true;//$user->authorise('core.manage',		'com_checkin') || $row->checked_out == $user->get('id') || $row->checked_out == 0;
			$canEditOwn	= true; //$user->authorise('core.edit.own',		'com_djimageslider.category.'.$item->catid) && $item->created_by == $userId;
			$canChange	= $user->authorise('core.edit.state',	'com_vquiz.quizmanager.'.$row->id) && $canCheckin;

		?> 

		<tr class="<?php echo "row$k"; ?>">

         <td><?php echo $this->pagination->getRowOffset($i); ?></td>
			<td>
				<?php echo $checked; ?>
			</td>

			<td>
				<?php if($tmpl=='component'){?>
					<?php echo substr($row->title,0,50); ?>
				<?php }else{?>
					<a href="<?php echo $link; ?>" onclick="if (window.parent) window.parent.<?php echo $this->escape($function);?>('<?php echo $row->id; ?>','<?php echo $this->escape(addslashes($row->title)); ?>',null);"><?php echo substr($row->title,0,50); ?></a>
				<?php }?>
				
			</td> 
			
			<td class="center">
				<?php echo $preview; ?>
			</td>

            <td>
				 <?php echo $row->categoryname; ?> 
			</td> 
			 <td>
				 <?php if($row->quiztype==1) 
                        echo JText::_('COM_VQUIZ_TRIVIA');
					else if($row->quiztype==11)
                        echo JText::_('COM_VQUIZ_SIMULATION_QUIZ');					
                    else if($row->quiztype==2)
                        echo JText::_('COM_VQUIZ_PERSONALITY');
					else if($row->quiztype==22)
                        echo JText::_('COM_VQUIZ_MULTI_CATEGORY_PERSONALITY_QUIZ');
                    else if($row->quiztype==3)
					echo JText::_('COM_VQUIZ_SURVEY'); 
                    else echo JText::_('ELECTION'); 
				 ?> 
			</td> 
            
            <td class="order center" nowrap="nowrap">
					<?php if ($canChange) : ?>
						<?php if ($saveOrder) :?>
							<?php if ($listDirn == 'asc') : ?>
								<span><?php echo $this->pagination->orderUpIcon($i, (@$item->catid == @$this->items[$i-1]->catid),'orderup', 'JLIB_HTML_MOVE_UP', $ordering); ?></span>
								<span><?php echo $this->pagination->orderDownIcon($i, $n, (@$item->catid == @$this->items[$i+1]->catid), 'orderdown', 'JLIB_HTML_MOVE_DOWN', $ordering); ?></span>
							<?php elseif ($listDirn == 'desc') : ?>
								<span><?php echo $this->pagination->orderUpIcon($i, (@$item->catid == @$this->items[$i-1]->catid),'quizmanager.orderdown', 'JLIB_HTML_MOVE_UP', $ordering); ?></span>
								<span><?php echo $this->pagination->orderDownIcon($i, $n, (@$item->catid == @$this->items[$i+1]->catid), 'quizmanager.orderup', 'JLIB_HTML_MOVE_DOWN', $ordering); ?></span>
							<?php endif; ?>
						<?php endif; ?>
						<?php $disabled = $saveOrder ?  '' : 'disabled="disabled"'; ?>

						<input  style="width:20px;" type="text" name="order[]" size="5" value="<?php echo $row->ordering;?>" <?php echo $disabled ?> class="text-area-order input-mini" />

					<?php else : ?>

						<?php echo $row->ordering; ?>

					<?php endif; ?>

				</td>
 
            <td class="center">
			 <?php if($tmpl!='component'){?>
				<a href="index.php?option=com_vquiz&view=quizquestion&quizid=<?php echo $row->id; ?>">
				<input class="btn btn-small" type="button" value="<?php echo JText::_('COM_VQUIZ_VIEW')?>(<?php echo $row->totalquestion; ?>)" />
				 </a>
			 <?php } else  echo $row->totalquestion;?>
			</td> 

			<td class="center publish_unpublish">
				<?php if($tmpl!='component' and JFactory::getUser()->authorise('core.edit.state','com_vquiz')){echo $published;}else{
					echo $row->published==1?JText::_('COM_VQUIZ_PUBLISHED'):JText::_('COM_VQUIZ_UNPUBLISHED');
				}?>
			</td>
            <td class="center featured_unfeatured"> 
            
			<?php 
			if($tmpl!='component' and JFactory::getUser()->authorise('core.edit.state','com_vquiz')){
				if($row->featured==1) {?>
				<a class="btn btn-micro active hasTooltip" title="Unfeatured Item" onclick="return listItemTask('cb<?php echo $i; ?>','unfeatured')" href="javascript:void(0);" data-original-title="featured Item">
				<i class="icon-featured"></i>
				</a>
				<?php } else  {?>
				<a class="btn btn-micro active hasTooltip" title="Featured Item" onclick="return listItemTask('cb<?php echo $i; ?>','featured')" href="javascript:void(0);" data-original-title="unfeatured Item">
				<i class="icon-unfeatured"></i>
				</a>
				<?php }
				
			}else{
				echo $row->featured==1?'<i class="icon-featured"></i>':'<i class="icon-unfeatured"></i>';
			}?>
            
            </td>
            <td>
            <?php if($tmpl!='component'){?>
				<a class="modal" id="modal" title="" href="<?php echo 'index.php?option=com_vquiz&view=quizmanager&layout=chartview&tmpl=component&chart='.$row->quiztype.'&quizid='.$row->id;?>" rel="{handler: 'iframe', size: {x: 950, y: 600}}"><input class="btn btn-small" type="button" value="<?php echo JText::_('COM_VQUIZ_VIEW')?>" /></a>
			<?php }?>
            </td>
 
            <td>
				<?php echo $row->id; ?>
			</td>

		</tr>

		<?php

		$k = 1 - $k;

	}

	?>
<tfoot>
        <tr>
        <td colspan="11"><?php echo $this->pagination->getListFooter(); ?></td>
        </tr>
        </tfoot>
	</table>
    
        


</div>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="quizmanager" />
<input type="hidden" name="selected_usercategory" value="<?php echo JRequest::getVar('selected_usercategory', 0); ?>" />
<input type="hidden" name="selected_userquiz" value="<?php echo JRequest::getVar('selected_userquiz', 0); ?>" />
<input type="hidden" name="selected_lpath_userquiz" value="<?php echo JRequest::getVar('selected_lpath_userquiz', 0); ?>" />
<input type="hidden" name="tmpl" value="<?php echo JRequest::getVar('tmpl', 'index'); ?>" />
<input type="hidden" name="function" value="<?php echo JRequest::getVar('function', ''); ?>" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />

 
<div id="light_import">
<a href="javascript:void(0);"  onclick="lightbox_close();" class="closepop"><?php echo JText::_('X')?></a>
	<div style="text-align:center;">
    <p><input type="file" name="quizcsv" id="quizcsv"></p>
    <p> <input type="button" value="<?php echo JText::_('COM_VQUIZ_IMPORT')?>" name="submitcsv" id="submitcsv" onclick="Joomla.submitform('import');"></p>
    </div>
</div>

<div id="light_move">
<a href="javascript:void(0);"  onclick="lightbox_close2();" class="closepop"><?php echo JText::_('X'); ?></a>
    <div style="text-align:center;">
     <p><?php echo JText::_('COM_VQUIZ_SELECT_CATEGORY'); ?></p>
      <p><select name="quizcategoryidmove" >
                <?php    for ($i=0; $i <count($this->category); $i++)	
                {
                ?>
                <option value="<?php echo $this->category[$i]->id;?>"  <?php  if($this->category[$i]->id == !empty($this->item->quiz_categoryid)?$this->item->quiz_categoryid:0) echo 'selected="selected"'; ?> ><?php echo $this->category[$i]->title;?></option>		
                <?php
                }
                ?>
                </select>
                </p>
                <p> <input type="button" value="Move" name="move"  class="btn btn-small" onclick="Joomla.submitform('movequestion');"></p>
      </div>          
</div>

	<div id="light_copy">
	<a href="javascript:void(0);"  onclick="lightbox_close2();" class="closepop"><?php echo JText::_('X'); ?></a>
		<div style="text-align:center;">
	<p><?php echo JText::_('COM_VQUIZ_SELECT_CATEGORY'); ?></p>
	  <p><select name="quizcategoryidcopy">
				   <?php/* <option value=""><?php echo JText::_('---Select---'); ?></option>*/?>
					<?php    for ($i=0; $i <count($this->category); $i++)	
					{
					?>
					<option value="<?php echo $this->category[$i]->id;?>"  <?php  if($this->category[$i]->id == !empty($this->item->quiz_categoryid)?$this->item->quiz_categoryid:0) echo 'selected="selected"'; ?> ><?php echo $this->category[$i]->title;?></option>		
					<?php
					}
					?>
					</select>
				</p>
				<p> <input type="button" value="Copy" name="copy" class="btn btn-small"  onclick="Joomla.submitform('copyquestion');"></p>
	  </div>          
	</div>

	<div id="fade" onClick="lightbox_close2();"></div> 
	
</form>
</div>


