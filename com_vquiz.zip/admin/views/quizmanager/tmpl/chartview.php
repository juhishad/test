<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.framework');
JHtml::_('behavior.tooltip');
JHTML::_('behavior.modal');

$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
//$document->addScript('components/com_vquiz/assets/js/library.js');
//$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');
//$document->addScript('components/com_vquiz/assets/js/googlemap.js');
$quizzesid = JRequest::getInt('quizzesid');
$chart = JRequest::getInt('chart');
?>
<script type="text/javascript" 
src="https://www.google.com/jsapi?autoload={'modules':[{'name':'visualization','version':'1','packages':['corechart'],'language':'ru'}]}">
</script>
   
 <script type="text/javascript">
    
jQuery(function(){
	
    if(typeof google !== "undefined"){   
	    google.setOnLoadCallback(drawChart);		
	}
	
	function mouseEventHandler(event)  {
		document.getElementById('chart').innerHTML += "You clicked " + event.region + "<br/>";
	}

    
    function drawChart() 
	{
		var quizzesid = jQuery('input[name="quizzesid"]').val();
		var chart = jQuery('input[name="chart"]').val();
		
		
		jQuery.ajax(
		{
			url: "index.php",
			type: "POST",
			dataType:"json",
			data: {'option':'com_vquiz','view':'quizmanager', 'task':'drawChart','quizzesid':quizzesid,'charttype':chart,'tmpl':'component',"<?php echo JSession::getFormToken(); ?>":1},
			beforeSend: function()	{
				jQuery(".poploadingbox").show();
			},
			complete: function()	{
				jQuery(".poploadingbox").hide();
			},
			
			success: function(data)	
			{ 
				if(data.result == "success")
				{
			
					var responce1=data.responce1;
					var responce2=data.responce2;
					var charttype=data.charttype;
					
					var data = new Array();
						
					data[0] = ['<?php echo JText::_('COM_VQUIZ_SCORE'); ?>', '<?php echo JText::_('COM_VQUIZ_NUMBER_OF_USERS'); ?>', {role: 'style'}];
					for(var j=0;j<responce1.length;j++)	{
					data[j+(1)] = new Array();
					data[j+(1)][0] = String(responce1[j][0]);
					data[j+(1)][1] = Number(responce1[j][1]);
					data[j+(1)][2] = 'color: #0000ff';
					}
					var data = google.visualization.arrayToDataTable(data);
					var view = new google.visualization.DataView(data);
					view.setColumns([0, {
						type: 'number',
						label: data.getColumnLabel(1),
						calc: function () {return 0;}
					}]);

					var options =  
					{
					title: '',
					hAxis: {title: '<?php echo JText::_('COM_VQUIZ_SCORES'); ?>', titleTextStyle: {color: 'red'}},
					height:300,
					animation: { duration: 1500, easing:'out'}
					};
					
					if(charttype!=3){
					
					
						
						if(charttype==2)
							var chart = new google.visualization.PieChart(document.getElementById('chart1'));
						else
							var chart = new google.visualization.ColumnChart(document.getElementById('chart1'));
						
						function errorHandler(errorMessage) {
							console.log(errorMessage);
							google.visualization.errors.removeError(errorMessage.id);
						}
						google.visualization.events.addListener(chart, 'error', errorHandler);
						
						chart.draw(data, options);
						if(responce1.length==0){
							jQuery('#chart1').html('No-data');
						}
					}


					<!--Respoce-2--->							 
					var data = google.visualization.arrayToDataTable(responce2);
					 var options = {
						width: 800,
						//height: 1000,
						title: '<?php echo JText::_('COM_VQUIZ_QUIZMANAGER_CHOOSED_OPTION_BY_USER'); ?>',
						hAxis: {title: '<?php echo JText::_('COM_VQUIZ_USERS'); ?>', titleTextStyle: {color: 'red'},gridlines:{color: '#FFFFF', count: 0}},
						vAxis: {title: '<?php echo JText::_('COM_VQUIZ_QUESTIONS'); ?>',titleTextStyle: {color: 'red'}},
						
						//chartArea: {width: '60%',height:'100%'},
						legend: {position: 'top',textStyle: {color: 'blue', fontSize: 16}, maxLines: 5 },
						bar: { groupWidth: '100%' },
						isStacked: true
					}; 
					var chart = new google.visualization.BarChart(document.getElementById("chart2"));
					function errorHandler(errorMessage) {
					console.log(errorMessage);
					google.visualization.errors.removeError(errorMessage.id);
					}
					google.visualization.events.addListener(chart, 'error', errorHandler);
					chart.draw(data, options);
 						
				 }
 
			}
		});
    }
	
});
</script>
 

<div class="poploadingbox">
<?php echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/loading.gif"   />' ?>
</div>

	<div class="cpanel-left">
	
	<?php if($chart==1 OR $chart==2) {?>	
        <div class="chart1">
        <h3>
		
		<?php
			if($chart==1)
				echo JText::_('COM_VQUIZ_USER_PLAYED_CHART');
			else
				echo JText::_('COM_VQUIZ_QUIZZES_MOST_SELECTED_PERSONALITY');

			?>
			</h3>
        <div id="chart1"></div>
        </div>
	<?php }?>
	
	<h3><?php echo JText::_('COM_VQUIZ_MOST_OPTION_CHOOSED')?></h3>
	<div class="chart2" style="text-align:center">
		<div id="chart2" style="display:inline-block;height:500px;position:relative;" ></div>
	</div>
	
   </div>
   
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="quizmanager" />
<input type="hidden" name="quizzesid" value="<?php echo $quizzesid; ?>" />
<input type="hidden" name="chart" value="<?php echo $chart; ?>" />
