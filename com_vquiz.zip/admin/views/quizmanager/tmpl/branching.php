<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHtml::_('behavior.framework');
JHtml::_('behavior.tooltip');
JHTML::_('behavior.modal');

$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$quizzesid=JRequest::getInt('quizid',0);
$quiztype=JRequest::getInt('quiztype',0);
$count_row=addslashes(JRequest::getVar('count_row',''));
$skip_enable=JRequest::getInt('skip_enable',0);

$b_ruleid=JRequest::getInt('b_ruleid',0);
$b_rulequestionid=JRequest::getInt('b_rulequestionid',0);
$b_rule_title=addslashes(JRequest::getVar('rule_question_title',JText::_('COM_VQUIZ_SELECT')));
$b_ruleoptionid=JRequest::getInt('b_ruleoptionid',0);
$rule_weight=JRequest::getInt('rule_weight',0);
$rule_weight_check=JRequest::getInt('rule_weight_check',0);
$score_percentile=JRequest::getInt('score_percentile',0);
$specific_sel=JRequest::getInt('specific_sel',0);
$rule_wno_question=JRequest::getInt('rule_wno_question',0);

$b_apply_title=addslashes(JRequest::getVar('apply_question_title',JText::_('COM_VQUIZ_SELECT')));
$b_applyid=JRequest::getInt('b_applyid',0);
$b_applyquestionid=JRequest::getInt('b_applyquestionid',0);
$apply_weight=JRequest::getInt('apply_weight',0);
$apply_weight_check=JRequest::getInt('apply_weight_check',0);
 
if($b_ruleid==1)
	$b_ruleid_1='selected="selected"';
else
	$b_ruleid_1='';
	if($b_ruleid==2)
	$b_ruleid_2='selected="selected"';
else
	$b_ruleid_2='';
if($b_ruleid==3)
	$b_ruleid_3='selected="selected"';
else
	$b_ruleid_3='';
if($b_ruleid==4)
	$b_ruleid_4='selected="selected"';
else
	$b_ruleid_4='';
if($b_ruleid==5)
	$b_ruleid_5='selected="selected"';
else
	$b_ruleid_5='';
if($b_ruleid==6)
	$b_ruleid_6='selected="selected"';
else
	$b_ruleid_6='';


if($b_applyid==1)
	$b_applyid_1='selected="selected"';
else
	$b_applyid_1='';
if($b_applyid==2)
	$b_applyid_2='selected="selected"';
else
	$b_applyid_2='';
if($b_applyid==3)
	$b_applyid_3='selected="selected"';
else
	$b_applyid_3='';
if($b_applyid==4)
	$b_applyid_4='selected="selected"';
else
	$b_applyid_4='';
if($b_applyid==5)
	$b_applyid_5='selected="selected"';
else
	$b_applyid_5='';
 

	$rules_select='<select name="ruleid" class="branching_rule" id="branching_rule">';
	$rules_select .='<option value="0">'.JText::_('COM_VQUIZ_SELECT').'</option>';
	if($quiztype==1 OR $quiztype==11 OR $quiztype==0){
		$rules_select .='<option value="1" '.$b_ruleid_1.' class=""><p>'.JText::_('COM_VQUIZ _BRANCHING_ANSWER_THIS_QUESTION').'<p></option>';
	}
	
	$rules_select .='<option value="2" '.$b_ruleid_2.'  class="skip_question_apply"><p>'.JText::_('COM_VQUIZ _BRANCHING_SKIP_THIS_QUESTION').'<p></option>';
	$rules_select .='<option value="3" '.$b_ruleid_3.'><p>'.JText::_('COM_VQUIZ _BRANCHING_CHO_PR_OPTION').'<p></option>';
	$rules_select .='<option value="4" '.$b_ruleid_4.'><p>'.JText::_('COM_VQUIZ _BRANCHING_NOT_CHO_PR_OPTION').'</p></option>';
	
	if($quiztype==1 OR $quiztype==11 OR $quiztype==0){
		$rules_select .='<option value="5" '.$b_ruleid_5.'><p>'.JText::_('COM_VQUIZ _BRANCHING_SCORE_PERCENTILE').'</p></option>';
	}

	$rules_select .='</select>';

	$b_apply_html ='<select name="applyid" class="branching_apply" id="branching_apply">';
	$b_apply_html .='<option value="0">'.JText::_('COM_VQUIZ_SELECT').'</option>';
	
	if($quiztype==1 OR $quiztype==11 OR $quiztype==0){
		
		$b_apply_html .='<option value="1" '.$b_applyid_1.'><p>'.JText::_('COM_VQUIZ _BRANCHING_INCLUDE_QUESTION').'</p></option>';
		$b_apply_html .='<option value="2" '.$b_applyid_2.'><p>'.JText::_('COM_VQUIZ _BRANCHING_EXCLUDE_QUESTION').'</p></option>';
	}

	$b_apply_html .='<option value="3" '.$b_applyid_3.'><p>'.JText::_('COM_VQUIZ _BRANCHING_JUMP_QUESTION').'</p></option>';
	$b_apply_html .='<option value="4" '.$b_applyid_4.'><p>'.JText::_('COM_VQUIZ _BRANCHING_SKIP_PER_QUESTION').'</p></option>';
	$b_apply_html .='<option value="5" '.$b_applyid_5.'><p>'.JText::_('COM_VQUIZ _BRANCHING_FORCE_END_QUIZ').'</P></option>';
	$b_apply_html .='</select>';

	if($rule_weight_check==1)
		$rule_ws='selected="selected"';
	else
		$rule_ws='';

	$rule_w_chk='<select name="rule_weight_check" id="rule_weight_check" style="width:120px;">';
	$rule_w_chk .='<option value="0">'.JText::_("<=").'</option>';
	$rule_w_chk .='<option value="1" '.$rule_ws.'>'.JText::_(">").'</option>';
	$rule_w_chk .='</select>';


	if($apply_weight_check==1)
		$apply_ws='selected="selected"';
	else
		$apply_ws='';
	$apply_w_chk='<select name="apply_weight_check" id="apply_weight_check" style="width:120px;">';
	$apply_w_chk .='<option value="0">'.JText::_("<=").'</option>';
	$apply_w_chk .='<option value="1" '.$apply_ws.' class="not_in_include">'.JText::_(">").'</option>';
	$apply_w_chk .='</select>';

	$specific_sel_ws1='';
	$specific_sel_ws2='';
	if($specific_sel==1)
		$specific_sel_ws1='selected="selected"';
	elseif($specific_sel==2)
		$specific_sel_ws2='selected="selected"';

	$speci_sel='<select name="specific_rule_selection" id="specific_selection">';
	$speci_sel .='<option value="1" '.$specific_sel_ws1.'><p>'.JText::_('COM_VQUIZ _BRANCHING_WHICH_N_Q_CHECK').'</P></option>';
	$speci_sel .='<option value="2" '.$specific_sel_ws2.'><p>'.JText::_('COM_VQUIZ _BRANCHING_WHICH_QUESTION_CHECK').'</P></option>';
	$speci_sel .='</select>';

	$script = array();
	$script[] = " jQuery(function($){";
	if($b_ruleid!=0){
		
		$script[] = " branching_apply_function($b_applyid);"; 
		$script[] = " branching_rule_function($b_ruleid);"; 
		if($b_rulequestionid!=0)
		$script[] = " get_options($b_rulequestionid,$b_ruleid);"; 
		if($b_applyid==1 OR $b_applyid==2){
			$script[] = " all_question_weight_apply($b_applyid);"; 
			$script[] = " jQuery('#apply_weight_check_span').html('$apply_w_chk');"; 
			if($b_applyid==1)
				$script[] = " jQuery('.not_in_include').hide();"; 
			else
				$script[] = " jQuery('.not_in_include').show();"; 
		}
		$script[] = " jQuery('#jform_request_rule_name').val('$b_rule_title');"; 
		$script[] = " jQuery('#jform_request_apply_name').val('$b_apply_title');"; 
		$script[] = " jQuery('#apply_weight_check').val('$apply_weight_check');"; 
		$script[] = " jQuery('#rule_weight_check').val('$rule_weight_check');";
		$script[] = " jQuery('#jform_request_rule_id').val('$b_rulequestionid');";
		$script[] = " jQuery('#rule_weight').val('$rule_weight');"; 
		$script[] = " jQuery('#apply_weight').val('$apply_weight');"; 
		$script[] = " jQuery('#score_percentile').val('$score_percentile');"; 
		$script[] = " jQuery('#jform_request_apply_id').val('$b_applyquestionid');";
		$script[] = " jQuery('#branching_rule_td').html('$rules_select');"; 
		$script[] = " jQuery('#branching_apply_td').html('$b_apply_html');"; 
		
		
		if($b_ruleid==5){
			$script[] = " jQuery('#rule_weight_check_span').html('$rule_w_chk');"; 
			$script[] = " jQuery('#specific_rule_selection_td').html('$speci_sel');"; 
			$script[] = " jQuery('#apply_which_number_input').val('$rule_wno_question');"; 
			$script[] = " specific_selection($specific_sel); "; 
		}
		
		$script[] = " jQuery('.add_rule_table').show();"; 
 		
	}
	if($skip_enable==1){
		$script[] = " jQuery('.skip_question_apply').show();"; 
	}else{
		$script[] = " jQuery('.skip_question_apply').hide();";  
	}
	$script[] = " });";
	JFactory::getDocument()->addScriptDeclaration(implode("\n", $script));


	if(version_compare(JVERSION, '3.0', '>=')) 
	JHtml::_('formbehavior.chosen', 'select'); 

?>
<script>
var jq=jQuery.noConflict();
function jSelectQuestion_jform_request_id(id, title, object){
	jQuery('#jform_request_rule_id').val(id);
	jQuery('#jform_request_rule_name').val(title);	
	SqueezeBox.close();
	var ruleid=jq('#branching_rule option:selected').val();
	get_options(id,ruleid);
	
}
	function all_question_weight(ruleid){
	
		jQuery.ajax({
			url:'index.php',
			type:'post',
			dataType:'json',
			data: {'option':'com_vquiz', 'view':'quizmanager','ruleid':ruleid,'task':'Question_weight', 'tmpl':'component','quizid':jq('#quizid').val(),"<?php echo JSession::getFormToken(); ?>":1},
			success:function(data){
				if(data.result=="success")	{
				
					jq('#score_percentile_span').html(data.question_weights);
					
					<?php if(version_compare(JVERSION, '3.0', '>=')) {?> 
						jQuery('select').chosen({
						disable_search_threshold : 10,
						allow_single_deselect : true
						});		
					<?php }?>
				}else{
					alert(data.error);
				}
			}
			
		})
		
	}
		
		
		function all_question_weight_apply(applyid){
			
		var apply_weight=<?php echo $apply_weight;?>;
 
		jQuery.ajax({
			url:'index.php',
			type:'post',
			dataType:'json',
			data: {'option':'com_vquiz', 'view':'quizmanager','applyid':applyid,'apply_weight':apply_weight,'task':'Question_weight_apply', 'tmpl':'component','quizid':jq('#quizid').val(),"<?php echo JSession::getFormToken(); ?>":1},
			success:function(data){
				if(data.result=="success")	{ 
				
					jq('#apply_weight_span').html(data.question_weights);
					
					<?php if(version_compare(JVERSION, '3.0', '>=')) {?> 
						jQuery('select').chosen({
						disable_search_threshold : 10,
						allow_single_deselect : true
						});		
					<?php }?>
				}else{
					alert(data.error);
				}
			}
			
		})
		
	}
	
	function get_options(id,ruleid){

		jQuery.ajax({
			url:'index.php',
			type:'post',
			dataType:'json',
			data: {'option':'com_vquiz', 'view':'quizmanager', 'task':'Question_options', 'tmpl':'component','ruleid':ruleid,'question_id':id,"<?php echo JSession::getFormToken(); ?>":1},
			success:function(data){
				if(data.result=="success")	{
				
					jq('#option_append').html(data.question_id);
					
					<?php if(version_compare(JVERSION, '3.0', '>=')) {?> 
						jQuery('select').chosen({
						disable_search_threshold : 10,
						allow_single_deselect : true
						});		
					<?php }?>
					jq('.submit_apply').show();

				}else{
					alert(data.error);
				}
			}
			
		})
		
	}
	
	function jSelectQuestion_jform_request_apply_id(id, title, object){
		jQuery('#jform_request_apply_id').val(id);
		jQuery('#jform_request_apply_name').val(title);	
		SqueezeBox.close();
		jq('.add_rule_table').show();
	}
 
	<!--  reset rule  -->
	function reset_rule(){ 
				
		jQuery('#jform_request_rule_id').val(0);
		jQuery('#jform_request_rule_name').val('<?php echo JText::_('COM_VQUIZ_SELECT_QUESTION');?>');
		jq('.check_rule_weight').hide();
		jq('#option_append').html('<select id="option_select_rule" name="option_select_rule"><option value="0"><?php echo JText::_('COM_VQUIZ_SELECT');?></option></select>');
		jq('.submit_apply').hide();
		
		<?php if(version_compare(JVERSION, '3.0', '>=')) { ?> 
			jQuery('select').chosen({
				disable_search_threshold : 10,
				allow_single_deselect : true
			});	
		<?php } ?>
		
		
	}
	
	<!--  reset apply  -->
	function reset_apply(){
	
		jQuery('#jform_request_apply_id').val(0);
		jQuery('#jform_request_apply_name').val('<?php echo JText::_('COM_VQUIZ_SELECT_QUESTION');?>');	
		
		jQuery('#jform_request_rule_id').val(0);
		jQuery('#jform_request_rule_name').val('<?php echo JText::_('COM_VQUIZ_SELECT_QUESTION');?>');
		jq('#option_append').html('<select id="option_select_rule" name="option_select_rule"><option value="0"><?php echo JText::_('COM_VQUIZ_SELECT');?></option></select>');
 
		
		var b_rule_html='<select name="ruleid" class="branching_rule" id="branching_rule">';
		b_rule_html +='<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT');?></option>';
		<?php if($quiztype==1 OR $quiztype==11 OR $quiztype==0){?>
		b_rule_html +='<option value="1" class=""><p><?php echo JText::_('COM_VQUIZ _BRANCHING_ANSWER_THIS_QUESTION'); ?><p></option>';
		<?php } ?>
		b_rule_html +='<option value="2" class="skip_question_apply"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_SKIP_THIS_QUESTION'); ?><p></option>';
		b_rule_html +='<option value="3"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_CHO_PR_OPTION'); ?><p></option>';
		b_rule_html +='<option value="4"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_NOT_CHO_PR_OPTION'); ?></p></option>';
		<?php if($quiztype==1 OR $quiztype==11 OR $quiztype==0){?>
		b_rule_html +='<option value="5"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_SCORE_PERCENTILE');?></p></option>';
		<?php }?>
	
		b_rule_html +='</select>';

		jq('#branching_rule_td').html(b_rule_html);
		jq('.add_question_rule').hide();
		jq('.add_options_rule').hide();
		jq('.submit_apply').hide();
		jq('.add_rule_table').hide()
		jq('.score_percentile_rule').hide();
		jq('.check_rule_weight').hide();
		jq('.specific_rule_selection').hide();
		jq('.apply_which_number_question').hide();

		<?php if(version_compare(JVERSION, '3.0', '>=')) { ?> 
			jQuery('select').chosen({
				disable_search_threshold : 10,
				allow_single_deselect : true
			});	
		<?php } ?>
		
	}
	
	<!--branching_rule_function -->
	function branching_rule_function(selected_value){

			reset_rule();
 
			if(selected_value==1 || selected_value==2){
				jq('.add_question_rule').show();
				jq('.add_options_rule').hide();
				jq('.check_rule_weight').hide();
				jq('.submit_apply').hide();
				jq('.score_percentile_rule').hide();
				jq('.specific_rule_selection').hide();
				jq('.apply_which_number_question').hide();

			}else if(selected_value==3 || selected_value==4){
			
				jq('.add_options_rule').show();
				jq('.add_question_rule').show();
				jq('.check_rule_weight').hide();
				jq('.submit_apply').hide();
				jq('.score_percentile_rule').hide();
				jq('.specific_rule_selection').hide();
				jq('.apply_which_number_question').hide();
				
			}else if(selected_value==5){
				jq('.check_rule_weight').show();
				jq('.score_percentile_rule').show();
				jq('.submit_apply').show();
				all_question_weight(selected_value);
				jq('.add_question_rule').hide();
				jq('.add_options_rule').hide();
				jq('.specific_rule_selection').show();
				jq('.apply_which_number_question').show();

			}else{
				jq('.add_question_rule').hide();
				jq('.add_options_rule').hide();
				jq('.check_rule_weight').hide();
				jq('.submit_apply').hide();
				jq('.score_percentile_rule').hide();
				jq('.specific_rule_selection').hide();
				jq('.apply_which_number_question').hide();
			}
			//return false;
	}
	
	<!--branching_apply_function -->
	
	function branching_apply_function(selected_value){
			
			reset_apply();
			if(selected_value==1 || selected_value==2){
				
				var dsd='<select name="apply_weight_check" id="apply_weight_check" style="width:120px;">';
				 dsd +='<option value="0"><?php echo JText::_('<=');?></option>';
				if(selected_value==2)
				 dsd +='<option value="1" class="not_in_include"><?php echo JText::_('>');?></option>';
				 dsd +='</select>';
				
				jq('.check_apply_weight').show();
				jq('.add_question_apply').hide();
				//jq('.submit_apply').show();
				jq('.add_rule_table').show();
				jq('.score_check_apply').show();
				jq('#apply_weight_check_span').html(dsd);
				all_question_weight_apply(selected_value);
				<?php if(version_compare(JVERSION, '3.0', '>=')) { ?> 
					jQuery('select').chosen({
						disable_search_threshold : 10,
						allow_single_deselect : true
					});	
				<?php } ?>
			}else if(selected_value==3 || selected_value==4){
				jq('.add_question_apply').show();
				jq('.check_apply_weight').hide();
				jq('.score_check_apply').hide();
			}else{
				jq('.add_question_apply').hide();
				jq('.check_apply_weight').hide();
				jq('.score_check_apply').hide();
				jq('.submit_apply').hide();
				if(selected_value==5)
					jq('.add_rule_table').show();
				else
					jq('.add_rule_table').hide();
				
 
				 
			}
		
		}
		
		
	function specific_selection(selected_value){
				
		if(selected_value==1){
			jq('.apply_which_number_question').show();
			jq('.add_question_rule').hide();
		}else if(selected_value==2){
			jq('.apply_which_number_question').hide();
			jq('.add_question_rule').show();

		}else{
			jq('.apply_which_number_question').hide();
			jq('.add_question_rule').hide();
		}
	}	
	
jq(document).ready(function(){

	jq(document).on('click','#braching_rule_apply',function() { 
		
	
		var branching_apply_txt=jq('#branching_apply option:selected').text();
		var branching_rule=jq('#branching_rule option:selected').val();
		var rule_question_id=jq('#jform_request_rule_id').val();
		var rule_option=jq('#option_select_rule').val();
		var rule_weight=jq('#rule_weight').val();
		var rule_weight_check=jq('#rule_weight_check').val();
		var rule_question_title=jQuery('#jform_request_rule_name').val();
		var score_percentile=jQuery('#score_percentile').val();
		var branching_apply=jq('#branching_apply').val();
		var apply_question_id=jq('#jform_request_apply_id').val();
		var apply_question_title=jq('#jform_request_apply_name').val();
		var apply_weight=jq('#apply_weight').val();
		var apply_weight_check=jq('#apply_weight_check').val();
		var specific_selection=jq('#specific_selection option:selected').val();
		var which_number_input=jq('#apply_which_number_input').val();

		var add_html ='<td>';
		add_html +=branching_apply_txt;
		add_html +='<input type="hidden" name="apply_text[]" value="'+branching_apply_txt+'" />';
		add_html +='<input type="hidden" name="branching_ruleid[]" value="'+branching_rule+'" />';
		add_html +='<input type="hidden" name="rule_questiontitle[]" value="'+rule_question_title+'" />';
		add_html +='<input type="hidden" name="branching_rulequestionid[]" value="'+rule_question_id+'" />';
		add_html +='<input type="hidden" name="branching_ruleoptionid[]" value="'+rule_option+'" />';
		add_html +='<input type="hidden" name="rule_weight[]" value="'+rule_weight+'" />';
		add_html +='<input type="hidden" name="rule_weight_check[]" value="'+rule_weight_check+'" />';
		add_html +='<input type="hidden" name="score_percentile[]" value="'+score_percentile+'" />';
		
		add_html +='<input type="hidden" name="branching_applyid[]" value="'+branching_apply+'" />';
		add_html +='<input type="hidden" name="branching_applyquestionid[]" value="'+apply_question_id+'" />';
		add_html +='<input type="hidden" name="apply_weight[]" value="'+apply_weight+'" />';
		add_html +='<input type="hidden" name="apply_weight_check[]" value="'+apply_weight_check+'" />';
		
		add_html +='<input type="hidden" name="apply_questiontitle[]" value="'+apply_question_title+'" />';
		
		add_html +='<input type="hidden" name="rule_specific_select[]" value="'+specific_selection+'" />';
		
		add_html +='<input type="hidden" name="rule_wno_question[]" value="'+which_number_input+'" />';
		
		var count_row=parseInt(jq('#count_row').val());
 
		add_html +='</td>';
		
		var add_parameters='&b_ruleid='+branching_rule+'&b_rulequestionid='+rule_question_id+'&b_ruleoptionid='+rule_option+'&rule_weight='+rule_weight+'&rule_weight_check='+rule_weight_check+'&rule_question_title='+rule_question_title+'&score_percentile='+score_percentile+'&specific_sel='+specific_selection+'&rule_wno_question='+which_number_input+'&b_applyid='+branching_apply+'&b_applyquestionid='+apply_question_id+'&apply_question_title='+apply_question_title+'&apply_weight='+apply_weight+'&apply_weight_check='+apply_weight_check+'&count_row='+count_row+'&quizid='+jq('#quizid').val();
		
		var rel="{handler: 'iframe', size: {x: 1200, y: 600}}";
		
		add_html +='<td><a class="modal" id="click_simulate" title="" href="<?php echo 'index.php?option=com_vquiz&view=quizmanager&layout=branching&tmpl=component';?>'+add_parameters+'" rel="'+rel+'" ></a><a href="javascript:void(0);" class=" click_edit btn btn-success">Edit/Views</a></td>';
		
		add_html +='<td valign="middle" align="center"><a href="javascript:void(0);" class="btn btn-danger remrule">-</a></td>';
 
		
		
		<?php if($b_ruleid!=''){?>
		
			jQuery('#<?php echo 'row_id'.$count_row;?>',window.parent.document).html(add_html);	
			
		<?php } else {?>
		
			count_row=count_row+1;
			
			jQuery('#add_rule_table',window.parent.document).append('<tr id="row_id'+count_row+'">'+add_html+'</tr>');
			
			jQuery('#count_branch_row',window.parent.document).val(count_row);

		<?php }?>

		window.parent.SqueezeBox.close();
 
	});
 
	jq('#reset_rule_question').click(function(){	
		reset_rule();
	});
	
	jq('#reset_apply_question').click(function(){
		reset_apply();
	});
	
	jq(document).on('change','#branching_rule',function() { 
			var selected_value=jq(this).val();
			branching_rule_function(selected_value);
	});
	
	jq(document).on('change','#branching_apply',function() { 
	
		var selected_value=jq(this).val();
		branching_apply_function(selected_value);
		
	});
			
	jq('#specific_selection').on('change', function() {
			var selected_value=jq(this).val();
			specific_selection(selected_value);
	});
 
 });
</script>
<div class="cpanel-left">
	<fieldset>
		<legend><?php echo JText::_('COM_VQUIZ_CONDITIONAL_BRANCHING'); ?></legend>
 	
		<table class="adminform table table-striped add_rule_apply" width="100%" id="add_rule_apply">	
			<tr>
				<th><?php echo JText::_('COM_VQUIZ _BRANCHING_SELECT_ACTION'); ?></th>				
				<th class="check_apply_weight" style="display:none;"><?php echo JText::_('COM_VQUIZ _BRANCHING_WEIGHT'); ?></th>

				<th class="add_question_apply" style="display:none;"><?php echo JText::_('COM_VQUIZ _BRANCHING_SELECT_QUESTION'); ?></th>
				
				<th class="add_options_apply" style="display:none;"><?php echo JText::_('COM_VQUIZ _BRANCHING_SELECT_OPTION'); ?></th>
				
			</tr>
				
			<tr id="">
				<td id="branching_apply_td">	
					<select name="rule_apply" class="branching_apply" id="branching_apply">
						<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT');?></option>
						<?php if($quiztype==1 OR $quiztype==11 OR $quiztype==0){?>
						<option value="1"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_INCLUDE_QUESTION');?></p></option>
						<option value="2"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_EXCLUDE_QUESTION');?></p></option>
						<?php } ?>
						<option value="3"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_JUMP_QUESTION');?></p></option>
						<option value="4"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_SKIP_PER_QUESTION');?></p></option>
						<option value="5"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_FORCE_END_QUIZ');?> </P></option>
					</select>
				</td>
				
				<td class="check_apply_weight" style="display:none;">
				
					<span id="apply_weight_check_span">
						<select name="apply_weight_check" id="apply_weight_check" style="width:120px;">
							<option value="0"><?php echo JText::_('<=');?></option>
						</select>
					</span>
					<span id="apply_weight_span">
					<select name="apply_weight" id="apply_weight" style="width:120px;">
					<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT');?></option>
					</select>
					<span>
				</td>
 
				<td class="add_question_apply" style="display:none;">
					<span class="input-append">
					   <?php 
							$monitor_quiz_title=JText::_('COM_VQUIZ_SELECT_QUESTION');	$monitor_quiz_title=!empty($monitor_quiz_title)?$monitor_quiz_title:JText::_('COM_VQUIZ_SELECT_QUESTION');
						?>
							<input type="text" size="80" disabled="disabled" value="<?php echo $monitor_quiz_title;?>" id="jform_request_apply_name" name="monitor_question_title[]" class="input-medium" />
							
							<input type="hidden" value="0" name="branching_apply_question" class="required modal-value" id="jform_request_apply_id" aria-required="true" required="required">

							 <a currten_id="" rel="{handler: 'iframe', size: {x: 800, y: 450}}" href="index.php?option=com_vquiz&view=quizquestion&tmpl=component&function=jSelectQuestion_jform_request_apply_id&quizid=<?php echo $quizzesid;?>" title="" class="modal btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_QUESTION');?>"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_SELECT");?></a> 
							 
							<input type="button" value="Reset" name="reset" currten_id="" id="reset_apply_question" class="btn reset"/>
						</span>
				</td>
			</tr>
		</table>
		
		<h2 class="add_rule_table" style="display:none;text-align:center;"><?php echo JText::_('When');?></h2>
				
				
		<table class="adminform table table-striped add_rule_table" width="100%" id="add_rule_table" style="display:none;">	
			<tr>
				<th><?php echo JText::_('COM_VQUIZ _BRANCHING_SELECT_CONDITION'); ?></th>
				<th class="score_percentile_rule" style="display:none;"><?php echo JText::_('COM_VQUIZ _BRANCHING_WEIGHT'); ?></th>
				<th class="check_rule_weight" style="display:none;"><?php echo JText::_('COM_VQUIZ _SCORE'); ?></th>
				<th class="specific_rule_selection" style="display:none;"><?php echo JText::_('COM_VQUIZ _BRANCHING_SPECIFIC_SELECTION'); ?></th>
				<th class="apply_which_number_question" style="display:none;"><?php echo JText::_('COM_VQUIZ _BRANCHING_NUMBER_QUESTION'); ?></th>
				
				<th class="add_question_rule" style="display:none;"><?php echo JText::_('COM_VQUIZ _BRANCHING_SELECT_QUESTION'); ?></th>
				<th class="add_options_rule" style="display:none;"><?php echo JText::_('COM_VQUIZ _BRANCHING_SELECT_OPTION'); ?></th>
			</tr>
				
			<tr id="add_rule_tr">
				<td id="branching_rule_td">			
					<select name="ruleid" id="branching_rule">
						<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT');?></option>
						
						<?php if($quiztype==1OR $quiztype==11 OR $quiztype==0){?>
						<option value="1" class=""><p><?php echo JText::_('COM_VQUIZ _BRANCHING_ANSWER_THIS_QUESTION');?></p></option>
						<?php } ?>
						
						<option value="2" class="skip_question_apply"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_SKIP_THIS_QUESTION');?></p></option>
						<option value="3"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_CHO_PR_OPTION');?></p></option>
						<option value="4"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_NOT_CHO_PR_OPTION');?></p></option>
						<?php if($quiztype==1 OR $quiztype==11 OR $quiztype==0){?>
						<option value="5"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_SCORE_PERCENTILE');?></p></option>
						<?php }?>
												
					</select>
				</td>
				<td id="score_percentile_rule" class="score_percentile_rule" style="display:none;">
					<span id="score_percentile_span"><select name="" id="score_percentile">
						<option value="0"><?php echo JText::_('All');?></option>
					</select>
					</span>
				</td>
				<td class="check_rule_weight" style="display:none;">
					<span id="rule_weight_check_span"><select name="rule_weight_check" id="rule_weight_check" style="width:120px;">
						<option value="0"><?php echo JText::_('<=');?></option>
						<option value="1"><?php echo JText::_('>');?></option>
					</select>
					</span>
					<div style="padding:5px;"><input type="text" value="0" style="width:80px;" name="rule_weight" id="rule_weight"/></span>	
				</td>
				<td id="specific_rule_selection_td" class="specific_rule_selection" style="display:none;">
					<select name="specific_rule_selection" id="specific_selection">
						<option value="1"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_WHICH_N_Q_CHECK');?> </P></option>
						<option value="2"><p><?php echo JText::_('COM_VQUIZ _BRANCHING_WHICH_QUESTION_CHECK');?> </P></option>
					</select>
				</td>
				
				<td class="apply_which_number_question" style="display:none;">
					<input type="number" value="" style="width:80px;" id="apply_which_number_input" name="apply_which_number_input"/></td>

				<td class="add_question_rule" style="display:none;">
					<span class="input-append">
					   <?php 
							$monitor_quiz_title=JText::_('COM_VQUIZ_SELECT_QUESTION');	$monitor_quiz_title=!empty($monitor_quiz_title)?$monitor_quiz_title:JText::_('COM_VQUIZ_SELECT_QUESTION');
						?>
							<input type="text" size="80" disabled="disabled" value="<?php echo $monitor_quiz_title;?>" id="jform_request_rule_name" name="monitor_question_title[]" class="input-medium" />
							
							<input type="hidden" value="0" name="branching_rule_question" class="required modal-value" id="jform_request_rule_id" aria-required="true" required="required">

							 <a currten_id="" rel="{handler: 'iframe', size: {x: 800, y: 450}}" href="index.php?option=com_vquiz&view=quizquestion&tmpl=component&function=jSelectQuestion_jform_request_id&quizid=<?php echo $quizzesid;?>" title="" class="modal btn hasTooltip" data-original-title="<?php echo JText::_('COM_VQUIZ_SELECT_QUESTION');?>"><i class="icon-file"></i><?php echo JText::_("COM_VQUIZ_SELECT");?></a> 
							 
							<input type="button" value="Reset" name="reset" currten_id="" id="reset_rule_question" class="btn reset"/>
						</span>
				</td>
				<td class="add_options_rule" id="option_append" style="display:none;">			
					<select name="rule" id="option_select_rule">
						<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT');?></option>
					</select>
				</td>
			</tr>
		</table>
		<br>
 
		<br>
		<div class="submit_apply" style="display:none;text-align:center;">
			<input type="button" class="btn btn-success"  name="braching_rule_apply" value="<?php echo JText::_('COM_VQUIZ _BRANCHING_APPLY_RULE');?>" id="braching_rule_apply"/>
		</div>
		
	</fieldset>
</div>   
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="quizmanager" />
<input type="hidden" name="" id="quizid" value="<?php echo $quizzesid; ?>" />
<input type="hidden" name="" id="count_row" value="<?php echo JRequest::getInt('count_row',0); ?>" />
