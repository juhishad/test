<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die('Restricted access');
$document = JFactory::getDocument();
JHTML::_('behavior.modal');
//$document->addScript(JURI::root().'/administrator/components/com_vquiz/assets/js/library.js');
$document->addStyleSheet(JURI::root().'/administrator/components/com_vquiz/assets/css/evol.colorpicker.min.css');
$document->addStyleSheet(JURI::root().'/administrator/components/com_vquiz/assets/css/style.css');
$document->addScript(JURI::root().'/administrator/components/com_vquiz/assets/js/jquery-ui.js');
$document->addScript(JURI::root().'/administrator/components/com_vquiz/assets/js/evol.colorpicker.min.js');
$document->addScript(JURI::root().'/media/editors/tinymce/tinymce.min.js');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');
$session=JFactory::getSession(); 
$p_type=JRequest::getInt('p_type',0);
$style='.multi_p{display:none}';
if($p_type!=1){
	$document->addStyleDeclaration( $style );	
}

?>

<script>	
function  tinymce_init(){	
 
 	tinymce.init({
			selector: "textarea",
			relative_urls : false,
			menubar: false,
			remove_script_host : true,
			document_base_url :"<?php echo JURI::root();?>",
		  plugins: [
			  "advlist autolink lists link image charmap print preview anchor",
			  "searchreplace visualblocks code fullscreen",
			  "insertdatetime media table contextmenu paste"
		  ],
		  toolbar: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image" 
	  });
}

tinymce_init();

	var jq=jQuery.noConflict();
	jq(document).ready(function() { 
 	
 		jQuery(".p_color_picker").colorpicker();
		
		var max_fields      = 50;  
		var wrapper         = jq(".input_fields_wrap");  
		var add_button      = jq(".add_field_button");  
		
		
		var x =0;  
		var y=1;
		jq(document).on("click",".add_field_button", function(e){  
			e.preventDefault();
			x=parseInt(jq(".count_row").val());
	 
			var html ='<tr class="editor"><td><input type="text" name="answer[]" class="answer" value="" /></td>';
			html +='<td><textarea rows="5" cols="5"  name="description[]" class="description"></textarea>';

			html +='</td>';
			html +='<td class="multi_p"><input  style="width:100px;"  type="text" name="color[]" class="p_color_picker" value=""/></td>';
			html +='<td class="">';


			html +='<select name="article_id[]">';
			html +='<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_MENUITEM');?></option>';
			<?php for($b=0;$b<count($this->menuItems);$b++){?>
			html +='<option value="<?php echo $this->menuItems[$b]->id; ?>"><?php echo addslashes($this->menuItems[$b]->title); ?></option>';
			<?php }?>
			html +='</select>';

			html +='</td>';

			html +='<td><a class="remove_field btn btn-danger" href="javascript:void(0);">-</a></td></tr>';


			jq(wrapper).prepend(html);


			SqueezeBox.assign(jq('a.modal').get(), {
			parse: 'rel'
			});


			jq(".p_color_picker").colorpicker();

			jQuery('select').chosen({
			disable_search_threshold : 10,
			allow_single_deselect : true
			});

			tinymce_init();
			setTimeout(function(){if(jq('.editor').first().find('div').hasClass('mce-tinymce')===false){
						jq('.editor').first().find('textarea').attr("id","id_"+y);
						jq('.editor').first().find('textarea').addClass('discription');
						y++;
						tinymce_init();
					}},500);

			x++;  
			jq(".count_row").val(x);
				
	 
		});
		

		jq(document).on("click",".remove_field", function(e){  
			e.preventDefault(); 
			jq(this).parent().parent().find('.answer').val('');
			jq(this).parent().parent().remove(); 
			x--;
			jq(".count_row").val(x);
			tinymce_init();
				
		})
		

		jq('.modal').on("click", function(e){ 
			currten_id=jq(this).attr('currten_id');
			jq('#currten_id').val(currten_id);
		});

		jq('.reset').on("click", function(e){  
				currten_id=jq(this).attr('currten_id');
				jq('#jform_request_id_id'+currten_id).val('');
				jq('#jform_request_id_name'+currten_id).val('<?php echo JText::_('COM_VQUIZ_SELECT_AN_ARTICLE')?>');
		});
		
		jq(document).on("click",".reset", function(e){  
				currten_id=jq(this).attr('currten_id');
				jq('#jform_request_id_id'+currten_id).val('');
				jq('#jform_request_id_name'+currten_id).val('<?php echo JText::_('COM_VQUIZ_SELECT_AN_ARTICLE')?>');
		});
       
 
 
    });
	
	var currten_id=jQuery('#currten_id').val();
	
	function myFunction(currten_id) {
		currten_id=currten_id;
		jq('#currten_id').val(currten_id);
	}

	function jSelectArticle_jform_request_id(id, title, object){
		var currten_id=jQuery('#currten_id').val();
		jQuery('#jform_request_id_id'+currten_id).val(id);
		jQuery('#jform_request_id_name'+currten_id).val(title);
		SqueezeBox.close();
	}

 Joomla.submitbutton = function(task) {
	if (task == 'cancel') {
		Joomla.submitform(task, document.getElementById('adminForm'));
	}else{
			 jq('input[name="category_combination[]"]').each(function(){
				jQuery(this).prop('disabled', false);
			 });
		} 	
		Joomla.submitform(task, document.getElementById('adminForm'));
	} 
</script>
	
	<div id="toolbar" class="btn-toolbar">
		<div id="toolbar-apply" class="btn-wrapper">
			<button class="btn btn-small btn-success" onclick="Joomla.submitbutton('personality_message')">
			<span class="icon-apply icon-white"></span><?php echo JText::_('COM_VQUIZ_SAVE')?></button>
		</div>
	</div>
	
<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">

	<div class="cpanel-left">
		<fieldset class="adminform">
		
		<?php  if($p_type!=2){ ?>
			<label style="float:right"><input type="button" class="btn  btn-success add_field_button" value="+">
			</label>
		<?php }?>
		<label><?php echo JText::_('COM_VQUIZ_PERSONALITY_QUIZ_MESSAGE'); ?></label>

		<legend></legend>

				<table class="adminlist table table-striped table-hover">
					<thead>
					<tr>
						<?php  if($p_type==2){ ?>
						<th width="100" valign="middle" align="center"><label><?php echo JText::_('PERSONALITY_CATEGORY_COMBINATION');?></label></th>
						<?php }?>
						<th width="200" valign="middle" align="center"><label><?php echo JText::_('COM_VQUIZ_ANSWER') ?></label></th>
						<th valign="middle" align="center"><label><?php echo JText::_('COM_VQUIZ_QUIZZES_DESCRIPTION') ?></label></th>
						<?php  if($p_type==2){ ?>
						<th><label><?php echo JText::_('COM_VQUIZ_COLOR') ?></label></th>
						<?php }else{?>
						<th class="multi_p"><label><?php echo JText::_('COM_VQUIZ_COLOR') ?></label></th>
						<?php }?>
						<th valign="middle" align="center"><label><?php echo JText::_('MENU_ITEM') ?></label></th>
					</thead>
					</tr>
		<tbody class="input_fields_wrap">			
		<?php if($p_type==2){
		
			if(!empty($this->personality_category->category)){
				$p_cat=json_decode($this->personality_category->category);
							
				$count_column =$this->personality_category->count_column>0?$this->personality_category->count_column:1;
				
				$personality_category=array_chunk($p_cat,$count_column);
				
														
				function combinations($arrays, $i = 0) {
					if (!isset($arrays[$i])) {
						return array();
					}
					if ($i == count($arrays) - 1) {
						return $arrays[$i];
					}

					// get combinations from subsequent arrays
					$tmp = combinations($arrays, $i + 1);

					$result = array();

					// concat each array from tmp with each element from $arrays[$i]
					foreach ($arrays[$i] as $v) {
						foreach ($tmp as $t) {
							$result[] = is_array($t) ? 
								array_merge(array($v), $t) :
								array($v, $t);
						}
					}

					return $result;
				}

				$all_combination=combinations($personality_category);
			}else{
				$all_combination=null;
				echo $msg_empty_category=JText::_('COM_VQUIZ_QUIZZES_FIRST_SAVE_PERSONALITY_CATEGORY');
			}

			?>
			<?php for($i=0;$i<count($all_combination);$i++){?>
				<tr>
				<td width="100">
					<input type="text" name="category_combination[]" class="category_combination" disabled="disabled" value="<?php echo implode('',$all_combination[$i])?>" style="width:100px"/>
					</td>
				<td width="200">
				<input type="text" name="answer[]" class="answer" value="<?php if(!empty($this->personality_messages[$i]->answer)) echo $this->personality_messages[$i]->answer;?>" />
				</td>
				<td>
				<textarea rows="5" cols="5"  name="description[]" class="description"><?php if(!empty($this->personality_messages[$i]->description)) echo $this->personality_messages[$i]->description;?></textarea>
				</td>
				
				<td>
				<input  style="width:100px;"  type="text" name="color[]" class="p_color_picker" value="<?php  if(!empty($this->personality_messages[$i]->color)) echo $this->personality_messages[$i]->color?>"/>
				</td>

				<td class="">	
				
				<select  name="article_id[]>" >
					<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_MENUITEM');?></option>
					<?php for($b=0;$b<count($this->menuItems);$b++){?>
						<option value="<?php echo $this->menuItems[$b]->id; ?>" <?php if(@$this->personality_messages[$i]->article_id==$this->menuItems[$b]->id) echo "selected='selected';"?>><?php echo $this->menuItems[$b]->title; ?></option>
					<?php }?>
				</select>
				
				</td>

				<td valign="middle" align="center">
				<a href="javascript:void(0);" class="remove_field btn btn-danger">-</a></td>
				</tr>
			<?php }?>

		<?php } else {?>
				
				<?php 
				if(!empty($this->personality_messages)){ ?>
					<input type="hidden" class="count_row" value="<?php echo count($this->personality_messages); ?>">
					<?php 	

					for($i=0;$i<count($this->personality_messages);$i++){?>
						<tr>
						<td>
						<input type="text" name="answer[]" class="answer" value="<?php echo $this->personality_messages[$i]->answer?>" />
						</td>
						<td>

						<textarea rows="5" cols="5"  name="description[]" class="description"><?php echo $this->personality_messages[$i]->description?></textarea>

						</td>
						<td class="multi_p">
						<input  style="width:100px;"  type="text" name="color[]" class="p_color_picker" value="<?php echo $this->personality_messages[$i]->color?>"/>
						</td>
						
						<td class="">	
						
						
							<select  name="article_id[]>" >
								<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_MENUITEM');?></option>
								<?php for($b=0;$b<count($this->menuItems);$b++){?>
									<option value="<?php echo $this->menuItems[$b]->id; ?>" <?php if(@$this->personality_messages[$i]->article_id==$this->menuItems[$b]->id) echo "selected='selected';"?> ><?php echo $this->menuItems[$b]->title; ?></option>
								<?php }?>
							</select>
						
						</td>
						
						<td valign="middle" align="center">
						<a href="javascript:void(0);" class="remove_field btn btn-danger">-</a></td>
						</tr>
					<?php }?>
				<?php }else if($session->has('personality_message_session')){
						$tm=$session->get('personality_message_session');
				?>
					<input type="hidden" class="count_row" value="<?php echo count($tm['answer']); ?>">
						<?php 	for($i=0;$i<count($tm['answer']);$i++){ if(!empty($tm['answer'][$i])){?>
						<tr>
							<td>
								<input type="text" name="answer[]" class="answer" value="<?php echo $tm['answer'][$i]?>" />
							</td>

							<td>
								<textarea rows="5" cols="5"  name="description[]" class="message"><?php echo $tm['description'][$i]?></textarea>
							</td>

							<td class="multi_p">
								<input  style="width:100px;"  type="text" name="color[]" class="p_color_picker" value="<?php echo $tm['color'][$i]?>"/>

							</td>

							<td class="">
								
								<select  name="article_id[]>" >
									<option value="0"><?php echo JText::_('COM_VQUIZ_SELECT_MENUITEM');?></option>
									<?php for($b=0;$b<count($this->menuItems);$b++){?>
										<option value="<?php echo $this->menuItems[$b]->id; ?>" <?php if($tm['article_id'][$i]->article_id==$this->menuItems[$b]->id) echo "selected='selected';"?> ><?php echo addslashes($this->	menuItems[$b]->title); ?></option>
									<?php }?>
								</select>

							</td>
							
							<td valign="middle" align="center">
								<a class="remove_field btn btn-danger" href="javascript:void(0);">-</a>
							</td>
						</tr>
						<?php }}?>
				<?php }
				
				else{?>

					<input type="hidden" class="count_row" value="0">
				<?php }?>
				
			<?php }?>	
			</tbody>
		</table>
		</fieldset>
	</div>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="quizmanager" />
<input type="hidden" name="quizid" value="<?php echo JRequest::getInt('id');?>" />
<input type="hidden" name="p_type" value="<?php echo JRequest::getInt('p_type',0);?>" />
<input type="hidden" name="currten_id" value="0" id="currten_id" />
</form>