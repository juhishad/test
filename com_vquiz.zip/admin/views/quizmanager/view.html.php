	<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.view' );
class VquizViewQuizmanager extends JViewLegacy
{ 
	function display($tpl = null)
	{

			  $mainframe =JFactory::getApplication();
			  $user = JFactory::getUser();
			  
			  if(!$user->authorise('core.userviews','com_vquiz')){
				jerror::raiseWarning('403', JText::_('UNAUTH_ACCESS'));
				return false;	 
			  }  
				
			  $session=JFactory::getSession();
		      $context	= 'com_vquiz.quizmanager.list.';
			  $layout = JRequest::getCmd('layout', '');
			  
			  //$this->form=$this->get('Form');
			  
			 
			 
			  $search = $mainframe->getUserStateFromRequest( $context.'search', 'search', '',	'string' );
		      $search = JString::strtolower( $search );
			  $qcategoryid= $mainframe->getUserStateFromRequest( $context.'qcategoryid', 'qcategoryid',	'',	'string' );
			  $selected_userquiz= $mainframe->getUserStateFromRequest( $context.'selected_userquiz', 'selected_userquiz',	'',	'string' );
			  $categorysearch= $mainframe->getUserStateFromRequest( $context.'categorysearch', 'categorysearch',	'',	'string' );
			  $publish_item= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );
			  
			  $filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
       		  $filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
			  
			  $this->config = $this->get('Configuration');	
			  
			 //echo "<pre>";print_r(JFactory::getConfig());
				if($layout == 'form'){
				
					$this->access = $this->get('Access');
					$this->branching_rule = $this->get('Branching_rule');
					$this->skills =$this->get('Skills');
					
					$this->form=$this->get('Form');

					$item =$this->get('Item'); //print_r($item);
					$isNew		= ($item->id < 1);
					$this->assignRef( 'item', $item ); 
					$this->category  = $this->get('Category');
					$this->configuration  = $this->get('Configuration');
					$this->score_category  = $this->get('Score_category');
					$this->personality_category  = $this->get('personality_category');
					$this->menuItems = $this->get('MenuItems');
					$this->totalQuestion  = $this->get('CountQuestion');
					$this->questiongroup  = $this->get('Questiongroup');
					
					$this->lists['access'] = JHtml::_('access.assetgrouplist', 'access', $this->item->access,'size="10"',false);
					 
					if($isNew)	{
						JToolBarHelper::title( JText::_( 'NEWQUIZ' ), 'question-2.png' );					
					}else{
						if($this->item->access_token<>""){						
						  JToolBarHelper::title( JText::_( 'EDITQUIZ' ).' <a href="'.JURI::root( true ).'/index.php?option=com_vquiz&view=quizmanager&layout=description&id='.$item->id.'&access='.$this->item->access_token.'" target="_blank">'.$item->title.'</a>', 'question-2.png' );
						}else{
							JToolBarHelper::title( JText::_( 'EDITQUIZ' ).' <a href="'.JURI::root( true ).'/index.php?option=com_vquiz&view=quizmanager&layout=description&id='.$item->id.'" target="_blank">'.$item->title.'</a>', 'question-2.png' );
						}
					}
					if($isNew)
					{
						if($isNew && JFactory::getUser()->authorise('core.create','com_vquiz'))
						{
							JToolBarHelper::apply();
							JToolBarHelper::save();	
							
						}
						if ( JFactory::getUser()->authorise('core.create','com_vquiz'))
						{
							JToolbarHelper::save2new('save2new');
						}
					}else{
						if($user->authorise('core.edit','com_vquiz') OR ($user->authorise('core.edit.own','com_vquiz') and $this->item->created_by == $user->get('id')))
						{
							JToolBarHelper::apply();
							JToolBarHelper::save();		
						}
						if ( JFactory::getUser()->authorise('core.create','com_vquiz'))
						{
							JToolbarHelper::save2new('save2new');
							JToolbarHelper::save2copy('save2copy');
						}
					}
					
					
					
					JToolBarHelper::cancel();
					JToolBarHelper::help('help', true);
					
				}elseif($layout == 'trivia_messages'){
					
						$this->trivia_messages = $this->get('Trivia_messages');	
						$this->menuItems = $this->get('MenuItems');	
						
				}elseif($layout == 'qgroup_messages'){
					
						$this->qgroup_messages = $this->get('Qgroup_messages');	
						$this->menuItems = $this->get('MenuItems');	
						
				}elseif($layout == 'personality_messages'){
					
						$this->personality_messages = $this->get('Personality_messages');	
						$this->personality_category  = $this->get('p_c_personality_view');
						$this->menuItems = $this->get('MenuItems');	
						
				}else{
					
					$session->clear('trivia_message_session');
					$session->clear('personality_message_session');

					JToolBarHelper::title( JText::_('QUIZMANAGER'), 'question-2.png' );
					
					if($user->authorise('core.create','com_vquiz')){
						JToolBarHelper::addNew();
					}
					if(JFactory::getUser()->authorise('core.edit','com_vquiz')){
						JToolBarHelper::editList();
					}
					if(JFactory::getUser()->authorise('core.edit.state','com_vquiz')){
						JToolBarHelper::publish();
						JToolBarHelper::unpublish();
					}
					if(JFactory::getUser()->authorise('core.delete','com_vquiz')){
						JToolBarHelper::deleteList(JText::_('DO_YOU_WANT_DELETE_RECORD'));	
					}
						JToolBarHelper::custom( 'copy', 'copy', 'copy', JText::_('COM_VQUIZ_COPY'), false );
						JToolBarHelper::custom( 'move', 'move', 'move', JText::_('COM_VQUIZ_MOVE'), false );
					
					if(JFactory::getUser()->authorise('core.import','com_vquiz')){
						JToolBarHelper::custom( 'import', 'download', 'upload', JText::_('COM_VQUIZ_CSV_IMPORT'), false );
					}
					if(JFactory::getUser()->authorise('core.export','com_vquiz')){
										
						JToolBarHelper::custom( 'export', 'upload', 'download', JText::_( 'COM_VQUIZ_CSV_EXPORT'), false );
					}
					
					
					JToolBarHelper::help('help', true);
					$version = new JVersion;
					$joomla = $version->getShortVersion();
					$jversion = substr($joomla,0,3);
					$this->sidebar ='';
					if($jversion>=3.0)
					{
					$this->sidebar = JHtmlSidebar::render();
					}
					if(JFactory::getUser()->authorise('core.admin','com_vquiz')){
						JToolBarHelper::preferences('com_vquiz','', '','ACL');
					}
					
					$items = $this->get('Items');
					$this->assignRef( 'items', $items );
					$this->category  = $this->get('Category');
					$this->pagination = $this->get('Pagination');
					$lists['search']= $search;
					$lists['publish_item']= $publish_item;
					$requestcategoryid = JRequest::getVar('qcategoryid');
						
					if($qcategoryid and $requestcategoryid ){
						$lists['categorysearch']=$qcategoryid;
					}
					else{
						$lists['categorysearch']= $categorysearch;
					}
					
					$this->assignRef( 'lists', $lists );
					// Table ordering.
					$this->lists['order_Dir'] = $filter_order_Dir;
					$this->lists['order']     = $filter_order;

					
			   }
			   
			 parent::display($tpl);
	
		 }

}
