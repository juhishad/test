<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');

if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

//error_reporting(0);
//print_r($this->usergroup); exit;
?>
<script type="text/javascript">
Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
 
			if(!jQuery('input[name="title"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_PLANS_PLZ_ENTER_PLAN_TITLE', true); ?>');
				document.adminForm.title.focus();
				return false;
			}				
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}
</script>
<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">

<div class="row-fluid">

	<div class="span6">
	<fieldset class="form-horizontal">
		
		<legend><?php echo JText::_('COM_VQUIZ_PLANS_DETAILS' ); ?> </legend>
		
		<div class="control-group">
			<div class="control-label"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_TITLE'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_TITLE'); ?></label>
			</div>
			<div class="controls"><input type="text"  name="title" id="title" class="title" value="<?php echo $this->item->title;?>"/>
			</div>	
		</div>	
					
	</fieldset>
	</div>
	
	
	<div class="span6">
	
	</div>
	
</div>

<div class="col101">
    <fieldset class="adminform">
    <legend><?php echo JText::_('COM_VQUIZ_PLANS_DETAILS'); ?></legend>
        <table class="adminform table table-striped">
		
	    <tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_TITLE'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_TITLE'); ?></label></td>
			<td><input type="text"  name="title" id="title" class="title" value="<?php echo $this->item->title;?>"/></td>
        </tr>
		
		<tr>
			<td class="key" width="200"><label  class="hasTip" title="<?php echo JText::sprintf('ALIAS'); ?>"><?php echo JText::_('ALIAS'); ?></label></td>
			<td><input type="text"  name="alias" id="alias"  value="<?php echo $this->item->alias;?>" placeholder="Automatic Genarated" /></td>
        </tr>
		
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_STATUS'); ?>"><?php echo JText::_('COM_VQUIZ_STATUS'); ?></label></td>
			
			<td>
				<select  name="published" id="published" >
				<option value="1" <?php if($this->item->published==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?> </option>
				<option value="0" <?php if($this->item->published==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?> </option>
				</select>

			</td>
		</tr>
		
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_SELECT_USER_GROUP_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_SELECT_USER_GROUP_LBL'); ?></label></td>
			
			<td>
				<select  name="usergroup_id" id="usergroup_id" >
					<?php    for ($i=0; $i <count($this->usergroup); $i++)	
						{
						?>
						<option value="<?php echo $this->usergroup[$i]->id;?>"  <?php  if($this->usergroup[$i]->id == $this->item->usergroup_id) echo 'selected="selected"'; ?> >
						<?php echo $this->usergroup[$i]->title;?>
						</option>		
						<?php
						}
						?>
				</select>

			</td>
		</tr>
		
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('DESCRIPTIONS'); ?>"><?php echo JText::_('DESCRIPTIONS'); ?></label></td>
			
			<td>
				<?php $editor = JFactory::getEditor();
				echo $editor->display("description",  $this->item->description, "400", "300", "20", "5",true, null, null, null, array('mode' => 'simple'));?>

			</td>
		</tr>
		
		<tr>
			<td class="key"><label><?php echo JText::_('COM_VQUIZ_PLANS_TIME_PARAMETERS'); ?></label></td>
			
			
		</tr>
		
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_TIME_EXPIRATION_TYPE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_TIME_EXPIRATION_TYPE_LABEL'); ?></label></td>
			
			<td>
				<select name="expirationtype" id="expirationtype">
				 
				 <option value="forever"<?php if(isset($this->item->expirationtype)&&$this->item->expirationtype=='forever') echo ' selected="selected"';?>><?php echo JText::_('COM_VQUIZ_PLANS_TIME_EXPIRATION_FOREVER'); ?></option>
				 
				 <option value="fixed"<?php if(isset($this->item->expirationtype)&&$this->item->expirationtype=='fixed') echo ' selected="selected"';?>><?php echo JText::_('COM_VQUIZ_PLANS_TIME_EXPIRATION_FIXED'); ?></option>
				 
				
				 </select>

			</td>
		</tr>
		
		
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_PAYMENT_PRICE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_PAYMENT_PRICE_LBL'); ?></label></td>
			
			<td>
				<input name="price" min="0" type="number" class="number"  size="30" value="<?php echo $this->item->price;?>" />

			</td>
		</tr>
		
		<tr>
			<td class="key"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_TIME_EXPIRATION_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_TIME_EXPIRATION_LBL'); ?></label></td>
			
			<td>
				<input id="expiration" name="expiration" type="text"  size="30" value="<?php echo $this->item->expiration;?>" />
								   

			</td>
		</tr>
	   
       </table>
    </fieldset>

</div> 

<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="plans" />
</form>







