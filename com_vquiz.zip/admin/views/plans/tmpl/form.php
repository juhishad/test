<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');$document = JFactory::getDocument();$document->addStyleSheet('components/com_vquiz/assets/css/style.css');

if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

//error_reporting(0);
//print_r($this->usergroup); exit;
?>
<script type="text/javascript">
Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
 
			if(!jQuery('input[name="title"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_PLANS_PLZ_ENTER_PLAN_TITLE', true); ?>');
				document.adminForm.title.focus();
				return false;
			}				
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}
</script>
<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data"><div class="col101">

<div class="row-fluid">

	<div class="span6">
	<fieldset class="form-horizontal">
		
		<legend><?php echo JText::_('COM_VQUIZ_PLANS_DETAILS' ); ?> </legend>
		
		<div class="control-group">
			<div class="control-label"><label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_TITLE'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_TITLE'); ?></label>
			</div>
			
			<div class="controls"><input type="text"  name="title" id="title" class="title" value="<?php echo $this->item->title;?>"/>
			</div>	
		</div>
		
		<div class="control-group">
			<div class="control-label"><label  class="hasTip" title="<?php echo JText::sprintf('ALIAS'); ?>"><?php echo JText::_('ALIAS'); ?></label>
			</div>
			
			<div class="controls"><input type="text"  name="alias" id="alias"  value="<?php echo $this->item->alias;?>" placeholder="Automatic Genarated" />
			</div>	
		</div>
		
		<div class="control-group">
			<div class="control-label"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_STATUS'); ?>"><?php echo JText::_('COM_VQUIZ_STATUS'); ?></label>
			</div>
			
			<div class="controls"><select  name="published" id="published" >
				<option value="1" <?php if($this->item->published==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PUBLISHED'); ?> </option>
				<option value="0" <?php if($this->item->published==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_UNPUBLISHED'); ?> </option>
				</select>
			</div>	
		</div>
		
		<div class="control-group">
			<div class="control-label"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_SELECT_USER_GROUP_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_SELECT_USER_GROUP_LBL'); ?></label>
			</div>
			
			<div class="controls">
				<select  name="usergroup_id" id="usergroup_id" >
					<?php    for ($i=0; $i <count($this->usergroup); $i++)	
					{
					?>
					<option value="<?php echo $this->usergroup[$i]->id;?>"  <?php  if($this->usergroup[$i]->id == $this->item->usergroup_id) echo 'selected="selected"'; ?> >
					<?php echo $this->usergroup[$i]->title;?>
					</option>		
					<?php
					}
					?>
				</select>
			</div>	
		</div>
		
		<div class="control-group">
			<div class="control-label"><label class="hasTip" title="<?php echo JText::sprintf('DESCRIPTION'); ?>"><?php echo JText::_('DESCRIPTION'); ?></label>
			</div>
			
			<div class="controls">
				<?php $editor = JFactory::getEditor();
				echo $editor->display("description",  $this->item->description, "400", "300", "20", "5",true, null, null, null, array('mode' => 'simple'));?>
			</div>	
		</div>
					
	</fieldset>
	</div>
	
	
	<div class="span6">
		
		<fieldset class="form-horizontal">
			 <legend><?php echo JText::_( 'COM_VQUIZ_PLANS_TIME_PARAMETERS' ); ?></legend>
			 
		<div class="control-group">
			<div class="control-label"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_TIME_EXPIRATION_TYPE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_TIME_EXPIRATION_TYPE_LABEL'); ?></label>
			</div>
			
			<div class="controls">
				<select name="expirationtype" id="expirationtype">
				 
				 <option value="forever"<?php if(isset($this->item->expirationtype)&&$this->item->expirationtype=='forever') echo ' selected="selected"';?>><?php echo JText::_('COM_VQUIZ_PLANS_TIME_EXPIRATION_FOREVER'); ?></option>
				 
				 <option value="fixed"<?php if(isset($this->item->expirationtype)&&$this->item->expirationtype=='fixed') echo ' selected="selected"';?>><?php echo JText::_('COM_VQUIZ_PLANS_TIME_EXPIRATION_FIXED'); ?></option>
				 
				
				 </select>
			</div>		
			
		</div>
		
		<div class="control-group">
			<div class="control-label"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_PAYMENT_PRICE_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_PAYMENT_PRICE_LBL'); ?></label>
			</div>
			
			<div class="controls">
				<input name="price" min="0" type="number" class="number"  size="30" value="<?php echo $this->item->price;?>" />
			</div>		
			
		</div>
		
		<div class="control-group">
			<div class="control-label"><label class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PLANS_TIME_EXPIRATION_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_PLANS_TIME_EXPIRATION_LBL'); ?></label>
			</div>
			
			<div class="controls exp_time">
				
				<!--<input id="expiration" name="expiration" type="text"  size="30" value="<?php// echo $this->item->expiration;?>" />-->
				
				<?php $expiration_arr = str_split($this->item->expiration, 2); ?>
				
				<?php echo JText::_('COM_VQUIZ_PLANS_Y'); ?> <select name="expiration_year">
				 <?php for($i=0 ; $i<=10 ; $i++){ ?>					 
				 
				 <option value="<?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?>" <?php if(isset($expiration_arr[0])&&$expiration_arr[0]==$i) echo ' selected="selected"';?>><?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?></option>
				 
				 <?php } ?> 
				
				 </select>
				 
				 <?php echo JText::_('COM_VQUIZ_PLANS_M'); ?> <select name="expiration_month">
				 <?php for($i=0 ; $i<=11 ; $i++){ ?>					 
				 
				 <option value="<?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?>" <?php if(isset($expiration_arr[1])&&$expiration_arr[1]==$i) echo ' selected="selected"';?>><?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?></option>
				 
				 <?php } ?> 
				
				 </select>
				 
				 <?php echo JText::_('COM_VQUIZ_PLANS_D'); ?> <select name="expiration_day">
				 <?php for($i=0 ; $i<=30 ; $i++){ ?>					 
				 
				 <option value="<?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?>" <?php if(isset($expiration_arr[2])&&$expiration_arr[2]==$i) echo ' selected="selected"';?>><?php echo str_pad($i,2,"0",STR_PAD_LEFT); ?></option>
				 
				 <?php } ?> 
				
				 </select>
				 
			</div>		
			
		</div>
		
		</fieldset>
		
	</div>
	
</div>



<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="plans" /></div>
</form>







