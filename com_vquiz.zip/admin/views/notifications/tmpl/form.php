<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.tooltip');
JHTML::_('behavior.modal');
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/select2.min.css');
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
$document->addScript('components/com_vquiz/assets/js/select2.min.js');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');

//error_reporting(0);
//echo "<pre>";print_r($this->item);
//var_dump($this->item->applicable_user); //exit;

?>
<style type="text/css">
	.chzn-container-multi{
		display:none;
	}
	
</style>

<script type="text/javascript">

var jq=jQuery.noConflict();
jq(document).ready(function(){
	
	jq('#type').on("change",function(){
		var type= jq("#type").val();
		if(type == 1 || type == 2){
			jq("#selectTime").show();
		}
		else{
			jq("#selectTime").hide();
		}
		if(type==1){
			jq("#timeLabel").replaceWith('<td id="timeLabel"><label  class="hasTip" title="<?php echo JText::sprintf("COM_VQUIZ_PRE_EXPIRY_TIME"); ?>"><?php echo JText::_("COM_VQUIZ_PRE_EXPIRY_TIME"); ?></label></td>');
		}
		if(type==2){
			jq("#timeLabel").replaceWith('<td id="timeLabel"><label  class="hasTip" title="<?php echo JText::sprintf("COM_VQUIZ_POST_EXPIRY_TIME"); ?>"><?php echo JText::_("COM_VQUIZ_POST_EXPIRY_TIME"); ?></label></td>');
		}
	});
	
	jq(".js-example-tags").select2({
			tags: true
		})

});
	
Joomla.submitbutton = function(task) {
		if (task == 'cancel') {
			
			Joomla.submitform(task, document.getElementById('adminForm'));
		} else {
 
			/* if(!jQuery('input[name="codes"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_COUPONS_PLZ_ENTER_COUPON_CODE', true); ?>');
				document.adminForm.codes.focus();
				return false;
			}
			if(!jQuery('input[name="offer"]').val()){
				alert('<?php echo JText::_('COM_VQUIZ_COUPONS_PLZ_ENTER_COUPON_DISCOUNT', true); ?>');
				document.adminForm.offer.focus();
				return false;
			} */			
			Joomla.submitform(task, document.getElementById('adminForm'));
			
		}
	}
</script>
<form action="index.php?option=com_vquiz" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
	<?php if (!empty( $this->sidebar)) : ?>   
	<div id="j-sidebar-container" class="span2">
	<?php echo $this->sidebar; ?>
	</div>
	<div id="j-main-container" class="span10">
	<?php else : ?>
	<div id="j-main-container">
	<?php endif;?>
	<div class="span4">
		<label><p><?php echo JText::_('COM_VQUIZ_NOTIFICATION_EMAILER_DETAILS');?></p></label>
        <table class="adminform table table-striped">
		
	    <tr>			
			<td class="key" width="200">
				<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_NOTIFICATION_TITLE'); ?>"><?php echo JText::_('COM_VQUIZ_NOTIFICATION_TITLE'); ?><span class="star">*</span></label>
			</td>			
			<td>
				<input type="text"  name="title" id="" class="title" value="<?php echo $this->item->title;?>"/>
			</td>			
        </tr>		
		<tr>			
			<td class="key">
				<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_ENABLED'); ?>"><?php echo JText::_('COM_VQUIZ_ENABLED'); ?></label>
			</td>			
			<td>
				<fieldset class="radio btn-group">
					<label for="published1" id="published1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_ENABLED'); ?></label>
					<input type="radio" name="published" id="published1" value="1" <?php if($this->item->published ==1) echo 'checked="checked"';?>/>
					<label for="published0" id="published0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_DISABLED'); ?></label>
					<input type="radio" name="published" id="published0" value="0" <?php if($this->item->published ==0) echo 'checked="checked"';?>/>
				</fieldset>
			</td>			
        </tr>
		<tr>			
			<td class="key">
				<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_NOTIFICATION_DESC'); ?>"><?php echo JText::_('COM_VQUIZ_NOTIFICATION_DESC'); ?></label>
			</td>			
			<td>
				<textarea rows="5" name="description"><?php echo $this->item->description?></textarea>
			</td>			
        </tr>
		   
       </table>

	</div> 
	<div class="span8">
		<label><p><?php echo JText::_('COM_VQUIZ_NOTIFICATION_PARAMETERS');?></p></label>
		<table class="adminform table table-striped">
			<tr>
				<td width="100">
					<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_WHEN_TO_EMAIL'); ?>"><?php echo JText::_('COM_VQUIZ_WHEN_TO_EMAIL'); ?></label>
				</td>
			
				<td>
					<select  name="type" id="type">
						<option value="0" <?php if($this->item->type==0) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_SELECT'); ?> </option>
						
						<option value="1" <?php if($this->item->type==1) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_PRE_EXPIRATION'); ?> </option>
						
						<option value="2" <?php if($this->item->type==2) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_POST_EXPIRATION'); ?> </option>
						
						<option value="3" <?php if($this->item->type==3) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_ACTIVATION_SUBSCRIPTION'); ?> </option>
						
						<option value="4" <?php if($this->item->type==4) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_EXPIRE_SUBSCRIPTION'); ?> </option>
												
						<option value="5" <?php if($this->item->type==5) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_ADD_NEW_CATEGORY'); ?> </option>
						
						<option value="6" <?php if($this->item->type==6) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_ADD_NEW_QUIZZES'); ?> </option>
						
						<option value="7" <?php if($this->item->type==7) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_ADD_NEW_LEARNING_PATH'); ?> </option>
						
						<option value="8" <?php if($this->item->type==8) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_ADD_NEW_LESSION'); ?> </option>
						
						<option value="9" <?php if($this->item->type==9) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_ADD_NEW_SKILL'); ?> </option>
						
						<option value="10" <?php if($this->item->type==10) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_REGISTER_NEW_USER'); ?> </option>
						
						<option value="11" <?php if($this->item->type==11) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_SEND_NEW_INVITATION'); ?> </option>
						
						<option value="12" <?php if($this->item->type==12) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_COMPLETE_INVITATION'); ?> </option>
						
						<option value="13" <?php if($this->item->type==13) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_SEND_CERTIFICATE'); ?> </option>
												
						<option value="14" <?php if($this->item->type==14) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_QUIZ_COMPLETION'); ?> </option>
						
						<option value="15" <?php if($this->item->type==15) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_LEARNING_PATH_COMPLETION'); ?> </option>
						
						<option value="16" <?php if($this->item->type==16) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_INCOMPLETE_QUIZ'); ?> </option>
						
						<option value="17" <?php if($this->item->type==17) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_INCOMPLETE_ORDER'); ?> </option>
						
					</select>
				</td>
			</tr>
			<?php
				if($this->item->type==1 || $this->item->type==2)
					$isDisplay = '';
				else
					$isDisplay = 'style="display:none"';
			?>
			<tr id="selectTime" <?php echo $isDisplay;?>>
				<td id="timeLabel">
					<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_PRE_EXPIRY_TIME'); ?>"><?php echo JText::_('COM_VQUIZ_PRE_EXPIRY_TIME'); ?></label>
				</td>
				<td>
					<select name="days" id="days">
						<option value="0" <?php if($this->item->days==0) echo 'selected="selected"';?>><?php echo JText::_('COM_VQUIZ_SELECT'); ?> </option>
						<option value="1" <?php if($this->item->days==1) echo 'selected="selected"';?>>1</option>
						<option value="2" <?php if($this->item->days==2) echo 'selected="selected"';?>>2</option>
						<option value="3" <?php if($this->item->days==3) echo 'selected="selected"';?>>3</option>
						<option value="4" <?php if($this->item->days==4) echo 'selected="selected"';?>>4</option>
						<option value="5" <?php if($this->item->days==5) echo 'selected="selected"';?>>5</option>
						<option value="6" <?php if($this->item->days==6) echo 'selected="selected"';?>>6</option>
						<option value="7" <?php if($this->item->days==7) echo 'selected="selected"';?>>7</option>
						<option value="8" <?php if($this->item->days==8) echo 'selected="selected"';?>>8</option>
						<option value="9" <?php if($this->item->days==9) echo 'selected="selected"';?>>9</option>
						<option value="10" <?php if($this->item->days==10) echo 'selected="selected"';?>>10</option>
						<option value="11" <?php if($this->item->days==11) echo 'selected="selected"';?>>11</option>
						<option value="12" <?php if($this->item->days==12) echo 'selected="selected"';?>>12</option>
						<option value="13" <?php if($this->item->days==13) echo 'selected="selected"';?>>13</option>
						<option value="14" <?php if($this->item->days==14) echo 'selected="selected"';?>>14</option>
						<option value="15" <?php if($this->item->days==15) echo 'selected="selected"';?>>15</option>
						<option value="16" <?php if($this->item->days==16) echo 'selected="selected"';?>>16</option>
						<option value="17" <?php if($this->item->days==17) echo 'selected="selected"';?>>17</option>
						<option value="18" <?php if($this->item->days==18) echo 'selected="selected"';?>>18</option>
						<option value="19" <?php if($this->item->days==19) echo 'selected="selected"';?>>19</option>
						<option value="20" <?php if($this->item->days==20) echo 'selected="selected"';?>>20</option>
						<option value="21" <?php if($this->item->days==21) echo 'selected="selected"';?>>21</option>
						<option value="22" <?php if($this->item->days==22) echo 'selected="selected"';?>>22</option>
						<option value="23" <?php if($this->item->days==23) echo 'selected="selected"';?>>23</option>
						<option value="24" <?php if($this->item->days==24) echo 'selected="selected"';?>>24</option>
						<option value="25" <?php if($this->item->days==25) echo 'selected="selected"';?>>25</option>
						<option value="26" <?php if($this->item->days==26) echo 'selected="selected"';?>>26</option>
						<option value="27" <?php if($this->item->days==27) echo 'selected="selected"';?>>27</option>
						<option value="28" <?php if($this->item->days==28) echo 'selected="selected"';?>>28</option>
						<option value="29" <?php if($this->item->days==29) echo 'selected="selected"';?>>29</option>						
						<option value="30" <?php if($this->item->days==30) echo 'selected="selected"';?>>30</option>
					</select>					
				</td>
			</tr>
			<tr>
				<td>
					<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_EMAIL_CC'); ?>"><?php echo JText::_('COM_VQUIZ_EMAIL_CC'); ?></label>
				</td>
				<td>
				<select name="email_cc[]" id="email_cc" class="js-example-tags" multiple>
							<?php 
							
							$email_cc=explode(',',$this->item->email_cc);

							 if(!empty($email_cc)){
								for($j=0;$j<count($email_cc);$j++){?>
								<option value="<?php echo $email_cc[$j];?>" selected='selected'><?php echo $email_cc[$j];?></option>
							<?php 
								}
							} 
							?>
						</select></td>
			</tr>
			<tr>
				<td>
					<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_EMAIL_BCC'); ?>"><?php echo JText::_('COM_VQUIZ_EMAIL_BCC'); ?></label>
				</td>
				<td>
				<select name="email_bcc[]" id="email_bcc" class="js-example-tags" multiple>
							<?php 
							
							$email_bcc=explode(',',$this->item->email_bcc);

							 if(!empty($email_bcc)){
								for($j=0;$j<count($email_bcc);$j++){?>
								<option value="<?php echo $email_bcc[$j];?>" selected='selected'><?php echo $email_bcc[$j];?></option>
							<?php 
								}
							} 
							?>
						</select></td>
			</tr>
			<tr>			
				<td class="key">
					<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_EMAIL_QUIZ_CREATOR'); ?>"><?php echo JText::_('COM_VQUIZ_EMAIL_QUIZ_CREATOR'); ?></label>
				</td>			
				<td>
					<fieldset class="radio btn-group">
						<label for="send_to_creator1" id="send_to_creator1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_YES'); ?></label>
						<input type="radio" name="send_to_creator" id="send_to_creator1" value="1" <?php if($this->item->send_to_creator ==1) echo 'checked="checked"';?>/>
						<label for="send_to_creator0" id="send_to_creator0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_NO'); ?></label>
						<input type="radio" name="send_to_creator" id="send_to_creator0" value="0" <?php if($this->item->send_to_creator ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>			
			</tr>
			<tr>			
				<td class="key">
					<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_EMAIL_QUIZ_MODEATOR'); ?>"><?php echo JText::_('COM_VQUIZ_EMAIL_QUIZ_MODEATOR'); ?></label>
				</td>			
				<td>
					<fieldset class="radio btn-group">
						<label for="send_to_moderator1" id="send_to_moderator1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_YES'); ?></label>
						<input type="radio" name="send_to_moderator" id="send_to_moderator1" value="1" <?php if($this->item->send_to_moderator ==1) echo 'checked="checked"';?>/>
						<label for="send_to_moderator0" id="send_to_moderator0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_NO'); ?></label>
						<input type="radio" name="send_to_moderator" id="send_to_moderator0" value="0" <?php if($this->item->send_to_moderator ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>			
			</tr>
			<tr>			
				<td class="key">
					<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_EMAIL_SUPERUSER'); ?>"><?php echo JText::_('COM_VQUIZ_EMAIL_SUPERUSER'); ?></label>
				</td>			
				<td>
					<fieldset class="radio btn-group">
						<label for="send_to_superuser1" id="send_to_superuser1-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_YES'); ?></label>
						<input type="radio" name="send_to_superuser" id="send_to_superuser1" value="1" <?php if($this->item->send_to_superuser ==1) echo 'checked="checked"';?>/>
						<label for="send_to_superuser0" id="send_to_superuser0-lbl" class="radio"><?php echo JText::_('COM_VQUIZ_NO'); ?></label>
						<input type="radio" name="send_to_superuser" id="send_to_superuser0" value="0" <?php if($this->item->send_to_superuser ==0) echo 'checked="checked"';?>/>
					</fieldset>
				</td>			
			</tr>
			<tr>
				<td>
					<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_EMAIL_SUBJECT'); ?>"><?php echo JText::_('COM_VQUIZ_EMAIL_SUBJECT'); ?></label>
				</td>
				<td><textarea rows="5" name="email_subject"><?php echo $this->item->email_subject;?></textarea></td>
			</tr>
			</tr>
			<tr>
				<td>
					<label  class="hasTip" title="<?php echo JText::sprintf('COM_VQUIZ_EMAIL_CONTENT'); ?>"><?php echo JText::_('COM_VQUIZ_EMAIL_CONTENT'); ?></label>
				</td>
				<td>
					<?php 

					$editor = JFactory::getEditor();
					$email_content = $this->item->email_content;
					
					echo $editor->display("email_content",  $email_content, "100%", "50%", "10", "5",true, null, null, null, array());
					
					?>
					
					<div class="conf_right_panel">
								<h3><?php echo JText::_("COM_VQUIZ_PARAMETER");?></h3>
										<div class="">
											
											<!-- Categories -->
											
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{quizcategory}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUIZ_CATEGORY')?>">{quizcategory}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{quiztitle}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUIZ_TITLE')?>">{quiztitle}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{username}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERNAME')?>">{username}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{firstname}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USER_FIRSTNAME')?>">{firstname}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{middlename}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USER_MIDDLENAME')?>">{middlename}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{lastname}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USER_LASTNAME')?>">{lastname}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{email}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_EMAIL')?>">{email}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{learningtitle}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_LEARNING_TITLE')?>" >{learning_title}</span></a>
							<br>
							
							<a  onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{lesson_title}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_LESSON_TITLE')?>" >{lesson_title}</span></a>
							<br>


							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{quizname}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUIZNAME')?>">{quizname}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{startdate}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_STARTTIME')?>">{startdate}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{enddate}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_ENDTIME')?>">{enddate}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{startdate}', 'params_Value');return false;" href="javascript:void(0);">{starttime}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{enddate}', 'params_Value');return false;" href="javascript:void(0);">{endtime}</a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{maxscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_MAXSCORE')?>">{maxscore}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{userscore}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_USERSCORE')?>">{userscore}</span></a>
							<br>

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{passed}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PASSED')?>">{passed}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{total_questions}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_TOTAL_QUESTIONS')?>">{total_questions}</span></a>
							
							<br>
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{given_answers}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_GIVEN_ANSWERS')?>">{given_answers}</span></a>
							
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{play_date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_DATE')?>">{play_date}</span></a>
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_CURRENT_DATE')?>">{current_date}</span></a>
							<br>
							

							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{quizurl}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_QUIZ_URL')?>">{quizurl}</span></a>							
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{skill_title}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_SKILL_TITLE')?>">{skill_title}</span></a>					
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{plan_title}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_PLAN_TITLE')?>">{plan_title}</span></a>					
							<br>
							
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{buyer_name}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_BUYER_NAME')?>">{buyer_name}</span></a>					
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{subscription_date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_SUBSCRIPTION_DATE')?>">{subscription_date}</span></a>		
							<br>						
														
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{expiration_date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_EXPIRATION_DATE')?>">{expiration_date}</span></a>		
							<br>
							
							<a onclick="if (typeof(jInsertEditorText) != 'undefined') jInsertEditorText('{order_date}', 'params_Value');return false;" href="javascript:void(0);"><span class="hasTip" title="<?php echo JText::_('COM_VQUIZ_KEYWORD_ORDER_DATE')?>">{order_date}</span></a>		
							<br>
							
							
							

										</div>
									</div>
									
				</td>
			</tr>
		</table>
	</div>

<div class="clr"></div>

<?php echo JHTML::_( 'form.token' ); ?>

<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="view" value="notifications" />
</div>
</form>







