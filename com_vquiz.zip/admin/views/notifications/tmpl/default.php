<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.html.pagination');	
JHtml::_('behavior.tooltip');
if(version_compare(JVERSION, '3.0', '>=')) 
JHtml::_('formbehavior.chosen', 'select');
$document = JFactory::getDocument();
$document->addStyleSheet('components/com_vquiz/assets/css/style.css');
//$document->addScript('components/com_vquiz/assets/js/jquery-ui.js');

//echo '<pre>';print_r( $this->items ); exit;

		
		
?>
												
<div class="poploadingbox">
<?php echo '<img src="'.JURI::root().'/components/com_vquiz/assets/images/loading.gif"/>' ?>
</div>
<form action="index.php?option=com_vquiz&view=notifications" method="post" name="adminForm" id="adminForm" enctype="multipart/form-data">
<?php if (!empty( $this->sidebar)) : ?>   
		<div id="j-sidebar-container" class="span2">
		<?php echo $this->sidebar; ?>
		</div>
		<div id="j-main-container" class="span10">
		<?php else : ?>
		<div id="j-main-container">
		<?php endif;?>
		
            <div class="search_buttons">
                <div class="btn-wrapper input-append">
                <input placeholder="Search" type="text" name="search" id="search" value="<?php echo $this->lists['search'];?>" class="text_area" onchange="document.adminForm.submit();" />
                <button class="btn" onclick="this.form.submit();"><i class="icon-search"></i><span class="search_text"><?php echo JText::_('COM_VQUIZ_SEARCH'); ?></button>
                <button class="btn" onclick="document.getElementById('search').value='';this.form.submit();"><?php echo JText::_('COM_VQUIZ_RESET'); ?></button>
                </div>
            </div>
	
			<div class="btn-group pull-right hidden-phone">

				<select name="publish_item" id="publish_item"class="inputbox" onchange="this.form.submit()">
					<option value=""><?php echo JText::_('COM_VQUIZ_STATE');?></option>
					<option value="p" <?php  if( 'p'== $this->lists['publish_item']) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_ENABLED');?></option>
					<option value="u" <?php  if('u'== $this->lists['publish_item']) echo 'selected="selected"'; ?>><?php echo JText::_('COM_VQUIZ_DISABLED');?></option>
				</select>

				<label for="limit" class="element-invisible"><?php echo JText::_('JFIELD_PLG_SEARCH_SEARCHLIMIT_DESC');?></label>
				<?php echo $this->pagination->getLimitBox(); ?>
			</div>
			
<div id="editcell">
	<table class="adminlist table table-striped table-hover">
	<thead>
		<tr>
        	<th width="5">
                 <?php echo JText::_('COM_VQUIZ_NOTIFICATION_NUM_LBL'); ?>
			</th>
			
			<th width="20">
			<input type="checkbox" name="toggle" value="" onclick="Joomla.checkAll(this);" />
			</th>
			
			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_NOTIFICATION_TITLE', 'i.offer', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
                 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_NOTIFICATION_TYPE', 'i.type_offer', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
				 <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_STATUS', 'i.published', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>	
			</th>
			
			<th>
				<?php echo JHTML::_('grid.sort', 'COM_VQUIZ_NOTIFICATION_CREATED', 'i.expiry_date', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
			<th>
				<?php echo JHTML::_('grid.sort', 'COM_VQUIZ_NOTIFICATION_CREATED_BY', 'i.code_used', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
			
            <th width="5">
				  <?php echo JHTML::_('grid.sort', 'COM_VQUIZ_NOTIFICATION_ID_LBL', 'i.id', @$this->lists['order_Dir'], @$this->lists['order'] ); ?>
			</th>
		</tr>
	</thead>
    
	<?php

	$k = 0;
	for ($i=0, $n=count( $this->items ); $i < $n; $i++)	{
		$row = &$this->items[$i];
        
		$checked 	= JHTML::_('grid.id',   $i, $row->id );
		
		$link 		= JRoute::_( 'index.php?option=com_vquiz&view=notifications&task=edit&cid[]='. $row->id );		
				
		if(JFactory::getUser()->authorise('core.edit.state','com_vquiz'))
			$published  = JHTML::_( 'jgrid.published', $row->published, $i );
		else{
			if($row->published==1)
				$published  = JText::_('COM_VQUIZ_ENABLED');
			else
				$published  = JText::_('COM_VQUIZ_DISABLED');
		}
		
		?>

		<tr class="<?php echo "row$k"; ?>">
			
			<td><?php echo $this->pagination->getRowOffset($i); ?></td>
			
			<td>
				<?php echo $checked; ?>
			</td>

			<td>
		    <a href="<?php echo $link; ?>"> <?php echo $row->title;  ?></a>
			</td>
			
			<td align="center">
				<?php switch($row->type){
					case 1:
						echo JText::_('COM_VQUIZ_PRE_EXPIRATION');
						break;
					case 2:
						echo JText::_('COM_VQUIZ_POST_EXPIRATION');
						break;
					case 3:
						echo JText::_('COM_VQUIZ_ACTIVATION_SUBSCRIPTION');
						break;
					case 4:
						echo JText::_('COM_VQUIZ_EXPIRE_SUBSCRIPTION');
						break;
					case 5:
						echo JText::_('COM_VQUIZ_ADD_NEW_CATEGORY');
						break;
					case 6:
						echo JText::_('COM_VQUIZ_ADD_NEW_QUIZZES');
						break;
					case 7:
						echo JText::_('COM_VQUIZ_ADD_NEW_LEARNING_PATH');
						break;
					case 8:
						echo JText::_('COM_VQUIZ_ADD_NEW_LESSION');
						break;
					case 9:
						echo JText::_('COM_VQUIZ_ADD_NEW_SKILL');
						break;
					case 10:
						echo JText::_('COM_VQUIZ_REGISTER_NEW_USER');
						break;
					case 11:
						echo JText::_('COM_VQUIZ_SEND_NEW_INVITATION');
						break;
					case 12:
						echo JText::_('COM_VQUIZ_COMPLETE_INVITATION');
						break;
					case 13:
						echo JText::_('COM_VQUIZ_SEND_CERTIFICATE');
						break;					
					case 14:
						echo JText::_('COM_VQUIZ_QUIZ_COMPLETION');
						break;
					case 15:
						echo JText::_('COM_VQUIZ_LEARNING_PATH_COMPLETION');
						break;
					case 16:
						echo JText::_('COM_VQUIZ_INCOMPLETE_QUIZ');
						break;
					case 17:
						echo JText::_('COM_VQUIZ_INCOMPLETE_ORDER');
						break;
				} ?> 
			</td>
						
			<td class="center publish_unpublish">
				<?php echo $published; ?>
			</td> 
			
			<td align="center">
				<?php echo $row->created_date; ?>
			</td>
			
			<td align="center">
				<?php echo JFactory::getUser($row->created_by)->username; ?>
			</td>	
			
			<td><?php echo $row->id;  ?></td>
			
		</tr>
		<?php
		$k = 1 - $k;
	}
	?>
	
	<tfoot>
    <tr>
    <td colspan="11"> <?php echo $this->pagination->getListFooter(); ?></td>
    </tr>
    </tfoot>
	
	</table>

</div>
<input type="hidden" name="option" value="com_vquiz" />
<input type="hidden" name="task" value="" />
<input type="hidden" name="boxchecked" value="0" />
<input type="hidden" name="view" value="notifications" />
<input type="hidden" name="tmpl" value="<?php echo JRequest::getVar('tmpl', 'index'); ?>" />
<input type="hidden" name="filter_order" value="<?php echo $this->lists['order']; ?>" />
<input type="hidden" name="filter_order_Dir" value="<?php echo $this->lists['order_Dir']; ?>" />
</div>  
</form>



