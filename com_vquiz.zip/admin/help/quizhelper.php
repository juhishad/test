<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
class QuizHelper
{ 
   
	// Subscriptions
	const NONE	    = 4;
	const SUBSCRIPTION_ACTIVE	= 1;
	const SUBSCRIPTION_HOLD		= 2;
	const SUBSCRIPTION_EXPIRED	= 3;
	const SUBSCRIPTION_NONE	    = 4;
	
	// Orders
	const ORDER_NONE		    = 30;
	const ORDER_PAID		    = 31;
	const ORDER_HOLD 		    = 32;
	const ORDER_EXPIRED 		= 33;    
	const ORDER_CANCEL 			= 34;
	const ORDER_REFUND 			= 35;
	
	function __construct($time=null)
	{
		
		$subscriptions = QuizHelper::getActiveSubscriptionsWhichAreExpried($time); 
		foreach($subscriptions as $subscription){ 
			$subscriptionDetail = QuizHelper::subscriptionDetail($subscription->id);
			$orderDetail = QuizHelper::orderDetail($subscription->id);
			if($subscriptionDetail->status==QuizHelper::SUBSCRIPTION_ACTIVE){
				$db = JFactory::getDbo();
				$query = 'update #__vquiz_plans_subscription set `status`='.$db->quote(QuizHelper::SUBSCRIPTION_EXPIRED).' where `id`='.$db->quote($subscription->id);
				$db->setQuery($query);
				$db->execute(); 
				$query = 'select * from `#__vquiz_plans_order` where `order_id`=(select max(order_id) from `#__vquiz_plans_order` where `subscr_id`='.$db->quote($subscription->id).' AND `status`="31")';
				$db->setQuery($query);
				$lastorder = $db->loadObject();
				
				$query = 'update #__vquiz_plans_order set `status`='.$db->quote(QuizHelper::ORDER_EXPIRED).' where `order_id`='.$db->quote($lastorder->order_id);
				$db->setQuery($query);
				$db->execute(); 
			
			}
		}
		return true;
	}
	
   public static function planDetails($subid=false,$planid=false){
	    $db=JFactory::getDbo();
        $query=$db->getQuery(true);
		$query->select('s.*, p.*');
        $query->from('#__vquiz_plans_subscription AS s');
        $query->join('LEFT', $db->quoteName('#__vquiz_plans', 'p') . ' ON (' . $db->quoteName('s.plan_id') . ' = ' . $db->quoteName('p.id') . ')');
        if($subid)		
         $query->where($db->quoteName('s.id') . ' = '.$db->quote($subid));
          if($planid)		
         $query->where($db->quoteName('p.id') . ' = '.$db->quote($planid));	 
	     $db->setQuery($query);
		 return $db->loadObject();
   }
   public static function planDetail($planid=false){
	    $db=JFactory::getDbo();
        $query=$db->getQuery(true);
		$query->select('p.*');
        $query->from('#__vquiz_plans AS p');
         if($planid)		
         $query->where($db->quoteName('p.id') . ' = '.$db->quote($planid));	 
	     $db->setQuery($query);
		 return $db->loadObject();
   }
   public static function subscriptionDetail($subid=false){
	    $db=JFactory::getDbo();
        $query=$db->getQuery(true);
		$query->select('s.*');
        $query->from('#__vquiz_plans_subscription AS s');
         if($subid)		
         $query->where($db->quoteName('s.id') . ' = '.$db->quote($subid));	 
	     $db->setQuery($query);
		 return $db->loadObject();
   }
   public static function lastOrderDetail($sub_id=false){
	    $db=JFactory::getDbo();
		if(!$sub_id){ 
			return array();
		}
		
	   $query = 'select * from `#__vquiz_plans_order` where `order_id`=(select max(order_id) from `#__vquiz_plans_order` where `subscr_id`='.$db->quote($sub_id).')';
	   $db->setQuery($query); 
	   $data = $db->loadObject();
	   return $data;
	   
   }
    public static function orderDetail($oid=false){
	    $db=JFactory::getDbo();
        $query=$db->getQuery(true);
		$query->select('s.*');
        $query->from('#__vquiz_plans_order AS s');
         if($oid)		
         $query->where($db->quoteName('s.order_id') . ' = '.$db->quote($oid));	 
	     $db->setQuery($query);
		 return $db->loadObject();
   }
	public static function getPaymentPlugins()
	{   $view = JRequest::getVar('view', 'vquiz');
		$db=JFactory::getDbo();
        $query=$db->getQuery(true);
		$query->select('*');
        $query->from('#__vquiz_payment_plugin AS p');
		$db->setQuery($query);
		$db->Query($query);
            if( $db->getNumRows() > 0 ) {
			JSubMenuHelper::addEntry( '<span class="configuration" title="'.JText::_('COM_VQUIZ_PLANS_DESC').'">'.JText::_('COM_VQUIZ_PLANS').'</span>' , 'index.php?option=com_vquiz&view=plans', $view == 'plans' );
			JSubMenuHelper::addEntry( '<span class="configuration" title="'.JText::_('COM_VQUIZ_SUBSCRIPTIONS_DESC').'">'.JText::_('COM_VQUIZ_SUBSCRIPTIONS').'</span>' , 'index.php?option=com_vquiz&view=subscriptions', $view == 'subscriptions' );
			JSubMenuHelper::addEntry( '<span class="configuration" title="'.JText::_('COM_VQUIZ_INVOICES_DESC').'">'.JText::_('COM_VQUIZ_INVOICES').'</span>' , 'index.php?option=com_vquiz&view=orders', $view == 'orders' );
	        JSubMenuHelper::addEntry( '<span class="configuration" title="'.JText::_('COM_VQUIZ_PAYMENT_APP_DESC').'">'.JText::_('COM_VQUIZ_PAYMENT_APP').'</span>' , 'index.php?option=com_vquiz&view=paymentapp', $view == 'paymentapp' ); 
			}
			JSubMenuHelper::addEntry( '<span class="configuration" title="'.JText::_('COM_VQUIZ_COUPON_DESC').'">'.JText::_('COM_VQUIZ_COUPON').'</span>' , 'index.php?option=com_vquiz&view=coupons', $view == 'coupons' );
			
	}
	static function edit($name, $value, $class)
	{
		// $prefix = $control_name.$name;
		$selected_value = str_split($value, 2); 
		$yearHtml = '<span >'.JText::_('COM_QUIZ_TIMER_YEARS').'</span>'
					.'<select class="'.$class.'" name="'.$class.'_year" id="'.$class.'_year" style="width:auto;" >';
		$monthHtml= '<span >'.JText::_('COM_QUIZ_TIMER_MONTHS').'</span>'
					.'<select class="'.$class.'" name="'.$class.'_month" id="'.$class.'_month" style="width:auto;">';
		$dayHtml  = '<span >'.JText::_('COM_QUIZ_TIMER_DAYS').'</span>'
					.'<select class="'.$class.'" name="'.$class.'_day" id="'.$class.'_day" style="width:auto;" >';
		$hourHtml = '<span >'.JText::_('COM_QUIZ_TIMER_HOURS').'</span>'
					.'<select class="'.$class.'" name="'.$class.'_hour" id="'.$class.'_hour" style="width:auto;" >';
		$minHtml  = '<span >'.JText::_('COM_QUIZ_TIMER_MINUTES').'</span>'
					.'<select class="'.$class.'" name="'.$class.'_minute" id="'.$class.'_minute" style="width:auto;" >';
		$secHtml  = '<span>'.JText::_('COM_QUIZ_TIMER_SECONDS').'</span>'
					.'<select class="'.$class.'" name="'.$class.'_second" id="'.$class.'_second" style="width:auto;" >';		 
			
		for($count=0 ; $count<=60 ; $count++){
			$yearHtml  .= ($count<=10) ? '<option value="'.$count.'"'.(count($selected_value)>0&&(int)$selected_value[0]==$count?' selected="selected"':'').'>'.$count.'</option>' : '';
			$monthHtml .= ($count<=11) ? '<option value="'.$count.'"'.(count($selected_value)>0&&(int)$selected_value[1]==$count?' selected="selected"':'').'>'.$count.'</option>' : '';
			$dayHtml   .= ($count<=30) ? '<option value="'.$count.'"'.(count($selected_value)>0&&(int)$selected_value[2]==$count?' selected="selected"':'').'>'.$count.'</option>' : '';
			$hourHtml  .= ($count<=23) ? '<option value="'.$count.'"'.(count($selected_value)>0&&(int)$selected_value[3]==$count?' selected="selected"':'').'>'.$count.'</option>' : '';
			$minHtml   .= ($count<=59) ? '<option value="'.$count.'"'.(count($selected_value)>0&&(int)$selected_value[4]==$count?' selected="selected"':'').'>'.$count.'</option>' : '';
			$secHtml   .= ($count<=59) ? '<option value="'.$count.'"'.(count($selected_value)>0&&(int)$selected_value[5]==$count?' selected="selected"':'').'>'.$count.'</option>' : '';
		}

		$yearHtml  .= '</select> ';
		$monthHtml .= '</select> ';
		$dayHtml   .= '</select> ';
		$hourHtml  .= '</select> ';
		$minHtml   .= '</select> ';
		$secHtml   .= '</select> ';

		$text = '<span id="'.$class.'" >&nbsp;</span>';

		//IMP : due to js incorrect calculation NaN gets set in the value 
		// which ultimately results incorrect time so NaN is replaced with default value
		$value = str_replace('NaN', '00', $value);
		$hidden = '<input type="hidden" id="'.$class.'" name="'.$name.'" value="'.$value.'" />';
		
		self::_setupTimerScript();
	    
		ob_start();
		?>
		jQuery(function(){ 
			quizplans.element.timer.setup('<?php echo $class;?>', '<?php echo $value;?>');			
		});
		<?php
		$content = ob_get_contents();
		ob_end_clean();
		JFactory::getDocument()->addScriptDeclaration($content);

		$micro = '<span class="hide">'.$hourHtml.$minHtml.$secHtml.'</span>';
		
		return 	'<div id="timer-warp-'.$class.'">
					<div class="readable pp-mouse-pointer">
						<span class="pp-icon-edit">&nbsp;</span>
						<span class="pp-content"></span>
					</div>
					<div class="editable">'
						. $yearHtml.$monthHtml.$dayHtml.$micro
						. $hidden.
						'<span class="muted">&emsp;'.JText::_("COM_QUIZ_PLAN_LIFE_TIME_EXPIRATION_MSG").'</span>
					</div>
				</div>';
	}

	static function _setupTimerScript()
	{
		static $added = false;
		if($added){
			return true;
		}
		
		
		
	
	$content = "
	var quizplans = {};
	(function($){
			// if elements not defined already
			
			quizplans.element = {};
			quizplans.element.timer = {
				elems : Array('year', 'month', 'day', 'hour', 'minute', 'second'),
			
				// get value from selects and combine into string
				getValue : function(elem_class)
				{
					var prefix	= elem_class+'_';
	        		var timer 	= '';
					for(var i=0; i<this.elems.length ; i++)
					{
							var value= parseInt(jQuery('#' + prefix + this.elems[i]).val());
							if(10 > value){
								value = '0' + value;
							}
		
							timer += value;
					}
					
					return timer;
				},
				
				// set given string to different timer selects
				setValue : function(elem_class, value){
					var prefix	= elem_class+'_';
					if(value == null || value.trim().length <=0){
						value = '000000000000';
					}
					 
					value = value.replace(/NaN/g, '00'); 
		 			for(var i =0; i < this.elems.length ; i++){
					
		 				jQuery('#' + prefix+ this.elems[i]).val(parseInt(value.substr(i*2, 2), 10)).trigger('chosen:updated');
		 			}
				},
				
				
				format : function(elem_class){
					var prefix	= elem_class+'_';
					
					var data = {timer:{}};
	 				for(var i =0; i < this.elems.length ; i++){
	 					var value = jQuery('#' + prefix + this.elems[i]).val();
	 					if(typeof(value) == 'undefined' || value == null){
	 						value = 0;
	 					}
	 					data.timer[this.elems[i]]=parseInt(value);
					}
					
					data['domObject'] = 'timer-warp-'+elem_class+' .readable span.pp-content';
					var url='index.php?option=com_vquiz&task=format&object=timer&headerFooter=0';
					//jQuery.post(url, data);
					jQuery.ajax({
						url: url,
						method: 'POST',
                        data: data
                       })
					  .done(function( res ) {
						 jQuery('#timer-warp-expiration span.pp-content').html(res);
					  });
				},
			
				onchange : function(elem_class){
					jQuery('#' + elem_class).attr('value', this.getValue(elem_class));
					this.format(elem_class);
				},
				
				setup : function(elem_class, value){
	
		 			this.setValue(elem_class, value);
		 						   		
			   		// show readble
			   		this.format(elem_class);
			   		
					
					var hoverClass='pp-mouse-hover';    		        
			        
			        jQuery('#timer-warp-'+elem_class+' .editable').hide();
					jQuery('#timer-warp-'+elem_class+' .readable').click(function(){
							jQuery('#timer-warp-'+elem_class+' .editable').fadeToggle(200);
						});
					
					// setup onchange functionality
		    		jQuery('select.'+elem_class).on('change' , function(){ 
		    				quizplans.element.timer.onchange(elem_class);
		    			});  
				}
			}
		})(quizplans.jQuery);";
       
	   JFactory::getDocument()->addScriptDeclaration($content);
	  $content = " (function($){
			// if elements not defined already
			if(typeof(quizplans.element)=='undefined'){
				quizplans.element = {};
			}
	
			quizplans.element.parammanipulator = {
				_queue 	: new Array(),
				_elem_count : 0, 
				_show_queue 	: new Array(),
				
				insert : function(prefix, elem, params){
					var data = new Object;
					
					data.prefix = prefix;
					data.elem 	= elem[0];
					data.params = eval(params);
					
					queue = quizplans.element.parammanipulator._queue;
					queue.push(data);
					
					if(queue.length == this._elem_count){
						this.init();
					}
				},
				
				init : function(){
					
					queue = quizplans.element.parammanipulator._queue;
					show_queue = quizplans.element.parammanipulator._show_queue ;
					
					// initiliaze all manipulators on screen
					for(var index=0 ; index < queue.length; index++){
						var data = queue[index];
						quizplans.element.parammanipulator.manipulate(data.prefix, data.elem, data.params);
					}
					
					quizplans.element.parammanipulator._show_queue = new Array();
					
					jQuery('.pp-parammanipulator').change(quizplans.element.parammanipulator.init);
				},
				
				manipulate : function(prefix, elem, params){
					
					show_queue = quizplans.element.parammanipulator._show_queue ;
					 
					var elems = jQuery('#'+elem.id);
					// hide all childs
					jQuery.each(params, function(key, val) {
							jQuery.each(val, function(){
								// only hide if none make it visible
								
								if(this.toString() != '' && show_queue.indexOf('.' + prefix + this) == -1){
									jQuery('.' + prefix + this).hide();
								}
							});
						});
					
					// show child if, I am visible
					//parammanipulator won't work in case of tabs,if check for element visibility
<!--					if(elems.is(':visible') == true){-->
						jQuery.each(params[elems.val()], function(){
							
							if(this.toString() != ''){
								jQuery('.' + prefix + this).show();
								show_queue.push('.' + prefix + this);
							}
						});
<!--					}-->
				}
			}
			
			// 
			jQuery(document).ready(function(){
				quizplans.element.parammanipulator._elem_count = jQuery('.pp-parammanipulator').length;
			});
			
		})(quizplans.jQuery)";
		JFactory::getDocument()->addScriptDeclaration($content);
		$added = true;
		return true;
	}
	 public static function getformatTime()
	 {
	   
	   $timer = JRequest::getVar('timer', array(), 'post', 'array');
	   $lifetime = true;
		$count = 0;
		
		foreach($timer as $key => $value){
			$value = (int)$value;
			if($value > 0){
				$lifetime = false;
			}
					
			$count 	+= $value ? 1 : 0;
		}

		if($lifetime){
			echo JText::_('COM_QUIZ_PLAN_LIFE_TIME');
			return;
		}
			
		$counter = 0;
		$str = '';
		foreach($timer as $key => $value)
		{
			$value = (int)$value;
			$key = JString::strtoupper($key);
			
			// show values if they are greater than zero only
			if(!$value){
				continue;
			}
				
			$key .= ($value>1) ? 'S':'';
			$valueStr = $value." ";
			
			$concatStr = $counter ? ' '.JText::_('COM_QUIZ_PLANTIME_CONCATE_STRING_AND').' ' : '';
			$str .= $concatStr.$valueStr.JText::_("COM_QUIZ_PLAN_{$key}"); 
			$counter++;
		}

		echo $str;
		return;	 
	 }
	 public static function getConfiguration()
	 {
		$db=JFactory::getDbo();
        $query=$db->getQuery(true);
		$query->select('*');
        $query->from('#__vquiz_configuration AS c');
		$db->setQuery($query); 
		return $db->loadObject();
	 }
	 public static function pricewithtax($price){
		 $config = QuizHelper::getConfiguration();
		
		 return $config->tax_in=='percent'?$price+(($config->tax_value*$price)/100):$price+$config->tax_value; 
		
	 }
	 public static function validateCoupon($coupon_key, $subid)
	 {
		$db = JFactory::getDbo();
		$time =  date("Y-m-d H:m:s");
		if( strlen( $coupon_key ) > 0 ) {
		 $q = "SELECT * FROM `#__vquiz_coupons` WHERE `codes`=".$db->quote($coupon_key)." AND `published`=1 AND `expiry_date`>=".$db->quote($time)."";
			$db->setQuery($q);
			$status = false;
			$db->Query($q);
				if( $db->getNumRows() ) {
		            $coupon = $db->loadAssocList(0);
					$coupon = $coupon[0];
					$subid_detail = QuizHelper::subscriptionDetail($subid);
					//$plan_detail = QuizHelper::planDetail($subid_detail->plan_id);
					
					
					$subscribed_plan_id = $subid_detail->plan_id;
					$subscribed_quiz_id = $subid_detail->quiz_id;
					$subscribed_user_id = $subid_detail->user_id;

					if(!empty($coupon['plan_id']) && $subscribed_plan_id!=0){
						if($coupon['plan_id'] == $subscribed_plan_id){
							$status = true;
						}
				    }
					if(!empty($coupon['quizids']) && $subscribed_quiz_id!=0){
						
						$quiz_arr = json_decode($coupon['quizids'],true);
						
						if(in_array($subscribed_quiz_id,$quiz_arr)){
							$status = true;
						}
				    }
					if(!empty($coupon['applicable_user']) && $subscribed_user_id!=0){
						
						$user_arr = json_decode($coupon['applicable_user'],true);
						
						if(in_array($subscribed_user_id,$user_arr)){
							$status = true;
						}
				    }
				   
				}
		}
		return $status;
	 }
	 
	 public static function priceformat($amount)
	 {
		     $config = QuizHelper::getConfiguration();
			 $fractionDigitCount = $config->fractionDigitCount;
			 $separator = $config->price_decimal_separator;
			 $currency = $config->	currencysymbol;
		     $amount = number_format(round($amount, $fractionDigitCount), $fractionDigitCount, $separator, '');
			 $html = '';
			 if($config->show_currency_at == "before"):
			$html .= '<span class="pp-currency">'.$currency.'</span>&nbsp;'
			.'<span class="pp-amount">'.$amount.'</span>';
			else :
			$html .= '<span class="pp-amount">'.$amount.'</span>&nbsp;'
			.'<span class="pp-currency">'.$currency.'</span>';
			endif;
			return $html;
	 }
	 public static function Totalusers()
	 {
			$likeusers = JRequest::getVar('username');
			$db=JFactory::getDbo();
			$query=$db->getQuery(true);
			$query->select('*');
			$query->from('#__users AS c');
			if(!empty($likeusers))
			$query->wherer('c.username LIKE '.$this->_db->Quote( '%'.$db->escape( $likeusers, true ).'%', false ));
			$db->setQuery($query); 
			$total_user = $db->loadObjectList();
			$users = array();
			foreach($total_user as $user){
				    $stvalue = new stdClass();
					$stvalue->id =  $user->id;
					$stvalue->label = $user->username;
					//$stvalue->value = $user->id;
					array_push($users, $stvalue);
			}
			return $users;
			
	 }
	 
	 public static function getSubscriptionStatsValue()
	{ 
		$db=JFactory::getDbo();
		$query=$db->getQuery(true);
		$query->select('count(*) AS count, `plan_id`, `status`')
			  ->from('`#__vquiz_plans_subscription`')
			  ->group("`plan_id` , `status`");
		return $query->dbLoadQuery()->loadObjectList();		
	}
	
	 public static function getSubscriptionStatusForPlan($planid){
		$db = JFactory::getDbo();
		
		$active=0;$hold=0;$expire=0;$nostatus=0;
		
		$query = 'select count(`plan_id`) from `#__vquiz_plans_subscription` where `plan_id`='.$db->quote($planid).' AND status=1';
		$db->setQuery($query);
		$active = $db->loadResult();
		
		
		$query = 'select count(`plan_id`) from `#__vquiz_plans_subscription` where `plan_id`='.$db->quote($planid).' AND  status=2';
		$db->setQuery($query);
		$hold = $db->loadResult();
		
		$query = 'select count(`plan_id`) from `#__vquiz_plans_subscription` where `plan_id`='.$db->quote($planid).' AND  status=3';
		$db->setQuery($query);
		$expire = $db->loadResult();
		
		$query = 'select count(`plan_id`) from `#__vquiz_plans_subscription` where `plan_id`='.$db->quote($planid).' AND  status=4';
		$db->setQuery($query);
		$nostatus = $db->loadResult();
		
		$subscriptionCount = $active+$hold+$expire+$nostatus;
		$html = '';
		if($subscriptionCount>0)
		$html .= '<div class="progress">';
		if($active>0){
			$html .= ' <div class="bar bar-success" title="'.JText::_('COM_VQUIZ_PLAN_USAGE_ANALYTICS_ACTIVE_SUBSCRIPTION_DESC').'" style="width:'.(($active/$subscriptionCount)*100).'%"><b>'.$active.'</b></div>';
		}
		if($hold>0){
			$html .= ' <div class="bar bar-warning" title="'.JText::_('COM_VQUIZ_PLAN_USAGE_ANALYTICS_HOLD_SUBSCRIPTION_DESC').'" style="width:'.(($hold/$subscriptionCount)*100).'%"><b>'.$hold.'</b></div>';
		}
		if($expire>0){
			$html .= ' <div class="bar bar-danger" title="'.JText::_('COM_VQUIZ_PLAN_USAGE_ANALYTICS_EXPIRED_SUBSCRIPTION_DESC').'" style="width:'.(($expire/$subscriptionCount)*100).'%"><b>'.$expire.'</b></div>';
		}		
		if($nostatus>0){
			$html .= ' <div class="bar bar-info" title="'.JText::_('COM_VQUIZ_PLAN_USAGE_ANALYTICS_NO_STATUS_SUBSCRIPTION_DESC').'" style="width:'.(($nostatus/$subscriptionCount)*100).'%"><b>'.$nostatus.'</b></div>';
		}
		
		if($subscriptionCount>0)
		$html .= '</div>';	 //echo $active; //exit;
       return $html;	
		
	}
		 
	 public static function getTotalSubscription($status)
	{ 
		$db=JFactory::getDbo();
		$query=$db->getQuery(true);
		$query->select('count(*) AS count')
			  ->from('`#__vquiz_plans_subscription`')
			   ->where('`status`='.$db->quote($status));
			   $db->setQuery($query);
			  return $db->loadResult();
	}
	public static function getSubscriptionStats($activeSub, $expiredSub, $holdSub, $nostatusSub)
	{
		$totalSub    	= $activeSub+$expiredSub+$holdSub+$nostatusSub;
		if(!$totalSub){ 
			return array();	
		}
         $subscriptionStats = array();    
        $subscriptionStats['count'][0]		= $nostatusSub;
		$subscriptionStats['count'][1]		= $activeSub;
		$subscriptionStats['count'][2]		= $holdSub;
		$subscriptionStats['count'][3]		= $expiredSub;
		
		
		// Percentage : According to Subscription Status
		$subscriptionStats['width'][0]		= ($nostatusSub/$totalSub)*100;
		$subscriptionStats['width'][1]		= ($activeSub/$totalSub)*100;
		$subscriptionStats['width'][2]		= ($holdSub/$totalSub)*100;
		$subscriptionStats['width'][3]		= ($expiredSub/$totalSub)*100;
		
                
        // Tool-tip : According to the Status
        $subscriptionStats['message'][0]		= JText::_("COM_VQUIZ_PLAN_USAGE_ANALYTICS_NO_STATUS_SUBSCRIPTION_DESC");		
		$subscriptionStats['message'][1]		= JText::_("COM_VQUIZ_PLAN_USAGE_ANALYTICS_ACTIVE_SUBSCRIPTION_DESC");
		$subscriptionStats['message'][2]		= JText::_("COM_VQUIZ_PLAN_USAGE_ANALYTICS_HOLD_SUBSCRIPTION_DESC");
		$subscriptionStats['message'][3]		= JText::_("COM_VQUIZ_PLAN_USAGE_ANALYTICS_EXPIRED_SUBSCRIPTION_DESC");
		
		
		// Color Coding: According to Subscription Status
		$subscriptionStats['class'][0]		= 'bar-info';
		$subscriptionStats['class'][1]		= 'bar-success';
		$subscriptionStats['class'][2]		= 'bar-warning';
		$subscriptionStats['class'][3]		= 'bar-danger';
		
		return $subscriptionStats;
	}
	static public function timeago($time)
	{ 	
		$date = new DateTime($time);
		$config = JFactory::getConfig();
		$date->setTimezone(new DateTimeZone($config->get('offset')));
	   
		$str  = $date->format(DateTime::ISO8601);
		if($time=='0000-00-00 00:00:00' || !isset($time)){
			return JText::_('COM_VQUIZ_NEVER');
		}
		
		$time = $date->format('Y-m-d H:i:s');
		
		return "<span class='timeago' title='{$str}'>$time</span>"; 
	}
	static public function gridStatus($name, $value, $entity, $class="", $attributeId="", $recordKey)
	{
		$status = QuizHelper::getStatusOf($entity);
		 
		$options = array();
		$stvalues = array();
		
		    $stvalue = new stdClass();
			$stvalue->name =  JText::_('COM_VQUIZ_SELECT_STATUS');
			$stvalue->value = '';
			$stvalues[0] = $stvalue; 
			$options[] = JHTML::_('select.option', '', JText::_('COM_VQUIZ_SELECT_STATUS'));
		
		foreach($status as $key => $val){
			$stvalue = new stdClass();
			$stvalue->name =  JText::_('COM_VQUIZ_STATUS_'.$val);
			$stvalue->value = $key;
			$stvalues[$key] = $stvalue; 
    		$options[] = JHTML::_('select.option', $key, JText::_('COM_VQUIZ_STATUS_'.$val));
		}	
		
         $style = isset($class)?" class=$class":"";
	     $style .= isset($recordKey)&&!empty($recordKey)?" onchange=$recordKey":"";
    	return JHTML::_('select.genericlist', $options, $name, $style, 'value', 'text', $value);
	}
	static public function getStatusOf($entity='', $excludedStatus = array())
	{
		static $allStatus = null;

		//Cache the results
		if($allStatus === null) {
			$class = new ReflectionClass(__CLASS__);
			$allStatus = $class->getConstants();
		}

		// if we need all status then return it, without none
		if(empty($entity)){
			$result = array_flip($allStatus);
			//unset($result[self::NONE]);
			return $result;
		}

		// no need of all
		$entity = JString::strtoupper($entity);

		$status = array();
		foreach($allStatus as $key => $val){
			if(preg_match("/^{$entity}_/i", $key) && !in_array($val, $excludedStatus))
				$status[$val] = $key;
		}

		return $status;
	}
	static public function convertIntoTimeArray($rawTime)
	{
		$time['year']    = "00";
		$time['month']   = "00";
		$time['day']     = "00";
		$time['hour']    = "00";
		$time['minute']  = "00";
		$time['second']  = "00";

		if($rawTime != 0)
		{
			$rawTime = str_split($rawTime, 2);
			$time = array();
			$time['year']    =  array_shift($rawTime);
			$time['month']   = array_shift($rawTime);
			$time['day']     =  array_shift($rawTime);
			$time['hour']    =  array_shift($rawTime);
			$time['minute']  =  array_shift($rawTime);
			$time['second']  =  array_shift($rawTime);
		}

		return $time;
	}
	static public function addExpiration($expirationTime)
	{   
		$date = array();
		$timerElements = array('year', 'month', 'day', 'hour', 'minute', 'second');
		$date = date_parse(QuizHelper::toString());
		$count = count($timerElements);
		if($expirationTime != 0){
			 for($i=0; $i<$count ; $i++){ 
				$date[$timerElements[$i]] +=   intval(JString::substr($expirationTime, $i*2, 2), 10);
			} 
			
			$date = date("Y-m-d H:m:s",mktime($date['hour'], $date['minute'], $date['second'], $date['month'], $date['day'], $date['year']));
			
		}
		else{ 
			$date=false;
		}
       
		return $date;
	}
	static public function toArray()
	{
		return JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString(); 
	}

	static public function toString()
	{
		return JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString(); 
	}
	public static function getPaymenPluginDetail($app_id=false)
	{  
		if(!$app_id){
			return array();
		}
		$db=JFactory::getDbo();
        $query=$db->getQuery(true);
		$query->select('*');
        $query->from('#__vquiz_payment_plugin AS p');
		$query->where('`p`.`id`='.$db->quote($app_id));
		$db->setQuery($query);
		$db->Query($query);
            if( $db->getNumRows() > 0 )
			{
				return $db->loadObject();
			}
		return array();	
	}
	public function getActiveSubscriptionsWhichAreExpried($time=null)
	{
		$db=JFactory::getDbo();
        $query=$db->getQuery(true);
		$query->select('s.*');
        $query->from('#__vquiz_plans_subscription AS s');
		$time =  date("Y-m-d H:m:s");

		if($time === null){
		 	$time = date("Y-m-d H:m:s");
		}
		 $query->where("`s`.`expiration_date` < '".$time."' AND `s`.`expiration_date` <> '0000-00-00 00:00:00'")
		 ->where('`s`.`status` = '.QuizHelper::SUBSCRIPTION_ACTIVE);
          $db->setQuery($query);
		return $db->loadObjectList();
	}
	
	public function getPreExpirySubscriptions(Array $plans, $preExpiryTime, $onAllPlans = false)
	{
		//get query
		$query = $this->getQuery();
		$tmpQuery = $query->getClone();

		// E1 : preexpiry time as per last cron run
		// E2 : preexpiry time as per current cron run
		// if expiration time is between E1 & E2
		// we will trigger PreExpiry event for subcsription
		$e1 = new XiDate(XiFactory::getConfig()->cronAcessTime);
		$e2	= new XiDate('now');
	
		$e1->addExpiration($preExpiryTime);
		$e2->addExpiration($preExpiryTime);

		$tmpQuery->clear('where')
				 ->where("`tbl`.`expiration_date` > '".$e1->toMySQL()."'" )
				 ->where("`tbl`.`expiration_date` < '".$e2->toMySQL()."'" )
				 ->where('`tbl`.`status` = '.PayplansStatus::SUBSCRIPTION_ACTIVE);
				
		if($onAllPlans !== true){
			$tmpQuery->where("`tbl`.`plan_id` in ( ". implode(',', $plans)." )" );
		} 

		return $tmpQuery->dbLoadQuery()->loadObjectList($this->getTable()->getKeyName());
	}
	
	public function getPostExpirySubscriptions(Array $plans, $postExpiryTime, $onAllPlans = false)
	{
		//get query
		$query = $this->getQuery();
		$tmpQuery = $query->getClone();

		// E1 : postexpiry time as per last cron run
		// E2 : postexpiry time as per current cron run
		// if post expiration time is between E1 & E2
		// we will trigger PostExpiry event for subcsription
		$e1 = new XiDate(XiFactory::getConfig()->cronAcessTime);
		$e2	= new XiDate('now');
	
		$e1->subtractExpiration($postExpiryTime);
		$e2->subtractExpiration($postExpiryTime);

		$tmpQuery->clear('where')
				 ->where("`tbl`.`expiration_date` > '".$e1->toMySQL()."'" )
				 ->where("`tbl`.`expiration_date` < '".$e2->toMySQL()."'" )
				 ->where('`tbl`.`status` = '.PayplansStatus::SUBSCRIPTION_EXPIRED);
				
		if($onAllPlans !== true){
			$tmpQuery->where("`tbl`.`plan_id` in ( ". implode(',', $plans)." )" );
		} 

		return $tmpQuery->dbLoadQuery()->loadObjectList($this->getTable()->getKeyName());
		
	} 
	
	public function getPostActivationSubscriptions(Array $plans, $postActivationTime, $onAllPlans = false)
	{
		//get query
		$query = $this->getQuery();
		$tmpQuery = $query->getClone();

		// A1 : postactivation time as per last cron run
		// A2 : postactivation time as per current cron run
		// if post expiration time is between A1 & A2
		// we will trigger PostActivation event for subcsription
		$a1 = new XiDate(XiFactory::getConfig()->cronAcessTime);
		$a2	= new XiDate('now');
	
		$a1->subtractExpiration($postActivationTime);
		$a2->subtractExpiration($postActivationTime);

		$tmpQuery->clear('where')
				 ->where("`tbl`.`subscription_date` > '".$a1->toMySQL()."'" )
				 ->where("`tbl`.`subscription_date` < '".$a2->toMySQL()."'" )
				 ->where('`tbl`.`status` = '.PayplansStatus::SUBSCRIPTION_ACTIVE);
				
		if($onAllPlans !== true){
			$tmpQuery->where("`tbl`.`plan_id` in ( ". implode(',', $plans)." )" );
		} 

		return $tmpQuery->dbLoadQuery()->loadObjectList($this->getTable()->getKeyName());
		
	}
	
	public static function generateSerialCode($len=12){
	        $_TOKENS = array( 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', '0123456789');
			$_key = '';
			for( $i = 0; $i < $len; $i++ ) {
			$_row = rand( 0, count( $_TOKENS )-1 );
			$_col = rand( 0, strlen( $_TOKENS[$_row] )-1 );
			$_key .= '' . $_TOKENS[$_row][$_col];
			}
			return $_key;
   }
   
   public static function checkNotification($notification_type){
		
		$db=JFactory::getDbo();
		$query=$db->getQuery(true);
		
		$query = 'SELECT * FROM #__vquiz_notifications WHERE type = '.$notification_type;
		$db->setQuery( $query );
		$result= $db->loadObject();		
		
		if(count($result)>0 AND $result->published==1){
			return true;
		}else{
			return false;
		}
		
   }
   
   public static function findUsersToNotify($col_name){
		
		$db=JFactory::getDbo();
		$query=$db->getQuery(true);
		
		$query = "SELECT u.id FROM #__vquiz_config c INNER JOIN #__users u ON c.user_id=u.id WHERE $col_name = 1";
		$db->setQuery( $query );  
		$result= $db->loadObjectList();		
		
		$users = array();
		foreach($result as $user){				
				array_push($users, $user->id);
		}
		return $users;			
   }
   
   public static function findUsersToEnotify($col_name){
		
		$db=JFactory::getDbo();
		$query=$db->getQuery(true);
		
		$query = "SELECT u.email FROM #__vquiz_config c INNER JOIN #__users u ON c.user_id=u.id WHERE $col_name = 1";
		$db->setQuery( $query );  
		$result= $db->loadObjectList();		
		
		$users = array();
		foreach($result as $user){				
				array_push($users, $user->email);
		}
		return $users;			
   }
	
   public static function sendNotification($data){
	   
 	    $user = JFactory::getUser();
		$mailer = JFactory::getMailer();
		$config = JFactory::getConfig();
				
		$db=JFactory::getDbo();
        $query=$db->getQuery(true);
		
		$query = 'SELECT * FROM #__vquiz_notifications WHERE type = '.$data['notification_type'];
		$db->setQuery( $query );
		$result= $db->loadObject();
		
		if($result->send_to_creator==1 && $data['notification_enabled_by_creator']==1){
			
			$query = 'SELECT u.* FROM #__users u INNER JOIN #__vquiz_quizzes q ON q.created_by=u.id  WHERE q.id = '.$data['quizid'];
			$db->setQuery( $query );
			$creator_result= $db->loadObjectList();
			
			$creator_ids = array();
			$creator_emails = array();
			
			foreach($creator_result as $creator){				
					array_push($creator_ids, $creator->id);
					array_push($creator_emails, $creator->email);
			}
			
			$data['notify_users'] = array_unique(array_merge($data['notify_users'],$creator_ids));
			$data['enotify_users'] = array_unique(array_merge($data['enotify_users'],$creator_emails));
		}
		
		if($result->send_to_superuser==1){			
			
			$query = 'SELECT u.* FROM #__users u INNER JOIN #__user_usergroup_map g ON g.user_id=u.id  WHERE g.group_id = 8';
			$db->setQuery( $query );
			$superuser_result= $db->loadObjectList();
			
			$suser_ids = array();
			$suser_emails = array();
			
			foreach($superuser_result as $suser){				
					array_push($suser_ids, $suser->id);
					array_push($suser_emails, $suser->email);
			}
			
			$data['notify_users'] = array_unique(array_merge($data['notify_users'],$suser_ids));
			$data['enotify_users'] = array_unique(array_merge($data['enotify_users'],$suser_emails));
			
		}
					
		
		$insert = new stdClass();
		$insert->id = null;
		$insert->created = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
		$insert->created_by = $user->id;		
		$insert->itemid = $data['itemid'];					
		$insert->notification_type = $data['notification_type'];
		$insert->email_subject = $result->email_subject;
		$insert->email_cc = $result->email_cc;
		$insert->email_bcc = $result->email_bcc;
		
		$text = $result->email_content;
		
		if(strpos($text, '{quizcategory}')!== false)
		{
			$text = str_replace('{quizcategory}', $data['replace_quizcategory'], $text);
		}
		if(strpos($text, '{quiztitle}')!== false)
		{
			$text = str_replace('{quiztitle}', $data['replace_quiztitle'], $text);
		}
		if(strpos($text, '{username}')!== false)
		{
			$text = str_replace('{username}', $data['replace_username'], $text);
		}
		if(strpos($text, '{firstname}')!== false)
		{
			$text = str_replace('{firstname}', $data['replace_firstname'], $text);
		}
		if(strpos($text, '{middlename}')!== false)
		{
			$text = str_replace('{middlename}', $data['replace_middlename'], $text);
		}
		if(strpos($text, '{lastname}')!== false)
		{
			$text = str_replace('{lastname}', $data['replace_lastname'], $text);
		}
		if(strpos($text, '{email}')!== false)
		{
			$text = str_replace('{email}', $data['replace_email'], $text);
		}
		if(strpos($text, '{learning_title}')!== false)
		{
			$text = str_replace('{learning_title}', $data['replace_learning_title'], $text);
		}
		if(strpos($text, '{lesson_title}')!== false)
		{
			$text = str_replace('{lesson_title}', $data['replace_lesson_title'], $text);
		}
		if(strpos($text, '{quizname}')!== false)
		{
			$text = str_replace('{quizname}', $data['replace_quizname'], $text);
		}
		if(strpos($text, '{current_date}')!== false)
		{
			$text = str_replace('{current_date}', $data['replace_current_date'], $text);
		}
		if(strpos($text, '{quizurl}')!== false)
		{
			$text = str_replace('{quizurl}', $data['replace_quizurl'], $text);
		}
		if(strpos($text, '{skill_title}')!== false)
		{
			$text = str_replace('{skill_title}', $data['replace_skill_title'], $text);
		}
		if(strpos($text, '{plan_title}')!== false)
		{
			$text = str_replace('{plan_title}', $data['replace_plan_title'], $text);
		}
		if(strpos($text, '{buyer_name}')!== false)
		{
			$text = str_replace('{buyer_name}', $data['replace_buyer_name'], $text);
		}
		if(strpos($text, '{subscription_date}')!== false)
		{
			$text = str_replace('{subscription_date}', $data['replace_subscription_date'], $text);
		}
		if(strpos($text, '{expiration_date}')!== false)
		{
			$text = str_replace('{expiration_date}', $data['replace_expiration_date'], $text);
		}
		if(strpos($text, '{order_date}')!== false)
		{
			$text = str_replace('{order_date}', $data['replace_order_date'], $text);
		}
		
		$insert->email_content = $text;						
		
		
		if(!$db->insertObject('#__vquiz_notes', $insert, 'id'))	{
			$this->setError($db->stderr());
			return false;
		}
		$note_id = $db->insertid();
		
		
		
		 for($i=0;$i<count($data['notify_users']);$i++)	{
			 
				$insert = new stdClass();
				
				$insert->note_id = $note_id;				
				$insert->user_id = $data['notify_users'][$i];
				$insert->created = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
			
				if(!$db->insertObject('#__vquiz_notesnuser', $insert, 'id'))	{
				
					$msg = $this->setError($db->stderr());
					return false;
				}
			}
				
		
		
		// send notification mail 
		
		
		$mailsubject = $result->email_subject;
		$body = $text;
		$sender = array( 
			$config->get( 'mailfrom' ),
			$config->get( 'fromname' ) 
		);
		$recievermail = $data['enotify_users'];//$user->email;
		$cc = $result->email_cc;
		$bcc = $result->email_bcc;
		
		$mailer->setSender($sender);						
		$mailer->setSubject($mailsubject);
		$mailer->setBody($body);
		$mailer->addRecipient($recievermail);
		$mailer->addCC($cc);
		$mailer->addBCC($bcc);
		$mailer->IsHTML(true);
		$send = $mailer->send();
		
		if($send==true){
			return true;
		}else{
			return false;
		}
			
   }
   
   public static function find_quizzes($catids){   
 	    	
		$db=JFactory::getDbo();
        $query=$db->getQuery(true);
		
		$query = 'SELECT id FROM #__vquiz_quizzes  WHERE catid in ('.$catids.')';
		$db->setQuery( $query );
		$quizresult= $db->loadObjectList(); //print_r($result);
		
		$quizids_arr=array();
		foreach($quizresult as $quiz){
				    //$stvalue = new stdClass();
					$id =  $quiz->id;					
					array_push($quizids_arr, $id);
			}
			
		$quizids = implode(',',$quizids_arr); 
		return $quizids;
	}
	
	
	
}