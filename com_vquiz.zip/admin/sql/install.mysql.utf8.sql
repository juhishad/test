DROP TABLE IF EXISTS `#__vquiz_category`;
CREATE TABLE IF NOT EXISTS `#__vquiz_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) NOT NULL,
  `title` text NOT NULL,
  `alias` text NOT NULL,
  `published` int(2) NOT NULL,
  `created` datetime NOT NULL,
  `photopath` varchar(250) NOT NULL,
  `ordering` int(11) NOT NULL,
  `parent_id` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `lft` int(11) NOT NULL,
  `rgt` int(11) NOT NULL DEFAULT '1',
  `path` varchar(250) NOT NULL,
  `language` char(11) NOT NULL,
  `access` int(11) NOT NULL,
  `meta_desc` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;


INSERT INTO `#__vquiz_category` (`id`, `asset_id`, `title`, `alias`, `published`, `created`, `photopath`, `ordering`, `parent_id`, `level`, `lft`, `rgt`, `path`, `language`, `access`, `meta_desc`, `meta_keyword`, `created_by`, `modified`, `modified_by`) VALUES
(1, 0, 'ROOT', 'root', 0, '2015-03-24 10:49:58', '', 1, 0, 0, 0, 27, '', '*', 1, '', '', 0, '0000-00-00 00:00:00', 0);


DROP TABLE IF EXISTS `#__vquiz_config`;
CREATE TABLE IF NOT EXISTS `#__vquiz_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `notfify_add_quizcategory` tinyint(1) NOT NULL DEFAULT '0',
  `notfify_add_quiz` tinyint(1) NOT NULL DEFAULT '0',
  `notify_add_lpath` tinyint(1) NOT NULL DEFAULT '0',
  `notify_add_lesson` tinyint(1) NOT NULL DEFAULT '0',
  `notify_add_skill` tinyint(1) NOT NULL DEFAULT '0',
  `notify_complete_quiz` tinyint(1) NOT NULL DEFAULT '0',
  `notify_incomplete_quiz` tinyint(1) NOT NULL DEFAULT '0',
  `notify_complete_lpath` tinyint(1) NOT NULL DEFAULT '0',
  `notify_send_invitation` tinyint(1) NOT NULL DEFAULT '0',
  `notify_complete_invitation` tinyint(1) NOT NULL DEFAULT '0',
  `notify_user_registration` tinyint(1) NOT NULL DEFAULT '0',
  `notify_pre_expiration` tinyint(1) NOT NULL DEFAULT '0',
  `notify_post_expiration` tinyint(1) NOT NULL DEFAULT '0',
  `notify_active_subscription` tinyint(1) NOT NULL DEFAULT '0',
  `notify_expire_subscription` tinyint(1) NOT NULL DEFAULT '0',
  `enotfify_add_quizcategory` tinyint(1) NOT NULL DEFAULT '0',
  `enotfify_add_quiz` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_add_lpath` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_add_lesson` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_add_skill` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_complete_quiz` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_incomplete_quiz` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_complete_lpath` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_send_invitation` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_complete_invitation` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_user_registration` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_pre_expiration` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_post_expiration` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_active_subscription` tinyint(1) NOT NULL DEFAULT '0',
  `enotify_expire_subscription` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS `#__vquiz_configuration`;
CREATE TABLE IF NOT EXISTS `#__vquiz_configuration` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currencyname` varchar(25) NOT NULL,
  `currencysymbol` varchar(25) NOT NULL,
  `enableDiscount` tinyint(1) NOT NULL,
  `tax_enable` tinyint(1) NOT NULL,
  `tax_value` int(255) NOT NULL,
  `tax_in` varchar(255) NOT NULL,
  `show_currency_at` varchar(255) NOT NULL,
  `price_decimal_separator` varchar(25) NOT NULL,
  `fractionDigitCount` int(25) NOT NULL,
  `extend_subscription` tinyint(1) NOT NULL,
  `sendermail` varchar(250) NOT NULL,
  `mailformat` text NOT NULL,
  `mailformat2` text NOT NULL,
  `mailformat3` text NOT NULL,
  `mailformat4` text NOT NULL,
  `textformat` text NOT NULL,
  `textformat2` text NOT NULL,
  `textformat3` text NOT NULL,
  `textformat4` text NOT NULL,
  `textformat5` text NOT NULL,
  `take_snapshot` tinyint(1) NOT NULL,
  `share_button` tinyint(1) NOT NULL,
  `share_btn_choosed` varchar(50) NOT NULL,
  `users_moderation` tinyint(1) NOT NULL,
  `categorythumbnailwidth` varchar(50) NOT NULL,
  `categorythumbnailheight` varchar(50) NOT NULL,
  `dateformat` varchar(11) NOT NULL,
  `certificate` int(11) NOT NULL,
  `list_column` int(11) NOT NULL,
  `load_jquery` tinyint(1) NOT NULL,
  `question_prepare_content` tinyint(1) NOT NULL,
  `quiz_prepare_content` tinyint(1) NOT NULL,
  `continuous_question` tinyint(1) NOT NULL,
  `later_play` tinyint(1) NOT NULL,
  `invite` tinyint(1) NOT NULL,
  `certificate_number_setting` int(11) NOT NULL,
  `start_with` varchar(250) NOT NULL,
  `end_with` varchar(250) NOT NULL,
  `cet_digits` int(11) NOT NULL,
  `cet_format` int(11) NOT NULL,
  `cet_type` int(11) NOT NULL,
  `disable_print_copy_result` tinyint(1) NOT NULL,
  `g_ads` text NOT NULL,
  `ads_shows` tinyint(1) NOT NULL,
  `column_limit` int(255) NOT NULL,
  `row_limit` int(255) NOT NULL,
  `sstatus` tinyint(1) NOT NULL,
  `facebook_appid` varchar(250) NOT NULL,
  `frontend_allowed` varchar(250) NOT NULL,
  `next_quiz` tinyint(1) NOT NULL,
  `prev_quiz` tinyint(1) NOT NULL,
  `subcategory_list_layout` tinyint(1) NOT NULL,
  `question_key` int(11) NOT NULL,
  `save_certificate` int(1) NOT NULL,
  `cet_name` varchar(250) NOT NULL,
  `allowed_take_snapshot` tinyint(1) NOT NULL,
  `featured` tinyint(1) NOT NULL,
  `flag` tinyint(1) NOT NULL,
  `paging` int(11) NOT NULL,
  `access` int(11) NOT NULL,
  `published` int(11) NOT NULL,
  `payment_system` tinyint(4) NOT NULL,
  `lead_generation` tinyint(4) NOT NULL,
  `submit_button` tinyint(4) NOT NULL,
  `allowed_continuous_question` tinyint(1) NOT NULL,
  `allowed_later_play` tinyint(1) NOT NULL,
  `allowed_invite` tinyint(1) NOT NULL,
  `allowed_disable_print_copy_result` tinyint(1) NOT NULL,
  `allowed_share_button` tinyint(1) NOT NULL,
  `allowed_question_key` tinyint(1) NOT NULL,
  `allowed_featured` tinyint(1) NOT NULL,
  `allowed_flag` smallint(1) NOT NULL,
  `allowed_paging` tinyint(1) NOT NULL,
  `allowed_certificate` tinyint(1) NOT NULL,
  `allowed_result` tinyint(1) NOT NULL,
  `allowed_accesslevel` tinyint(1) NOT NULL,
  `allowed_alias` tinyint(1) NOT NULL,
  `allowed_ordering` tinyint(1) NOT NULL,
  `allowed_published` tinyint(1) NOT NULL,
  `allow_submit_button` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


INSERT INTO `#__vquiz_configuration` (`id`, `currencyname`, `currencysymbol`, `enableDiscount`, `tax_enable`, `tax_value`, `tax_in`, `show_currency_at`, `price_decimal_separator`, `fractionDigitCount`, `extend_subscription`, `sendermail`, `mailformat`, `mailformat2`, `mailformat3`, `mailformat4`, `textformat`, `textformat2`, `textformat3`, `textformat4`, `textformat5`, `take_snapshot`, `share_button`, `share_btn_choosed`, `users_moderation`, `categorythumbnailwidth`, `categorythumbnailheight`, `dateformat`, `certificate`, `list_column`, `load_jquery`, `question_prepare_content`, `quiz_prepare_content`, `continuous_question`, `later_play`, `invite`, `certificate_number_setting`, `start_with`, `end_with`, `cet_digits`, `cet_format`, `cet_type`, `disable_print_copy_result`, `g_ads`, `ads_shows`, `column_limit`, `row_limit`, `sstatus`, `facebook_appid`, `frontend_allowed`, `next_quiz`, `prev_quiz`, `subcategory_list_layout`, `question_key`, `save_certificate`, `cet_name`, `allowed_take_snapshot`, `featured`, `flag`, `paging`, `access`, `published`, `payment_system`, `lead_generation`, `submit_button`, `allowed_continuous_question`, `allowed_later_play`, `allowed_invite`, `allowed_disable_print_copy_result`, `allowed_share_button`, `allowed_question_key`, `allowed_featured`, `allowed_flag`, `allowed_paging`, `allowed_certificate`, `allowed_result`, `allowed_accesslevel`, `allowed_alias`, `allowed_ordering`, `allowed_published`, `allow_submit_button`) VALUES
(1, 'USD', '$', 1, 1, 5, 'percent', 'before', '-', 2, 1, 'danish@wdmtech.com', '<div style=\"width: 95%; padding: 2.5%;\">\r\n<div style=\"width: 90%; padding: 2.5%; text-align: center; border: 10px solid #787878; margin: 0 auto;\">\r\n<div style=\"text-align: right;\">{certificate_number}</div>\r\n<div style=\"text-align: right;\"> </div>\r\n<div style=\"padding: 25px; text-align: center; border: 5px solid #787878;\"><span style=\"font-size: 36px; font-weight: bold;\">Certificate of Completion</span> <br /><br />\r\n<p style=\"font-size: 18px;\">Dear, <label>{username}</label>! You have <span style=\"text-transform: lowercase; font-size: 20px; font-weight: bold;\">{passed}</span> quiz \'{quizname}\'.</p>\r\n<br /><br />\r\n<table style=\"width: 490px; border-collapse: collapse; border: 1px solid #dddddd; font-size: 16px; height: 435px;\" cellspacing=\"0\" cellpadding=\"10\">\r\n<tbody>\r\n<tr>\r\n<th style=\"text-align: left; width: 222.222px; white-space: nowrap; border: 1px solid #dddddd;\">Result</th>\r\n<td style=\"text-align: left; border: 1px solid #dddddd; width: 224.444px;\">{userscore} / {maxscore}</td>\r\n</tr>\r\n<tr>\r\n<th style=\"text-align: left; width: 222.222px; white-space: nowrap; border: 1px solid #dddddd;\">Category Score:</th>\r\n<td style=\"text-align: left; border: 1px solid #dddddd; width: 224.444px;\"> {categoryscore}</td>\r\n</tr>\r\n<tr>\r\n<th style=\"text-align: left; white-space: nowrap; border: 1px solid #dddddd; width: 222.222px;\">Percentage</th>\r\n<td style=\"text-align: left; border: 1px solid #dddddd; width: 224.444px;\">{percentscore} %</td>\r\n</tr>\r\n<tr>\r\n<th style=\"text-align: left; white-space: nowrap; border: 1px solid #dddddd; width: 222.222px;\">Status</th>\r\n<td style=\"text-align: left; border: 1px solid #dddddd; width: 224.444px;\"><span style=\"font-weight: bold; font-size: 16px;\">{passed}</span></td>\r\n</tr>\r\n<tr>\r\n<th style=\"text-align: left; white-space: nowrap; border: 1px solid #dddddd; width: 222.222px;\">Start Time</th>\r\n<td style=\"text-align: left; border: 1px solid #dddddd; width: 224.444px;\">{starttime}</td>\r\n</tr>\r\n<tr>\r\n<th style=\"text-align: left; white-space: nowrap; border: 1px solid #dddddd; width: 222.222px;\">End Time</th>\r\n<td style=\"text-align: left; border: 1px solid #dddddd; width: 224.444px;\">{endtime}</td>\r\n</tr>\r\n<tr>\r\n<th style=\"text-align: left; white-space: nowrap; border: 1px solid #dddddd; width: 222.222px;\">Spent Time</th>\r\n<td style=\"text-align: left; border: 1px solid #dddddd; width: 224.444px;\">{spenttime}</td>\r\n</tr>\r\n<tr>\r\n<th style=\"border: 1px solid #dddddd; text-align: left; width: 222.222px;\">Passed Percentage</th>\r\n<td style=\"border: 1px solid #dddddd; text-align: left; width: 224.444px;\">{passedscore} %</td>\r\n</tr>\r\n<tr>\r\n<th style=\"border: 1px solid #dddddd; text-align: left; width: 222.222px;\">Total Questions</th>\r\n<td style=\"border: 1px solid #dddddd; text-align: left; width: 224.444px;\">{total_questions}</td>\r\n</tr>\r\n<tr>\r\n<th style=\"border: 1px solid #dddddd; text-align: left; width: 222.222px;\">Given Answers</th>\r\n<td style=\"border: 1px solid #dddddd; text-align: left; width: 224.444px;\">{given_answers}</td>\r\n</tr>\r\n<tr>\r\n<th style=\"border: 1px solid #dddddd; text-align: left; width: 222.222px;\">Correct Answers</th>\r\n<td style=\"border: 1px solid #dddddd; text-align: left; width: 224.444px;\">{correct_answers} </td>\r\n</tr>\r\n<tr>\r\n<th style=\"border: 1px solid #dddddd; text-align: left; width: 222.222px;\">Total Questions flag</th>\r\n<td style=\"border: 1px solid #dddddd; text-align: left; width: 224.444px;\">{flag}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<div style=\"padding: 15px 0 0; width: 100%; font-size: 16px; text-align: right;\">\r\n<p><span class=\"hasTip\" title=\"\"> </span></p>\r\n<p>All the best and have a great day</p>\r\n<p>Danish Iqbal | wdmTech Co -Founder.</p>\r\n<a href=\"../themeforest/www.wdmtech.com\">www.wdmtech.com</a><span style=\"color: blue;\"> | info@wdmtech.com</span></div>\r\n</div>\r\n</div>\r\n</div>', '<div style=\"width: 95%; padding: 2.5%;\">\r\n<div style=\"width: 90%; padding: 2.5%; text-align: center; border: 10px solid #787878; margin: 0 auto;\">\r\n<div style=\"text-align: right;\">{certificate_number}</div>\r\n<div style=\"text-align: right;\"> </div>\r\n<div style=\"padding: 25px; text-align: center; border: 5px solid #787878;\"><br /> <span style=\"font-size: 36px; font-weight: bold;\">Certificate of Completion</span> <br /><br />\r\n<p style=\"font-size: 18px;\">Dear,<span style=\"font-size: 20px; color: #008080; font-weight: bold;\"><label>{username}</label></span>!</p>\r\n<p style=\"font-size: 18px;\">Your <span style=\"text-transform: lowercase; font-size: 20px; font-weight: bold;\">{personality_score}</span></p>\r\n<p style=\"font-size: 18px;\">\'{quizname}\'.</p>\r\n<p style=\"font-size: 18px;\">{personality_message}</p>\r\n<br /><br />\r\n<div style=\"padding: 15px 0 0; width: 100%; font-size: 16px; text-align: right;\">\r\n<p>All the best and have a great day</p>\r\n<p>Danish Iqbal | wdmTech Co -Founder.</p>\r\n<a href=\"../themeforest/www.wdmtech.com\">www.wdmtech.com</a><span style=\"color: blue;\"> | info@wdmtech.com</span></div>\r\n</div>\r\n</div>\r\n</div>', '<div style=\"width: 95%; padding: 2.5%;\">\r\n<div style=\"width: 90%; padding: 2.5%; text-align: center; border: 10px solid #787878; margin: 0 auto;\">\r\n<div style=\"text-align: right;\">{certificate_number}</div>\r\n<div style=\"text-align: right;\"> </div>\r\n<div style=\"padding: 25px; text-align: center; border: 5px solid #787878;\"><br /> <span style=\"font-size: 36px; font-weight: bold;\">Certificate of Completion</span> <br /><br />\r\n<p style=\"font-size: 18px;\">Dear,<span style=\"font-size: 20px; color: #008080; font-weight: bold;\"><label>{username}</label></span>!</p>\r\n<p style=\"font-size: 18px;\">Your <span style=\"text-transform: lowercase; font-size: 20px; font-weight: bold;\">{personality_score}</span></p>\r\n<p style=\"font-size: 18px;\">\'{quizname}\'.</p>\r\n<p style=\"font-size: 18px;\"><a><span class=\"hasTip\" title=\"\">{correct_answers}</span></a></p>\r\n<br /><br />\r\n<div style=\"padding: 15px 0 0; width: 100%; font-size: 16px; text-align: right;\">\r\n<p>All the best and have a great day</p>\r\n<p>Danish Iqbal | wdmTech Co -Founder.</p>\r\n<a href=\"../themeforest/www.wdmtech.com\">www.wdmtech.com</a><span style=\"color: blue;\"> | info@wdmtech.com</span></div>\r\n</div>\r\n</div>\r\n</div>', '<div style=\"width: 95%; padding: 2.5%;\">\r\n<div style=\"width: 90%; padding: 2.5%; text-align: center; border: 10px solid #787878; margin: 0 auto;\">\r\n<div style=\"text-align: right;\">{certificate_number}</div>\r\n<div style=\"text-align: right;\"> </div>\r\n<div style=\"padding: 25px; text-align: center; border: 5px solid #787878;\"><br /> <span style=\"font-size: 36px; font-weight: bold;\">Certificate of Completion</span> <br /><br />\r\n<p style=\"font-size: 18px;\">Dear,<span style=\"font-size: 20px; color: #008080; font-weight: bold;\"><label>{username}</label></span>!</p>\r\n<p style=\"font-size: 18px;\">Your <span style=\"text-transform: lowercase; font-size: 20px; font-weight: bold;\">{personality_score}</span></p>\r\n<p style=\"font-size: 18px;\">\'{quizname}\'.</p>\r\n<p style=\"font-size: 18px;\"><a><span class=\"hasTip\" title=\"\">{given_answers}</span></a></p>\r\n<br /><br />\r\n<div style=\"padding: 15px 0 0; width: 100%; font-size: 16px; text-align: right;\">\r\n<p>All the best and have a great day</p>\r\n<p>Danish Iqbal | wdmTech Co -Founder.</p>\r\n<a href=\"../themeforest/www.wdmtech.com\">www.wdmtech.com</a><span style=\"color: blue;\"> | info@wdmtech.com</span></div>\r\n</div>\r\n</div>\r\n</div>', '<div class=\"result_text\" style=\"text-align: center;\">\r\n<p><strong> {trivia_message}</strong></p>\r\n<p> </p>\r\n<p>Dear,<strong><label>{username}</label>!</strong> You have {passed} quiz <strong>\'{quizname}\'</strong>.</p>\r\n</div>\r\n<table style=\"width: 100%;\" border=\"1\" cellspacing=\"0\" cellpadding=\"5\">\r\n<tbody>\r\n<tr>\r\n<td>Result :</td>\r\n<td>{userscore} / {maxscore}</td>\r\n</tr>\r\n<tr>\r\n<td>Category Score:</td>\r\n<td>{categoryscore}</td>\r\n</tr>\r\n<tr>\r\n<td>Percentage :</td>\r\n<td>{percentscore} %</td>\r\n</tr>\r\n<tr>\r\n<td>Status:</td>\r\n<td>{passed}</td>\r\n</tr>\r\n<tr>\r\n<td>Start Time :</td>\r\n<td>{starttime}</td>\r\n</tr>\r\n<tr>\r\n<td>End Time :</td>\r\n<td>{endtime}</td>\r\n</tr>\r\n<tr>\r\n<td>Spent Time :</td>\r\n<td>{spenttime}</td>\r\n</tr>\r\n<tr>\r\n<td>Passed Percentage :</td>\r\n<td>{passedscore} %</td>\r\n</tr>\r\n<tr>\r\n<td>Total Questions :</td>\r\n<td>{total_questions}</td>\r\n</tr>\r\n<tr>\r\n<td>Given Answers :</td>\r\n<td>{given_answers}</td>\r\n</tr>\r\n<tr>\r\n<td>Correct Answers :</td>\r\n<td>{correct_answers}</td>\r\n</tr>\r\n<tr>\r\n<td>Total Questions flag :</td>\r\n<td>{flag}</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<p>{answersheet}</p>', '<div class=\"result_text\" style=\"text-align: center;\"> \r\n<h1>{quizname}</h1>\r\n<h2>  {personality_score}</h2>\r\n<p>Dear,<strong> <label>{username}</label>!</strong> <strong>\'{personality_message}</strong></p>\r\n</div>', '<div class=\"result_text\" style=\"text-align: center;\"> \r\n<h1>{quizname}</h1>\r\n<h2><a><span class=\"hasTip\" title=\"\">{correct_answers}</span></a></h2>\r\n<p>Dear,<strong> <label>{username}</label>!</strong> <strong>\'{personality_message}</strong></p>\r\n</div>', '<div class=\"result_text\" style=\"text-align: center;\"> \r\n<h1>{quizname}</h1>\r\n<h2><a><span class=\"hasTip\" title=\"\">{correct_answers}</span></a></h2>\r\n<p>Dear,<strong> <label>{username}</label>!</strong> <strong>\'{personality_message}</strong></p>\r\n</div>', '<div class=\"result_text\" style=\"text-align: center;\"> \r\n<h1>{quizname}</h1>\r\n<h2><a><span class=\"hasTip\" title=\"\">{correct_answers}</span></a></h2>\r\n<p>Dear,<strong> <label>{username}</label>!</strong> <strong>\'{personality_message}</strong></p>\r\n<p><strong> </strong></p>\r\n</div>', 0, 1, '1,2,3,0', 1, '480', '292', 'Y-m-d H:i:s', 0, 3, 0, 0, 0, 0, 1, 0, 0, 'CET', 'vQuiz', 10, 0, 1, 0, '', 0, 10, 150, 1, '', '0', 1, 1, 0, 1, 1, 'my certificate', 0, 0, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1);


DROP TABLE IF EXISTS `#__vquiz_coupons`;
CREATE TABLE IF NOT EXISTS `#__vquiz_coupons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codes` varchar(250) NOT NULL,
  `offer` varchar(250) NOT NULL,
  `type_offer` int(11) NOT NULL,
  `code_used` int(11) NOT NULL,
  `above_amount` int(11) NOT NULL,
  `expiry_date` datetime NOT NULL,
  `published` int(11) NOT NULL,
  `ordering` int(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `maximum_discount` int(11) NOT NULL,
  `start_date` datetime NOT NULL,
  `applyallquizss` tinyint(1) NOT NULL,
  `applyallcategory` tinyint(1) NOT NULL,
  `qcategories` varchar(255) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `quizids` varchar(255) NOT NULL,
  `restaurant_ids` varchar(250) NOT NULL,
  `menuitem_ids` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `applicable_user` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_leads`;
CREATE TABLE IF NOT EXISTS `#__vquiz_leads` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quizid` int(11) NOT NULL,
  `resultid` int(11) NOT NULL,
  `user_fname` varchar(50) NOT NULL,
  `user_lname` varchar(50) NOT NULL,
  `user_company` varchar(100) NOT NULL,
  `user_title` varchar(100) NOT NULL,
  `user_email` varchar(250) NOT NULL,
  `user_mobile` varchar(50) NOT NULL,
  `created` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_learning`;
CREATE TABLE IF NOT EXISTS `#__vquiz_learning` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `title` varchar(250) NOT NULL,
  `alias` varchar(250) NOT NULL,
  `image` varchar(250) NOT NULL,
  `set_price` tinyint(1) NOT NULL,
  `price` float NOT NULL,
  `description` text NOT NULL,
  `urlrestriction` tinyint(1) NOT NULL,
  `minimum_per` int(11) NOT NULL,
  `minimum_custom_per` int(11) NOT NULL,
  `next_quiz_delay` varchar(250) NOT NULL,
  `delay_periods` varchar(50) NOT NULL,
  `certificate` text NOT NULL,
  `certificate_multi_item` text,
  `start_with` varchar(250) NOT NULL,
  `end_with` varchar(250) NOT NULL,
  `cet_digits` int(11) NOT NULL,
  `cet_format` int(11) NOT NULL,
  `cet_type` int(11) NOT NULL,
  `access` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `language` varchar(50) NOT NULL,
  `ordering` int(11) NOT NULL,
  `trivia_results` text NOT NULL,
  `article_id` int(11) NOT NULL,
  `display_result` int(11) NOT NULL,
  `display_certificate` tinyint(1) NOT NULL,
  `endpublish_date` datetime NOT NULL,
  `startpublish_date` datetime NOT NULL,
  `level_release` varchar(25) NOT NULL,
  `quiz_lesson` varchar(25) NOT NULL,
  `quiz_lesson_delay_count` varchar(25) NOT NULL,
  `attempt_count` int(11) NOT NULL,
  `attempt_delay` varchar(250) NOT NULL,
  `attempt_delay_param` varchar(250) NOT NULL,
  `ipaddress_allow` text NOT NULL,
  `quiz_lesson_delay` varchar(25) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_learning_lnq`;
CREATE TABLE IF NOT EXISTS `#__vquiz_learning_lnq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `learningid` int(11) NOT NULL,
  `lessionid` int(11) NOT NULL,
  `quizid` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=398 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_learning_playedquizzes`;
CREATE TABLE IF NOT EXISTS `#__vquiz_learning_playedquizzes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `resultid` int(11) NOT NULL,
  `learning_id` int(11) NOT NULL,
  `quizid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `cookieId` varchar(250) NOT NULL,
  `played` int(11) NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_learning_result`;
CREATE TABLE IF NOT EXISTS `#__vquiz_learning_result` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `learning_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `cookieId` varchar(250) NOT NULL,
  `created` datetime NOT NULL,
  `played_id` int(11) NOT NULL,
  `lession_id` int(11) NOT NULL,
  `video_seen` varchar(10) DEFAULT '0',
  `completed` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_lessons`;
CREATE TABLE IF NOT EXISTS `#__vquiz_lessons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `alias` varchar(250) NOT NULL,
  `thumbnail` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(15) NOT NULL,
  `files` text NOT NULL,
  `slide_img` text NOT NULL,
  `ordering` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `access` tinyint(1) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `language` char(7) NOT NULL,
  `slidesdelay` int(11) NOT NULL,
  `auto_slide` tinyint(1) NOT NULL,
  `slide_control` tinyint(1) NOT NULL,
  `moveslides` int(11) NOT NULL,
  `num_carousel` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_lns`;
CREATE TABLE IF NOT EXISTS `#__vquiz_lns` (
  `lessionid` int(11) NOT NULL,
  `skillid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_monitor_category`;
CREATE TABLE IF NOT EXISTS `#__vquiz_monitor_category` (
  `userid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_monitor_quiz`;
CREATE TABLE IF NOT EXISTS `#__vquiz_monitor_quiz` (
  `userid` int(11) NOT NULL,
  `quizid` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`quizid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_monitor_user`;
CREATE TABLE IF NOT EXISTS `#__vquiz_monitor_user` (
  `userid` int(11) NOT NULL,
  `muserid` int(11) NOT NULL,
  PRIMARY KEY (`userid`,`muserid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_notes`;
CREATE TABLE IF NOT EXISTS `#__vquiz_notes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `notification_type` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `itemid` int(11) NOT NULL,
  `email_subject` text NOT NULL,
  `email_content` text NOT NULL,
  `email_cc` varchar(255) NOT NULL,
  `email_bcc` varchar(255) NOT NULL,
  `seen` int(2) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_notesnuser`;
CREATE TABLE IF NOT EXISTS `#__vquiz_notesnuser` (
  `note_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `seen` tinyint(1) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  PRIMARY KEY (`note_id`,`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

DROP TABLE IF EXISTS `#__vquiz_notifications`;
CREATE TABLE IF NOT EXISTS `#__vquiz_notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `published` tinyint(4) NOT NULL,
  `description` text NOT NULL,
  `type` int(11) NOT NULL,
  `days` int(11) NOT NULL,
  `email_cc` varchar(255) NOT NULL,
  `email_bcc` varchar(255) NOT NULL,
  `send_to_creator` tinyint(4) NOT NULL,
  `send_to_moderator` tinyint(4) NOT NULL,
  `send_to_superuser` tinyint(4) NOT NULL,
  `email_subject` text NOT NULL,
  `email_content` text NOT NULL,
  `created_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified_date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_option`;
CREATE TABLE IF NOT EXISTS `#__vquiz_option` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qid` int(11) NOT NULL,
  `image` varchar(250) NOT NULL,
  `qoption` varchar(250) NOT NULL,
  `correct_ans` tinyint(1) NOT NULL,
  `options_score` int(11) NOT NULL,
  `personality_optionid` varchar(250) NOT NULL,
  `multi_p_options_score` float NOT NULL,
  `category_score` varchar(250) NOT NULL,
  `ordering` int(11) NOT NULL,
  `imageB` varchar(255) DEFAULT NULL,
  `qoptionB` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=112 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_payment_plugin`;
CREATE TABLE IF NOT EXISTS `#__vquiz_payment_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `plugin_type` varchar(50) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `description` mediumtext NOT NULL,
  `ordering` int(11) NOT NULL,
  `published` tinyint(1) NOT NULL,
  `plan_id` int(100) NOT NULL,
  `quiz_id` int(100) NOT NULL,
  `filename` text NOT NULL,
  `created` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` int(11) NOT NULL,
  `checked_out` int(11) NOT NULL,
  `checked_out_time` datetime NOT NULL,
  `params` text NOT NULL,
  `language` varchar(11) NOT NULL,
  `access` varchar(255) NOT NULL,
  `metadata` varchar(2048) NOT NULL,
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `featured` varchar(255) NOT NULL,
  `report` varchar(255) NOT NULL,
  `hits` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


INSERT INTO `#__vquiz_payment_plugin` (`id`, `title`, `plugin_type`, `alias`, `icon`, `description`, `ordering`, `published`, `plan_id`, `quiz_id`, `filename`, `created`, `created_by`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `params`, `language`, `access`, `metadata`, `metakey`, `metadesc`, `featured`, `report`, `hits`) VALUES
(1, 'Wire', 'wire', 'wire', '14825782721421251030_Money2.png', '', 0, 1, 0, 0, '', '2018-09-16 06:59:09', 0, '2018-09-16 06:59:09', 0, 0, '1000-01-01 00:00:00', '[]', 'en-GB', '1', '', '', '', '0', '', 0),
(2, 'Paypal', 'paypal', 'paypal', '1482331900paypal_logo.png', '', 0, 1, 0, 0, '', '2018-09-16 06:59:09', 0, '2018-09-16 06:59:09', 0, 0, '2018-01-11 11:27:06', '{\"paypal_email\":\"\",\"paypal_sandbox\":\"1\",\"wire_status\":\"0\"}', 'en-GB', '1', '', '', '', '1', '', 0),
(3, 'Paypal Pro', 'paypal_pro', '', '', 'Paypal Pro', 0, 1, 0, 0, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '{\"paypal_email\":\"\",\"paypal_sandbox\":\"1\",\"paypal_pro_email\":\"\",\"paypal_pro_api_username\":\"\",\"paypal_pro_api_password\":\"\",\"paypal_pro_api_signature\":\"\",\"paypal_pro_sandbox\":\"1\",\"wire_status\":\"0\"}', '', '1', '', '', '', '', '', 0);


DROP TABLE IF EXISTS `#__vquiz_personality_message`;
CREATE TABLE IF NOT EXISTS `#__vquiz_personality_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quizid` int(11) NOT NULL,
  `answer` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `category_combination` varchar(250) NOT NULL,
  `article_id` int(11) NOT NULL,
  `color` varchar(250) NOT NULL,
  `concate_desc` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_plans`;
CREATE TABLE IF NOT EXISTS `#__vquiz_plans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `published` tinyint(1) DEFAULT '1',
  `ordering` int(255) DEFAULT '0',
  `access_group` varchar(250) NOT NULL,
  `price` varchar(255) DEFAULT '0',
  `expirationtype` varchar(255) DEFAULT '0000-00-00 00:00:00',
  `created_date` datetime DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime NOT NULL,
  `expiration` varchar(255) NOT NULL,
  `description` text,
  `details` text,
  `applyall` tinyint(4) NOT NULL,
  `applyallquizss` tinyint(1) NOT NULL,
  `quizcategory` varchar(255) NOT NULL,
  `quizid` varchar(255) NOT NULL,
  `usergroup_id` int(11) NOT NULL,
  `params` text,
  `created_by` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_plans_order`;
CREATE TABLE IF NOT EXISTS `#__vquiz_plans_order` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `buyer_id` int(11) NOT NULL,
  `coupon_code` varchar(255) NOT NULL,
  `app_id` int(25) NOT NULL,
  `subtotal` decimal(15,5) NOT NULL,
  `discount_amount` decimal(15,5) NOT NULL,
  `total` decimal(15,5) NOT NULL DEFAULT '0.00000',
  `tax` decimal(15,5) NOT NULL,
  `currency` char(3) DEFAULT NULL,
  `status` varchar(255) NOT NULL DEFAULT '0',
  `gateway_txn_id` varchar(255) NOT NULL,
  `gateway_parent_txn` varchar(255) NOT NULL,
  `subscr_id` varchar(255) NOT NULL,
  `checked_out` int(11) DEFAULT '0',
  `checked_out_time` datetime DEFAULT NULL,
  `created_date` datetime NOT NULL,
  `modified_date` datetime NOT NULL,
  `order_key` varchar(255) NOT NULL,
  `paid_date` datetime NOT NULL,
  `params` text,
  PRIMARY KEY (`order_id`),
  KEY `idx_buyer_id` (`buyer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_plans_subscription`;
CREATE TABLE IF NOT EXISTS `#__vquiz_plans_subscription` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `plan_id` int(11) NOT NULL,
  `quiz_id` int(11) NOT NULL,
  `learning_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `total` decimal(15,5) DEFAULT '0.00000',
  `subscription_date` datetime DEFAULT '0000-00-00 00:00:00',
  `expiration_date` datetime DEFAULT '0000-00-00 00:00:00',
  `cancel_date` datetime DEFAULT '0000-00-00 00:00:00',
  `checked_out` int(11) DEFAULT '0',
  `checked_out_time` datetime DEFAULT '0000-00-00 00:00:00',
  `modified_date` datetime DEFAULT '0000-00-00 00:00:00',
  `ordering` int(255) NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `#__vquiz_qns`;
CREATE TABLE IF NOT EXISTS `#__vquiz_qns` (
  `questionid` int(11) NOT NULL,
  `skillid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_quesncategory`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quesncategory` (
  `questionid` int(11) NOT NULL,
  `catid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_quesns`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quesns` (
  `questionid` int(11) NOT NULL,
  `skillid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_question`;
CREATE TABLE IF NOT EXISTS `#__vquiz_question` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `questiontime_parameter` varchar(50) NOT NULL,
  `question_timelimit` int(11) NOT NULL,
  `optiontype` int(11) NOT NULL,
  `user_comment` int(11) NOT NULL,
  `flagcount` int(11) NOT NULL,
  `qtitle` text NOT NULL,
  `explanation` text NOT NULL,
  `hint` text NOT NULL,
  `transcript` text NOT NULL,
  `scoretype` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `expire_timescore` int(11) NOT NULL,
  `penalty` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  `published` tinyint(1) NOT NULL,
  `created_by` int(11) NOT NULL,
  `text_field_ans` varchar(250) NOT NULL,
  `case_sensitive` int(11) NOT NULL,
  `random_option` int(11) NOT NULL,
  `questiongroup` int(11) NOT NULL,
  `modified_by` int(11) NOT NULL,
  `other_option` tinyint(1) NOT NULL,
  `hotspot_img` varchar(255) DEFAULT NULL,
  `rectangle` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `#__vquiz_quizdraft`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quizdraft` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `quizid` int(11) NOT NULL,
  `session_data` text NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_quiznques`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quiznques` (
  `quizid` int(11) NOT NULL,
  `questionid` int(11) NOT NULL,
  PRIMARY KEY (`quizid`,`questionid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_quizns`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quizns` (
  `quizid` int(11) NOT NULL,
  `skillid` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_quizresult`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quizresult` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quizid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `starttime` time NOT NULL,
  `endtime` time NOT NULL,
  `score` int(11) NOT NULL,
  `passed_score` int(11) NOT NULL,
  `maxscore` int(11) NOT NULL,
  `personality_result` varchar(111) NOT NULL,
  `created` datetime NOT NULL,
  `ip_address` text NOT NULL,
  `textarea_quiz` tinyint(1) NOT NULL,
  `question_group_result` text NOT NULL,
  `drag_answer` varchar(255) DEFAULT NULL,
  `hotspotAns` varchar(255) DEFAULT NULL,
  `cet_number` varchar(250) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=187 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `#__vquiz_quizresult_qna`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quizresult_qna` (
  `qna_id` int(11) NOT NULL AUTO_INCREMENT,
  `resultid` int(11) NOT NULL,
  `qid` int(11) NOT NULL,
  `answer` varchar(250) NOT NULL,
  `text_answer` varchar(250) NOT NULL,
  `textarea_answer` text NOT NULL,
  `textarea_score` float NOT NULL,
  `comment` varchar(250) NOT NULL,
  `personality_result` varchar(250) NOT NULL,
  `multi_weight_personality` varchar(250) NOT NULL,
  `multi_weight_percentage` varchar(250) NOT NULL,
  PRIMARY KEY (`qna_id`),
  UNIQUE KEY `resultid` (`resultid`,`qid`)
) ENGINE=MyISAM AUTO_INCREMENT=511 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_quizresult_questiongroup`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quizresult_questiongroup` (
  `resultid` int(11) NOT NULL,
  `guestiongroup` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  PRIMARY KEY (`resultid`,`guestiongroup`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_quizuser_invitation`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quizuser_invitation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `result_id` int(11) NOT NULL,
  `emails` text NOT NULL,
  `reciver_result_id` text NOT NULL,
  `played` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_quizzes`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quizzes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asset_id` int(10) NOT NULL,
  `catid` int(11) NOT NULL,
  `startpublish_date` datetime NOT NULL,
  `endpublish_date` datetime NOT NULL,
  `title` varchar(250) NOT NULL,
  `alias` text NOT NULL,
  `image` text NOT NULL,
  `set_price` tinyint(1) NOT NULL,
  `price` float NOT NULL,
  `passed_score` float NOT NULL,
  `total_timelimit` int(11) NOT NULL,
  `totaltime_parameter` varchar(50) NOT NULL,
  `random_question` tinyint(1) NOT NULL,
  `quiztype` int(11) NOT NULL,
  `prev_button` tinyint(1) NOT NULL,
  `slider_bar` int(11) NOT NULL,
  `question_number` tinyint(1) NOT NULL,
  `skip_button` tinyint(1) NOT NULL,
  `flag` tinyint(1) NOT NULL,
  `livescore` int(11) NOT NULL,
  `correctans` tinyint(1) NOT NULL,
  `question_options_display` int(11) NOT NULL,
  `explanation` tinyint(1) NOT NULL,
  `hint` int(1) NOT NULL,
  `transcript` int(1) NOT NULL,
  `penalty` tinyint(1) NOT NULL,
  `userscore` tinyint(11) NOT NULL,
  `graph_type` varchar(250) NOT NULL,
  `paging` int(1) NOT NULL,
  `paging_limit` int(11) NOT NULL,
  `next_quiz` int(11) NOT NULL,
  `prev_quiz` int(11) NOT NULL,
  `take_snapshot` int(11) NOT NULL,
  `quiz_prepare_content` int(11) NOT NULL,
  `question_prepare_content` int(11) NOT NULL,
  `continuous_question` int(11) NOT NULL,
  `later_play` int(11) NOT NULL,
  `invite` int(11) NOT NULL,
  `disable_print_copy_result` int(11) NOT NULL,
  `share_button` int(11) NOT NULL,
  `share_btn_choosed` varchar(50) NOT NULL,
  `question_key` int(11) NOT NULL,
  `quiz_certificate` int(11) NOT NULL,
  `accessuser` int(11) NOT NULL,
  `attempt_count` int(11) NOT NULL,
  `count_ipaddress` tinyint(1) NOT NULL,
  `attempt_delay` int(11) NOT NULL,
  `delay_periods` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `created` datetime NOT NULL,
  `created_by` text NOT NULL,
  `published` tinyint(1) NOT NULL,
  `featured` tinyint(1) NOT NULL,
  `ordering` int(11) NOT NULL,
  `language` char(7) NOT NULL,
  `access` int(11) NOT NULL,
  `question_limit` int(11) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_desc` text NOT NULL,
  `show_graph` int(11) NOT NULL,
  `answers_type` int(11) NOT NULL,
  `personality_type` int(11) NOT NULL,
  `multi_p_percentage` float NOT NULL,
  `multi_p_score` int(11) NOT NULL,
  `completion_level` int(11) NOT NULL,
  `display_result` int(11) NOT NULL,
  `ipaddress_allow` text NOT NULL,
  `random_option` tinyint(1) NOT NULL,
  `answer_sheet_option` tinyint(1) NOT NULL,
  `prev_answer` tinyint(1) NOT NULL,
  `answer_sheet` tinyint(1) NOT NULL,
  `certificate` text NOT NULL,
  `textformat` text NOT NULL,
  `start_with` varchar(250) NOT NULL,
  `end_with` varchar(250) NOT NULL,
  `cet_digits` int(11) NOT NULL,
  `cet_format` int(11) NOT NULL,
  `cet_type` int(11) NOT NULL,
  `input_first_name` int(11) NOT NULL,
  `input_last_name` int(1) NOT NULL,
  `input_company` int(11) NOT NULL,
  `input_title` int(11) NOT NULL,
  `input_email` int(11) NOT NULL,
  `input_mobile` int(11) NOT NULL,
  `answersheet_explanation` tinyint(1) NOT NULL,
  `lead_generate` tinyint(1) NOT NULL,
  `lead_generate_mandatory` tinyint(1) NOT NULL,
  `play_users` text NOT NULL,
  `play_user_name` text NOT NULL,
  `enable_questiongroup` tinyint(1) NOT NULL,
  `show_qgroup_title` int(1) NOT NULL,
  `show_qgroup_description` int(1) NOT NULL,
  `access_token` text NOT NULL,
  `questionreview` int(11) NOT NULL,
  `questionreview_answer` int(11) NOT NULL,
  `questionreview_option` int(11) NOT NULL,
  `questionreview_question` int(11) NOT NULL,
  `questionreview_qlink` int(11) NOT NULL,
  `questionreview_box` int(11) NOT NULL,
  `lead_generate_mendatory` int(11) NOT NULL,
  `lead_generate_shows` int(11) NOT NULL,
  `play_user_ids` text NOT NULL,
  `save_certificate` int(1) NOT NULL,
  `cet_name` varchar(250) NOT NULL,
  `article_link_id` int(11) NOT NULL,
  `submit_button` tinyint(4) NOT NULL,
  `force_correct_answer` tinyint(4) NOT NULL,
  `correct_answer_msg` text NOT NULL,
  `wrong_answer_msg` text NOT NULL,
  `instruction_msg` text NOT NULL,
  `correct_answer_color` varchar(10) NOT NULL,
  `wrong_answer_color` varchar(10) NOT NULL,
  `instruction_msg_color` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;



DROP TABLE IF EXISTS `#__vquiz_quizzes_branching`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quizzes_branching` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `apply_text` varchar(250) NOT NULL,
  `quizid` int(11) NOT NULL,
  `ruleid` int(11) NOT NULL,
  `rule_questionid` int(11) NOT NULL,
  `rule_questiontitle` varchar(50) NOT NULL,
  `rule_optionid` int(11) NOT NULL,
  `rule_weight` int(11) NOT NULL,
  `rule_weight_check` int(11) NOT NULL,
  `rule_scorepercentile` int(11) NOT NULL,
  `rule_wno_question` int(11) NOT NULL,
  `rule_specific_select` int(11) NOT NULL,
  `applyid` int(11) NOT NULL,
  `apply_questionid` int(11) NOT NULL,
  `apply_questiontitle` varchar(250) NOT NULL,
  `apply_weight` int(11) NOT NULL,
  `apply_weight_check` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_quizzes_questiongroup`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quizzes_questiongroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `qorder` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `quizid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_quizzes_questiongroup_message`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quizzes_questiongroup_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quizid` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `message` text CHARACTER SET latin1 NOT NULL,
  `rating` varchar(20) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_quiz_personality_category`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quiz_personality_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quizid` int(11) NOT NULL,
  `count_column` int(11) NOT NULL,
  `category` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_quiz_score_category`;
CREATE TABLE IF NOT EXISTS `#__vquiz_quiz_score_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quizid` int(11) NOT NULL,
  `category` varchar(250) NOT NULL,
  `score_depend` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_skills`;
CREATE TABLE IF NOT EXISTS `#__vquiz_skills` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(250) NOT NULL,
  `published` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_tax`;
CREATE TABLE IF NOT EXISTS `#__vquiz_tax` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(250) NOT NULL,
  `tax_value` int(11) NOT NULL,
  `published` int(2) NOT NULL,
  `tax_desc` text NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_trivia_message`;
CREATE TABLE IF NOT EXISTS `#__vquiz_trivia_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `quizid` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `message` text NOT NULL,
  `rating` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `article_link_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `#__vquiz_users`;
CREATE TABLE IF NOT EXISTS `#__vquiz_users` (
  `userid` int(11) NOT NULL DEFAULT '0',
  `profile_pic` varchar(250) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `comment` varchar(250) NOT NULL,
  `dob` date NOT NULL,
  `country` varchar(50) NOT NULL,
  PRIMARY KEY (`userid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `#__vquiz_widget`;
CREATE TABLE IF NOT EXISTS `#__vquiz_widget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `chart_type` varchar(250) NOT NULL,
  `datatype_option` varchar(250) NOT NULL,
  `data` text,
  `detail` text,
  `access_level` text NOT NULL,
  `create_time` datetime NOT NULL,
  `userid` int(11) NOT NULL,
  `site` tinyint(1) NOT NULL,
  `single_user` tinyint(1) NOT NULL,
  `ordering` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;


INSERT INTO `#__vquiz_widget` (`id`, `name`, `chart_type`, `datatype_option`, `data`, `detail`, `access_level`, `create_time`, `userid`, `site`, `single_user`, `ordering`) VALUES
(27, 'Top Played Quizzes', '', 'predefined', NULL, '{\"descriptin_widget\":\"Top Played Quizzes\",\"existing_database_table\":\"Top Played Quizzes\",\"remote_query_value\":\"SELECT q.title as `{quiz_title}`, count(r.userid) as Count from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id  WHERE q.published=1 {category_id}  {quiz_type} {created_by} group by r.quizid order by r.id desc LIMIT 10\",\"box_column\":\"5\",\"box_row\":\"2\",\"style_layout\":\"listing_formate\",\"style_type_allow\":\"\",\"style_layout_editor\":\"\"}', '{\"access_interface\":[\"1\"]}', '2016-12-21 12:48:52', 509, 0, 0, 9),
(29, 'Quizzes being played', 'Column Chart', 'predefined', NULL, '{\"descriptin_widget\":\"Played Quizzes\",\"existing_database_table\":\"Played Quizzes\",\"remote_query_value\":\"SELECT date_format(r.created, \'{type}\') as month ,count(r.userid) as users from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id where q.published=1 {category_id} {created_by} group by month order by r.id asc\",\"box_column\":\"5\",\"box_row\":\"2\",\"style_layout\":\"charting_formate\",\"style_type_allow\":\"\",\"limit_value\":\"\",\"series_column_color\":\"\",\"legend\":\"none\",\"x_axis\":\"Date\",\"y_axis\":\"Users\",\"style_layout_editor\":\"\"}', '{\"access_interface\":[\"1\"]}', '2016-12-21 13:36:44', 509, 0, 0, 6),
(30, 'Top Played Quizzes', 'Pie Chart', 'predefined', NULL, '{\"descriptin_widget\":\"Top Played Quizzes\",\"existing_database_table\":\"Top Played Quizzes\",\"remote_query_value\":\"SELECT q.title as qtitle,q.id as quizid ,count(r.userid) as totaluser from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id  WHERE q.published=1 {category_id}  {quiz_type} {created_by} group by r.quizid order by r.id desc LIMIT 10\",\"box_column\":\"5\",\"box_row\":\"2\",\"style_layout\":\"charting_formate\",\"style_type_allow\":\"\",\"series_column_color\":\"\",\"legend\":\"none\",\"piehole\":\"\",\"style_layout_editor\":\"\"}', '{\"access_interface\":[\"1\"]}', '2016-12-21 13:41:29', 509, 0, 0, 7),
(39, 'Daily Quiz Players', 'Line Chart', 'predefined', NULL, '{\"descriptin_widget\":\"COM_VQUIZ_DAYWISE_REGISTER_USERS_DESC\",\"existing_database_table\":\"COM_VQUIZ_DAYWISE_REGISTER_USERS\",\"remote_query_value\":\"SELECT date_format(r.created, \\\"%e, %b\\\") as func ,count(r.userid) as `Total Users` from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id where q.published=1 group by func order by r.id asc\",\"box_column\":\"5\",\"box_row\":\"2\",\"style_layout\":\"charting_formate\",\"style_type_allow\":\"c,l\",\"limit_value\":\"\",\"series_column_color\":\"#5cd183\",\"legend\":\"none\",\"x_axis\":\"Date\",\"y_axis\":\"Users\",\"chart_churve\":\"chart_churve\",\"style_layout_editor\":\"\"}', '{\"access_interface\":[\"8\"]}', '2016-12-21 12:49:12', 509, 0, 0, 10),
(41, '', '', 'predefined', NULL, '{\"descriptin_widget\":\"Total Played Quiz\",\"existing_database_table\":\"Total Played Quiz\",\"remote_query_value\":\"SELECT count(r.id) as `total_quiz` from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id where q.published=1 {created_by}\",\"box_column\":\"2\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"s\",\"limit_value\":\"\",\"style_layout_editor\":\"<div class=\\\"total_played_quiz\\\">\\r\\n<p><span class=\\\"q_pic\\\">Image<\\/span> <span class=\\\"hex_value\\\">{total_quiz}<\\/span><\\/p>\\r\\n<h3>Quizzes played so far<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"1\"]}', '2016-12-21 11:59:39', 509, 0, 0, 1),
(42, '', '', 'predefined', NULL, '\r\n{\"descriptin_widget\":\"Today Played Quiz\",\"existing_database_table\":\"Today Played Quiz\",\"remote_query_value\":\"SELECT count(r.id) as `total_quiz` from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id where q.published=1 and r.created=curdate()  {created_by}\",\"box_column\":\"2\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"s\",\"limit_value\":\"\",\"style_layout_editor\":\"<div class=\\\"today_played_quiz\\\">\\r\\n<p><span class=\\\"q_pic\\\">Image<\\/span> <span class=\\\"hex_value\\\">{total_quiz}<\\/span><\\/p>\\r\\n<h3>Quizzes played today<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"1\"]}', '2016-12-21 12:00:18', 509, 0, 0, 2),
(44, '', '', 'predefined', NULL, '{\"descriptin_widget\":\"Average Score\",\"existing_database_table\":\"Average Score\",\"remote_query_value\":\"SELECT TRUNCATE(AVG((i.score*100)\\/i.maxscore),2) as `average score` FROM `#__vquiz_quizresult` as i LEFT JOIN `#__users` as u ON i.userid = u.id WHERE i.passed_score !=0 and `i`.`userid`{userid} order by i.id desc\",\"box_column\":\"3\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"s\",\"limit_value\":\"\",\"style_layout_editor\":\"<div class=\\\"average_score\\\">\\r\\n<p><span class=\\\"q_pic\\\">Image<\\/span> <span class=\\\"hex_value\\\">{average score}%<\\/span><\\/p>\\r\\n<h3>Average Score<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"2\",\"8\"]}', '2016-12-17 14:19:36', 509, 1, 1, 6),
(45, 'Quiz Players across the Globe', 'Geo Chart', 'predefined', NULL, '{\"descriptin_widget\":\"Location Wise Users\",\"existing_database_table\":\"Location Wise Users\",\"remote_query_value\":\"SELECT i.country as Country,count(u.id) as `Total Users` from #__vquiz_users as i left join #__users as u on i.userid=u.id group by i.country order by u.id desc\",\"box_column\":\"10\",\"box_row\":\"3\",\"style_layout\":\"charting_formate\",\"style_type_allow\":\"c,l\",\"extra_condition\":\"\",\"limit_value\":\"\",\"series_column_color\":\"#4eeb49\",\"legend\":\"in\",\"region_label\":\"-1\",\"displaymode\":\"region\",\"style_layout_editor\":\"\"}', '{\"access_interface\":[\"8\"]}', '2016-12-21 12:51:26', 509, 0, 0, 11),
(48, 'top Play quiz', '', 'predefined', NULL, '{\"descriptin_widget\":\"Top Played Quizzes\",\"existing_database_table\":\"Top Played Quizzes\",\"remote_query_value\":\"SELECT q.title as `{quiz_title}` ,count(r.userid) as Count from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id  WHERE q.published=1 {category_id}  {quiz_type} {created_by} group by r.quizid order by r.id desc LIMIT 10\",\"box_column\":\"5\",\"box_row\":\"2\",\"style_layout\":\"listing_formate\",\"style_type_allow\":\"\",\"style_layout_editor\":\"\\t\\t\"}', '{\"access_interface\":[\"1\"]}', '2016-12-02 11:48:28', 759, 1, 0, 12),
(63, 'Playes Quizzes', 'Column Chart', 'predefined', NULL, '{\"descriptin_widget\":\"Played Quizzes\",\"existing_database_table\":\"Played Quizzes\",\"remote_query_value\":\"SELECT date_format(r.created, \'{type}\') as month ,count(r.userid) as users from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id where q.published=1 {category_id} {created_by} group by month order by r.id asc\",\"box_column\":\"10\",\"box_row\":\"2\",\"style_layout\":\"charting_formate\",\"style_type_allow\":\"\",\"limit_value\":\"\",\"series_column_color\":\"\",\"legend\":\"none\",\"x_axis\":\"Date\",\"y_axis\":\"Users\",\"style_layout_editor\":\"\\t\\t\"}\r\n', '{\"access_interface\":[\"1\"]}', '2016-12-02 12:07:14', 759, 1, 0, 11),
(64, 'Top Played Quizzes', 'Pie Chart', 'predefined', NULL, '{\"descriptin_widget\":\"Top Played Quizzez\",\"existing_database_table\":\"Top Played Quizzez\",\"remote_query_value\":\"SELECT q.title as qtitle,q.id as quizid ,count(r.userid) as totaluser from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id  WHERE q.published=1 {category_id}  {quiz_type} {created_by} group by r.quizid order by r.id desc LIMIT 10\",\"box_column\":\"5\",\"box_row\":\"2\",\"style_layout\":\"charting_formate\",\"style_type_allow\":\"\",\"series_column_color\":\"\",\"legend\":\"none\",\"piehole\":\"\",\"style_layout_editor\":\"\"}', '{\"access_interface\":[\"2\",\"8\"]}', '2016-12-19 11:47:02', 509, 1, 0, 12),
(67, 'Result', 'Table Chart', 'predefined', NULL, '{\"descriptin_widget\":\"COM_VQUIZ_QUIZ_RESULT_DESC\",\"existing_database_table\":\"COM_VQUIZ_QUIZ_RESULT\",\"remote_query_value\":\"SELECT q.title as `{quiz_title}`, if(u.username=\\\"NULL\\\", \\\"No User\\\", u.username) as `{name}`, i.score as `{score}`, IF(i.`score`>=((i.passed_score*i.maxscore)\\/100), \\\"Pass\\\", \\\"Fail\\\") as `{quiz_result}`, i.created as `{date}` FROM #__vquiz_quizresult as i LEFT JOIN #__vquiz_quizzes as q ON i.quizid = q.id LEFT JOIN #__users as u ON i.userid = u.id WHERE i.passed_score !=0 and i.userid{userid} group by i.id order by i.id desc\",\"box_column\":\"10\",\"box_row\":\"2\",\"style_layout\":\"charting_formate\",\"style_type_allow\":\"l\",\"limit_value\":\"\",\"table_page\":\"1\",\"table_page_size\":\"10\",\"table_page_button\":\"1\",\"style_layout_editor\":\"\"}\r\n', '{\"access_interface\":[\"1\"]}', '2016-12-15 07:43:51', 509, 1, 1, 25),
(69, '', '', 'predefined', NULL, '{\"descriptin_widget\":\"Total Played Quiz\",\"existing_database_table\":\"Total Played Quiz\",\"remote_query_value\":\"SELECT count(r.id) as `total_quiz` from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id where q.published=1 {created_by}\",\"box_column\":\"2\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"s\",\"limit_value\":\"\",\"style_layout_editor\":\"<div class=\\\"total_played_quiz\\\">\\r\\n<p><span class=\\\"q_pic\\\">Image<\\/span> <span class=\\\"hex_value\\\">{total_quiz}<\\/span><\\/p>\\r\\n<h3>Quizzes played so far<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"1\"]}', '2016-12-20 05:51:15', 509, 1, 0, 9),
(70, '', '', 'predefined', NULL, '{\"descriptin_widget\":\"Today Played Quiz\",\"existing_database_table\":\"Today Played Quiz\",\"remote_query_value\":\"SELECT count(r.id) as `total_quiz` from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id where q.published=1 and r.created=curdate()  {created_by}\",\"box_column\":\"2\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"s\",\"limit_value\":\"\",\"style_layout_editor\":\"<div class=\\\"today_played_quiz\\\">\\r\\n<p><span class=\\\"q_pic\\\">Image<\\/span> <span class=\\\"hex_value\\\">{total_quiz}<\\/span><\\/p>\\r\\n<h3>Quizzes played today<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"1\"]}', '2016-12-20 05:52:41', 509, 1, 0, 5),
(71, '', '', 'predefined', NULL, '{\"descriptin_widget\":\"I Played Quiz\",\"existing_database_table\":\"I Played Quiz\",\"remote_query_value\":\"SELECT count(r.id) as `total_quiz` from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id where r.`userid`{userid}  \",\"box_column\":\"3\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"s\",\"limit_value\":\"\",\"style_layout_editor\":\"<div class=\\\"i_played\\\">\\r\\n<p><span class=\\\"q_pic\\\">Image<\\/span> <span class=\\\"hex_value\\\">{total_quiz}<\\/span><\\/p>\\r\\n<h3>I Played<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"2\",\"8\"]}', '2016-12-21 06:24:26', 509, 1, 1, 10),
(72, '', '', 'predefined', NULL, '{\"descriptin_widget\":\"Average Score\",\"existing_database_table\":\"Average Score\",\"remote_query_value\":\"SELECT TRUNCATE(AVG((i.score*100)\\/i.maxscore),2) as `average score` FROM `#__vquiz_quizresult` as i LEFT JOIN `#__users` as u ON i.userid = u.id WHERE i.passed_score !=0 and `i`.`userid`{userid} order by i.id desc\",\"box_column\":\"2\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"s\",\"limit_value\":\"\",\"style_layout_editor\":\"<div class=\\\"average_score\\\">\\r\\n<p><span class=\\\"q_pic\\\">Image<\\/span> <span class=\\\"hex_value\\\">{average score}%<\\/span><\\/p>\\r\\n<h3>Average Score<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"2\"]}', '2018-05-08 10:58:32', 426, 0, 0, 4),
(73, 'Quiz Players across the Globe', 'Geo Chart', 'predefined', NULL, '{\"descriptin_widget\":\"Location Wise Users\",\"existing_database_table\":\"Location Wise Users\",\"remote_query_value\":\"SELECT i.country as Country,count(u.id) as `Total Users` from #__vquiz_users as i left join #__users as u on i.userid=u.id group by i.country order by  u.id desc\",\"box_column\":\"10\",\"box_row\":\"3\",\"style_layout\":\"charting_formate\",\"style_type_allow\":\"c,l\",\"extra_condition\":\"\",\"limit_value\":\"\",\"series_column_color\":\"#4eeb49\",\"legend\":\"in\",\"region_label\":\"-1\",\"displaymode\":\"region\",\"style_layout_editor\":\"\"}', '{\"access_interface\":[\"8\"]}', '2016-12-15 12:19:59', 509, 1, 0, 28),
(74, '', '', 'predefined', NULL, '{\"descriptin_widget\":\"User Top Score\",\"existing_database_table\":\"User Top Score\",\"remote_query_value\":\"SELECT TRUNCATE(MAX((i.score*100)\\/i.maxscore),2) as `maximum` from #__vquiz_quizresult as i left join #__users as u on i.userid=u.id where `i`.`userid`{userid} order by i.id desc\",\"box_column\":\"2\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"l,s\",\"limit_value\":\"\",\"style_layout_editor\":\"<div class=\\\"top_score\\\">\\r\\n<p><span class=\\\"q_pic\\\">Image<\\/span> <span class=\\\"hex_value\\\">{maximum}% <\\/span><\\/p>\\r\\n<h3>Top Score<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"2\",\"8\"]}', '2016-12-20 09:19:18', 509, 1, 1, 7),
(75, '', '', 'predefined', NULL, '{\"descriptin_widget\":\"Last Play Quiz\",\"existing_database_table\":\"Last Play Quiz\",\"remote_query_value\":\"SELECT TRUNCATE((i.score*100)\\/i.maxscore,2) as `lastscore` from #__vquiz_quizresult as i left join #__users as u on i.userid=u.id where `i`.`userid`{userid} order by i.id desc LIMIT 1\",\"box_column\":\"3\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"l,s\",\"style_layout_editor\":\"<div class=\\\"last_play_quiz\\\">\\r\\n<p><span class=\\\"q_pic\\\">&nbsp; Image<\\/span> <span class=\\\"hex_value\\\">{lastscore}%<\\/span><\\/p>\\r\\n<h3>Last Play Quiz<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"2\",\"8\"]}', '2016-12-20 09:45:42', 509, 1, 1, 8),
(76, '', '', 'predefined', NULL, '{\"descriptin_widget\":\"COM_VQUIZ_TOTAL_PASS_USERS_DESC\",\"existing_database_table\":\"COM_VQUIZ_TOTAL_PASS_USERS\",\"remote_query_value\":\"SELECT  SUM(IF(((i.score*100)\\/i.maxscore)>=i.`passed_score`, 1, 0)) as `quizresult` FROM `#__vquiz_quizresult` as i LEFT JOIN `#__vquiz_quizzes` as q on q.id=i.quizid LEFT JOIN `#__users` as u ON i.userid = u.id WHERE i.passed_score !=0 {created_by} order by i.id desc\",\"box_column\":\"2\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"l,s\",\"limit_value\":\"\",\"style_layout_editor\":\"<div class=\\\"total-pass-users\\\">\\r\\n<p><span class=\\\"q_pic\\\">Image<\\/span> <span class=\\\"hex_value\\\">{quizresult}<\\/span><\\/p>\\r\\n<h3>Total Passed Users<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"2\",\"8\"]}', '2018-05-08 11:00:06', 426, 2, 0, 5),
(77, '', '', 'predefined', NULL, '{\"descriptin_widget\":\"COM_VQUIZ_TOTAL_FAIL_USERS_DESC\",\"existing_database_table\":\"COM_VQUIZ_TOTAL_FAIL_USERS\",\"remote_query_value\":\"SELECT  SUM(IF(((i.score*100)\\/i.maxscore)<i.`passed_score`, 1, 0)) as `quizresult` FROM `#__vquiz_quizresult` as i LEFT JOIN `#__vquiz_quizzes` as q on q.id=i.quizid LEFT JOIN `#__users` as u ON i.userid = u.id WHERE i.passed_score !=0 {created_by} order by i.id desc\",\"box_column\":\"2\",\"box_row\":\"1\",\"style_layout\":\"single_formate\",\"style_type_allow\":\"l,s\",\"limit_value\":\"\",\"style_layout_editor\":\"<div class=\\\"total-fail-users\\\">\\r\\n<p><span class=\\\"q_pic\\\">Image<\\/span> <span class=\\\"hex_value\\\">{quizresult}<\\/span><\\/p>\\r\\n<h3>Total Failed Users<\\/h3>\\r\\n<\\/div>\"}', '{\"access_interface\":[\"2\",\"8\"]}', '2016-12-21 12:01:06', 509, 2, 0, 3),
(79, 'Recent Quiz Results', 'Table Chart', 'predefined', NULL, '{\"descriptin_widget\":\"Quiz Result Display\",\"existing_database_table\":\"Quiz Result Display\",\"remote_query_value\":\"SELECT (select title from `#__vquiz_quizzes` as `qs` where `i`.quizid=`qs`.`id` LIMIT 1) as `{quiz_title}`, (select title from `#__vquiz_category` as `c` where `q`.catid=`c`.`id` LIMIT 1) as `{quiz_category}`, i.score as `{score}`, IF(i.`score`>=((i.passed_score*i.maxscore)\\/100), \\\"{quiz_pass}\\\", \\\"{quiz_fail}\\\") as `{quiz_result}`, i.created as `{date}` FROM `#__vquiz_quizresult` as i LEFT JOIN `#__vquiz_quizzes` as `q` on `i`.quizid=`q`.id  LEFT JOIN `#__users` as u ON i.userid = u.id WHERE i.passed_score !=0 {created_by}  group by i.id order by i.id desc\",\"box_column\":\"10\",\"box_row\":\"2\",\"style_layout\":\"charting_formate\",\"style_type_allow\":\"l\",\"table_page\":\"1\",\"table_page_size\":\"10\",\"table_page_button\":\"1\",\"style_layout_editor\":\"\"}', '{\"access_interface\":[\"2\",\"8\"]}', '2016-12-21 12:48:04', 509, 2, 0, 8);