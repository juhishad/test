<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );

 

class TableLessons extends JTable
{

	var $id = null;
	var $catid = 0;
	var $title = null;
	var $desc = null;
	var $type = null;
	var $files = null;
	var $filepath = null;
	var $access = 1;
	var $published = 1;
	var $lang = null;

	function __construct(& $db) {

		parent::__construct('#__vquiz_lessons', 'id', $db);

	}
	
	function bind($array, $ignore = '')
	{
		return parent::bind($array, $ignore);
	}
	
	function store($updateNulls = false)
	{
		 
		//store single file(pdf)
		
		$input=JFactory::getApplication()->input;
		$files=$input->files->get('files');
		$data = JRequest::get( 'post' );
		
		$skillid=$input->post->get('skillid','',array());
		
		for($i=0,$j=1;$i<count($skillid);$i++,$j++){
			
			$obj=new stdClass();
			$obj->skillid=$skillid[$i];
			$obj->lessionid=$this->id;
			if(!$this->_db->insertObject('#__vquiz_lns',$obj)){
				$this->setError(JText::_('JLIB_DATABASE_ERROR_MUSTCONTAIN_A_TITLE_CATEGORY'));
				return false;
			} 
		}	
 
		if($data["id"]){
			$query = ' SELECT files from #__vquiz_lessons WHERE id = '.$data["id"];
			$this->_db->setQuery( $query );
			$oldimage_path = $this->_db->loadResult();
		}


		if($files){
			 
			$tmpFilePath=$files['tmp_name'];
	
			if(!empty($files['name'])){
				$name=time().'_'.JFile::makeSafe($files['name']);
				if($tmpFilePath!=""){
					$newFilePath=JPATH_ROOT."/media/com_vquiz/vquiz/images/files/".$name;
					$flag=JFile::upload($tmpFilePath, $newFilePath);
					
					if($flag and $oldimage_path)
					{
					
						$path=JPATH_ROOT."/media/com_vquiz/vquiz/images/files/";
						unlink($path.$oldimage_path);
					
					}
				
				}
			} 
				 
			$this->files=$name;
		}
		
		 
		
		if(!parent::store($updateNulls))	{
			return false;
		}
				
		return true;
		
	}
	
 

}