<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.database.tablenested'); 

class TableQuizcategory extends JTableNested//JTable
{	 
			public $id = 0;
			public $title = null;
			public $alias = null;
			public $photopath= null;
			public $published= null;
			public $language= null;
			public $access= null;
			public $ordering= null;
			public $created= null;
			public $level= 1;
			public $parent_id= null;
			public $path= null;
			public $extension= null;
			public $lft= null;
			public $rgt= null;

			
			function __construct(& $db) {
	
				parent::__construct('#__vquiz_category', 'id', $db);
		 
			}
		
			function delete($pk = null, $children = false)
			{ 
				return parent::delete($pk, $children);
			} 
				
 
		 function check()
		 {

				if (trim($this->title) == '')
				{
					$this->setError(JText::_('JLIB_DATABASE_ERROR_MUSTCONTAIN_A_TITLE_CATEGORY'));
		
					return false;
				}
		
				$this->alias = trim($this->alias);
		
				if (empty($this->alias))
				{
					$this->alias = $this->title;
				}
		
				$this->alias = JApplication::stringURLSafe($this->alias);
		
				if (trim(str_replace('-', '', $this->alias)) == '')
				{
					$this->alias = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->format('Y-m-d-H-i-s');
				}
		
				return true;
			}

	    function store($updateNulls = false)
		{ 
		 
  			$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
			$user = JFactory::getUser();
 			$table = JTable::getInstance('Category', 'JTable', array('dbo' => $this->getDbo()));
			
			if ($table->load(array('alias' => $this->alias, 'parent_id' => $this->parent_id, 'extension' => $this->extension))
			&& ($table->id != $this->id || $this->id == 0))
			{
				$this->setError(JText::_('JLIB_DATABASE_ERROR_CATEGORY_UNIQUE_ALIAS'));
				return false;
			}
			return parent::store($updateNulls);
		}
		
		protected function _getAssetName()
	{
		$k = $this->_tbl_key;
		return 'com_vquiz.quizcategory.'.(int) $this->$k;
	}
	
	protected function _getAssetParentId(JTable $table = NULL, $id = NULL)
	{
		// We will retrieve the parent-asset from the Asset-table
		$assetParent = JTable::getInstance('Asset');
		// Default: if no asset-parent can be found we take the global asset
		$assetParentId = $assetParent->getRootId();

			// The item has the component as asset-parent
			$assetParent->loadByName('com_vquiz');
	
		// Return the found asset-parent-id
		if ($assetParent->id)
		{
			$assetParentId=$assetParent->id;
		}
		return $assetParentId;
	}
	
	protected function _getAssetTitle()
	{
		return $this->title;
	}
	/* public function bind($array, $ignore = '')
	{
		

		// Bind the rules.
		if (isset($array['params']) )
		{
			$rules = new JAccessRules($array['params']);
			$this->setRules($rules);
		}
		//print_r($rules);exit;
		return parent::bind($array, $ignore);
	}
	
 */
	
}