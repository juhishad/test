<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );

 

class TableLearning extends JTable
{

	var $id = null;
	var $learningid = null;
	var $ipaddress = null;

	function __construct(& $db) {
		parent::__construct('#__vquiz_learning', 'id', $db);
	}
	
	function bind($array, $ignore = ''){
		return parent::bind($array, $ignore);
	}
	
		
	function store($updateNulls = false)
	{
		if(!parent::store($updateNulls))	{
			return false;
		}
		
		$quizes_order = JRequest::getVar('quizes_order','','post','array');
		$lessons_order = JRequest::getVar('lessons_order','','post','array');
		
		/* $query = $this->_db->getQuery(true);
		$query->select('quizid');
		$query->from($this->_db->quoteName('#__vquiz_learning_lnq'));
		$query->where('learningid='.$this->_id);
		$this->_db->setQuery( $query );
		$allquizids=$this->_db->loadColumn(); */
		
		if(!empty($quizes_order) or !empty($lessons_order)){
			
			$query = $this->_db->getQuery(true);
			$query->delete($this->_db->quoteName('#__vquiz_learning_lnq'));
			$query->where('learningid='.$this->id);
			$this->_db->setQuery($query);
			$this->_db->execute();
			
			for($i=0;$i<count($quizes_order);$i++){ 
				$insert =new stdClass();
				$insert->learningid=$this->id;
				$insert->lessionid=isset($lessons_order[$i])?$lessons_order[$i]:0;
				$insert->quizid=isset($quizes_order[$i])?$quizes_order[$i]:0;
				$insert->ordering=$i+1;
				$this->_db->insertObject('#__vquiz_learning_lnq',$insert);
			}

		}
		return true;
	}
 
}