<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );

class TablePaymentapp extends JTable
{	 
		    var $id = null;
			/* public $plugin_extension_id = null;
			public $title = null;
			public $name = null;
			public $alias= null;
			public $type= null;
			public $description= null;
			public $main_params= null;
			public $extra_params= null;
			public $plan_id= null;
			public $ordering= null;
			public $published= null; */
		
		function __construct(& $db) {
		    
			parent::__construct('#__vquiz_payment_plugin', 'id', $db);
	   
	    }
	   
	    function bind($array, $ignore = '')
		{
			return parent::bind($array, $ignore);
		}
		
    			
		
		
	
}