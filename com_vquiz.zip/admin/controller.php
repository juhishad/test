<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
JHTML::_('behavior.tooltip');
class VquizController extends JControllerLegacy
{
	function display($cachable = false, $urlparams = false)
	{  
        if(!$this->sstatus())
		{  
			JRequest::setVar('view', 'vquiz');
			JRequest::setVar('layout', 'information');
		}
		else
		{
		$this->showToolbar();
		
		}
		
        parent::display();
	}
    function sstatus()
	{
		$db = JFactory::getDbo();
		$task = JFactory::getApplication()->input->get('task', '');
		if($task =='checkstatus')
			return true;
		$query = 'select `sstatus` from `#__vquiz_configuration`';
		$db->setQuery($query);
		if($db->loadResult())
		{
		return true;	
		}
		else
		return false;	
			
		
	}
	function checkstatus(){
		
		JSession::checkToken() or jexit('{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}');
		$password = JFactory::getApplication()->input->get('password', '', 'RAW');
		$emailaddress = JFactory::getApplication()->input->get('emailaddress', '', 'RAW');
		$url = 'https://www.wdmtech.com/demo/index.php';
		$postdata = array("option"=>"com_vmap", "task"=>"checkstatus", "password"=>$password, "emailaddress"=>$emailaddress, "componentname"=>"com_vquiz", "token"=>JSession::getFormToken());
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		
		$status = curl_exec($ch);
		$sub = new stdClass();
		$sub->result ="success";
		$sub->status = "No";  
		if($status === false)
		{  
			jexit('{"result":"error", "error":"'.curl_error($ch).'"}');
		}
		else
		{
			$status = json_decode($status); 
			if(isset($status->result) && $status->result=="success")
			{
				
				$sub->msg = $status->error;
				if(isset($status->status) && $status->status=="subscr")
				{
					$db =  JFactory::getDbo();
					$query = 'update `#__vquiz_configuration` set `sstatus`=1';
					$db->setQuery($query);
					$db->execute();
					$sub->result ="success";
					$sub->status ="ok";
				}
			}
			
		}
		
		curl_close($ch);
		jexit(json_encode($sub));
		
	}
	
	
	function showToolbar()
	{
		$view = JFactory::getApplication()->input->get('view', 'vquiz');
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		$jversion = substr($joomla,0,3);
		

		$user = JFactory::getUser();
		
		$isAdmin = $user->authorise('core.admin', 'com_vquiz'); 
		
		$canViewDashboard = $user->authorise('core.userviews', 'com_vquiz');
		$canViewConfig = $user->authorise('core.userviews', 'com_vquiz');
		$canViewCategory = $user->authorise('core.userviews', 'com_vquiz');
		$canViewQuizmanager = $user->authorise('core.userviews', 'com_vquiz');
		$canViewQuizresult = $user->authorise('core.userviews', 'com_vquiz');
		$canViewUsers = $user->authorise('core.userviews', 'com_vquiz');
		$canViewInvitationlist = $user->authorise('core.userviews', 'com_vquiz');
		$canViewPlans = $user->authorise('core.userviews', 'com_vquiz');
		$canViewSubscriptions = $user->authorise('core.userviews', 'com_vquiz');
		$canVieworders = $user->authorise('core.userviews', 'com_vquiz');
		$canViewpaymentapps = $user->authorise('core.userviews', 'com_vquiz');
		$canViewcoupon = $user->authorise('core.userviews', 'com_vquiz');
		$canViewnotifications = $user->authorise('core.userviews', 'com_vquiz');
		$canViewtax = $user->authorise('core.userviews', 'com_vquiz');
		
		$db = JFactory::getDbo();	
		
		$query = 'select * from `#__vquiz_configuration`';
		$db->setQuery($query);
		$configuration_result = $db->loadObject();		
		$payment_system = $configuration_result->payment_system;
		
		if($jversion>=3.0)
		{
			if($canViewDashboard){
				
				JHtmlSidebar::addEntry(
					'<span class="add_item hasTip" title="'.JText::_('DASHBOARD_DESC').'">'.JText::_('DASHBOARD').'</span>',
					'index.php?option=com_vquiz&view=vquiz',
					$view == 'vquiz');
			}
			
			if($canViewConfig){
				JHtmlSidebar::addEntry(
					'<span class="add_item hasTip" title="'.JText::_('CONFIGURATION_DESC').'">'.JText::_('CONFIGURATION').'</span>',
					'index.php?option=com_vquiz&view=configuration',
					$view == 'configuration');
			}
			
			if($canViewCategory){
				JHtmlSidebar::addEntry(
					'<span class="add_item hasTip" title="'.JText::_('COM_VQUIZ_CATEGORY_DESC').'">'.JText::_('COM_VQUIZ_CATEGORY').'</span>',
					'index.php?option=com_vquiz&view=quizcategory',
					$view == 'quizcategory');
			}
			
			if($canViewQuizmanager){
				JHtmlSidebar::addEntry(
						'<span class="add_item hasTip" title="'.JText::_('QUIZMANAGER_DESC').'">'.JText::_('QUIZMANAGER').'</span>',
						'index.php?option=com_vquiz&view=quizmanager&qcategoryid=0',
						$view == 'quizmanager');
			}
			/* if($canViewQuizmanager){
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('VQUIZ_QUESTION_POOL_DESC').'">'.JText::_('VQUIZ_QUESTION_POOL').'</span>',
				'index.php?option=com_vquiz&view=questionpool',
				$view == 'questionpool');
			} */
			JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('VQUIZ_LEARNING_PATH_DESC').'">'.JText::_('VQUIZ_LEARNING').'</span>',
				'index.php?option=com_vquiz&view=learning',
				$view == 'learning');
			
			
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('VQUIZ_LESSONS_DESC').'">'.JText::_('VQUIZ_LESSONS').'</span>',
				'index.php?option=com_vquiz&view=lessons',
				$view == 'lessons');
			
			
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('COM_VQUIZ_SKILLS_DESC').'">'.JText::_('COM_VQUIZ_SKILLS').'</span>',
				'index.php?option=com_vquiz&view=skills',
				$view == 'skills');
					
			if($canViewQuizresult){
				JHtmlSidebar::addEntry(
					'<span class="add_item hasTip" title="'.JText::_('QUIZRESULT_DESC').'">'.JText::_('QUIZRESULT').'</span>',
					'index.php?option=com_vquiz&view=quizresult',
					$view == 'quizresult');
			}
			
			if($canViewUsers){
				JHtmlSidebar::addEntry(
					'<span class="add_item hasTip" title="'.JText::_('USERS_DESC').'">'.JText::_('USERS').'</span>',
					'index.php?option=com_vquiz&view=users',
					$view == 'users');
			}
			if($canViewInvitationlist){
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('VQUIZ_INVITATION_LIST_DESC').'">'.JText::_('VQUIZ_INVITATION_LIST').'</span>',
				'index.php?option=com_vquiz&view=quizinvitation',
				$view == 'quizinvitation');
			}
			if($canViewPlans){
				if($payment_system){
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('COM_VQUIZ_PLANS_DESC').'">'.JText::_('COM_VQUIZ_PLANS').'</span>',
				'index.php?option=com_vquiz&view=plans',
				$view == 'plans');
				}
			}
			if($canViewSubscriptions){
				if($payment_system){
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('COM_VQUIZ_SUBSCRIPTIONS_DESC').'">'.JText::_('COM_VQUIZ_SUBSCRIPTIONS').'</span>',
				'index.php?option=com_vquiz&view=subscriptions',
				$view == 'subscriptions');
				}
			}
			if($canVieworders){
				if($payment_system){
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('COM_VQUIZ_INVOICES_DESC').'">'.JText::_('COM_VQUIZ_INVOICES').'</span>',
				'index.php?option=com_vquiz&view=orders',
				$view == 'orders');
				}
			}
			if($canViewpaymentapps){
				if($payment_system){
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('COM_VQUIZ_PAYMENT_APP_DESC').'">'.JText::_('COM_VQUIZ_PAYMENT_APP').'</span>',
				'index.php?option=com_vquiz&view=paymentapp',
				$view == 'paymentapp');
				}
			}
			if($canViewcoupon){
				if($payment_system){
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('COM_VQUIZ_COUPON_DESC').'">'.JText::_('COM_VQUIZ_COUPON').'</span>',
				'index.php?option=com_vquiz&view=coupons',
				$view == 'coupons');
				}
			}
			if($canViewnotifications){
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('COM_VQUIZ_NOTIFICATION_LABEL_DESC').'">'.JText::_('COM_VQUIZ_NOTIFICATION_LABEL').'</span>',
				'index.php?option=com_vquiz&view=notifications',
				$view == 'notifications');
			}
			if($canViewtax){
				JHtmlSidebar::addEntry(
				'<span class="add_item hasTip" title="'.JText::_('COM_VQUIZ_TAX').'">'.JText::_('COM_VQUIZ_TAX').'</span>',
				'index.php?option=com_vquiz&view=tax',
				$view == 'tax');
			}
		}
		else
		{
		if($canViewDashboard)	
        JSubMenuHelper::addEntry( '<span class="vquiz" title="'.JText::_('DASHBOARD').'">'.JText::_('DASHBOARD_DESC').'</span>' , 'index.php?option=com_vquiz&view=vquiz', $view == 'vquiz' );
        if($canViewConfig)
        JSubMenuHelper::addEntry( '<span class="configuration" title="'.JText::_('CONFIGURATION_DESC').'">'.JText::_('CONFIGURATION').'</span>' , 'index.php?option=com_vquiz&view=configuration', $view == 'configuration' );
         if($canViewCategory)
        JSubMenuHelper::addEntry( '<span class="quizcategory" title="'.JText::_('COM_VQUIZ_CATEGORY_DESC').'">'.JText::_('COM_VQUIZ_CATEGORY').'</span>' , 'index.php?option=com_vquiz&view=quizcategory', $view == 'quizcategory' );
         if($canViewQuizmanager)
        JSubMenuHelper::addEntry( '<span class="quizmanager" title="'.JText::_('QUIZMANAGER_DESC').'">'.JText::_('QUIZMANAGER').'</span>' , 'index.php?option=com_vquiz&view=quizmanager', $view == 'quizmanager' );
		if($isAdmin)
		JSubMenuHelper::addEntry( '<span class="users" title="'.JText::_('VQUIZ_LEARNING_PATH_DESC').'">'.JText::_('VQUIZ_LEARNING_PATH').'</span>' , 'index.php?option=com_vquiz&view=learning', $view == 'learning' ); 
		if($isAdmin)
		JSubMenuHelper::addEntry( '<span class="users" title="'.JText::_('VQUIZ_LESSONS_DESC').'">'.JText::_('VQUIZ_LESSONS').'</span>' , 'index.php?option=com_vquiz&view=lessons', $view == 'lessons' );
		if($isAdmin)
		JSubMenuHelper::addEntry( '<span class="users" title="'.JText::_('COM_VQUIZ_SKILLS_DESC').'">'.JText::_('COM_VQUIZ_SKILLS').'</span>' , 'index.php?option=com_vquiz&view=skills', $view == 'skills' );
			
        if($canViewQuizresult)
        JSubMenuHelper::addEntry( '<span class="quizresult" title="'.JText::_('QUIZRESULT_DESC').'">'.JText::_('QUIZRESULT').'</span>' , 'index.php?option=com_vquiz&view=quizresult', $view == 'quizresult' );

		if($canViewUsers)
        JSubMenuHelper::addEntry( '<span class="users" title="'.JText::_('USERS_DESC').'">'.JText::_('USERS').'</span>' , 'index.php?option=com_vquiz&view=users', $view == 'users' );
       }
	   
  	}

}