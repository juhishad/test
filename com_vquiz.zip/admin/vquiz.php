<?php
/*------------------------------------------------------------------------
# com_vquiz - vquiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
defined( '_JEXEC' ) or die( 'Restricted access' );
if(!defined('DS')) 
define('DS', '/');
// Access check
$user = JFactory::getUser();
if (!$user->authorise('core.manage', 'com_vquiz')) {
	return JError::raiseError(403, JText::_('JERROR_ALERTNOAUTHOR'));
}
$document = JFactory::getDocument();  
 
if (version_compare ( JVERSION, '3.0', 'ge' ))
	$document->addScript(JUri::root(true).'/media/jui/js/jquery.min.js');
if (version_compare ( JVERSION, '3.0', 'lt' ))
	$document->addScript(JUri::root(true).'/media/com_vquiz/js/jquery.js');
 
$document->addStyleSheet(JUri::root(true).'/media/com_vquiz/css/jquery-ui.css');
$document->addScript(JUri::root(true).'/media/com_vquiz/js/noconflict.js');

if(JRequest::getWord('view', 'vquiz')!=='quizcategory'){
	$document->addScript(JUri::root(true).'/media/com_vquiz/js/jquery-ui.js'); 
}

require_once( JPATH_SITE .'/administrator/components/com_vquiz/help/quizhelper.php');
new QuizHelper(date("Y-m-d H:m:s"));
require_once( JPATH_COMPONENT.'/controller.php' );

if($controller = JRequest::getWord('view', 'vquiz')) {
	$path = JPATH_COMPONENT.'/controllers/'.$controller.'.php';
	if (file_exists($path)) {
		require_once $path;
	} else {
		$controller = '';
	}
}
// Create the controller
$classname	= 'VquizController'.$controller;
$controller	= new $classname( );
// Perform the Request task
$controller->execute( JRequest::getVar( 'task' ) );
// Redirect if set by the controller
$controller->redirect();

echo '<div class="copyright">'.JText::_( 'WDM' ).'</div>';

