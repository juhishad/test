<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.controllerform');

class VquizControllerTax extends VquizController
{
	
	function __construct()
	{
		parent::__construct();
		
		$user = JFactory::getUser();
		$userId = $user->id;
		

		// Register Extra tasks
		$this->registerTask( 'add'  , 	'edit' );
	}

	function edit()
	{
		JRequest::setVar( 'view', 'tax' );
		JRequest::setVar( 'layout', 'edit'  );
		JRequest::setVar('hidemainmenu', 1);
		
		parent::display();
	}

	function save()
	{
		$model = $this->getModel('tax');
		$link = 'index.php?option=com_vquiz&view=tax';
		
		if ($model->store()) {
		
			$msg = JText::_( 'TAX_SAVED' );
			$this->setRedirect($link, $msg);
		} else {
			$msg = $model->getError();
			jerror::raiseWarning('', $msg);
			$this->setRedirect($link);
		}
	}
	
	function apply()
	{
		$model = $this->getModel('tax');
		
		if ($model->store()) {
			$msg = JText::_( 'TAX_SAVED' );
			$link = 'index.php?option=com_vquiz&view=tax&task=edit&cid[]='.JRequest::getInt('id', 0);
			$this->setRedirect($link, $msg);
		} else {
			$msg = $model->getError();
			jerror::raiseWarning('', $msg);
			$link = 'index.php?option=com_vquiz&view=tax&task=edit&cid[]='.JRequest::getInt('id', 0);
			$this->setRedirect($link);
		}
		
	}
    function saveNew()
	{
		$model = $this->getModel('tax');
		
		if ($model->store()) {
			$msg = JText::_( 'TAX_SAVED' );
			$link = 'index.php?option=com_vquiz&view=tax&task=edit';
			$this->setRedirect($link, $msg);
		} else {
			$msg = $model->getError();
			jerror::raiseWarning('', $msg);
			$link = 'index.php?option=com_vquiz&view=tax&task=edit';
			$this->setRedirect($link);
		}
		
	}
	function remove()
	{
		$model = $this->getModel('tax');
		if(!$model->delete()) {
			$msg = $model->getError();
		} else {
			$msg = JText::_( 'TAX_DELETED' );
		}
		$this->setRedirect( 'index.php?option=com_vquiz&view=tax', $msg );
	}

	function cancel()
	{
		$model = $this->getModel('tax');
		$msg = JText::_( 'OP_CANCEL' );
		$this->setRedirect( 'index.php?option=com_vquiz&view=tax', $msg );
	}
	function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=tax' );
	}	
}