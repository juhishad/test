<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerQuizcategory extends VquizController
{

	function __construct()
	{

		parent::__construct();
		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'unpublish',	'publish' );
		$this->registerTask( 'orderup',   'reorder' );
		$this->registerTask( 'orderdown', 'reorder' );
	}

	function edit()
	{
		JRequest::setVar( 'view', 'quizcategory' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);		
		parent::display();
	}

 	function publish()
	{

		$model = $this->getModel('quizcategory');
		$msg = $model->publish();
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory', $msg );
	}

 
	
	function reorder()
	{
   
		$ids = JFactory::getApplication()->input->post->get('cid', array(), 'array');
		$inc = ($this->getTask() == 'orderup') ? -1 : 1;
		$model = $this->getModel('quizcategory');
		$return = $model->reorder($ids, $inc);
		if($return){
		$msg = JText::_('REORDER_SAVED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory', $msg );
		}

	}

	function saveOrder()
	{ 
		$input=JFactory::getApplication()->input;
		$pks=$input->post->get('cid',array(),'array');
		$order=$input->post->get('order',array(),'array');
		JArrayHelper::toInteger($pks);
		JArrayHelper::toInteger($order);
		$model = $this->getModel('quizcategory');
		$return=$model->saveorder($pks,$order);
		if($return){
		$msg = JText::_('NEW_ORDER_SAVED');
	    $this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory', $msg );
		}
 		
	}
 

	function save()
	{
		  $model = $this->getModel('quizcategory');
		 if($model->store()) {
			
			$msg = JText::_('CATEGORY_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory', $msg );
			
		} else {
			$msg=$model->getError(); 
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory',$msg);
		}
	}


	function apply()
	{
		
		$model = $this->getModel('quizcategory');
		if($model->store()) {
			
			$msg = JText::_('CATEGORY_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory&task=edit&id='.JRequest::getInt('id', 0).'&cid[]='.JRequest::getInt('id', 0), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory&task=edit&id='.JRequest::getInt('id', 0).'&cid[]='.JRequest::getInt('id', 0) );
		}
	}
	
	function save2copy()
	{
		
		$model = $this->getModel('quizcategory');

		if($model->store()) {
			
			$msg = JText::_('CATEGORY_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory&task=edit&id='.JRequest::getInt('id', 0).'&cid[]='.JRequest::getInt('id', 0), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory&task=edit&id='.JRequest::getInt('id', 0).'&cid[]='.JRequest::getInt('id', 0) );
		}
	}
	
	function save2new()
	{
		
		$model = $this->getModel('quizcategory');
		if($model->store()) {
			
			$msg = JText::_('CATEGORY_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory&task=edit', $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory&task=edit&id='.JRequest::getInt('id', 0).'&cid[]='.JRequest::getInt('id', 0) );
		}
	}

	function remove()
	{
		$model = $this->getModel('quizcategory');
		if(!$model->delete()) 
		{
			$msg = JText::_('CATEGORY_COULD_NOT_DELETED');
		} 
		else 
		{
			$msg = JText::_('CATEGORY_DELETED');

		}
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory', $msg );
	}


	function cancel()
	{
		$msg = JText::_('OPERATION_CANCELLED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory', $msg );
	}
	
	

		  function importcategorycsv()
						{
							
							jimport('joomla.filesystem.file');
							 $db =JFactory::getDBO();
							$questioncsv = JRequest::getVar("categorycsv", null, 'files', 'array');
		
							$questioncsv['categorycsv']=str_replace(' ', '', JFile::makeSafe($csv['name']));	
							$temp=$questioncsv["tmp_name"];
										
		
								if(is_file($temp))	{

									$fp = fopen($temp, "r");
									$count = 0;
									$i=0;

									while(($data = fgetcsv($fp, 100000, ",", '"')) !== FALSE)
									{
										$i++;
										if($i==1)
										continue;
									
										$insert = new stdClass();
										$insert->id = null;
										$insert->title =$data[1];
										$insert->alias =$data[2];
										$insert->published = $data[3];
										$insert->created = $data[4];
										$insert->photopath = $data[5];
										$insert->ordering = $data[6];
										$insert->parent_id = $data[7];
										$insert->level = $data[8]>0?$data[8]:1;
										$insert->lft = $data[9]+1;
										$insert->rgt = $data[10]+1;
										$insert->path = $data[11];
										$insert->extension = $data[12];
										$insert->language = $data[13];
										$insert->access = $data[14];
										$insert->meta_desc = $data[15];
										$insert->meta_keyword = $data[16];
																					
										if(!$db->insertObject('#__vquiz_category', $insert, 'id'))	{
											
											$msg = $this->setError($db->stderr());
											$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory', $msg );
											return false;
										}
									$count++;
								}
								fclose($fp);
								$msg = JText::_('CSV_IMPORT_SUCCESS');
								$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory', $msg );
							}
						
					}
   								
								
							function export()
							{
								$model = $this->getModel('quizcategory');
								$model->getCsv();	
								
								if(version_compare(JVERSION, '3.0', '>=')) {
									$dispatcher = JEventDispatcher::getInstance();
								}else{
									$dispatcher	= JDispatcher::getInstance();
								}
								
								//$dispatcher = JDispatcher::getInstance();
								
								try{
									$dispatcher->trigger('startExport');
									jexit(/*JText::_('INTERNAL_SERVER_ERROR')*/);
								}catch(Exception $e){
									jerror::raiseWarning('', $e->getMessage());
									$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory', $msg );
								}
							
							
							}
								function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizcategory' );
	}	

	
	}