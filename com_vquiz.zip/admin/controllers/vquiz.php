<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die();
jimport('joomla.application.component.modellist');
class VquizControllerVquiz extends VquizController
{

	function __construct(){
	
		parent::__construct();
		$this->model = $this->getModel('vquiz');
		JRequest::setVar( 'view', 'vquiz' );
		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'unpublish',	'publish' );

	}
	
	  function drawLineChart(){ 
 		$model = $this->getModel('vquiz');
 		$obj = $model->getLinechart();	
 		jexit(json_encode($obj));
	} 
	
	function drawpieChart(){ 
		$model = $this->getModel('vquiz');
		$obj = $model->getpiechart();	 	
		jexit(json_encode($obj));

	} 
	
	function drawflagChart(){ 

 		$model = $this->getModel('vquiz');
		$obj = $model->getflagpiechart();	
		jexit(json_encode($obj));

	} 
	
	 function drawgeoChart(){ 
	 
		$model = $this->getModel('vquiz');
		$obj = $model->getgeochart();	
		jexit(json_encode($obj));

	}
//check user login status
	function check_login_status()
	{
		$obj = new stdClass();
		$obj->result='error';
		$state = JFactory::getUser()->id>0 ? true:false;
		$obj->result = 'success';
		$obj->state = $state;
		jexit(json_encode($obj));
	}
	//reorder widget 
	function update_profile_ordering()
	{
		
		$model = $this->getModel('vquiz');
		$this->model->updateordering();
		/* $user = JFactory::getUser();
		$db = JFactory::getDbo();
		$obj = new stdClass();
		$obj->result='error';
		
		$ordering_data = JFactory::getApplication()->input->get('new_ordering', 0, 'ARRAY');
		//echo'<pre>';print_r($ordering_data);
		$row = $this->getTable('Widget', 'VaccountTable');
		for($i=0;$i<count($ordering_data);$i++){
			$data = explode(':', $ordering_data[$i]);
			$query ='UPDATE #__vaccount_widget set ordering='.($i+1).' WHERE id='.(int)$data[0];
			$db->setQuery($query);
				if(!$db->query())	{
				$obj->result = $db->getErrorMsg();
				return false;
			} else {
				$obj->result = 'success';
			}
		}
		
		jexit(json_encode($obj)); */
		
	}
	function live_data_update()
	{  
		
		
		header('Content-Type: text/event-stream');
		header('Cache-Control: no-cache');
 
		$this->model = $this->getModel('vquiz');
		$this->profiles = $this->model->getProfiles();
         $user = JFactory::getUser();
		 $groups = $user->getAuthorisedGroups();
		require_once JPATH_COMPONENT.'/help/drawchart.php';
		$datas = array();
		$profile_outer = array();
		$profile_listing = array();
		$other_profile_listing = array();
		
		for($j=0;$j<count($this->profiles);$j++)
		{
			
			$profile = json_decode($this->profiles[$j]->detail);
			$tran_registry = new JRegistry;
			$tran_registry->loadString($this->profiles[$j]->access);
			$allow_access = $tran_registry->get('access_interface'); 
			$allow_check = false;
			 if(is_array($allow_access) && count($allow_access)>0)
			{  
				foreach($groups as $group)
				{
					if(in_array($group,$allow_access))
					{
					$allow_check=true;
					
					}
				}
			}
			elseif(!empty($allow_access))
			{
				if(in_array($allow_access, $groups))
				{
				$allow_check=true;    

				}	
			}
			if(!$allow_check)
			continue; 
			if(isset($profile->style_layout) && $profile->style_layout=='single_formate')
			{
				$single_data = vchart::widgetvalue($profile);
				if(isset($single_data->result)&&$single_data->result=='error'){
					array_push($profile_outer, $single_data->error);
				}
				else
				{
					$single_data = $single_data->data;

					$object_array = get_object_vars($single_data);
					$object_array = count($object_array)>0?array_keys($object_array):array();
					$regex		= '/{(.*?)}/i';
					preg_match_all($regex, $profile->style_layout_editor, $matches, PREG_SET_ORDER);
					foreach ($single_data as $key=>$value)
					{
						if($value==null)	
							array_push($profile_outer, 0);
						else
							array_push($profile_outer, $value);
					}
				}
			}
			

		}
		array_push($datas,$profile_outer);
		array_push($datas,$profile_listing);
		$datas = json_encode($datas);
		echo "data:".$datas."\n\n";
		echo "retry: 8000" . PHP_EOL;
		flush();

		jexit();
	}
	
	//update dashboard widget
	function update_dashboard_new()
	{
		$this->model = $this->getModel('vquiz');
		$this->profiles = $this->model->getProfiles();
		$this->configuration = $this->model->getConfiguration();
		$this->category = $this->model->getCategory();
		$this->update_item = JFactory::getApplication()->input->get('status_action','');
		$status_index = JFactory::getApplication()->input->get('status_index','');
		$status_index = $status_index==0?count($this->profiles)+1:($status_index+1);
		$this->profile = $this->model->getProfile($this->update_item);
		$row_siz = $this->configuration->row_limit;;
		$one_column_size = 100/$this->configuration->column_limit;
		require_once JPATH_COMPONENT.'/help/drawchart.php';
		$prev_current_width ='';
		$future_width ='';
		$column_widget_width_value = '';
		$row_widget_height_value = '';
		$row_widget_height_value_chart = '';
		
		
		$live_data_query = array('Server Response Monitoring','Server CPU Monitoring','Server Monitoring','Thread Status','Queries Status');
		
		$data = new stdClass();
		$data->result = 'error';
		
		$html ='';
		$script =''; 
		$li =''; 
		$k =1;
		$profile = json_decode($this->profile->detail);
		$current_width ='';
		$style = '';
		$sub_current_width =0;$box_class_name='';
		
		if(isset($profile->box_column) && $profile->box_column)
		{
			$column_widget_width_value = (($profile->box_column*$one_column_size)-2).'%';	
		}

		if(isset($profile->box_row) && $profile->box_row)
		{
			$row_widget_height_value =	(($profile->box_row*$row_siz)-20).'px';
			$row_widget_height_value_chart = (($profile->box_row*$row_siz)-20);
		}
		
		if($column_widget_width_value!='' && $row_widget_height_value!='') 
			$style = ' style="width:'.$column_widget_width_value.';height:'.$row_widget_height_value.';"';
		
		$style_update = $column_widget_width_value.':'.$row_widget_height_value;
		
		if(isset($profile->box_layout) && $profile->box_layout=="onebox"){
			$sub_current_width=1;$box_class_name=' onebox';
		} else if(isset($profile->box_layout) && $profile->box_layout=="twobox") {
			$sub_current_width=2;
			$box_class_name=' twobox';
		} else if(isset($profile->box_layout) && $profile->box_layout=="threebox"){
			$sub_current_width=3;
			$box_class_name=' threebox';
		} else if(isset($profile->box_layout) && $profile->box_layout=="fourbox"){
			$sub_current_width=4;
			$box_class_name=' fourbox';
		} else if(isset($profile->box_layout) && $profile->box_layout=="fivebox"){
			$sub_current_width=5;
			$box_class_name=' fivebox';
		} else if(isset($profile->box_layout) && $profile->box_layout=="sixbox"){
			$sub_current_width=5;
			$box_class_name=' sixbox';
		}
		
		if(empty($prev_current_width))
		{
			$prev_current_width = $current_width;	
		}
		
		$current_width ='';
		if(isset($profile->style_layout) && $profile->style_layout=='single_formate')
		{ 
			$li .= '<li class="common_profile_main single_formate num'.($status_index);
			if($this->profile->datatype_option=='profile')
			{
				$li .= ' profile_widget';
			} 
			$li .= $box_class_name.'" data-ordering-profile="'.$this->profile->id.':'.$this->profile->ordering.'"'.$style.'>'; 
			
			$html .= '<div class="panel_header">';
			if(isset($this->profile->name)&& $this->profile->name!='')
				$html .='<span class="profile_name">'.$this->profile->name.'</span>';
            
			$html .='<span class="delete-widget" onclick="delete_widget(this);" data-widget-id="'.$this->profile->id.'"><i class="icon-delete"><strong>'.JText::_("Delete").'</strong></i></span>';
			
			$html .='<span class="edit-widget" onclick="edit_widget(this);" data-widget-id="'.$this->profile->id.'"><i class="icon-edit"><strong>'.JText::_('Edit').'</strong></i></span>';
			
			$html .='</div><div class="profile_mid_data">';
             

			$single_data = vchart::widgetvalue($profile);
			$test_v = $profile->style_layout_editor;

			$object_array = get_object_vars($single_data);
			$object_array = count($object_array)>0?array_keys($object_array):array();
			$regex		= '/{(.*?)}/i';
			preg_match_all($regex, $profile->style_layout_editor, $matches, PREG_SET_ORDER);

			foreach ($matches as $match)
			{ 

				foreach ($single_data->data as $key=>$value)
				{
					if($value=='') $value=0;
					if(isset($profile->style_layout_editor) && $profile->style_layout_editor!=''&&$value!=null&&$match[1]==$key)
					{	
						$test_v = preg_replace("|$match[0]|", '<span class="innser_single_trigger" data-profile-ids="profile_'.$this->profile->id.'" id="inner_single_'.trim(preg_replace('/\s*\([^)]*\)/', '', $key)).'">'.$value.'</span>', $test_v, 1);
						
						//$test_v = str_replace('{cur}', $this->configuration->currency, $test_v);
				
					}
					elseif(isset($profile->style_layout_editor) && $profile->style_layout_editor!=''&&$value==null){
						$test_v = preg_replace("|$match[0]|", '<span class="innser_single_trigger" data-profile-ids="profile_'.$this->profile->id.'" id="inner_single_'.trim(preg_replace('/\s*\([^)]*\)/', '', $key)).'">'.$value.'</span>', $test_v, 1);

						//$test_v = str_replace('{cur}', $this->configuration->currency, $test_v);
					}
				}	
			}			
			$html .= $test_v;

			$html .='</div>';

		}
		else if(isset($profile->style_layout) && $profile->style_layout=='listing_formate')
		{ 
			$k =1;
			if($profile->existing_database_table=='vQuiz Profiles'){

				

						
			}
			
			else {

				$li .= '<li class="common_profile_main listing_profiles listing_formate num'.($status_index);
				if($this->profile->datatype_option=='profile'){
					$li  .= ' profile_widget';
				}
				
				$li .= $box_class_name.'" data-ordering-profile="'.$this->profile->id.':'.$this->profile->ordering.'"'.$style.' data-options="widget_'. $this->profile->id.':'.$this->profile->chart_type.':'.$profile->style_layout.'">';
				
				$html .= '<div class="panel_header">';
				$html .= '<span class="profile_name">';
			
					
					if($profile->existing_database_table==JText::_('COM_VQUIZ_TOP_PLAY_QUIZZES')){
						$html .= '<span class="" style="float:left;width: 30%">';
                     	if(isset($this->profile->name)&& $this->profile->name!='')
					       $html .= $this->profile->name;
					   $html .= '</span>';
                       $html .= '<span class="filter pietype" style="display:inline-block; width:70%;">
							<div class="select_quiz_type select_type" style="display:inline-block; width:50%; float:left;">
							<select name="piequiz_type" class="" id="piequiz_type">
							<option value="">'.JText::_('COM_VQUIZ_SELECT_QUIZ_TYPE').'</option>
							<option value="1">'.JText::_('COM_VQUIZ_TRIVIA_QUIZ').'</option>
							<option value="2">'.JText::_('COM_VQUIZ_PERSONALITY_QUIZ').'</option>
							<option value="3">'.JText::_('COM_VQUIZ_SURVEY_QUIZ').'</option>
							</select> 
							</div>	
							
                            <div class="select_type" style="display:inline-block;width:50%; float:left;">
                            <select name="piecategory" id="piecategory">
                             <option value="0">'.JText::_('COM_VQUIZ_SELECT_CATEGORY').'</option>';
                             for($i=0;$i<count($this->category);$i++)	{

                              $html .= '<option value="'.$this->category[$i]->id.'">
                            '.JText::_($this->category[$i]->title).'
                            </option>';

                             }
                            $html .= '</select>';
                            $html .= '</div>';
					        $html .= '</span>';
					}
					else if($profile->existing_database_table==JText::_('COM_VQUIZ_PLAYED_QUIZZES')){
					$html .= '<span class="" style="float:left;width: 30%">';	
				   if(isset($this->profile->name)&& $this->profile->name!='')
					$html .= $this->profile->name;
				   $html .= '</span>';
					$html .= '<span class="" style="width:70%;"><span class="linecharttype" style="width:65%; float:left;">
					<span class="btn" data-type="day">'.JText::_('COM_VQUIZ_DAILY').'</span> 
					<span class="btn" data-type="week">'.JText::_('COM_VQUIZ_WEEKLY').'</span> 
					<span class="active btn" data-type="month">'.JText::_('COM_VQUIZ_MONTHLY').'</span></span> 

					<span class="select_type linecharttypes" style="width:35%; float:left;">
					<select name="category" id="category">
					<option value="0">'.JText::_('COM_VQUIZ_SELECT_CATEGORY').'</option>';
						for($i=0;$i<count($this->category);$i++)	{

						$html .= '<option value="'.$this->category[$i]->id.'">
						'.JText::_($this->category[$i]->title).'
						</option>';

						}
					$html .= '</select>';
					$html .= '</span></span>';

					}
					else if($profile->existing_database_table==JText::_('COM_VQUIZ_AREAWISE_USERS')){
					$html .= '<span class="" style="float:left;width: 50%">';	
						if(isset($this->profile->name)&& $this->profile->name!='')
					$html .= $this->profile->name;
				    $html .= '</span>';
					$html .= ' <span class="select_type geotype" style="width:50%;">
					<select name="agegroup" id="agegroup">  
					<option value="">'.JText::_('COM_VQUIZ_CHOOSE_AGE_GROUP').'</option>
					<option value="10">'.JText::_('10-20').'</option>
					<option value="20">'.JText::_('20-30').'</option>
					<option value="30">'.JText::_('30-40').'</option>
					<option value="40">'.JText::_('40-50').'</option>
					<option value="50">'.JText::_('50-60').'</option>
					<option value="60">'.JText::_('60-All').'</option></select></span>';

					}
					else
					{
					$html .= '<span class="">';	
					if(isset($this->profile->name)&& $this->profile->name!='')
					$html .= $this->profile->name;	
					 $html .= '</span>';
					}
				
				$html .= '</span>';
				
				
				 
				$html .='<span class="delete-widget" onclick="delete_widget(this);" data-widget-id="'.$this->profile->id.'"><i class="icon-delete"><strong>'.JText::_("Delete").'</strong></i></span>';
			 
			    $html .='<span class="edit-widget" onclick="edit_widget(this);" data-widget-id="'.$this->profile->id.'"><i class="icon-edit"><strong>'.JText::_("Edit").'</strong></i></span>';
				
				$html .= '</div><div class="profile_mid_data">';

				$single_data = vchart::widgetvalue($profile);

				//Changed by Waseem
				$single_data = $single_data->data;
				$object_array = isset($single_data[0])?get_object_vars($single_data[0]):array();
				//$object_array = get_object_vars($single_data);
				$object_array = count($object_array)>0?array_keys($object_array):array();
				$html .= '<div class="listing_layout_others" style="height:'.($row_widget_height_value_chart-60).'px;">';
				$html .= '<table class="adminlist table table-hover listing_info listing_info_'.$this->profile->id.' profile_mid_data_inner" width="100%"><thead><tr>';
				
				for ($s = 0;$s<count($object_array);$s++)
				{
					$html .= '<th>'.$object_array[$s].'</th>';
				}			
				$html .= '</thead>';
				
				$g = 0;
				for ($l=0; $l < count( $single_data ); $l++)
				{
					$listing = $single_data[$l];
					$html .= '<tr>';
					foreach($listing as $listings) {
						$html .= '<td>'.$listings.'</td>';	
					}
					$html .= '</tr>';
				}
				$html .= '</table></div>';
				$html .= '</div>';
			}	
		}
		else
		{ 

			$li .= '<li class="common_profile_main num'.($status_index);
			if($this->profile->datatype_option=='profile')
			{
				$li .= ' profile_widget';
			}
			$li .= $box_class_name.'" data-ordering-profile="'.$this->profile->id.':'.$this->profile->ordering.'"'.$style.' data-options="widget_'. $this->profile->id.':'.$this->profile->chart_type.':'.$profile->style_layout.'">';
			
			$html .= '<div class="panel_header">';
			$html .= '<span class="profile_name chart_x_tool">';
			$html .='<span class="profile_name_label" style="float:left;width: 30%">';
			if(isset($this->profile->name)&& $this->profile->name!='')
				$html .= $this->profile->name;
			$html .= '</span>';
			if($profile->existing_database_table==JText::_('COM_VQUIZ_TOP_PLAY_QUIZZES')){

                       $html .= '<span class="filter pietype"  style="display:inline-block; width:70%">
							<div class="select_quiz_type select_type" style="width:50%; float:left;">
							<select name="piequiz_type" class="" id="piequiz_type">
							<option value="">'.JText::_('COM_VQUIZ_SELECT_QUIZ_TYPE').'</option>
							<option value="1">'.JText::_('COM_VQUIZ_TRIVIA_QUIZ').'</option>
							<option value="2">'.JText::_('COM_VQUIZ_PERSONALITY_QUIZ').'</option>
							<option value="3">'.JText::_('COM_VQUIZ_SURVEY_QUIZ').'</option>
							</select> 
							</div>	
							
                            <div class="select_type" style="width:50%; float:left;">
                            <select name="piecategory" id="piecategory">
                             <option value="0">'.JText::_('COM_VQUIZ_SELECT_CATEGORY').'</option>';
                             for($i=0;$i<count($this->category);$i++)	{

                              $html .= '<option value="'.$this->category[$i]->id.'">
                            '.JText::_($this->category[$i]->title).'
                            </option>';

                             }
                            $html .= '</select>';
                            $html .= '</div>';
					        $html .= '</span>';
					}
					else if($profile->existing_database_table==JText::_('COM_VQUIZ_PLAYED_QUIZZES')){
					$html .= '<span class=""  style="width:70%;"><span class="linecharttype" style="width:65%; float:left;">
					<span class="btn" data-type="day">'.JText::_('COM_VQUIZ_DAILY').'</span> 
					<span class="btn" data-type="week">'.JText::_('COM_VQUIZ_WEEKLY').'</span> 
					<span class="active btn" data-type="month">'.JText::_('COM_VQUIZ_MONTHLY').'</span></span> 

					<span class="select_type linecharttypes"   style="width:35%; float:left;">
					<select name="category" id="category">
					<option value="0">'.JText::_('COM_VQUIZ_SELECT_CATEGORY').'</option>';
						for($i=0;$i<count($this->category);$i++)	{

						$html .= '<option value="'.$this->category[$i]->id.'">
						'.JText::_($this->category[$i]->title).'
						</option>';

						}
					$html .= '</select>';
					$html .= '</span></span>';

					}
					else if($profile->existing_database_table==JText::_('COM_VQUIZ_AREAWISE_USERS')){
					$html .= ' <span class="select_type geotype" style="width:50%;">
					<select name="agegroup" id="agegroup">  
					<option value="">'.JText::_('COM_VQUIZ_CHOOSE_AGE_GROUP').'</option>
					<option value="10">'.JText::_('10-20').'</option>
					<option value="20">'.JText::_('20-30').'</option>
					<option value="30">'.JText::_('30-40').'</option>
					<option value="40">'.JText::_('40-50').'</option>
					<option value="50">'.JText::_('50-60').'</option>
					<option value="60">'.JText::_('60-All').'</option></select></span>';

					} 
			
			   $html .= '</span>';
             
			   $html .='<span class="delete-widget" onclick="delete_widget(this);" data-widget-id="'.$this->profile->id.'"><i class="icon-delete"><strong>'.JText::_("Delete").'</strong></i></span>';
			 
			    $html .='<span class="edit-widget" onclick="edit_widget(this);" data-widget-id="'.$this->profile->id.'"><i class="icon-edit"><strong>'.JText::_("Edit").'</strong></i></span>';
			  
			$html .='</div><div class="profile_mid_data"><ul>';

			if($this->profile->datatype_option=='predefined')
			{ 

				if(isset($this->profile->chart_type) && $this->profile->chart_type!=''){
					
					$style= $row_widget_height_value_chart!=''?' style="height:'.($row_widget_height_value_chart-68).'px"':'';
					$script_data = vchart::draw_view_chart($this->profile);

					if($script_data->result=='success'){ 
						$html .=' <li class="chart_profile num'.($status_index).'" data-ordering-profile="'.$this->profile->id.':'.$this->profile->ordering.'" data-widget-label="'.strtolower(str_replace(" ","_",$profile->existing_database_table)).$this->profile->id.'" style="height:300px;">';
						$html .=' <div id="widget_'.$this->profile->id.'" class="widget_chart" data-profile-id="drawchart'.$this->profile->id.'" '.$style.'></div></li>';

						$script .= '<script type="text/javascript"> ';
						$script .= $script_data->scripts;
						$script .= '</script>';
					} 
					else if($script_data->result=='error')
					{
						$script .= $script_data->error; 
					} 
				}
					  

			}
			elseif($this->profile->datatype_option=='writequery'){
				$script_data = vchart::draw_view_chart($this->profile);
				if($script_data->result=='success')
				{ 
					$html .= ' <li class="chart_profile num'.($status_index).'" data-widget-label="'.strtolower(str_replace(" ","_",$profile->existing_database_table)).$this->profile->id.'" data-ordering-profile="'.$this->profile->id.':'.$this->profile->ordering.'">';
					$html .= ' <div id="widget_'.$this->profile->id.'" class="widget_chart" data-profile-id="drawchart'.$this->profile->id.'" style="width: 100%; height: 80%;"></div></li>';

					$script .= '<script type="text/javascript"> ';
					$script .=  $script_data->scripts;
					$script .=  '</script>';  
				}  
				else if($script_data->result=='error'){
					$script .= $script_data->error; 
				} 
			}

			$html .= '</ul></div>'; 
		}
		$data->html = $html;
		$data->script = $script;
		$data->li = $li;
		$data->style = $style_update;
		$data->result = 'success';
		jexit(json_encode($data));
	}
	//delete dashboard widget
	function delete_widget()
	{
		$model = $this->getModel('vquiz');
        $data = new stdClass();
		$data->result = 'error';
		if($model->delete()) {
		$data->result = 'success';	
		} 
        jexit(json_encode($data));
	}	
	function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=vquiz' );
	}
 
}

 
?>