<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
//jimport('joomla.filesystem.file');
class VquizControllerQuizmanager extends VquizController
{

	function __construct()
	{
		parent::__construct();
		
		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'unpublish',	'publish' );
		$this->registerTask( 'orderup', 		'reorder' );
		$this->registerTask( 'orderdown', 		'reorder' );
		$this->registerTask( 'unfeatured','featured' );	
	
	}
	
	function edit()
	{
		JRequest::setVar( 'view', 'quizmanager' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);
		
		parent::display();
	}
	
	
 	function publish()
	{
		$model = $this->getModel('quizmanager');
		$msg = $model->publish();
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
	}

	function featured(){
 
		$model = $this->getModel('quizmanager');
		$msg = $model->featured();
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
		
	}
			
	function reorder()
	{ 
	
		$model = $this->getModel('quizmanager');
		$msg = $model->reorder();

		$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
	
	}
	
	function drawChart()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		
		$model = $this->getModel('quizmanager');
		$obj = $model->drawChart();	
		jexit(json_encode($obj));
	} 
	
 
	
 
	function saveOrder(){
	
		$model = $this->getModel('quizmanager');
		$msg = $model->saveOrder();
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
	}
	 
	function save(){
	
		$model = $this->getModel('quizmanager');
		if($model->store()) {
			$msg=JText::_('QUIZZES_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager');
		}
	
	}
	
	function apply()
	{
		$model = $this->getModel('quizmanager');
		if($model->store()) {
			$msg=JText::_('QUIZZES_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&task=edit&id='.JRequest::getInt('id', 0).'&cid[]='.JRequest::getInt('id', 0), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&task=edit&id='.JRequest::getInt('id', 0).'&cid[]='.JRequest::getInt('id', 0) );
		}

	}
	
		
	function cancel()
	{
			$msg = JText::_('OPERATION_CANCELLED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
	}
	
	function save2copy()
	{
		$model = $this->getModel('quizmanager');
		if($model->store()) {
			$msg = JText::_('QUIZZES_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&task=edit&id='.JRequest::getInt('id', 0).'&cid[]='.JRequest::getInt('id', 0), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&task=edit&id='.JRequest::getInt('id', 0).'&cid[]='.JRequest::getInt('id', 0) );
		}
	}
	
	function save2new()
	{
		
		$model = $this->getModel('quizmanager');
		if($model->store()) {
			$msg = JText::_('QUIZZES_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&task=edit', $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&task=edit&id='.JRequest::getInt('id', 0).'&cid[]='.JRequest::getInt('id', 0) );
		}
	}
 
	
	function remove()
	{
		$model = $this->getModel('quizmanager');
		
		if(!$model->delete()) 
		{
			$msg = JText::_('QUIZ_COULD_NOT_DELETED');
		} 
		else 
		{
			$msg = JText::_('QUIZ_DELETED');
		}
		
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
	}
 
	function copyquestion()
	{
		$model = $this->getModel('quizmanager');
			if(!$model->copyquestion()) 
			$msg = JText::_('COULD_NOT_BE_COPY');
			else 	 
			$msg = JText::_('COPY_SUCCESSFUL');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
	}
			
							
  function movequestion()
	{
		$model = $this->getModel('quizmanager');
			if(!$model->movequestion()) 
			$msg = JText::_('COULD_NOT_BE_COPY');
			else 	 
			$msg = JText::_('MOVE_SUCCESSFUL');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
	}
	
 
	 function trivia_message()
		{ 
			$model = $this->getModel('quizmanager');
			if($model->trivia_messagestore()) {
				$quizid=JRequest::getInt('id');
				$msg = JText::_('MESSAGE_SAVED');
				$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&layout=trivia_messages&id='.$quizid.'&tmpl=component', $msg );
			} else {
				jerror::raiseWarning('', $model->getError());
				$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&layout=trivia_messages&tmpl=component');
			}
		
		}
	

	function personality_message()
	{ 
		$model = $this->getModel('quizmanager');
		$p_type=JRequest::getInt('p_type',0);
		
		if($model->personality_messagestore()) {
			$quizid=JRequest::getInt('id',0);
			$msg = JText::_('MESSAGE_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&layout=personality_messages&id='.$quizid.'&p_type='.$p_type.'&tmpl=component', $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&layout=personality_messages&p_type='.$p_type.'&tmpl=component');
		}
	}
	
	function qgroup_message()
	{ 
		$model = $this->getModel('quizmanager');
		if($model->qgroup_messagescore()) {
			$quizid=JRequest::getInt('quizid',0);
			$qorder=JRequest::getInt('qorder',0);
			$msg = JText::_('MESSAGE_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&layout=qgroup_messages&qorder='.$qorder.'&id='.$quizid.'&tmpl=component', $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&layout=qgroup_messages&tmpl=component');
		}
	
	}
	
	function export(){
		
		$model = $this->getModel('quizmanager');
		$model->getCsv();	
		
		if(version_compare(JVERSION, '3.0', '>=')) {
			$dispatcher = JEventDispatcher::getInstance();
		}else{
			$dispatcher	= JDispatcher::getInstance();
		}
		try{
			$dispatcher->trigger('startExport');
			jexit(/*JText::_('INTERNAL_SERVER_ERROR')*/);
		}catch(Exception $e){
			jerror::raiseWarning('', $e->getMessage());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
		}
		
	}
	
	function import(){
							
			jimport('joomla.filesystem.file');
			$db =JFactory::getDBO();			
			$quizcsv = JRequest::getVar("quizcsv", null, 'files', 'array');
			$quizcsv['quizcsv']=str_replace(' ', '', JFile::makeSafe($quizcsv['name']));	
			$temp=$quizcsv["tmp_name"];
			$same_quiz_check=0;
			$inserted_quizid=0;

			if(is_file($temp))	{
			
				$fp = fopen($temp, "r");
				$count = 0;
				$i=0;
				while(($data = fgetcsv($fp, 100000, ",", '"')) !== FALSE)
				{
					$i++;
					if($i==1)
					continue;
				
				
					if($same_quiz_check!=$data[0]){
					
						$insert = new stdClass();
						$insert->id = null;
						$insert->title = $data[1];
						$insert->quiz_categoryid = $data[2];
						$insert->image = $data[3];
						$insert->quiztype =$data[4];
						$insert->personality_type =$data[5];
						$insert->answers_type = $data[6];
						$insert->published = $data[7];
						$insert->featured = $data[8];
						$insert->random_question = $data[9];
						$insert->random_option = $data[10];
						$insert->passed_score = $data[11];
						$insert->total_timelimit = $data[12];
						$insert->question_limit = $data[13];
						$insert->description = $data[14];
						$insert->livescore = $data[15];
						$insert->slider_bar = $data[16];
						$insert->completion_level = $data[17];
						$insert->next_quiz = $data[18];
						$insert->prev_quiz = $data[19];
						$insert->skip_button = $data[20];
						$insert->prev_button = $data[21];
						$insert->prev_answer = $data[22];
						$insert->explanation = $data[23];
						$insert->answer_sheet = $data[24];
						$insert->display_result = $data[25];
						$insert->show_graph = $data[26];
						$insert->flag = $data[27];
						$insert->paging = $data[28];
						
						if(!$db->insertObject('#__vquiz_quizzes', $insert, 'id'))	{
							
							$msg = $this->setError($db->stderr());
							$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
							return false;
						}
						
						$same_quiz_check=$data[0];
						$inserted_quizid = $db->insertid();
					}
					
					
					
					$insert_question = new stdClass();
					$insert_question->id = null;
					$insert_question->qtitle = $data[30];
					$insert_question->explanation = $data[31];
					$insert_question->quizzesid =$inserted_quizid;
					$insert_question->quiztype =$data[32];
					$insert_question->optiontype = $data[33];
					$insert_question->score = $data[34];
					$insert_question->penalty = $data[35];
					$insert_question->published = $data[36];
					$insert_question->question_timelimit = $data[37];
					$insert_question->questiontime_parameter = $data[38];
					$insert_question->user_comment = $data[39];
					$insert_question->flagcount = $data[40];
					//$insert_question->text_field_ans = $data[39];
					$insert_question->case_sensitive = $data[41];
					$insert_question->created_by = $data[42];
													
																				
					if(!$db->insertObject('#__vquiz_question', $insert_question, 'id'))	{
						
						$msg = $this->setError($db->stderr());
						$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
						return false;
					}
					
					$id = $db->insertid();
					
					$correct=array();
					
					//quiztype =$data[3];
					
					//answers_type =$data[5];
					
					
					$correct=explode(',',$data[43]);
					$option_index=44;
					if($data[3]==2 and $data[4]==1){
						$multi_p_score=explode(',',$data[44]);
						$option_index=$option_index+1;
					}
	
					 for($n=0,$i=$option_index;$i<count($data);$i++,$n++)	{	
					
						$insertoption = new stdClass();
						$insertoption->id = null;
						$insertoption->qid = $id;
						$insertoption->qoption =$data[$i];
						
						if($data[3]==2){
						
							$insertoption->personality_optionid =$correct[$n];
							
							if($data[4]==1){
								$insertoption->multi_p_options_score =$multi_p_score[$n];
							}
							
						}elseif($data[3]==1){
						
							if($data[5]==0){
								$insertoption->correct_ans = in_array($n,$correct)?1:0;
							}elseif($data[5]==1){
								$insertoption->options_score =$correct[$n];
							}elseif($data[5]==2){
								$insertoption->category_score =$correct[$n];
							}
						}
						
						
						if(!$db->insertObject('#__vquiz_option', $insertoption, 'id'))	{
							$msg = $this->setError($db->stderr());
							$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
							return false;
						}
						
					} 
					
					$count++;
				}
				
	
			
			fclose($fp);
			$msg = JText::_('CSV_IMPORTED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
		}
		
	}
	
	function Question_options(){
	
		JRequest::checkToken() or jexit('{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj=$model->getQuestion_options();
		jexit(json_encode($obj));
		
	}
	function Question_weight(){
	
		JRequest::checkToken() or jexit('{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj=$model->getQuestion_weight();
		jexit(json_encode($obj));
		
	}
	
	function Question_weight_apply(){
	
		JRequest::checkToken() or jexit('{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizmanager');
		$obj=$model->getQuestion_weight_apply();
		jexit(json_encode($obj));
		
	}
	function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager&task=updateNotes&data_id='.$data_id.'&user_id='.$user_id.'' );    
	}
}