<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerLessons extends VquizController
{

		function __construct()
		{
			parent::__construct();
			$this->registerTask( 'add'  , 	'edit' );
			$this->registerTask( 'unpublish',	'publish' );

		}
 
		function edit()
		{
 
			JRequest::setVar( 'view', 'lessons' );
 			JRequest::setVar( 'layout', 'form'  );
 			JRequest::setVar('hidemainmenu', 1);
 			parent::display();
 		}

 		function apply()
		{
			
			$model = $this->getModel('lessons');
			if($model->store()) {
				
				$msg = JText::_('COM_VQUIZ_LESSON_SAVED');
				$this->setRedirect( 'index.php?option=com_vquiz&view=lessons&task=edit&cid[]='.JRequest::getInt('id', 0), $msg );
			} else {
				jerror::raiseWarning('', $model->getError());
				$this->setRedirect( 'index.php?option=com_vquiz&view=lessons&task=edit&cid[]='.JRequest::getInt('id', 0) );
			}
		}

 		function save()
 		{
			$model = $this->getModel('lessons');
			if($model->store()) {
				$msg = JText::_('COM_VQUIZ_LESSON_SAVED');
				$this->setRedirect( 'index.php?option=com_vquiz&view=lessons', $msg );
			} else {
				jerror::raiseWarning('', $this->model->getError());
				$this->setRedirect( 'index.php?option=com_vquiz&view=lessons');
			}
		}

		function remove()
		{
			$model = $this->getModel('lessons');
			if(!$model->delete()) 
			{
				$msg = JText::_( 'COULD_NOT_DELETED' );
			} 
			else 
			{
				$msg = JText::_('COM_VQUIZ_LESSON_DELETED');
			}
			$this->setRedirect( 'index.php?option=com_vquiz&view=lessons', $msg );
	
		}

		function publish()
		{

			$model = $this->getModel('lessons');
			$msg = $model->publish();
			$this->setRedirect( 'index.php?option=com_vquiz&view=lessons', $msg );
		}

 
		function cancel()
		{
			$msg = JText::_('CANCELLED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=lessons', $msg );
		}
			
		public function deleteFile(){
			//$input=JFactory::getApplication()->input;
			$data = JRequest::get('post'); //print_r($data);jexit('asfe');
			$doc=$data['ftd'];
			 
			$id=$data['id'];
			 
			$column = 'files';
			$folder = 'files/';
			 
			$db=JFactory::getDBO();
			$query=$db->getQuery(true);
			$query->select($column);
			$query->from('#__vquiz_lessons');
			$query->where('id='.$id);
			$db->setQuery($query);
			$result=$db->loadResult();
			 
			if($result==$doc){
				$paths=JPATH_COMPONENT_SITE.DIRECTORY_SEPARATOR."/media/com_vquiz/vquiz/images/".$folder;
				JFile::delete($paths.$result);
				 
				//unset($vals[$key]);
			}
			 
			$query->update('#__vquiz_lessons');
			$query->set($column.'=""');
			$query->where('id='.$id);
			$db->setQuery($query);
			$res=$db->query();
			jexit($res);
	} 
	
	public function saveOrderAjax()
	{
		// Get the input
		$pks = $this->input->post->get('cid', array(), 'array');
		$order = $this->input->post->get('order', array(), 'array');

		// Sanitize the input
		JArrayHelper::toInteger($pks);
		JArrayHelper::toInteger($order);

		// Get the model
		$model = $this->getModel('lessons');

		// Save the ordering
		$return = $model->saveorder($pks, $order);

		if ($return)
		{
			echo "1";
		}

		// Close the application
		JFactory::getApplication()->close();
	}
	
	function slidDeleteImg()
	{
			$db=JFactory::getDbo();
			$img=JRequest::getVar('img','');
			$id=JRequest::getInt('id','');
			$obj = new stdClass();
			$obj->result =0;
 
			if($id)
			{
				$image=JPATH_SITE.'/media/com_vquiz/vquiz/images/slide/';
				
				$query = $db->getQuery(true);
				$query->select('slide_img');
				$query->from('#__vquiz_lessons');
				$query->where('id='.$id);
				$db->setQuery($query);
				$slide_img_array = json_decode($db->loadResult(),TRUE);
			
				$result = array_diff($slide_img_array,array($img));

				unlink(JPATH_SITE.'/media/com_vquiz/vquiz/images/slide/'.$img);
 
				$query=$db->getQuery(true);
				$query->update('#__vquiz_lessons');
				$query->set('slide_img='.$db->quote(json_encode($result)));
				$query->where('id='.$id);
				$db->setQuery($query);
				$res=$db->execute();
				if($res){
					$obj->result =1;
				}
			}
	
			jexit(json_encode($obj));
			
	}
	function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=lessons' );
	}
 
}