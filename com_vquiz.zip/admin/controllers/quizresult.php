<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerQuizresult extends VquizController
{

		function __construct()
		{
			parent::__construct();
			$this->registerTask( 'add'  , 	'edit' );
		}
 
		function edit()
		{
			JRequest::setVar( 'view', 'quizresult' );
 			JRequest::setVar( 'layout', 'form'  );
 			JRequest::setVar('hidemainmenu', 1);
 			parent::display();
 		}

		function apply()
 		{
			  $model = $this->getModel('quizresult');
				if($model->store()) {
					$msg = JText::_('GREETING_SAVE');
				$this->setRedirect( 'index.php?option=com_vquiz&view=quizresult', $msg );
				} else {
				jerror::raiseWarning('', $this->model->getError());
				$this->setRedirect( 'index.php?option=com_vquiz&view=quizresult');
			}
		}

		function remove()
		{
			$model = $this->getModel('quizresult');
			if(!$model->delete()) 
			{
				$msg = JText::_( 'COULD_NOT_DELETED' );
			} 
			else 
			{
				$msg = JText::_('GREETING_DELETED');
			}
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizresult', $msg );
	
		}

 
		function cancel(){
			$msg = JText::_('CANCELLED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizresult', $msg );
		}
		
		function save_textarea_answer(){
				$id= JRequest::getInt('id',0);
				$model = $this->getModel('quizresult');
				$model->getUpdatetextarea_score();
				$msg = JText::_('TEXT_AREA_SCORE_UPDATED');
				$this->setRedirect( 'index.php?option=com_vquiz&view=quizresult&task=edit&cid[]='.$id, $msg );
		}
			
		function export(){
		
				$model = $this->getModel('quizresult');
				$model->getCsv();	
				
				if(version_compare(JVERSION, '3.0', '>=')) {
					$dispatcher = JEventDispatcher::getInstance();
				}else{
					$dispatcher	= JDispatcher::getInstance();
				}
				
				//$dispatcher = JDispatcher::getInstance();
				
				try{
					$dispatcher->trigger('startExport');
					jexit(/*JText::_('INTERNAL_SERVER_ERROR')*/);
				}catch(Exception $e){
					jerror::raiseWarning('', $e->getMessage());
					 $this->setRedirect( 'index.php?option=com_vquiz&view=quizresult', $msg );
				}
			
			}
				
		function sendTemplate(){	
			
				$db = JFactory::getDbo();
				$cids = JRequest::getVar('cid',  0, '', 'array');
				$query = 'select id,userid from #__vquiz_quizresult WHERE id IN ('.implode(',',$cids).')';
				$db->setQuery( $query );
				$results =$db->loadObjectList();
				$res=false;
				for($i=0;$i<count($results);$i++){
					if($results[$i]->userid>0){
						$res=$this->sendmail($results[$i]->userid,$results[$i]->id);
					}
				}
				if($res){
					$msg = JText::_('COM_VQUIZ_MAIL_SEND');
					
					$data_arr = array();
					$data_arr['itemid'] = 0;
					$data_arr['notification_type'] = 13;
						
					if(QuizHelper::checkNotification($data_arr['notification_type'])){
						$data_arr['notify_users'] = QuizHelper::findUsersToNotify('notfify_send_certificate');
						$data_arr['enotify_users'] = QuizHelper::findUsersToEnotify('enotfify_send_certificate');
						//print_r($data_arr); exit;
						QuizHelper::sendNotification($data_arr);
					}
					
				}else{
					$msg = JText::_('COM_VQUIZ_MESSAGE_NOT_SEND');
				}
				$this->setRedirect( 'index.php?option=com_vquiz&view=quizresult', $msg); 
				
		}
		
		function sendmail($userid,$resultid){ 
		
			$user = JFactory::getUser();
			//$date =JFactory::getDate();
			$datetime = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString(); 
			$db = JFactory::getDbo();
			$mailer = JFactory::getMailer();
			$config = JFactory::getConfig();
			
			$query  ='  select learning_id from #__vquiz_learning_playedquizzes';
			$query .= ' where resultid ='.$resultid;
			$db->setQuery( $query);		
			$learning_result = $db->loadObject();
			
			$learningId = $learning_result->learning_id;
			
			
			$query = 'select * from #__users where id='.$userid;
			$db->setQuery( $query );
			$users_result =$db->loadObject();
	
			$query = 'select * from #__vquiz_configuration';
 			$db->setQuery( $query );
 			$confiresult =$db->loadObject();

					
			$query = 'select r.*,q.title as title  from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on q.id=r.quizid  where r.id='.$resultid;
			$db->setQuery( $query );
			$quizesult =$db->loadObject();
			
			$query = 'select sum(q.flagcount) as flagcount from #__vquiz_question  as q left join #__vquiz_quiznques as qe on qe.questionid = q.id  where qe.quizid='.$quizesult->quizid;
			$db->setQuery( $query );
			$flagcount =$db->loadResult();
			
			$score=$quizesult->score;
			$maxscore=$quizesult->maxscore;
			$spenttime=$quizesult->quiz_spentdtime;
			$spenttime=$endtime-$starttime;
			$quiztitle=$quizesult->title;
			$startdatetime=$quizesult->starttime;
			$play_date=$quizesult->created;
			$enddatetime=$quizesult->endtime;
			$passed_score=$quizesult->passed_score;
			$flag=$flagcount;
			
			$query = 'select id,quiztype,personality_type,answers_type from #__vquiz_quizzes where id='.$quizesult->quizid;
			$db->setQuery( $query );
			$quizzes_results =$db->loadObject();
						
			if($quizesult->optiontypescore==2)
				$text = $confiresult->mailformat2;
			else
				$text = $confiresult->mailformat;
			echo $text;exit;
			
			$cet_digits =$confiresult->cet_digits;
					
			$certificate_number =$confiresult->start_with;
		
			if($confiresult->cet_type==1){
			
				if($confiresult->cet_format==1){
					$certificate_number .=$this->generateRandomAlphanumericString($cet_digits);
				}elseif($confiresult->cet_format==2){
					$certificate_number .=$this->generateRandomAlphabeticString($cet_digits);
				}else{
					$certificate_number .=$this->generateRandomnumericString($cet_digits);
				}
				
			}else{
			
				$query = ' SELECT count( * ) FROM #__vquiz_quizresult ';
				$db->setQuery( $query );
				$input_sequnce =$db->loadResult();
				$certificate_number .=str_pad($input_sequnce, $cet_digits, 0, STR_PAD_LEFT);
			}
			
			$certificate_number .=$confiresult->end_with;
			
			if($maxscore>0)
				$persentagescore=round($score/$maxscore*100,2)>100?100:round($score/$maxscore*100,2);
			else
			$persentagescore=$score;


					if($persentagescore>=$passed_score)
						$passed_text='<span style="color:green">'.JText::_('PASSED').'</span>';	
					else
						$passed_text='<span style="color:red">'.JText::_('FAILED').'</span>';
				
					if(!empty($users_result))
						$username=$users_result->username;
				    else
						$username='';
				
					if(strpos($text, '{username}')!== false)
					{
					$text = str_replace('{username}', $username, $text);
					}
				    if(strpos($text, '{quizname}')!== false)
					{
					$text = str_replace('{quizname}', $quiztitle, $text);
					}
					if(strpos($text, '{userscore}')!== false)
					{
					$text = str_replace('{userscore}', $score, $text);
					}
					if(strpos($text, '{maxscore}')!== false)
					{
					$text = str_replace('{maxscore}', $maxscore, $text);
					}
				    if(strpos($text, '{starttime}')!== false)
					{
					$text = str_replace('{starttime}', $startdatetime, $text);
					}
				    if(strpos($text, '{endtime}')!== false)
					{
					$text = str_replace('{endtime}', $enddatetime, $text);
					}
					if(strpos($text, '{spenttime}')!== false)
					{
					$text = str_replace('{spenttime}', $spenttime, $text);
					}
					if(strpos($text, '{passedscore}')!== false)
					{
					$text = str_replace('{passedscore}', $passed_score, $text);
					}
					if(strpos($text, '{percentscore}')!== false)
					{
					$text = str_replace('{percentscore}', $persentagescore, $text);
					}
				    if(strpos($text, '{passed}')!== false)
					{
					$text = str_replace('{passed}', $passed_text, $text);
					}
					if(strpos($text, '{flag}')!== false)
					{
					$text = str_replace('{flag}', $flag, $text);
					}
					
					if($quizzes_results->personality_type==1 and $quizzes_results->quiztype==2){
					
						$multi_w_personality=json_decode($quizesult->multi_w_personality);
						$multi_w_persentage=json_decode($quizesult->multi_w_persentage);
						$array_p_result=json_decode($multi_w_personality[0]);
						$array_p_color=json_decode($multi_w_personality[1]);
						
						$txt_p='<div class="p_answer_row" style="width:100%;display:inline-block;">';

						for($r=0;$r<count($multi_w_persentage);$r++){
					
							$txt_p .='<p><label style="color:'.$array_p_color[$r].';float:left;width:50%" target="_blank">'.$array_p_result[$r].'</label>';
							$txt_p .='<label class="answer_percentage_span" style="color:'.$array_p_color[$r].';float:left;width:30%;">'.$multi_w_persentage[$r].'%</label></p>';
						}
						
						$txt_p .='</div>';

					}else{
					
						$txt_p='';							
					}	
						
					if(strpos($text, '{personality_score}')!== false)
					{
						$text = str_replace('{personality_score}', $txt_p, $text);
					} 
					
					
					$quiz_answers=json_decode($quizesult->quiz_answers);
					$quiz_questions=json_decode($quizesult->quiz_questions);
					$remove = array(0);
					$givenanswers = array_values(array_diff($quiz_answers, $remove));  
					
					if(strpos($text, '{total_questions}')!== false)
					{
						$text = str_replace('{total_questions}', count($quiz_questions), $text);
					}
					
					if(strpos($text, '{given_answers}')!== false)
					{
						$text = str_replace('{given_answers}', count($givenanswers), $text);
						
					}

					/*---count corrct answers---*/
					$model = $this->getModel('quizresult');
					$correct_answers_count=$model->getCorrect_answers(json_decode($quizesult->quiz_questions),json_decode($quizesult->quiz_answers));
 
					if(strpos($text, '{correct_answers}')!== false)
					{
						if($quizzes_results->quiztype==1 and $quizzes_results->answers_type==0){
							$text = str_replace('{correct_answers}', $correct_answers_count, $text);
						}else{
							$text = str_replace('{correct_answers}','--', $text);
						}
					}
					
					if(strpos($text, '{certificate_number}')!== false)
					{
						$text = str_replace('{certificate_number}', $certificate_number, $text);
					}
					
					if(strpos($text, '{date}')!== false)
					{
						$text = str_replace('{date}', JFactory::getDate('now', JFactory::getConfig()->get('offset'))->format("j F, Y"), $text);
					}
					
					if(strpos($text, '{play_date}')!== false)
					{
						$text = str_replace('{play_date}', $play_date, $text);
					}

					
				/*------Save Certificte to  pdf formate-------*/
		
				require_once( JPATH_SITE.'/components/com_vquiz/assets/dompdf_library/dompdf_config.inc.php');

				$foldername=JPATH_ADMINISTRATOR.'/components/com_vquiz/assets/certificate';
				$pdfname='Certificate.pdf';
				$pdf_name=$foldername.'/'.$pdfname;
				unlink($pdf_name);
				
				if (get_magic_quotes_gpc()){
					$text = stripslashes($text);
				}
				
				$dompdf = new DOMPDF();
				$dompdf->load_html($text);
				$dompdf->set_paper('a4', 'portrait');
				$dompdf->render();
				file_put_contents($pdf_name, $dompdf->output()); 
				
				/*--end ----*/
				
				
				if(!empty($users_result))
					$email = $users_result->email; 
				else
					$email ='';

				
				$mailsubject =JText::_('CERTIFICATE_SEND_SUBJECT');
				$body =JText::sprintf('CERTIFICATE_SEND_BODY',$email);
				
				$mailer->setSender($config->get('mailfrom'));
				$mailer->setSubject($mailsubject);
				$mailer->setBody($body);
				$mailer->addAttachment($pdf_name);
				$recievermail = $email;
				$mailer->addRecipient($recievermail);
				$mailer->IsHTML(true);
				$send = $mailer->send();
				
				if($send==true){
					return true;
				}else{
					return false;
				}

			}	 
			 
			function generateRandomAlphanumericString($cet_digits) {
				return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $cet_digits);
			}
			function generateRandomAlphabeticString($cet_digits) {
				return substr(str_shuffle("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $cet_digits);
			}
			function generateRandomnumericString($cet_digits) {
				return substr(str_shuffle("0123456789"), 0, $cet_digits);
			}	
			
		function Leadexport(){
			
				$model = $this->getModel('quizresult');
				$model->Leadexport();	
				
				if(version_compare(JVERSION, '3.0', '>=')) {
					$dispatcher = JEventDispatcher::getInstance();
				}else{
					$dispatcher	= JDispatcher::getInstance();
				}
				
				try{
					$dispatcher->trigger('startExport');
					jexit(/*JText::_('INTERNAL_SERVER_ERROR')*/);
				}catch(Exception $e){
					jerror::raiseWarning('', $e->getMessage());
					 $this->setRedirect( 'index.php?option=com_vquiz&view=quizresult', $msg );
				}
			
			}

function getLearningPathCertificateInfo($learning_id,$quizid,$userid,$resultid){

			$db = JFactory::getDbo();
						
			$query=$db->getQuery(true);
			
			
			
			$query->select('id,certificate,certificate_multi_item,title,article_id');
			$query->from($db->quoteName('#__vquiz_learning'));
			$query->where('id='.$db->quote($learningId));
			$db->setQuery($query);
			$learningPathcertificate=$db->loadObject();
			$text = $learningPathcertificate->certificate;
			//return $text;
			
			if(!empty($learningPathcertificate)){
				
				$query  ='  select quizid from #__vquiz_learning_lnq';
				$query .= ' where learningid ='.$learningPathcertificate->id;
				$query .= ' ORDER BY id asc';
				$db->setQuery( $query);		//echo $query; print_r($learningPathcertificate);exit;
				$quizes_order = $db->loadColumn(); 
				
				$text = $learningPathcertificate->certificate;
				$learningtitle=$learningPathcertificate->title;
				$arIds=$learningPathcertificate->article_id;
				$articleid=JRoute::_('index.php?option=com_content&view=article&id='.$arIds);
				$total_questions=count($quizes_order);
				
				$query  ='  select r.id,r.video_seen,l.title as lesson_title from #__vquiz_learning_result r left join #__vquiz_lessons l ON r.lession_id=l.id';
				$query .= ' where r.learning_id ='.$learningPathcertificate->id;
				$query .= ' AND r.userid ='.$userid;
				$query .= ' AND r.lession_id<>0 AND r.completed = 1';
				$query .= ' ORDER BY r.id asc';
				$db->setQuery( $query);		
				$lessons_list = $db->loadObjectList(); //echo $query; print_r($lessons_list);exit;
				
				$query="SELECT date_format(date(created),'%m/%d/%Y') as quiz_passed_date FROM #__vquiz_quizresult WHERE userid = ". $userid." And quizid = ".$quizid." Order by id desc limit 1"; 	 		
				$db->setQuery( $query);		
				$qresult_detail = $db->loadObject(); 
				
				$quiz_passed_date = $qresult_detail->quiz_passed_date;
								
				 
			}else{
				$text = ''; 
			}
			
			
			$username=$user->username;	
			$email=$user->email;			
			$name = $user->name;
			
			if(strpos($text, '{name}')!== false)
			{
				$text = str_replace('{name}', $name, $text);
			}
			
			if(strpos($text, '{passed_date}')!== false)
			{
				$text = str_replace('{passed_date}', $quiz_passed_date, $text);
			}
						
			if(strpos($text, '{username}')!== false)
			{
				$text = str_replace('{username}', $username, $text);
			}
			
			if(strpos($text, '{email}')!== false)
			{
				$text = str_replace('{email}', $email, $text);
			}
			
			if(strpos($text, '{learningtitle}')!== false)
			{
				$text = str_replace('{learningtitle}', $learningtitle, $text);
			}

			if(strpos($text, '{current_date}')!== false)
			{
				$text = str_replace('{current_date}', JFactory::getDate('now', JFactory::getConfig()->get('offset'))->format("j F, Y"), $text);
			}
			
			if(strpos($text, '{total_questions}')!== false)
			{
				$text = str_replace('{total_questions}', $total_questions, $text);
			}	
			
			if(strpos($text, '{articleid}')!== false)
			{
				$text = str_replace('{articleid}', $articleid, $text);
			}
			
			
			//get multi-item listing
			$multi_lessons = $learningPathcertificate->certificate_multi_item;
			$multi_item=array();
			$lesson_total_hour = $lesson_total_minute = 0;
			
			for($i=0;$i<count($lessons_list);$i++) {
			
				$lesson_title = $lessons_list[$i]->lesson_title;
				$lesson_hour = floor($lessons_list[$i]->video_seen / 3600);
				$lesson_minute = floor(($lessons_list[$i]->video_seen / 60) % 60);			
				
				$multi_item_name_new = $multi_lessons;					
				 
				
				if(strpos($multi_item_name_new, '{lesson_title}')!== false)	{
					$multi_item_name_new = str_replace('{lesson_title}', $lesson_title, $multi_item_name_new);
				}

				if(strpos($multi_item_name_new, '{lesson_hour}')!== false)	{
					$multi_item_name_new = str_replace('{lesson_hour}', str_pad($lesson_hour,2,"0",STR_PAD_LEFT), $multi_item_name_new);
				}
				
				if(strpos($multi_item_name_new, '{lesson_minute}')!== false)	{
					$multi_item_name_new = str_replace('{lesson_minute}', str_pad($lesson_minute,2,"0",STR_PAD_LEFT), $multi_item_name_new);
				}
				
				$multi_item[$i] =  $multi_item_name_new;
				
				$lesson_total_hour += $lesson_hour;
				$lesson_total_minute += $lesson_minute;
						
			}
			
			//if total minute exceeds 60 min, add to total hour
			if($lesson_total_minute>=60){
				$new_hour = floor($lesson_total_minute / 60);
				$lesson_total_hour += $new_hour;
				$lesson_total_minute = floor($lesson_total_minute % 60);
			}
			
			$mitem = implode('',$multi_item);
			
			if(strpos($text, '{multi_item}')!== false)	{
				$text = str_replace('{multi_item}', $mitem, $text);
			}
			
			if(strpos($text, '{lesson_total_hour}')!== false)
			{
				$text = str_replace('{lesson_total_hour}', str_pad($lesson_total_hour,2,"0",STR_PAD_LEFT), $text);
			}
			
			if(strpos($text, '{lesson_total_minute}')!== false)
			{
				$text = str_replace('{lesson_total_minute}', str_pad($lesson_total_minute,2,"0",STR_PAD_LEFT), $text);
			}
 
			return $text;
		
		}	
	function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizresult' );
	}		

}