<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerConfiguration extends VquizController
{
		function __construct()
		{
			parent::__construct();
			$this->registerTask( 'add'  , 	'edit' );
		}
 
		function edit()
		{
			JRequest::setVar( 'view', 'configuration' );
			JRequest::setVar( 'layout', 'form'  );
			JRequest::setVar('hidemainmenu', 1);
			parent::display();
		}
 
	function apply()
		{
				  $model = $this->getModel('configuration');
				if($model->store()) {
					$msg = JText::_('CONFIGURATION_SAVE');
					$this->setRedirect( 'index.php?option=com_vquiz&view=configuration', $msg );
				} else {
					jerror::raiseWarning('', $this->model->getError());
					$this->setRedirect( 'index.php?option=com_vquiz&view=configuration');
				}

		}
		function cancel()
		{
			$msg = JText::_('OPERATION_CANCELLED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=vquiz', $msg );
		}
 function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=vquiz' );
	}
}