<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerOrders extends VquizController
{

	function __construct()
	{

		parent::__construct();
		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'unpublish',	'publish' );
		$this->registerTask( 'orderup',   'reorder' );
		$this->registerTask( 'orderdown', 'reorder' );
	}

	function edit()
	{
		JRequest::setVar( 'view', 'orders' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);		
		parent::display();
	}
	
	function applycoupon(){ 
	
		$db = JFactory::getDbo();
		
		$session = JFactory::getSession();
		$obj = new stdclass();
		$obj->result = 'error';
		$coupon_key = JRequest::getString('couponkey','');
		$subscription_id = JRequest::getVar('subscription_id','');	
	
		//$obj->result = 'success';
		$cp_err = true;
		if( strlen( $coupon_key ) > 0 ) { 
		 $q = "SELECT * FROM `#__vquiz_coupons` WHERE `codes`=".$db->quote($coupon_key); //.";"
			$db->setQuery($q);
			$db->Query($q);					
				if( $db->getNumRows() ) { 
					$coupon = $db->loadAssocList(0);
					$coupon = $coupon[0];
					
					if( QuizHelper::validateCoupon( $coupon_key, $subscription_id ) ) { 
						$session->set('coupon_data',$coupon);
						 $obj->result = 'success';
						 $obj->message = JText::_('COM_VQUIZ_COUPON_FOUND');
						 $cp_err = false;
					} else {
						 $session->clear('coupon_data');
						 $obj->message = JText::_('COM_VQUIZ_COUPON_NOT_VALID');
						
					}
					
				}else {
				 $session->clear('coupon_data');
				 $obj->message = JText::_('COM_VQUIZ_COUPON_NOT_VALID');
			}
		}
		
		jexit(json_encode($obj));
		
	}

 	function createOrder(){
        $subscr_id = JRequest::getInt('subscr_id','');
		if(empty($subscr_id)){
		    $msg = JText::_('COM_VQUIZ_SELECT_SUBSCRIPTION_TO_ADD_NEW_ORDERS');
			$this->setRedirect( 'index.php?option=com_vquiz&view=subscriptions', $msg );	
		}
		JRequest::setVar( 'view', 'orders' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);
		parent::display();	
	}

	function save()
	{
		 $model = $this->getModel('orders');
		 
		 $subscr_id = JRequest::getInt('subscr_id',0);
		 
		 if($model->store()) {
			
			$msg = JText::_('ORDERS_SAVE');
			$this->setRedirect( 'index.php?option=com_vquiz&view=orders', $msg );
		} else {
			$msg=$model->getError(); 
			$this->setRedirect( 'index.php?option=com_vquiz&view=orders',$msg);
		}
	}


	function apply()
	{
		
		$model = $this->getModel('orders');
		
		$subscr_id = JRequest::getInt('subscr_id',0);
		
		if($model->store()) {
			
			$msg = JText::_('ORDERS_SAVE');
			$this->setRedirect( 'index.php?option=com_vquiz&view=orders&subscr_id='.$subscr_id.'&task=edit&cid[]='.JRequest::getInt('order_id', 0), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=orders&subscr_id='.$subscr_id.'&task=edit&cid[]='.JRequest::getInt('order_id', 0) );
		}
	}

	function remove()
	{
		$model = $this->getModel('orders');
		
		$subscr_id = JRequest::getInt('subscr_id',0);
		
		if(!$model->delete()) 
		{
			$msg = JText::_('ORDERS_COULD_NOT_DELETED');
		} 
		else 
		{
			$msg = JText::_('ORDERS_DELETED');

		}
		$this->setRedirect( 'index.php?option=com_vquiz&view=orders&subscr_id='.$subscr_id, $msg );
	}


	function cancel()
	{
		$subscr_id = JRequest::getInt('subscr_id',0);
		$msg = JText::_('OPERATION_CANCELLED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=orders&subscr_id='.$subscr_id, $msg );
	}
		function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=orders' );
	}
	
	}