<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerNotifications extends VquizController
{

	function __construct()
	{

		parent::__construct();
		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'unpublish',	'publish' );
		$this->registerTask( 'orderup',   'reorder' );
		$this->registerTask( 'orderdown', 'reorder' );
	}

	function edit()
	{
		JRequest::setVar( 'view', 'notifications' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);		
		parent::display();
	}

 	function publish()
	{

		$model = $this->getModel('notifications');
		$msg = $model->publish();
		$this->setRedirect( 'index.php?option=com_vquiz&view=notifications', $msg );
	}

	
 

	function save()
	{
		  $model = $this->getModel('notifications');
		 if($model->store()) {
			
			$msg = JText::_('COM_VQUIZ_NOTIFICATIONS_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=notifications', $msg );
		} else {
			$msg=$model->getError(); 
			$this->setRedirect( 'index.php?option=com_vquiz&view=notifications',$msg);
		}
	}


	function apply()
	{
		
		$model = $this->getModel('notifications');
		if($model->store()) {
			
			$msg = JText::_('COM_VQUIZ_NOTIFICATIONS_SAVED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=notifications&task=edit&cid[]='.JRequest::getInt('id', 0), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=notifications&task=edit&cid[]='.JRequest::getInt('id', 0) );
		}
	}

	function remove()
	{
		$model = $this->getModel('notifications');
		if(!$model->delete()) 
		{
			$msg = JText::_('COM_VQUIZ_NOTIFICATIONS_NOT_DELETED');
		} 
		else 
		{
			$msg = JText::_('COM_VQUIZ_NOTIFICATIONS_DELETED');

		}
		$this->setRedirect( 'index.php?option=com_vquiz&view=notifications', $msg );
	}


	function cancel()
	{
		$msg = JText::_('OPERATION_CANCELLED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=notifications', $msg );
	}
	function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=notifications' );
	}
	
	
}