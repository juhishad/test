<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );

class VquizControllerQuizquestion extends VquizController
{
	
	
	function __construct(){
	
		parent::__construct();
		$this->registerTask( 'add'  , 	'edit' );
		$this->registerTask( 'orderup', 		'reorder' );
		$this->registerTask( 'orderdown', 		'reorder' );
		$this->registerTask( 'unpublish',	'publish' );
	}
		
	function edit(){
		JRequest::setVar( 'view', 'quizquestion' );
		JRequest::setVar( 'layout', 'form'  );
		JRequest::setVar('hidemainmenu', 1);
		parent::display();	
	}
				
	function save(){	
		
		$model = $this->getModel('quizquestion');
		$quizid = JRequest::getInt('quizid',0);
		$personalitytype = JRequest::getInt('personalitytype',0);

		if($model->store()) {
			if($personalitytype==2){
				$check_pcategory = $model->check_pcategory();
				if($check_pcategory->used==1){
					$msg_pc=$check_pcategory->no_category;
					
				}else{
				$msg_pc=0;
				}
			}else{
				$msg_pc=0;
			}
			$msg = JText::_('QUESTION_SAVE');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid.'&msg_pc='.$msg_pc, $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid);
		}
	}
		
		
	function apply(){
	
		$model = $this->getModel('quizquestion');
		$quizid = JRequest::getInt('quizid',0);
		//echo $quizid;exit;
		if($model->store()) {
			$msg = JText::_('QUESTION_SAVE');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid.'&task=edit&cid[]='.JRequest::getInt('id', 0), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid.'&task=edit&cid[]='.JRequest::getInt('id', 0) );
		}
	}
	
	function save2copy(){
	
		$model = $this->getModel('quizquestion');
		$quizid = JRequest::getInt('quizid',0);
		JRequest::setVar('id', 0);
		
		if($model->store()) {
			$msg = JText::_('QUESTION_SAVE');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid.'&task=edit&cid[]='.JRequest::getInt('id', 0), $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid.'&task=edit&cid[]='.JRequest::getInt('id', 0) );
		}
	}

	
	function save2new(){
	
		$model = $this->getModel('quizquestion');
		$quizid = JRequest::getInt('quizid',0);
		
		
		if($model->store()) {
			$msg = JText::_('QUESTION_SAVE');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid.'&task=edit', $msg );
		} else {
			jerror::raiseWarning('', $model->getError());
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid.'&task=edit&cid[]='.JRequest::getInt('id', 0) );
		}
	}
		 
	function remove(){

		$model = $this->getModel('quizquestion');
		$quizid = JRequest::getInt('quizid',0);
		if(!$model->delete()){
			$msg = JText::_('QUESTION_COULD_NOT_DELETED');
		} 
		else{
			$msg = JText::_('QUESTIONS_DELETED');
		}
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid, $msg );
	}
				
	function publish(){

		$model = $this->getModel('quizquestion');
		$quizid = JRequest::getInt('quizid',0);
		$msg = $model->publish();
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid, $msg );
	}
		
	function cancel(){
		$quizid = JRequest::getInt('quizid',0);
		$msg = JText::_('CANCELLED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid, $msg );

	}
	
	function reorder(){ 
	
		$quizid = JRequest::getInt('quizid',0);
		$model = $this->getModel('quizquestion');
		$msg = $model->reorder();

		$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid, $msg );

	}
							
	function saveOrder(){
		$quizid = JRequest::getInt('quizid',0);
		$model = $this->getModel('quizquestion');
		$msg = $model->saveOrder();
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid, $msg );
		
	}

	function importquestioncsv(){
							
			jimport('joomla.filesystem.file');
			$quizid = JRequest::getInt('quizid',0);
			$db =JFactory::getDBO();			
			$questioncsv = JRequest::getVar("questioncsv", null, 'files', 'array');
			$questioncsv['questioncsv']=str_replace(' ', '', JFile::makeSafe($questioncsv['name']));	
			$temp=$questioncsv["tmp_name"];
			
			$query = 'select quiztype,personality_type,answers_type from #__vquiz_quizzes where id='.$db->quote($quizid);
			$db->setQuery($query);
			$quiz_info = $db->loadObject();
					

			if(is_file($temp))	{
			
				$fp = fopen($temp, "r");
				$count = 0;
				$i=0;
				while(($data = fgetcsv($fp, 100000, ",", '"')) !== FALSE)
				{
					$i++;
					if($i==1)
					continue;
				
					$insert = new stdClass();
					$insert->id = null;
					$insert->qtitle = $data[1];
					$insert->explanation = $data[2];
					$insert->quizid =$data[3];
					$insert->quiztype =$data[4];
					$insert->optiontype = $data[5];
					$insert->score = $data[6];
					$insert->penalty = $data[7];
					$insert->published = $data[8];
					$insert->question_timelimit = $data[9];
					$insert->questiontime_parameter = $data[10];
					$insert->other_option = $data[11];
					$insert->flagcount = $data[12];
					$insert->text_field_ans = $data[13];
					$insert->case_sensitive = $data[14];
					$insert->created_by = $data[15];
													
																				
					if(!$db->insertObject('#__vquiz_question', $insert, 'id'))	{
						
						$msg = $this->setError($db->stderr());
						$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid, $msg );
						return false;
					}
					
					$id = $db->insertid();
					
					$correct=array();
					
					$correct=explode(',',$data[16]);
					
					$option_index=17;
					if($quiz_info->quiztype==2 and $quiz_info->personality_type==1){
						$multi_p_score=explode(',',$data[17]);
						$option_index=$option_index+1;
					}
					$q_i=0;
					$i_i=0;
					for($n=0,$i=$option_index;$i<count($data);$i++,$n++)	{	
					
						$insertoption = new stdClass();
						$insertoption->id = null;
						$insertoption->qid = $id;
						if($n==0){
							$q_i=$i;
							$i_i=$q_i+1;
						}else{
							$q_i=$q_i+2;
							$i_i=$i_i+2;
						}
							
						$insertoption->qoption =$data[$q_i];
						$insertoption->image =$data[$i_i];

						
						if($quiz_info->quiztype==2){
						
							$insertoption->personality_optionid =$correct[$n];
							
							if($quiz_info->personality_type==1){
								$insertoption->multi_p_options_score =$multi_p_score[$n];
							}
							
						}elseif($quiz_info->quiztype==1){
						
							if($quiz_info->answers_type==0){
								$insertoption->correct_ans = in_array($n,$correct)?1:0;
							}elseif($quiz_info->answers_type==1){
								$insertoption->options_score =$correct[$n];
							}elseif($quiz_info->answers_type==2){
								$insertoption->category_score =$correct[$n];
							}
						}
						
						if($data[$q_i]!=''){
							
							if(!$db->insertObject('#__vquiz_option', $insertoption, 'id'))	{
								$msg = $this->setError($db->stderr());
								$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion', $msg );
								return false;
							}
						}
						
					}
					
					$count++;
				}
			
			
			fclose($fp);
			$msg = JText::_('CSV_IMPORTED');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid, $msg );
		}

	}
	
	function export(){
	
		$model = $this->getModel('quizquestion');
		$model->getCsv();	
		$quizid = JRequest::getInt('quizid',0);	
		if(version_compare(JVERSION, '3.0', '>=')) {
			$dispatcher = JEventDispatcher::getInstance();
		}else{
			$dispatcher	= JDispatcher::getInstance();
		}
		//$dispatcher = JDispatcher::getInstance();
		try{
			$dispatcher->trigger('startExport');
			jexit(/*JText::_('INTERNAL_SERVER_ERROR')*/);
		}catch(Exception $e){
			jerror::raiseWarning('', $e->getMessage());
			 $this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid, $msg );
		}
	}
					
	function checktotaltime(){ 
	   // Check for request forgeries
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizquestion');
		// ansswer querty and jo send karna hai sab ko
		$obj = $model->checktotaltime();		
		
		jexit(json_encode($obj));
	} 
		 
	function copyquestion(){
	
		$model = $this->getModel('quizquestion');
		$quizid = JRequest::getInt('quizid',0);
		if(!$model->copyquestion()) 
			$msg = JText::_('QUESTION_COULD_NOT_BE_COPY');
		else 	 
			$msg = JText::_('COPY_SUCCESSFUL');
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid, $msg );
	}
							
  function movequestion()
	{
		$model = $this->getModel('quizquestion');
		$quizid = JRequest::getInt('quizid',0);
			if(!$model->movequestion()) 
				$msg = JText::_('QUESTION_COULD_NOT_BE_MOVE' );
			else 	 
				$msg = JText::_('MOVED_SUCCESS');
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion&quizid='.$quizid, $msg );
	}
	
	function drawChart()
	{ 
		JRequest::checkToken() or jexit( '{"result":"error", "error":"'.JText::_('INVALID_TOKEN').'"}' );
		$model = $this->getModel('quizquestion');
		$obj = $model->drawChart();	
		jexit(json_encode($obj));
	}
	
	function uploadHotspot()
	{ 
		$data = JRequest::get( 'post' );
		$data['hotspot_images'] = JRequest::getVar('hotspot_images', null, 'FILES', 'array');
		if(!empty($data['hotspot_images']['name']))
		{
	
			$allowed = array('.jpg', '.jpeg', '.gif', '.png');
			$dirpath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/';
			$image_name=str_replace(' ', '', JFile::makeSafe($data['hotspot_images']['name']));
			$image_tmp = $data['hotspot_images']['tmp_name'];
			$time = time();

			if($image_name <> "" )
			{
				
				$ext = strrchr($image_name, '.');
				
				if(!in_array($ext, $allowed)){
					$msg_error=JText::_('THIS_IMAGE_TYPE_NOT_ALLOWED');
					$this->setError($msg_error);
					return false;
				}		

				$size = getimagesize($image_tmp);
				$src_w = $size[0];
				$src_h = $size[1];

				$new_image1 = imagecreatetruecolor($src_w, $src_h);
				
				if($size['mime'] == "image/jpeg")
					imagejpeg($new_image1, $dirpath.$time.'_'.$image_name);
				elseif($size['mime'] == "image/gif")
					imagegif($new_image1, $dirpath.$time.'_'.$image_name);
				else
					imagepng($new_image1, $dirpath.$time.'_'.$image_name);
				
				if(move_uploaded_file($image_tmp, $dirpath.$time.'_'.$image_name)){
					$img = $time.'_'.$image_name;
				}
			}
		}
		$obj = new stdClass();
		$obj->img = $img;
		$obj->html = '<tr class="hotspot_check_tr" id="ajax_tr">
						<td class="key"></td>				
						<td>
							<label>'.JText::_("COM_VQUIZ_HOTSPOTIMG_DESC").'</label>
							<canvas id="canvas" width="700" height="400" style="border: 1px solid #ece8e8;"></canvas>
						</td>
					</tr>';
		jexit(json_encode($obj));
	}
	function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizquestion' );
	}
							
					
}