<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
class VquizControllerQuizinvitation extends VquizController
{

		function __construct()
		{
			parent::__construct();
			$this->registerTask( 'add'  , 	'edit' );
		}
 
		

		

		function remove()
		{
			$model = $this->getModel('quizinvitation');
			if(!$model->delete()) 
			{
				$msg = JText::_( 'COULD_NOT_DELETED' );
			} 
			else 
			{
				$msg = JText::_('GREETING_DELETED');
			}
			$this->setRedirect( 'index.php?option=com_vquiz&view=quizinvitation', $msg );
	
		}

 
		
	
		function export(){
		
				$model = $this->getModel('quizinvitation');
				$model->getCsv();	
				
				if(version_compare(JVERSION, '3.0', '>=')) {
					$dispatcher = JEventDispatcher::getInstance();
				}else{
					$dispatcher	= JDispatcher::getInstance();
				}
				
				//$dispatcher = JDispatcher::getInstance();
				
				try{
					$dispatcher->trigger('startExport');
					jexit(/*JText::_('INTERNAL_SERVER_ERROR')*/);
				}catch(Exception $e){
					jerror::raiseWarning('', $e->getMessage());
					 $this->setRedirect( 'index.php?option=com_vquiz&view=quizinvitation', $msg );
				}
			
			}
				
		
		function Leadexport(){
			
				$model = $this->getModel('quizinvitation');
				$model->Leadexport();	
				
				if(version_compare(JVERSION, '3.0', '>=')) {
					$dispatcher = JEventDispatcher::getInstance();
				}else{
					$dispatcher	= JDispatcher::getInstance();
				}
				
				try{
					$dispatcher->trigger('startExport');
					jexit(/*JText::_('INTERNAL_SERVER_ERROR')*/);
				}catch(Exception $e){
					jerror::raiseWarning('', $e->getMessage());
					 $this->setRedirect( 'index.php?option=com_vquiz&view=quizinvitation', $msg );
				}
			
			}
function updateNotes()
	{
		$db = JFactory::getDBO();
		$data_id = JFactory::getApplication()->input->get( 'data_id',0);
		$user_id = JFactory::getApplication()->input->get( 'user_id',0);
		
		$updatequery1 = 'UPDATE #__vquiz_notesnuser SET seen=1 WHERE note_id='.(int)$data_id.' AND user_id='.(int)$user_id.'';
			$db->setQuery($updatequery1)->query();
		$msg = JText::_('STATUS_UPDATED');
		$this->setRedirect( 'index.php?option=com_vquiz&view=quizinvitation' );
	}			

}