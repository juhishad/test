<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.modellist');
 
class VquizModelQuizinvitation extends JModelList
{
		function __construct()
		{
			parent::__construct();

			$mainframe = JFactory::getApplication();
		  	$context	= 'com_vquiz.result.list.';
			// Get pagination request variables
			$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
			$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );

			// In case limit has been changed, adjust it
			$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
			$this->setState('limit', $limit);
			$this->setState('limitstart', $limitstart);				 
			$array = JRequest::getVar('cid',  0, '', 'array');
			$this->setId((int)$array[0]);
		}

		function _buildQuery()
		{
			
			$db =JFactory::getDBO();
			$user = JFactory::getUser();

			/* $query ="SELECT i.*,sum(qes.flagcount) as flagcount, q.title as quiztitle,q.quiztype as quiztype ,l.user_name as lead_name, u.username as username FROM #__vquiz_quizresult as i LEFT JOIN #__users as u ON i.userid = u.id";
			$query .=" LEFT JOIN #__vquiz_leads as l ON l.resultid = i.id";
			$query .=" LEFT JOIN #__vquiz_quizzes as q ON q.id = i.quizid";
			$query .=" LEFT JOIN #__vquiz_quiznques as qq ON qq.quizid = q.id";
			$query .=" LEFT JOIN #__vquiz_question as qes ON qq.questionid = qes.id"; */
			
			$query ="SELECT i.*, q.title as quiztitle, u.username as username FROM #__vquiz_quizuser_invitation as i LEFT JOIN #__users as u ON i.user_id = u.id";
				$query .=" LEFT JOIN #__vquiz_quizresult as r ON r.id = i.result_id";
				$query .=" LEFT JOIN #__vquiz_quizzes as q ON q.id = r.quizid";
				$this->_db->setQuery( $query );
				$this->_data = $this->_db->loadObjectList();

			return $query;
		}
		

		function setId($id)	
		{
			$this->_id		= $id;
			$this->_data	= null;
 		}

		
		 function &getItem(){
			 
			if (empty( $this->_data )) {
				
				$query ="SELECT i.*, q.title as quiztitle,q.quiztype as quiztype ,l.user_name as lead_name,l.user_email as lead_email,l.user_mobile as lead_mobile, u.username as username FROM #__vquiz_quizresult as i LEFT JOIN #__users as u ON i.userid = u.id";
				$query .=" LEFT JOIN #__vquiz_leads as l ON l.resultid = i.id";
				$query .=" LEFT JOIN #__vquiz_quizzes as q ON q.id = i.quizid";
				$query .=" LEFT JOIN #__vquiz_quiznques as qq ON qq.quizid = q.id";
				$query .=" LEFT JOIN #__vquiz_question as qes ON qq.questionid = qes.id";
				$query .=" where i.id = ".$this->_id;
				
				
				$this->_db->setQuery( $query );
				$this->_data = $this->_db->loadObject();
			}



			if (!$this->_data) {
				$this->_data = new stdClass();
				$this->_data->id = 0;
				$this->_data->title = null;
				$this->_data->userid = null;
				$this->_data->starttime = null;
				$this->_data->endtime = null;
				$this->_data->score = null;
				$this->_data->passed_score = null;
				$this->_data->maxscore = null;
				$this->_data->quiz_spentdtime = null;

			}
			return $this->_data;
		}




		 function &getItems()
		{
				
			
			// Lets load the data if it doesn't already exist
			    
				 $query = $this->_buildQuery(); 
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();  
				
				 
				 $query .= $filter;
				 $query .= $orderby; 
				
				
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			
			return $this->_data;
		}
	 


	
		function getTotal()
		{
				
			if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$query .= $this->_buildContentFilter();
			$this->_total = $this->_getListCount($query);    
			}
			return $this->_total;
 		}



		function _buildItemOrderBy()
			{
				$mainframe = JFactory::getApplication();
				$context	= 'com_vquiz.result.list.';
				$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
			 
				$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
				$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
				return $orderby;
			}

			function getPagination()
			{
				// Load the content if it doesn't already exist
				if (empty($this->_pagination)) {
					jimport('joomla.html.pagination');
					$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
				}
				return $this->_pagination;
			}

	function _buildContentFilter()
	  {
			$mainframe =JFactory::getApplication();
	 
			$context	= 'com_vquiz.result.list.';
			$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
			
			
			$quiz_id = $mainframe->getUserStateFromRequest( $context.'quiz_id', 'quiz_id',	'',	'string' );
			

			
			if(empty($quiz_id)){
				$quiz_id = JRequest::getInt('quiz_id', 0);
			}
			
			$search		= JString::strtolower( $search );
	 
			$where = array();
			
			if($search)
			{	
				if (is_numeric($search)) 
				{		 
					$where[] = 'LOWER(  i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				}
				else
				{
				 $where[] = 'q.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
				}
			} 
			
			if(!empty($quiz_id) and $quiz_id!='')
			{		
					$where[] = 'q.id ='.$this->_db->Quote( $this->_db->escape( $quiz_id, true ), false );
			}
			
			//$where[] = 'i.userid=0';
			$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
			
			return $filter;
		}
			
		 function getAllQuizinresult()
			{
				$query='SELECT  i.quizid as quizid , q.title as quizzes_title';
				$query .=' FROM #__vquiz_quizresult as i LEFT JOIN #__vquiz_quizzes as q ON i.quizid = q.id group by quizid order by quizid asc ';	
				$this->_db->setQuery( $query );
				$resultdata = $this->_db->loadObjectList();
				return $resultdata;
			}	

 

		function delete()
		{
			$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
			$row =& $this->getTable();
			if (count( $cids )) {
			foreach($cids as $cid) {
				if (!$row->delete( $cid )) {
					$this->setError( $row->getErrorMsg() );
					return false;
					}
					
					$query = $this->_db->getQuery(true);
					$query->delete($this->_db->quoteName('#__vquiz_leads'));
					$query->where('resultid='.$this->_db->quote($cid));
					$this->_db->setQuery($query);
					$this->_db->execute();
				}
			}
			return true;
		}


 		function getCsv()
		{

			$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
			
		
			$columnhead =array("Username","Quiztitle","Quiztype","Quizcategory","StartTime","EndTime","Score","SpendTime","Date","Passed Score","Total Questions","Total Given Answers","Total Correct answer","Status");
				
							
			$query='SELECT case when u.username IS NULL then l.user_name else u.username end as username, q.title as quiztitle, case q.quiztype when 1 then "'.JText::_('Trivia').'" when 2 then "'.JText::_('Personality').'" when 11 then "'.JText::_('Simulation').'" when 22 then "'.JText::_('MBTI').'" else "'.JText::_('Survey').'" end as quiztype';
			
			$query .= ',(SELECT title from #__vquiz_category where id=q.catid) as quizcategory';
			
			$query .= ',i.starttime as starttime,i.endtime as endtime';
			
			$query .= ',case q.quiztype when 1 then i.score when 11 then i.score when 2 then i.personality_result when 22 then i.personality_result else  "survey" end  as score';
			
			
			$query .= ',i.starttime as quiz_spentdtime,i.created as created,CONCAT(i.passed_score," %")';
				
			$query .=' FROM #__vquiz_quizresult as i LEFT JOIN #__users as u ON i.userid = u.id';
			
			$query .= ' LEFT JOIN #__vquiz_quizzes as q ON q.id = i.quizid';
			
			$query .=' LEFT JOIN #__vquiz_leads as l ON l.resultid = i.id WHERE i.id IN ('.implode(',',$cids).')';
			
			$this->_db->setQuery( $query );
			$data = $this->_db->loadRowList();
			
			$max_quetion=0;
			
			$query = 'select score,maxscore,passed_score,quiz_questions,quiz_answers,text_answer,textarea_answer,quiztype from #__vquiz_quizresult where id IN ('.implode(',',$cids).')';
			$this->_db->setQuery( $query );
			$qusetion_id= $this->_db->loadObjectList();	

			 
			$Questions_array=array();
			$Useranswer_array=array();
			$total_questions=array();
			$total_givenans=array();
			$total_correctanswer=array();
			$result_status=array();
 
			for($i=0;$i<count($qusetion_id);$i++){
			
				$answer=array();

				$score=$qusetion_id[$i]->score;
				$maxscore=$qusetion_id[$i]->maxscore;
				$passed_score=$qusetion_id[$i]->passed_score;

				if($maxscore==0)
					$persentagescore=100;	
				else
					$persentagescore=round($score/$maxscore*100,2)>100?100:round($score/$maxscore*100,2);

				$persentagescore=$persentagescore>0?$persentagescore:0;
				
				if($persentagescore>=$passed_score){
					$status="Passed";
				}else{
					$status="Failed";
				}
				
				$ques=json_decode($qusetion_id[$i]->quiz_questions);
				$ans=json_decode($qusetion_id[$i]->quiz_answers);
				
				$qusetion_id[$i]->quiz_answers;
				$text_answer=json_decode($qusetion_id[$i]->text_answer);
				$textarea_answer=json_decode($qusetion_id[$i]->textarea_answer);
				
				$query = 'select qtitle from #__vquiz_question WHERE id IN ('.implode(',',$ques).') ORDER BY FIELD(id,'.implode(',',$ques).')';
				$this->_db->setQuery( $query );
				$result_ques=$this->_db->loadColumn();
				
				array_push($Questions_array,json_encode($result_ques));
				
				$max_quetion = count($result_ques)>$max_quetion?count($result_ques):$max_quetion;
				
				for($d=0;$d<count($ans);$d++){
				
					if($ans[$d]==0){
						if($text_answer[$d]!=''){
							array_push($answer,$text_answer[$d]);
						}elseif($textarea_answer[$d]!=''){
							array_push($answer,$textarea_answer[$d]);
						}	
					}else{
						$query = 'select qoption from #__vquiz_option WHERE id IN ('.$ans[$d].')';
						$this->_db->setQuery( $query );
						$result_option=$this->_db->loadColumn();
						array_push($answer,implode(',',$result_option));
					}
				}
				
					array_push($Useranswer_array,json_encode($answer)); 
					array_push($total_questions,count($ques)); 
					array_push($total_givenans,count($answer)); 
					
					if($qusetion_id[$i]->quiztype==1){
						$correct_answers_count=$this->getCorrect_answers($ques,$ans,$text_answer,$textarea_answer);
					}else{
						$correct_answers_count='';
						$status='';
					}

					array_push($total_correctanswer,$correct_answers_count); 
					array_push($result_status,$status); 
			}
				

		   for($j=0;$j<count($data);$j++){
		   
				array_push($data[$j],$total_questions[$j]);
				array_push($data[$j],$total_givenans[$j]);
				array_push($data[$j],$total_correctanswer[$j]);
				array_push($data[$j],$result_status[$j]);
				
				//array_push($data[$j],$Questions_array[$j]);
				//array_push($data[$j],$Useranswer_array[$j]);
				
				$questions=json_decode($Questions_array[$j]);
				$useranswer=json_decode($Useranswer_array[$j]);
				
				for($m=0;$m<count($questions);$m++)	{
					array_push($data[$j],$questions[$m]);
					if(isset($useranswer[$m]))
					array_push($data[$j],$useranswer[$m]);
				}
		   }

			for($n=0;$n<$max_quetion;$n++){
				array_push($columnhead,"Questions");
				array_push($columnhead,"Your Answer");
			} 

			//push the heading row at the top
			array_unshift($data, $columnhead);
			
			// output headers so that the file is downloaded rather than displayed
			header('Content-Type: text/csv; charset=utf-8');
			header('Content-Disposition: attachment; filename=Quiz-Result.csv');
			
			// create a file pointer connected to the output stream
			$output = fopen('php://output', 'w');
			
			foreach ($data as $fields) {
				/*
				$f=array();
				foreach($fields as $v)
				array_push($f, mb_convert_encoding($v, 'UTF-16LE', 'utf-8'));
				*/
				fputcsv($output, $fields, ',', '"');
			}
			fclose($output);
			return true;
					
		}
		
}