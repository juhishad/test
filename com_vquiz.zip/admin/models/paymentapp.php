 <?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
class VquizModelPaymentapp extends JModelList
{
	var $_total = null;
	var $_pagination = null;
	
	function __construct()
	{
		parent::__construct();
        $mainframe = JFactory::getApplication();
		
		$context	= 'com_vquiz.paymentapp.list.';
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		$filter_language		= $mainframe->getUserStateFromRequest( $context.'filter_language',	'filter_language',	'' );
		
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
		
		
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}

 
 	function _buildQuery()
 	{
		$db =JFactory::getDBO();
		$user = JFactory::getUser();
		
 		 $query="SELECT i.*  from `#__vquiz_payment_plugin` as `i`";
		 
   
		 return $query; 
	}
 
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}
    
	
	function &getItem()
	{ 
		
		// Load the data
		if (empty( $this->_data )) { //echo "<pre>";print_r($this); exit;
		$query = 'SELECT i.* from `#__vquiz_payment_plugin` as `i`'.
					'  WHERE `i`.`id` = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}

		if (!$this->_data) {
				$this->_data = new stdClass();
			    $this->_data->id = 0;
 				//$this->_data->plugin_extension_id = 1; // default
 				$this->_data->title= null; 
 			    $this->_data->plugin_type= null; 
 				$this->_data->alias= null;
				$this->_data->icon= null;
				$this->_data->type= null;
				$this->_data->description= null; 
 				$this->_data->params= null; 
 				$this->_data->ordering= 0; 
 				$this->_data->published= null;
			
			
		}

		return $this->_data; 

	}
	
	

		function &getItems()
			
		{ 
			// Lets load the data if it doesn't already exist
			
				 $query = $this->_buildQuery(); 
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();  
				 //echo $orderby; //exit;
				 
				 $query .= $filter;
				 $query .= $orderby; 
				// echo $query ; //exit;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			   // echo '<pre>'; print_r($this->_data);exit;
			return $this->_data;
		}
	 
	 
 
			function getTotal()
			{
		
			 if (empty($this->_total)) {
				$query = $this->_buildQuery();
				$query .= $this->_buildContentFilter();
				$query  .= $this->_buildItemOrderBy();
				$this->_total = $this->_getListCount($query);    
		 
				}
			   return $this->_total;
			}
		 
		 
			function _buildItemOrderBy()
			{
				$mainframe = JFactory::getApplication();
				
				$context	= 'com_vquiz.paymentapp.list.';
		 
				$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'i.id', 'cmd' );
				$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );substr(strrchr($filter_order, "."), 1);
				
				//var_dump($this->getTable('Payment', 'Table')->getFields());
		        if (!array_key_exists((string)substr(strrchr($filter_order, "."), 1), $this->getTable('Paymentapp', 'Table')->getFields()))
			        $filter_order = 'i.id'; 
		 		
				$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
		 
				return $orderby;
			}

	function _buildContentFilter()
	{

			$mainframe =JFactory::getApplication();
	 
			$context	= 'com_vquiz.paymentapp.list.';
			$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
			
			$search		= JString::strtolower( $search );
	 
			$where = array();
			
			
			if($search)
			{	
				if (is_numeric($search)) 
				{		 
					$where[] = 'LOWER( i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				}
				else
				{
	 
				 $where[] = 'i.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
	
				
				}
			}
			  
				$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
	 
			return $filter;
	}
		
	
	
 
		 
 

	function delete()
	{
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$row =& $this->getTable();
		if (count( $cids )) {
		foreach($cids as $cid) {
			if (!$row->delete( $cid )) {
				$this->setError( $row->getErrorMsg() );
				return false;
				}		
			}
		}
		return true;
	}			
					
	
							
		
	
	function store()
	{	
		
		//echo 1; 
		//$time = time();
		$session=JFactory::getSession();
		$user = JFactory::getUser();
	    $row =$this->getTable();
		$data = JRequest::get('post');
		
		
		
		//$datee =JFactory::getDate();
		
		$data['params'] = json_encode($data['params']); 
		
		// image processing //
		
		$image = JRequest::getVar('icon', null, 'FILES', 'array');
 		$allowed = array('.jpg', '.jpeg', '.gif', '.png');
 
		$dirpath = JPATH_ROOT.'/components/com_vquiz/assets/upload/icon/';
		

		jimport('joomla.filesystem.file');
		$image_name = str_replace(' ', '', JFile::makeSafe($image['name']));
		
		$image_tmp = $image['tmp_name'];
		$time = time(); 
		
		
		if($image_name <> "" )
		{
				
 			$ext = strrchr($image_name, '.');
 			    if(!in_array($ext, $allowed)){
				$msg_error=JText::_('THIS_IMAGE_TYPE_NOT_ALLOWED');
					$this->setError($msg_error);
					return false;
				}		
				if(move_uploaded_file($image_tmp, $dirpath.$time.'_'.$image_name)){
				
					$data['icon'] = $time.'_'.$image_name;
				}
 	
		}
		// end of image processing //			
									
		if (!$row->bind($data)) {
		$this->setError($this->_db->getErrorMsg());
		return false;
		}

		if (!$row->check()) {
		$this->setError($this->_db->getErrorMsg());
		return false;
		}
			//echo "<pre>";print_r($row); exit;
		if (!$row->store()) {
		$this->setError( $row->getErrorMsg() );
		return false; 
		}

		JRequest::setVar('id', $row->id);		
		
		return true;

	}
	
	function publish()
	{
		$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$task		= JRequest::getCmd( 'task' );
		$publish	= ($task == 'publish')?1:0;
		$n = count( $cid );
		if (empty( $cid )) 
		{
			return 'No item selected';
		}
		$cids = implode( ',', $cid );
		//implode() convert array into string
		$query = 'UPDATE #__vquiz_payment_plugin SET published = ' . (int) $publish . ' WHERE id IN ( ' . $cids . ' )';
		$this->_db->setQuery( $query );
		if (!$this->_db->query())
			return $this->_db->getErrorMsg();
		else
			return ucwords($task).'ed successfully.';
	}
	
	function getPlans(){
		$query = 'select `id`, `title` from `#__vquiz_plans` where `published`=1;';
		$this->_db->setQuery($query);
		return $this->_db->loadObjectList();
	}
	
	public function getPaymentPlugins()
	{
		$query = 'select extension_id, name, element, folder, manifest_cache from #__extensions where type = "plugin" and folder = "vquiz" and enabled = 1';
		$this->_db->setQuery( $query );
		return $this->_db->loadObjectList();
		
	}
	
	
 
 }