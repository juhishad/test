 <?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
class VquizModelOrders extends JModelList
{
	var $_total = null;
	var $_pagination = null;
	
	function __construct()
	{
		parent::__construct();
        $mainframe = JFactory::getApplication();
		
		$context	= 'com_vquiz.orders.list.';
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		$filter_language		= $mainframe->getUserStateFromRequest( $context.'filter_language',	'filter_language',	'' );
		
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
		
		
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}

 
 	function _buildQuery()
 	{
		$db =JFactory::getDBO();
		$user = JFactory::getUser();
		
 		  $query="SELECT i.*, `s`.`id` as `sid`  from `#__vquiz_plans_order` as `i` left join `#__vquiz_plans_subscription` as `s` on `i`.`subscr_id`=`s`.`id` left join `#__vquiz_plans` as `p` on `p`.`id`= `s`.`plan_id`";
		 
   
		 return $query; 
	}
 
	function setId($id)
	{
		// Set id and wipe data
		$this->_order_id		= $id;
		$this->_data	= null;
	}
    
	
	function &getItem()
	{ 
		
		// Load the data
		if (empty( $this->_data )) {
		$query = 'SELECT i.* from `#__vquiz_plans_order` as `i`'.
					'  WHERE `i`.`order_id` = '.$this->_order_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}

		if (!$this->_data) {
			$this->_data = new stdClass();
			    $this->_data->order_id = 0;
				$this->_data->app_id = 1;
				$this->_data->buyer_id = null;
				$this->_data->coupon_code= null; 
				$this->_data->status= null; 
				$this->_data->currency= null;
				$this->_data->subtotal= null;
				$this->_data->discount_amount= null; 				
				$this->_data->tax= null; 
				$this->_data->total= null; 
				$this->_data->gateway_txn_id= null; 
				$this->_data->gatewaway_parent_txn= null; 
				$this->_data->subscr_id= null;
				$this->_data->created_date= null;
				$this->_data->modified_date= null;
				$this->_data->paid_date= '0000-00-00 00:00:00';
				$this->_data->params= null;
			
			
		}
		
		if(!empty($this->subscr_id)){
		   
		   $query = 'SELECT s.*, p.*, s.params as sub_params from `#__vquiz_plans_subscription` as `s` left join `#__vquiz_plans` as `p` on `p`.`id`= `s`.`plan_id`'.
			'  WHERE `s`.`id` = '.$this->subscr_id;
			$this->_db->setQuery( $query );
			$subscription_data = $this->_db->loadObject();
			
			$this->_data->title = $subscription_data->title;
			$this->_data->price = $subscription_data->total;
			$this->_data->expirationtype = $subscription_data->expirationtype;
			$this->_data->expiration = $subscription_data->expiration;
			$params = json_decode($subscription_data->sub_params);
			
			if(isset($params->order_id) && !empty($params->order_id)){
				$query = 'select * from `#__vquiz_plans_order` where `order_id`=(select (order_id) from `#__vquiz_plans_order` where `subscr_id`='.$this->_db->quote($this->subscr_id).' AND `order_id`='.$this->_db->quote($params->order_id).')';
				
				$this->_db->setQuery($query);
				$this->_db->Query($query);
				
				if( $this->_db->getNumRows() > 0 ) { 
					$lastorder = $this->_db->loadObject(); 
					$this->_data->params = $lastorder->params;
					$this->_data->subtotal = $this->_data->subtotal;
					$this->_data->total = $this->_data->total;
				}
				else{
					$this->_data->params = $subscription_data->sub_params;
					$this->_data->subtotal = $subscription_data->total;
					$this->_data->total = $subscription_data->total;
				}
			}
			else
			{
				$this->_data->params = $subscription_data->sub_params;
				$this->_data->subtotal = $subscription_data->total;
				$this->_data->total = $subscription_data->total;
			} 
		}

		return $this->_data; 

	}
	
	

		function &getItems()
			
		{ 
			// Lets load the data if it doesn't already exist
			
				 $query = $this->_buildQuery(); 
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();  
				// echo 1; exit;
				 
				 $query .= $filter;
				 $query .= $orderby; 
				// echo $query ; //exit;
				 
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			   // echo '<pre>'; print_r($this->_data);exit;
			return $this->_data;
		}
	 
	 
 
			function getTotal()
			{
		
			 if (empty($this->_total)) {
				$query = $this->_buildQuery();
				$query .= $this->_buildContentFilter();
				$query  .= $this->_buildItemOrderBy();
				$this->_total = $this->_getListCount($query);    
		 
				}
			   return $this->_total;
			}
		 
		 
			function _buildItemOrderBy()
			{
				$mainframe = JFactory::getApplication();
				
				$context	= 'com_vquiz.orders.list.';
		 
				$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'i.order_id', 'cmd' );
				$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );substr(strrchr($filter_order, "."), 1);
				
		        if (!array_key_exists((string)substr(strrchr($filter_order, "."), 1), $this->getTable('Orders', 'Table')->getFields()))
			        $filter_order = 'i.order_id';
		 		
				$orderby = ' group by i.order_id order by '.$filter_order.' '.$filter_order_Dir . ' ';
		 
				return $orderby;
			}

	function _buildContentFilter()
	{

			$mainframe =JFactory::getApplication();
	 
			$context	= 'com_vquiz.orders.list.';
			$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
			$planid		= $mainframe->getUserStateFromRequest( $context.'planid', 'planid',	'',	'int' );
			$status		= $mainframe->getUserStateFromRequest( $context.'status', 'status',	'',	'int' );
			$paid_date= $mainframe->getUserStateFromRequest( $context.'paid_date', 'paid_date',	array(),	'ARRAY' );
			$search		= JString::strtolower( $search );
	 
			$where = array();
			
			if($status)
			{ 
				$where[] = 'i.status='.$this->_db->quote($status);
			}
			
			if($planid)
			{ 
				$where[] = 'p.id='.$this->_db->quote($planid);
			}
			
			if(count($paid_date)>0){
				if(isset($paid_date[0]) && !empty($paid_date[0]))
					$where[] = 'i.paid_date >= '.$this->_db->quote($paid_date[0]);
				if(isset($paid_date[1]) && !empty($paid_date[1]))
					$where[] = 'i.paid_date <= '.$this->_db->quote($paid_date[1]);
			}
			
			if($search)
			{	
				if (is_numeric($search)) 
				{		 
					$where[] = 'LOWER( i.order_id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				}
				else
				{
	 
				 $where[] = 'p.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
	
				
				}
			}
			  
				$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
	 
			return $filter;
	}
		
	
	
 
		 
 

	function delete()
	{
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$row =& $this->getTable();
		if (count( $cids )) {
		foreach($cids as $cid) {
			if (!$row->delete( $cid )) {
				$this->setError( $row->getErrorMsg() );
				return false;
				}
			}
		}
		return true;
	}			
					
	
							
		
	
	function store()
	{	
		
		$time = time();
		$session=JFactory::getSession();
		$user = JFactory::getUser();
	    $row =$this->getTable();
		$data = JRequest::get('post'); 
		
		$config = QuizHelper::getConfiguration();
		
		if(!isset($data['subscr_id']) || empty($data['subscr_id'])){
			return false;
		}
		
		
		//$datee =JFactory::getDate();
		
		$subscription = QuizHelper::subscriptionDetail($data['subscr_id']);  
		
		$plan = QuizHelper::planDetail($subscription->plan_id);
		
		$data['currency'] = $config->currencyname;
		$data['created_date'] = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
		
		
		$coupon = $session->get('coupon_data', '');
		$coupon_value = 0;
		
		if($data['order_id']){
		$data['subtotal'] = $config->tax_enable==1?QuizHelper::pricewithtax($plan->price):$plan->price;
		$data['total'] = $config->tax_enable==1?QuizHelper::pricewithtax($plan->price):$plan->price;
		}
		
		$order_detail = '';
		if($data['order_id']){
			$data['modified_date'] = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();;
			$order_detail = QuizHelper::orderDetail($data['order_id']);
			$data['subtotal'] = $order_detail->subtotal;
		}
		$update_subscription = false;
		
		if($data['status'] == QuizHelper::ORDER_PAID && (empty($order_detail) || $order_detail->paid_date=='0000-00-00 00:00:00')){ 
			$data['paid_date'] = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();;
			$update_subscription = true;
		}
		$total = $config->tax_enable==1?QuizHelper::pricewithtax($plan->price):$plan->price; 
		$data['tax'] = $config->tax_enable==1?$total-$plan->price:'0.00000';
		
		$coupon_str = "";
		
		if( !empty($coupon) ) {

		$coupon_str = $coupon['codes'] . ";;" . $coupon['offer'] . ";;" . $coupon['type_offer'];

		if( $coupon['type_offer'] == 1 ) { // TOTAL
		$coupon_value = $coupon['offer'];
		}
		if( $coupon['type_offer'] == 0 ) { // TOTAL
		$coupon_value = ($coupon['offer']*$total)/100;
		}
		$session->set('coupon_data', '');
		$data['coupon_code'] = $coupon_str;
		$data['subtotal'] = $coupon_value!=0?$total-$coupon_value:$total;
		}
		
		$params = JRequest::getVar('params', array());  print_r($params); 
		
		
		$expiration = $data['expiration_year'].$data['expiration_month'].$data['expiration_day'];
		
		$expiration .= '000000'; // for hour, minute, second 
	    
		$params['expiration'] = $params['expirationtype']=='fixed'?$expiration:'000000000000';
		
		
		$data['params'] = json_encode($params) ; 
		
		
		$data['app_id'] = isset($data['app_id'])?$data['app_id']:1; //for offline
		
		$data['buyer_id'] = $subscription->user_id;
		
								//echo "<pre>";print_r($subscription); exit;	//echo "<pre>";print_r($data); exit;
		if (!$row->bind($data)) {
		$this->setError($this->_db->getErrorMsg());
		return false;
		}

		if (!$row->check()) {
		$this->setError($this->_db->getErrorMsg());
		return false;
		}
			
		if (!$row->store()) {
		$this->setError( $row->getErrorMsg() );
		return false; 
		}

		JRequest::setVar('id', $row->id);
		
		if($update_subscription){
			$subscription =  $this->getTable('subscriptions', 'Table');
			$subscription->load($data['subscr_id']);
			if($subscription->status == QuizHelper::SUBSCRIPTION_ACTIVE && $config->extend_subscription){
				$seconds = strtotime($subscription->expiration_date) - time();
				$subscription->expiration_date = date("Y-m-d H:i:s", strtotime(QuizHelper::addExpiration($params['expiration']))+$seconds);	
				$subscription->total = $subscription->total+$row->subtotal;	
			}
			else
			{
				$subscription->expiration_date = QuizHelper::addExpiration($params['expiration']);
				$subscription->total = $row->subtotal;	
			}
			
			$subscription->status = QuizHelper::SUBSCRIPTION_ACTIVE;
			$subscription->total = $row->subtotal; // check here total
			$params['order_id'] = $row->order_id;
			$params['price'] = $row->subtotal;
			$subscription->params = json_encode($params);
			$subscription->store();
		}

		return true;

	}
	
	function getPlans(){
		$query = 'select `id`, `title` from `#__vquiz_plans` where `published`=1;';
		$this->_db->setQuery($query);
		return $this->_db->loadObjectList();
	}
	
 
 }