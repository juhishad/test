 <?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
class VquizModelPlans extends JModelList
{
	var $_total = null;
	var $_pagination = null;
	
	function __construct()
	{
		parent::__construct();
        $mainframe = JFactory::getApplication();
		
		$context	= 'com_vquiz.plans.list.';
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		$filter_language		= $mainframe->getUserStateFromRequest( $context.'filter_language',	'filter_language',	'' );
		//$akey			= $mainframe->getUserStateFromRequest( $context.'akey', 'akey', '',	'string' );
		//$akey			= JString::strtolower( $this->_akey );
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
		
		//$plan_id = JRequest::getVar('plan_id',  0);
		//$this->setId((int)$plan_id);
		
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}

 
 	function _buildQuery()
 	{
		$db =JFactory::getDBO();
		$user = JFactory::getUser();
		
 		 $query="SELECT i.* FROM #__vquiz_plans as `i`";
		 
   
		 return $query; 
	}
 
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}
    
	
	function &getItem()
	{ 
		
		// Load the data
		if (empty( $this->_data )) {
		$query = ' SELECT * FROM #__vquiz_plans'.
					'  WHERE id = '.$this->_id; 
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}

		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->title = null;
			$this->_data->alias = null;
			$this->_data->published= null;
			$this->_data->expiration= '000000000000';
			$this->_data->expirationtype= null;
			$this->_data->price= null;			
			$this->_data->ordering= null;
			$this->_data->created_date= null;
			$this->_data->description= '';			
			$this->_data->usergroup_id= null;
			$this->_data->created_by= null;
		}

		return $this->_data; 

	}
	
	

		function &getItems()
			
		{ 
			// Lets load the data if it doesn't already exist
			
				 $query = $this->_buildQuery(); 
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();
				 
				 $query .= $filter;
				 $query .= $orderby; //exit;
				 // echo $query .= $orderby; //exit;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			   // echo '<pre>'; print_r($this->_data);exit;
			return $this->_data;
		}
	 
	 
 
			function getTotal()
			{
		
			 if (empty($this->_total)) {
				$query = $this->_buildQuery();
				$query .= $this->_buildContentFilter();
				$query  .= $this->_buildItemOrderBy();
				$this->_total = $this->_getListCount($query);    
		 
				}
			   return $this->_total;
			}
		 
		 
			function _buildItemOrderBy()
			{
				$mainframe = JFactory::getApplication();
				
				$context	= 'com_vquiz.plans.list.';
		 
				$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'i.id', 'cmd' );
				$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );substr(strrchr($filter_order, "."), 1);
				
		        if (!array_key_exists((string)substr(strrchr($filter_order, "."), 1), $this->getTable('Plans', 'Table')->getFields()))
			        $filter_order = 'i.id';
		 		//$orderby = ' order by '.$filter_order.' '.$filter_order_Dir . ' ';
				$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
		 
				return $orderby;
			}

	function _buildContentFilter()
	{

			$mainframe =JFactory::getApplication();
	 
			$context	= 'com_vquiz.plans.list.';
			$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
			$publish_item		= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );
			$search		= JString::strtolower( $search );
	 
			$where = array();
			
			if($publish_item)
			{  

				if ( $publish_item == 'p' )
				$where[] = 'i.published= 1';
				
				else if($publish_item =='u')
				$where[] = 'i.published = 0';
		
			}
			 
			if($search)
			{	
				if (is_numeric($search)) 
				{		 
					$where[] = 'LOWER( i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				}
				else
				{
	 
				 $where[] = 'i.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
	
				
				}
			}
			  
				$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
	 
			return $filter;
	}
		
	
		
	
	/* function createUserOrderBeforePay()
 	{	
		
			$param = new stdClass();
			$param->expirationtype = $plan->expirationtype;
			$param->expiration = $plan->expiration;
			$param->title = $plan->title;
			$param->order_id = $order->order_id;
			$param->order_key = $order->order_key;
			$param->price = $order->subtotal;
			$subscription->params = json_encode($param);
			$subscription->store();
           
		return true;

	} */
 
		 
 

	function delete()
	{
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$row =& $this->getTable();
		if (count( $cids )) {
		foreach($cids as $cid) {
			if (!$row->delete( $cid )) {
				$this->setError( $row->getErrorMsg() );
				return false;
				}
			}
		}
		return true;
	}			
					
	function publish()
	{
		$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$task		= JRequest::getCmd( 'task' );
		$publish	= ($task == 'publish')?1:0;
		$n = count( $cid );
		if (empty( $cid )) 
		{
			return 'No item selected';
		}
		$cids = implode( ',', $cid );
		//implode() convert array into string
		$query = 'UPDATE #__vquiz_plans SET published = ' . (int) $publish . ' WHERE id IN ( ' . $cids . ' )';
		$this->_db->setQuery( $query );
		if (!$this->_db->query())
			return $this->_db->getErrorMsg();
		else
			return ucwords($task).'ed successfully.';
	}
							
		
	
	function store()
	{	
		
		//$time = time();
		$session=JFactory::getSession();
		$user = JFactory::getUser();
	    $row =$this->getTable(); 
		$data = JRequest::get('post');
		
		$data['description'] = JRequest::getVar('description', '', 'post', 'string', JREQUEST_ALLOWRAW);
		
		$data["alias"] = empty($data["alias"])?$data["title"]:$data["alias"];
		$data["alias"]= JFilterOutput::stringURLSafe($data['alias']);

		$query = 'select count( * ) from #__vquiz_plans where id <> '.$this->_db->quote($data['id']).' and alias = '.$this->_db->quote($data['alias']);
		$this->_db->setQuery( $query );
		$count = $this->_db->loadResult();

		if ($count>0) {
			$this->setError(JText::_('SAME_ALIAS'));
			return false;
		}
		
		
		$expiration = $data['expiration_year'].$data['expiration_month'].$data['expiration_day'];
		
		$expiration .= '000000'; // for hour, minute, second 
	    
		$data['expiration'] = $data['expirationtype']=='fixed'?$expiration:'000000000000';
		
		//$datee =JFactory::getDate();
		$data['modified_date'] = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
		
		if($data["id"]==0){		
			
			$data['created_date'] = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
			$data['created_by'] = $user->id;
			
			$query='select MAX(ordering) from #__vquiz_plans';
			$this->_db->setQuery($query);
			$highest_ordering=$this->_db->loadResult();

			$data['ordering'] = $highest_ordering+1;
		}
				
		if (!$row->bind($data)) {
		$this->setError($this->_db->getErrorMsg());
		return false;
		}

		if (!$row->check()) {
		$this->setError($this->_db->getErrorMsg());
		return false;
		}
 
		if (!$row->store()) {
		$this->setError( $row->getErrorMsg() );
		return false; 
		}

		JRequest::setVar('id', $row->id);
		
		return true;



	}
	
	function getUserGroup(){
		
		$query = $this->_db->getQuery(true);
		$query->select('a.id , a.title');
		$query->from($this->_db->quoteName('#__usergroups').' as a');
		$query->join('LEFT',$this->_db->quoteName('#__usergroups').' AS b ON a.lft > b.lft AND a.rgt < b.rgt');
		//$query->where('a.id !=1');
		$query->group('a.id, a.title, a.lft, a.rgt, a.parent_id');
		$query->order('a.lft ASC');
		$this->_db->setQuery($query);
		$result=$this->_db->loadObjectList();
		
		
		return $result;
		
	}
	
 
 }