<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.modellist');
 
class VquizModelSkills extends JModelList
{
		 function __construct()
			{
				parent::__construct();

				$mainframe = JFactory::getApplication();
				$context	= 'com_vquiz.skills.list.';
				// Get pagination request variables
				$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
				$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );

				// In case limit has been changed, adjust it
				$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
				$this->setState('limit', $limit);
				$this->setState('limitstart', $limitstart);				 
				$array = JRequest::getVar('cid',  0, '', 'array');
				$this->setId((int)$array[0]);
			}

			function _buildQuery()
			{

				$user = JFactory::getUser();
				
				$query= 'SELECT i.* FROM #__vquiz_skills as i ';
 
				
			 return $query;
			}

		function setId($id)	
		{
		$this->_id		= $id;
 		$this->_data	= null;
 		}

		
		 function &getItem()
		 {
		if (empty( $this->_data )) {
		$query='SELECT i.*';
		$query .=' FROM #__vquiz_skills as i where i.id = '.$this->_id;	
		
		$this->_db->setQuery( $query );
		$this->_data = $this->_db->loadObject();
		}



		if (!$this->_data) {
 		$this->_data = new stdClass();
  		$this->_data->id = 0;
 		$this->_data->title = null;
 		$this->_data->published = 1;
 
		}
 		return $this->_data;
 	}




		 function &getItems()
			
		{
			// Lets load the data if it doesn't already exist
			if (empty( $this->_data ))
			{
				 $query = $this->_buildQuery();
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();
				 
				 $query .= $filter;
				 $query .= $orderby;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			}
	
			return $this->_data;
		}
	 


	
		function getTotal()
		{
				
			if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$query .= $this->_buildContentFilter();
			$this->_total = $this->_getListCount($query);    
			}
			return $this->_total;
 		}



		function _buildItemOrderBy()
			{
				$mainframe = JFactory::getApplication();
				$context	= 'com_vquiz.skills.list.';
				$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
				$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
				$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
				return $orderby;
			}



			function getPagination()
			{
				// Load the content if it doesn't already exist
				if (empty($this->_pagination)) {
					jimport('joomla.html.pagination');
					$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
				}
				return $this->_pagination;
			}
 
 
 
		function _buildContentFilter()
		{
			$mainframe =JFactory::getApplication();

			$context	= 'com_vquiz.skills.list.';
			$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );

			$search		= JString::strtolower( $search );

			$publish_item		= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );

			$where = array();

			if($publish_item){  

				if ( $publish_item == 'p' ){
					$where[] = 'i.published= 1';
				}elseif($publish_item =='u'){
					$where[] = 'i.published = 0';
				}

			}

			if($search)
			{	
				if (is_numeric($search)) 
				{		 
					$where[] = 'i.id ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				}
				else
				{
					$where[] = 'lower(i.title) LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
				}
			}

			$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';

			return $filter;

		}
 
			function store()
			{	
				$user = JFactory::getUser();
				$mailer = JFactory::getMailer();
				$config = JFactory::getConfig();
			
				$row = $this->getTable();
				$data = JRequest::get( 'post' );
				
										
				if (!$row->bind($data)) {
				$this->setError($this->_db->getErrorMsg());
				return false;
				}
				
				if (!$row->check()) {
				$this->setError($this->_db->getErrorMsg());
				return false;
				}
				

				if (!$row->store()) {
				$this->setError( $row->getErrorMsg() );
				return false; 
				}				
								
				JRequest::setVar('id', $row->id);
				
				//echo "<pre>";print_r($data);exit; //echo "<pre>";print_r($row);
				
				//save notification on adding
				
				if(!$data['id']){ 
					
					$data_arr = array();
					$data_arr['itemid'] = $row->id;
					$data_arr['notification_type'] = 9;
					$data_arr['replace_skill_title'] = $row->title;
						
					if(QuizHelper::checkNotification($data_arr['notification_type'])){
						$data_arr['notify_users'] = QuizHelper::findUsersToNotify('notify_add_skill');
						$data_arr['enotify_users'] = QuizHelper::findUsersToEnotify('enotify_add_skill');
						//print_r($data_arr); exit;
						QuizHelper::sendNotification($data_arr);
					}
					
				}

				return true;
			}
 

		function delete()
		{
			$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
			$row =& $this->getTable();
			if (count( $cids )) {
			foreach($cids as $cid) {
				if (!$row->delete( $cid )) {
					$this->setError( $row->getErrorMsg() );
					return false;
					}
				}
			}
			return true;
		}

	function publish(){

		$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$task		= JRequest::getCmd( 'task' );
		$publish	= ($task == 'publish')?1:0;
		$n = count( $cid );
		if (empty( $cid )) {
			return JText::_('No item selected');
		}

		$cids = implode( ',', $cid );
		$query = 'UPDATE #__vquiz_skills SET published = ' . (int) $publish . ' WHERE id IN ( ' . $cids . ' )';
		$this->_db->setQuery( $query );
	
		if (!$this->_db->query()){
			return $this->_db->getErrorMsg();
		}
		else{
			return ucwords($task).'ed successfully.';
		}
	
	}
				
}