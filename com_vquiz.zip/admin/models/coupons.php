 <?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
class VquizModelCoupons extends JModelList
{
	var $_total = null;
	var $_pagination = null;
	
	function __construct()
	{
		parent::__construct();
        $mainframe = JFactory::getApplication();
		
		$context	= 'com_vquiz.coupons.list.';
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		$filter_language		= $mainframe->getUserStateFromRequest( $context.'filter_language',	'filter_language',	'' );
		
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
		
		
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}

 
 	function _buildQuery()
 	{
		$db =JFactory::getDBO();
		$user = JFactory::getUser();
		
 		 $query="SELECT i.* FROM #__vquiz_coupons as `i`";
		 
   
		 return $query; 
	}
 
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}
    
	
	function &getItem()
	{ 
		
		// Load the data
		if (empty( $this->_data )) {
		$query = ' SELECT * FROM #__vquiz_coupons'.
					'  WHERE id = '.$this->_id; 
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}

		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->codes = null;
			$this->_data->offer = null;
			$this->_data->type_offer = null;
			$this->_data->code_used = null;
			$this->_data->above_amount = null;			
			$this->_data->published= null;
			$this->_data->start_date= null;
			$this->_data->expiry_date= null;
			$this->_data->maximum_discount= null;
			$this->_data->ordering= null;
			$this->_data->description= '';
			$this->_data->created_date= null;
			$this->_data->created_by= null;
			$this->_data->plan_id = null;
			$this->_data->qcategories= null;
			$this->_data->quizids= null;
			$this->_data->applicable_user= null;
			
		}

		return $this->_data; 

	}
	
	

		function &getItems()
			
		{ 
			// Lets load the data if it doesn't already exist
			
				 $query = $this->_buildQuery(); 
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();  
				// echo 1; exit;
				 
				 $query .= $filter;
				 $query .= $orderby; 
				// echo $query ; //exit;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			   // echo '<pre>'; print_r($this->_data);exit;
			return $this->_data;
		}
	 
	 
 
			function getTotal()
			{
		
			 if (empty($this->_total)) {
				$query = $this->_buildQuery();
				$query .= $this->_buildContentFilter();
				$query  .= $this->_buildItemOrderBy();
				$this->_total = $this->_getListCount($query);    
		 
				}
			   return $this->_total;
			}
		 
		 
			function _buildItemOrderBy()
			{
				$mainframe = JFactory::getApplication();
				
				$context	= 'com_vquiz.coupons.list.';
		 
				$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'i.id', 'cmd' );
				$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );substr(strrchr($filter_order, "."), 1);
				
		        if (!array_key_exists((string)substr(strrchr($filter_order, "."), 1), $this->getTable('Coupons', 'Table')->getFields()))
			        $filter_order = 'i.id';
		 		//$orderby = ' order by '.$filter_order.' '.$filter_order_Dir . ' ';
				$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
		 
				return $orderby;
			}

	function _buildContentFilter()
	{

			$mainframe =JFactory::getApplication();
	 
			$context	= 'com_vquiz.coupons.list.';
			$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
			$publish_item		= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );
			$search		= JString::strtolower( $search );
	 
			$where = array();
			
			if($publish_item)
			{  

				if ( $publish_item == 'p' )
				$where[] = 'i.published= 1';
				
				else if($publish_item =='u')
				$where[] = 'i.published = 0';
		
			}
			 
			if($search)
			{	
				if (is_numeric($search)) 
				{		 
					$where[] = 'LOWER( i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				}
				else
				{
	 
				 $where[] = 'i.codes LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
	
				
				}
			}
			  
				$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
	 
			return $filter;
	}
		
	
	
 
		 
 

	function delete()
	{
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$row =& $this->getTable();
		if (count( $cids )) {
		foreach($cids as $cid) {
			if (!$row->delete( $cid )) {
				$this->setError( $row->getErrorMsg() );
				return false;
				}
			}
		}
		return true;
	}			
					
	function publish()
	{
		$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$task		= JRequest::getCmd( 'task' );
		$publish	= ($task == 'publish')?1:0;
		$n = count( $cid );
		if (empty( $cid )) 
		{
			return 'No item selected';
		}
		$cids = implode( ',', $cid );
		//implode() convert array into string
		$query = 'UPDATE #__vquiz_coupons SET published = ' . (int) $publish . ' WHERE id IN ( ' . $cids . ' )';
		$this->_db->setQuery( $query );
		if (!$this->_db->query())
			return $this->_db->getErrorMsg();
		else
			return ucwords($task).'ed successfully.';
	}
							
		
	
	function store()
	{	
		
		//$time = time();
		$session=JFactory::getSession();
		$user = JFactory::getUser();
	    $row =$this->getTable();
		$data = JRequest::get('post');
		
		//$data['description'] = JRequest::getVar('description', '', 'post', 'string', JREQUEST_ALLOWRAW);
		
		
		//$datee =JFactory::getDate();
		//$data['modified_date'] = $datee->toSQL();
		
		if($data["id"]==0){		
			
			$data['created_date'] = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
			$data['created_by'] = $user->id;
			
			$query='select MAX(ordering) from #__vquiz_coupons';
			$this->_db->setQuery($query);
			$highest_ordering=$this->_db->loadResult();

			$data['ordering'] = $highest_ordering+1;
		}
		
		$applicable_quiz_arr = !empty($data['quizids'])?explode(',',$data['quizids']):array();
		
		$data['quizids'] = json_encode($applicable_quiz_arr);
		
		$applicable_user_arr = !empty($data['applicable_user'])?explode(',',$data['applicable_user']):array();
		
		$data['applicable_user'] = json_encode($applicable_user_arr);
				//echo "<pre>";print_r($data); exit;
		if (!$row->bind($data)) {
		$this->setError($this->_db->getErrorMsg());
		return false;
		}

		if (!$row->check()) {
		$this->setError($this->_db->getErrorMsg());
		return false;
		}
 
		if (!$row->store()) {
		$this->setError( $row->getErrorMsg() );
		return false; 
		}

		JRequest::setVar('id', $row->id);	
		

		return true;



	}
	
	public function getCurrency()
	{
		$query=$this->_db->getQuery(true);
		$query->select('currencyname');
		$query->from('#__vquiz_configuration');
		//$query->where('config_key="currency"');
		$this->_db->setQuery($query);
		$result=$this->_db->loadResult();
		return $result;
	}
	
	function getPlans(){
		$query = 'select `id`, `title` from `#__vquiz_plans` where `published`=1;';
		$this->_db->setQuery($query);
		return $this->_db->loadObjectList();
	}
	
 
 }