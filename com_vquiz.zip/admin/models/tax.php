<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.model');

class VquizModelTax extends JModelLegacy
{
	var $_list;
    var $_data = null;
	var $_total = null;
	var $_pagination = null;
	
	function __construct()
	{
		parent::__construct();
		$mainframe = JFactory::getApplication();
		$context	= 'com_vquiz.tax.list.';
		
		// Get pagination request variables
		$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = JRequest::getVar('limitstart', 0, '', 'int');
		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}
	
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}
	//build query to fetch data
	function _buildQuery()
	{
		$query =' SELECT * FROM #__vquiz_tax ';
		return $query;
	}
	//get data listing
	function getItems()
	{
		// Lets load the data if it doesn't already exist
		if (empty( $this->_data ))
		{
				
			$query = $this->_buildQuery();
			
			$filter = $this->_buildItemFilter();
			$query .= $filter;
		
			$orderby = $this->_buildItemOrderBy();
			$query .= $orderby;

			$this->_data = $this->_getList( $query, $this->getState('limitstart'), $this->getState('limit'));
			echo $this->_db->getErrorMsg();
		}
		return $this->_data;
	}
	
	function getTotal()
	{
		// Load the content if it doesn't already exist
        if (empty($this->_total))
		{
			$query = $this->_buildQuery();
			$filter = $this->_buildItemFilter();
			$query .= $filter;
            $this->_total = $this->_getListCount($query);       
        }
        return $this->_total;
	}
	//get joomla pagination
	function getPagination()
	{
		// Load the content if it doesn't already exist
        if (empty($this->_pagination))
		{
            jimport('joomla.html.pagination');
            $this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
        }
        return $this->_pagination;
	}
	//sorting data by order
	function _buildItemOrderBy()
	{
        $mainframe = JFactory::getApplication();
		$context	= 'com_vquiz.tax.list.';
 
        $filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
        $filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
        $orderby = ' group by id order by '.$filter_order.' '.$filter_order_Dir . ' ';
        return $orderby;
	}
	//filtering data
	function _buildItemFilter()
	{
		$mainframe = JFactory::getApplication();
		$context	= 'com_vquiz.tax.list.';
		
		$filter_order = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'i.ordering', 'cmd' );
		$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', '', 'word' );
		
		$search = $mainframe->getUserStateFromRequest( $context.'search', 'search', '', 'string' );
		$search = JString::strtolower( $search );
		
		$user = JFactory::getUser();
		$uID = $user->id;
		
		//get listing of all users of an owner
		
		$where = array();
	
		if ($search)
		{
			if(is_numeric($search)) {
				$where[] = ' id= '.$this->_db->Quote($search);
			} else {
				$where[] = ' LOWER(tax_name) LIKE '.$this->_db->Quote('%'.$search.'%');
			}
		}
				
		
		
		$where = ( count( $where ) ? ' WHERE '. implode( ' AND ', $where ) : '' );
		return $where;
	}
	//get item detail
	function getItem()
	{
		// Load the data
		if (empty( $this->_data )) {
			$query = ' SELECT * FROM #__vquiz_tax WHERE id = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}
		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = null;
			$this->_data->tax_name = null;
			$this->_data->tax_value = null;
			$this->_data->published = null;
			$this->_data->tax_desc = null;
		} 
		
		return $this->_data;
	}
	
	public function getTable($type = 'Vaccount', $prefix = 'JTable', $config = array())
	{
		return JTable::getInstance($type, $prefix, $config);
	}
	
	function getTables()
	{
		
		$query = 'show tables';
		$this->_db->setQuery( $query );
		$items = $this->_db->loadColumn();
		
		return $items;
	}
	//save data to database
	function store()
	{	
		$row = $this->getTable('Tax', 'VquizTable');
		$data = JRequest::get( 'post' );
			
		$user = JFactory::getUser();
		$userId = $user->id;
		$groups = $user->getAuthorisedGroups();
		$data['tax_name'] = $data['tax_name'];
		$data['tax_value'] = $data['tax_value'];
		$data['tax_desc'] = JRequest::getVar('tax_desc', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$data['created_by'] = $userId;
	
		 $rowid = JRequest::getInt('id', 0); 
		 $querycheck = 'SELECT * FROM #__vquiz_tax WHERE tax_name = "'.$data['tax_name'].'"';
						$this->_db->setQuery( $querycheck ); 
					$gettax_name = $this->_db->loadObject();
					$counttaxname = count($gettax_name);
					if($counttaxname > 0 && $rowid == 0){
					$msg = JText::_( 'TAX_NAME_ALREADY_EXIST' );
			$this->setError(JFactory::getApplication()->enqueueMessage($msg, 'warning'));
			return false;	
						
					}
		if($rowid == 0){
	$insertquery = 'INSERT INTO #__vquiz_tax SET tax_name = "'.$data['tax_name'].'", tax_value='.$data['tax_value'].', published=1, tax_desc="'.$data['tax_desc'].'", created_by='.$data['created_by'].'';
						$this->_db->setQuery( $insertquery ); 
						$this->_db->query();
		}else{
			$updatequery = 'UPDATE #__vquiz_tax SET tax_name = "'.$data['tax_name'].'", tax_value='.$data['tax_value'].', published=1, tax_desc="'.$data['tax_desc'].'", created_by='.$data['created_by'].' WHERE id='.$rowid.'';
						$this->_db->setQuery( $updatequery ); 
						$this->_db->query();
		}
		
		return true;
	}
	//delete records
	function delete()
	{
		$user = JFactory::getUser();
		$groups = $user->getAuthorisedGroups();
		
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$row = $this->getTable('Tax', 'VquizTable');

		if (count( $cids )) {
			foreach($cids as $cid) {
					$deletequery = 'DELETE FROM #__vquiz_tax WHERE id = '.$this->_db->quote($cid);
						$this->_db->setQuery( $deletequery ); 
						$this->_db->query();
				
				
			}
		}
		return true;
	}

	
	
}