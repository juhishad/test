<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined('_JEXEC') or die();
jimport('joomla.application.component.modellist');
class VquizModelVquiz extends JModelList
{

	function __construct()
	{
		parent::__construct();
	}
	
	function _buildQuery()
	{
		
		$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
		$user = JFactory::getUser();
		
		$query='select * from `#__vquiz_category` where  published=1';
		
		if (!$user->authorise('core.admin','com_vquiz')){
			$groups = implode(',', $user->getAuthorisedViewLevels());
			$query .= ' and i.access IN (' . $groups . ')';
		}
		
		return $query;
	}
	
	function getConfiguration()
	{
		
		
		$query='select * from `#__vquiz_configuration`';
		$this->_db->setQuery($query);
		$config = $this->_db->loadObject(); 
		return $config;
	}
	
	function getProfile($profile_id){
		$data = array();
		if($profile_id!='')
		{
			$query = 'select * from #__vquiz_widget where id="'.$profile_id.'" order by ordering';
			$this->_db->setQuery($query);
			$data = $this->_db->loadObject();
		}
		return $data;
	}
	
	function getProfiles()
	{
		
		$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));
		$user = JFactory::getUser();
		
		$query='select * from `#__vquiz_widget` where site in(0,2) order by ordering';
		$this->_db->setQuery($query);
		$widget = $this->_db->loadObjectList(); 
		return $widget;
	}
	
	function getData()
	{
		// Lets load the data if it doesn't already exist
		if (empty( $this->_data ))
		{
			$query = $this->_buildQuery();

			$this->_data = $this->_getList( $query, $this->getState('limitstart'), $this->getState('limit'));
			echo $this->_db->getErrorMsg();
		}
		return $this->_data;
	}
	
	
	function getCategory()
	{
			
		$query = 'select id,title from #__vquiz_category WHERE published=1';
		$this->_db->setQuery( $query );
		$result = $this->_db->loadObjectList();
		
		return $result;
	}
				
	
	function getLinechart()
	{
		
		
		$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));	
		$type = JRequest::getVar('type', 'day');
		$category = JRequest::getInt('category', 0);
		$formate = JRequest::getVar('formate', '');
		
		$obj = new stdClass();
		$obj->result = "error";

		
		switch($type)
		{
		case 'day':
		$query = 'SELECT date_format(r.created, "%e, %b"),date_format(r.created, "%e, %b") as day';

		break;
		case 'week':
		$query = 'SELECT date_format(r.created, "%U, %Y"),date_format(r.created, "%U, %Y") as week';
		break;
		
		case 'month':
		$query = 'SELECT date_format(r.created, "%b"),date_format(r.created, "%b") as month';
		break;
		}
		
		
		$query .= ' ,count(r.userid) as users from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id ';
		
		if($category)
		{
		$query .=' where r.categoryid='.$category.'';
		}
		
		$query .= ' group by '.$type.' order by r.id asc';
		
		$this->_db->setQuery( $query );	
		$result=$this->_db->loadRowList(); 	
		if($formate=='listing_formate'){
			$this->_db->setQuery( $query );	
			$result=$this->_db->loadObjectList(); 	
			$html = ''; 
			for($r=0;$r<count($result);$r++){  
				if($r==0){
				$html .= '<thead><tr>';
				$h = 0;
				$newdata = '';
				foreach($result[$r] as $key => $value)
				{
					if($h == 0){$h=1; continue;}
					$html .= '<td>'.$key.'</td>';
					$newdata .= '<td>'.$value.'</td>';
				}
				$html .= '</tr></thead>';	
				$html .= '<tr>'.$newdata.'</tr>';	
				}
				else{
				$html .= '<tr>';
				$html .= '<td>'.$result[$r]->$type.'</td>';	
				$html .= '<td>'.$result[$r]->users.'</td>';
				$html .= '</tr>';
				}
				
			}
		$result	= $html;
		}
		$obj->playedquiz=$result;

		
		$obj->result = "success";

		return $obj;
	}
							
							
	function getpiechart()
		{
			
			
			$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));	
			$category = JRequest::getInt('category', 0);
			$quiz_type = JRequest::getInt('quiz_type', 0);
			$formate = JRequest::getVar('formate', '');
			$obj = new stdClass();
			$obj->result = "error";
			
			$arr2=array();

			$where = array();	
			 
		  
			$query = ' SELECT q.title as qtitle,q.id as quizid ,count(r.userid) as totaluser from #__vquiz_quizresult as r left join #__vquiz_quizzes as q on r.quizid=q.id ';
			$query = ' left join #__vquiz_category as c on c.id=q.catid ';
		
			$where[] = 'q.published=1';
			 
			if($category)
			{
				  //$query .=' where r.categoryid='.$category;
				  $where[] = ' c.categoryid='.$category;
			}
			if($quiz_type)
			{
			   // $query .=' where q.optinscoretype='.$quiz_type;
				$where[] = ' q.quiztype='.$quiz_type;
			}

			$filter = ' WHERE ' . implode(' AND ', $where);

			$query .= $filter;
		
			$query .= ' group by r.quizid order by r.id desc LIMIT 10';
		

			$this->_db->setQuery( $query );	
								
			$resulted=$this->_db->loadObjectList(); 
			
		  
			for($i=0;$i<count($resulted);$i++){
				$arr=array();
				$x=$resulted[$i]->qtitle;
				$y=$resulted[$i]->totaluser;

				$link=$resulted[$i]->quizid;
				array_push($arr,$x);
				array_push($arr,$link);
				array_push($arr,$y);
				array_push($arr2,$arr);
			}
			 if($formate=='listing_formate'){
					
				$html = '';
				for($r=0;$r<count($resulted);$r++){
					if($r==0){
					$html .= '<thead><tr>';
					$newdata = '';
					foreach($resulted[$r] as $key => $value)
					{
						
						$html .= '<td>'.$key.'</td>';
						$newdata .= '<td>'.$value.'</td>';
					}
					$html .= '</tr></thead>';	
					$html .= '<tr>'.$newdata.'</tr>';	
					}
					else{
					$html .= '<tr>';
					$html .= '<td>'.$resulted[$r]->$type.'</td>';	
					$html .= '<td>'.$resulted[$r]->users.'</td>';
					$html .= '</tr>';
					}
					
				}
			$arr2	= $html;
			}
						
			$obj->playedquiz=$arr2;				
			$obj->result = "success";

			return $obj;
		}
				
		
		function getgeochart()
		{
			
			
			$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));	
			$agegroup = JRequest::getInt('agegroup');
			$obj = new stdClass();
			$obj->result = "error";
			
			$query = ' SELECT i.country,count(u.id) from #__vquiz_users as i left join #__users as u on i.userid=u.id ';
			
			if($agegroup)
			{	
			$age=$agegroup+10;
			
			if($agegroup==60)
			$query .=' where TIMESTAMPDIFF(YEAR ,i.dob, NOW()) >='.$agegroup.'';
			else
			$query .=' where TIMESTAMPDIFF(YEAR ,i.dob, NOW()) >='.$agegroup.' and TIMESTAMPDIFF(YEAR ,i.dob, NOW()) <='.$age.'';
			
			}
			
			$query .= ' group by i.country order by  i.userid desc';
			
			$this->_db->setQuery( $query );	
			$result=$this->_db->loadRowList(); 					
			$obj->userinfo=$result;

			
			$obj->result = "success";

			return $obj;
		} 
				
				
				
		function getflagpiechart()
		{
			
			$date = JFactory::getDate('now', JFactory::getConfig()->get('offset'));	
			$category = JRequest::getInt('category', 0);
			
			$obj = new stdClass();
			$obj->result = "error";

			

			$arr2=array();
			$query = ' SELECT quizid,qtitle,id,flagcount from #__vquiz_question where flagcount!=0  order by id asc LIMIT 10';				
			$this->_db->setQuery( $query );	
			$result=$this->_db->loadObjectList(); 
				
			
				for($i=0;$i<count($result);$i++){
				$arr=array();
				$x=strip_tags($result[$i]->qtitle);
				$id=$result[$i]->id;
				$y=$result[$i]->flagcount;
				$quizid=$result[$i]->quizid;
				array_push($arr,substr($x,0,100));
				array_push($arr,$id);
				array_push($arr,$y);
				array_push($arr,$quizid);
				array_push($arr2,$arr);
				}

			$obj->flagquestion=$arr2;

			
			$obj->result = "success";

			return $obj;
		}
		
	//update widget ordering
	function updateordering(){
		
		$ordering_data = JFactory::getApplication()->input->get('new_ordering', 0, 'ARRAY');
		//echo'<pre>';print_r($ordering_data);
		$row = $this->getTable('Widget', 'Table');
		for($i=0;$i<count($ordering_data);$i++){
			$data = explode(':', $ordering_data[$i]);
			$query ='UPDATE #__vquiz_widget set ordering='.($i+1).' WHERE id='.(int)$data[0];
			$this->_db->setQuery($query);
			$this->_db->query();
		}
		jexit();
	}
	
    //delete widget ordering
	function delete()
	{ 
		
		$cids = JFactory::getApplication()->input->get( 'id',0);

		$row = $this->getTable('Widget', 'Table');

		if ($cids )
		{
			$query = 'delete from #__vquiz_widget where id='.(int)$cids;
			$this->_db->setQuery($query)->query();
			return true;				
		}
		return true;
	}			
			 
}

?>