<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
class VquizModelQuizmanager extends JModelList
{
	function __construct()
	{
		parent::__construct();
		$mainframe = JFactory::getApplication();
		$context	= 'com_vquiz.quizmanager.list.';
		/*--Get pagination request variables--*/
		$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		$filter_language = $mainframe->getUserStateFromRequest( $context.'filter_language',	'filter_language',	'' );
		/*--In case limit has been changed, adjust it--*/
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
		

	}

 	function _buildQuery()
	{
	    
		 $user = JFactory::getUser();
		 
		 
		 //$query="SELECT i.*, count(u.quizzesid) as totalquestion , x.quiztitle as categoryname FROM #__vquiz_quizzes as i left join #__vquiz_question as u ON i.id = u.quizzesid left join #__vquiz_category as x ON x.id = i.quiz_categoryid";
		 
		 $query =$this->_db->getQuery(true);
		 $query->select('i.*,count(q.questionid) as totalquestion , x.title as categoryname,u.name as uname ');
		 $query->from($this->_db->quoteName('#__vquiz_quizzes').' as i');
		 $query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').'as q on i.id = q.quizid ');
		// $query->join('LEFT',$this->_db->quoteName('#__vquiz_question').'as qu on qu.id = q.questionid ');
		 $query->join('LEFT',$this->_db->quoteName('#__vquiz_category').'as x ON x.id = i.catid');
		 $query->join('LEFT',$this->_db->quoteName('#__users').'as u ON i.created_by = u.id');
		 
		if (!$user->authorise('core.admin','com_vquiz')){
			$groups = implode(',', $user->getAuthorisedViewLevels());
			$query .= ' and i.access IN (' . $groups . ')';
		}
		
		return $query;
	}

	function setId($id)
	{
		$this->_id		= $id;
		$this->_data	= null;
	}
	
	
	function getCountQuestion(){
		if($this->_id!=0){		
		
			//$query=" select count(quizzesid)  FROM #__vquiz_question WHERE quizzesid = ".$this->_id;
			
			$query = $this->_db->getQuery(true);
			$query->select('count(questionid)');
			$query->from($this->_db->quoteName('#__vquiz_quiznques'));
			$query->where('quizid ='.$this->_db->quote($this->_id));
			$this->_db->setQuery( $query );
			$total_Question = $this->_db->loadResult();
			
		}else{
			$total_Question=0;
		}
		return $total_Question;
	}

	function getAccesstoken($chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890')
	{
		$length =20;	
		$chars_length = (strlen($chars) - 1);
		$string = $chars {rand(0, $chars_length)};
		for ($i = 1; $i < $length; $i = strlen($string))
		{
			$r = $chars {rand(0, $chars_length)};
			if ($r != $string {$i - 1})
			$string .= $r;
		}
		return $string;
	}
	
	function &getItem()
	{
		
					//print_r($data);exit;
		if (empty( $this->_data )) {
			$query = ' SELECT q.*, u.name FROM #__vquiz_quizzes as q INNER JOIN  #__users as u ON q.created_by = u.id WHERE q.id = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
			/* $query = ' SELECT params FROM #__vquiz_quizzes '.
					'  WHERE id = '.$this->_id;
			$this->_db->setQuery( $query );
			$params = $this->_db->loadcolumn();
			//print_r($params);exit;
			if (isset($this->_data->params) && is_array($this->_data->params))
			{
				// Convert the params field to a string.
				$parameter = new JRegistry;
				$parameter->loadArray($this->_data->params);
				$this->_data->params = (string)$parameter;
				//print_r($array['params']);exit;
			}
		 */
			//$query="SELECT i.*, count(u.quizzesid) as totalquestion FROM #__vquiz_quizzes as i left join #__vquiz_question as u ON i.id = u.quizzesid WHERE id = ".$this->_id;
			
			/* $query = $this->_db->getQuery(true);
			$query->select('count(q.questionid) as totalquestion');
			$query->from($this->_db->quoteName('#__vquiz_quizzes').' as i');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes').' as q on q.quizid=i.id');
			$query->where('i.id ='.$this->_db->quote($this->_id)); */
			
		}

		
		if (!$this->_data) {
				$this->_data = new stdClass();
				$this->_data->id = 0;
 				$this->_data->title = null;
 				$this->_data->catid= null; 
 			    $this->_data->startpublish_date= JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString(); 
 				$this->_data->endpublish_date= null;
 				$this->_data->question_categoryid= null; 
 				$this->_data->description= null;
 				$this->_data->published= 1;
				$this->_data->set_price= null;
				$this->_data->price= 0;
				$this->_data->featured= null;
 				$this->_data->total_timelimit= null;
				$this->_data->totaltime_parameter= null;
 				$this->_data->question_timelimit= null;
 				$this->_data->passed_score= null;
 				$this->_data->random_question= null;
 				$this->_data->prev_button= null;
 				$this->_data->skip_button= null;
				$this->_data->question_number= null;
 				$this->_data->show_correctans= null;
 				$this->_data->explanation= null;
 				$this->_data->penalty= null;
  				$this->_data->paging= null;
				$this->_data->paging_limit= null;
				
 				$this->_data->accessuser= null;
 				$this->_data->attempt_count = null;
				$this->_data->count_ipaddress = null;
 				$this->_data->attempt_delay= null;
 				$this->_data->delay_periods= null;
 				$this->_data->quiz_categoryname= null;
 				$this->_data->graph_type= null;
				$this->_data->flag= null;
				$this->_data->livescore= null;
				$this->_data->quiztype= null;
				$this->_data->question_limit= null;
				$this->_data->meta_keyword= null;
				$this->_data->meta_desc= null;
				$this->_data->userscore= null;
				$this->_data->ordering= null;
				$this->_data->access= null;
				$this->_data->language= null;
				$this->_data->slider_bar= null;
				$this->_data->correctans= null;
				$this->_data->question_options_display= null;
				$this->_data->show_graph= null;
				$this->_data->answers_type= null;
				$this->_data->personality_type= null;
				$this->_data->multi_p_percentage= null;
				$this->_data->completion_level= null;
				$this->_data->multi_p_score= null;
				$this->_data->ipaddress_allow= null;
				$this->_data->random_option =null;
				$this->_data->answer_sheet_option =1;
				$this->_data->prev_answer =0;
				$this->_data->answer_sheet =1;
				$this->_data->category_combination =null;
				$this->_data->certificate =null;
				$this->_data->cet_digits =10;
				$this->_data->end_with ='vQuiz';
				$this->_data->cet_format =0;
				$this->_data->cet_type =1;
				$this->_data->start_with ='CET';
				$this->_data->input_first_name =0;
				$this->_data->input_last_name =0;
				$this->_data->input_company =0;
				$this->_data->input_title =0;
				$this->_data->input_email =0;
				$this->_data->input_mobile =0;
				$this->_data->display_result =0;
				$this->_data->answersheet_explanation =0;
				$this->_data->lead_generate =0;
				$this->_data->lead_generate_mandatory =0;
				$this->_data->play_user_name =0;
				$this->_data->play_user_ids =null;
				$this->_data->enable_questiongroup =0;
				$this->_data->access_token =null;
				$this->_data->questionreview=0;
				$this->_data->questionreview_answer=0;
				$this->_data->questionreview_qlink=0;
				$this->_data->questionreview_option=0;
				$this->_data->questionreview_question=0;
				$this->_data->questionreview_box=0;
				$this->_data->textformat=null;
				
			$this->_data->next_quiz= 0;
				$this->_data->prev_quiz= 0;
				$this->_data->take_snapshot= 0;
				$this->_data->quiz_prepare_content= 0;
				$this->_data->question_prepare_content= 0;
				$this->_data->continuous_question= 0;
				$this->_data->later_play= 0;
				$this->_data->invite= 0;
				$this->_data->disable_print_copy_result= 0;
				$this->_data->share_button= 0;
				$this->_data->share_btn_choosed= 0;
				$this->_data->question_key= 0;
				$this->_data->quiz_certificate= null;
				$this->_data->save_certificate= 0;
				$this->_data->cet_name= null;
				$this->_data->show_qgroup_description=0;
				$this->_data->show_qgroup_title=0;
				$this->_data->hint=0;
				$this->_data->transcript=0;
				$this->_data->article_link_id=0;
		}
		return $this->_data;
	}
	
	
	function &getItems(){

			if (empty( $this->_data )){
			
				$query = $this->_buildQuery();
				$filter = $this->_buildContentFilter();
				$orderby = $this->_buildItemOrderBy();

				$query .= $filter;
				$query .= $orderby;				
				//$this->_data = $this->_getList( $query );
				$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			}
		return $this->_data;
	}
	
			 
	function getTotal(){
		
		if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$query .= $this->_buildContentFilter();
			$query  .= $this->_buildItemOrderBy();
			$this->_total = $this->_getListCount($query);    
		}
		return $this->_total;
	}
			
	function _buildItemOrderBy(){
	
		$mainframe = JFactory::getApplication();
		$context	= 'com_vquiz.quizmanager.list.';
		$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
		$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
		$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
		return $orderby;
	}

	function getPagination(){
	
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
		}
		return $this->_pagination;
	}
	
	function _buildContentFilter(){

		$requestcategoryid = JRequest::getVar('qcategoryid');
		$quiztype = JRequest::getInt('qtype',0);

		$mainframe =JFactory::getApplication();
 
		$context	= 'com_vquiz.quizmanager.list.';
		$qcategoryid	= $mainframe->getUserStateFromRequest( $context.'qcategoryid', 'qcategoryid',	'',	'string' );
		$selected_userquiz	= $mainframe->getUserStateFromRequest( $context.'selected_userquiz', 'selected_userquiz',	'',	'string' );
		$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
		$categorysearch	= $mainframe->getUserStateFromRequest( $context.'categorysearch', 'categorysearch',	'',	'integer' );
		$publish_item	= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );
		$search		= JString::strtolower( $search );
		
		$where = array();
		
		if($publish_item){  

			if ( $publish_item == 'p' ){
			$where[] = 'i.published= 1';
			
			}elseif($publish_item =='u'){
			$where[] = 'i.published = 0';
			}
	
		}
		
		if($qcategoryid and $requestcategoryid ){
		
			$where[] = 'i.catid LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $qcategoryid, true ).'%', false );
		
		}
		elseif($categorysearch){ 
			 $where[] = 'i.catid='.$this->_db->Quote( $this->_db->escape( $categorysearch, true ), false );
		}

		if($search){	
		
			if (is_numeric($search)){		 
				$where[] = 'LOWER( i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
			}else {
 
			 $where[] = 'i.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );

			}
		}
		
		$where[] = 'i.catid !=1';
		
		if($qcategoryid){
				  $where[] = 'i.catid LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $qcategoryid, true ).'%', false );
		
		}
		if($quiztype)
			$where[] = ' i.quiztype ='.$this->_db->quote($quiztype);
		
        if($selected_userquiz){			
			//$where[] = ' i.id not in('.$selected_userquiz.')'; //use if no need to display selected values in modal
		}
			$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';

		return $filter;
	}
		
		
	function reorder(){

			$mainframe =& JFactory::getApplication();
			/*--Check for request forgeries
			JRequest::checkToken() or jexit( 'Invalid Token' );--*/
			$cid 	= JRequest::getVar( 'cid', array(), 'post', 'array' );
			JArrayHelper::toInteger($cid);
			$task	= JRequest::getCmd('task', '');
			$inc	= ($task == 'orderup' ? -1 : 1);
			
			if (empty( $cid )) {
				return JError::raiseWarning( 500, 'No items selected' );
			}
			
			$row =& $this->getTable();
			$row->load( (int) $cid[0] );
			$row->move( $inc  );
			
			return JText::_('reordered successfully!');
		}
	
	function saveOrder(){
			/*--Check for request forgeries
			JRequest::checkToken() or jexit( 'Invalid Token' );--*/
			
			$cid 	= JRequest::getVar( 'cid', array(), 'post', 'array' );
			JArrayHelper::toInteger($cid);
			if (empty( $cid )) {
				return JError::raiseWarning( 500, 'No items selected' );
			}
			$total		= count( $cid );
			$row =& $this->getTable();
			$groupings = array();
			$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
			JArrayHelper::toInteger($order);
			// update ordering values
			for ($i = 0; $i < $total; $i++)
			{
				$row->load( (int) $cid[$i] );
				// track postions
				$groupings[] = $row->position;
				if ($row->ordering != $order[$i])
				{
					$row->ordering = $order[$i];
					if (!$row->store()) {
						return JError::raiseWarning( 500, $this->_db->getErrorMsg() );
					}
				}
			}
	
			// execute updateOrder for each parent group
			$groupings = array_unique( $groupings );
			foreach ($groupings as $group){
				$row->reorder();
			}
			return 'New ordering saved';
		}
			
			

	function store(){  
	
		$time = time();
		$session=JFactory::getSession();
		$user = JFactory::getUser();
	    $row =$this->getTable();
		$data = JRequest::get('post');
		$data['params']=$data['jform'];
		
		
		
		if($data['quiztype']!=11)
		{
			$data['answers_type']=0; 
		}
		if($data['quiztype']==22)
		{
			$data['personality_type']=2;
		}
		//print_r($data);exit;
		
		$data['description'] = JRequest::getVar('description', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$data['certificate'] = JRequest::getVar('certificate', '', 'post', 'string', JREQUEST_ALLOWRAW);
		$data['textformat'] = JRequest::getVar('textformat', '', 'post', 'string', JREQUEST_ALLOWRAW);
  		$data['quiz_categoryname'] =JRequest::getVar('quiz_categoryname','', 'post');
  		$data['ipaddress_allow'] =json_encode(JRequest::getVar('ipaddress_allow','', 'post'));
		
		$data['play_user_ids'] =implode(',',JRequest::getVar('play_user_ids','', 'post','array'));
		$data['play_user_name'] =implode(',',JRequest::getVar('play_user_name','', 'post','array'));
	
  		$data["alias"] = empty($data["alias"])?$data["title"]:$data["alias"];
		$data["alias"]= JFilterOutput::stringURLSafe($data['alias']);
		
		$data['share_btn_choosed'] =implode(',',JRequest::getVar('share_btn_choosed','', 'post','array'));

		$query = 'select count( * ) from #__vquiz_quizzes where id <> '.$this->_db->quote($data['id']).' and alias = '.$this->_db->quote($data['alias']);
		$this->_db->setQuery( $query );
		$count = $this->_db->loadResult();

		if ($count>0) {
			$this->setError(JText::_('SAME_ALIAS'));
			return false;
		}

		if($data["id"]==0){
		
			
			$data['created'] = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
			//$data['created_by'] = $user->id;
			$data['created_by'] = $data['created_by'];
			
			$query='select MAX(ordering) from #__vquiz_quizzes';
			$this->_db->setQuery($query);
			$highest_ordering=$this->_db->loadResult();

			$data['ordering'] = $highest_ordering+1;
 
			
		}
		else{
			
			$query = ' SELECT image from #__vquiz_quizzes WHERE id = '.$data["id"];
			$this->_db->setQuery( $query );
			$oldimage_path = $this->_db->loadResult();
		
		}
		
		if($data["id"]!=0)
		{
			 
 
			if(JRequest::getVar('task','')=='save2copy'){ //echo 111; exit;
			
				$origTable = clone $row;
				$origTable->load($data['id']);
				
				$data['created'] = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
				//$data['created_by'] = $user->id;
			    $data['created_by'] = $data['created_by'];
			
				$query='select MAX(ordering) from #__vquiz_quizzes';
				$this->_db->setQuery($query);
				$highest_ordering=$this->_db->loadResult();

				$data['ordering'] = $highest_ordering+1;
			
				if($data['title'] == $origTable->title){
					$data['id'] = 0;
				
					while ($row->load(array('alias' => $data['alias'], 'catid' => $data['catid'])))
					{
						$data['title'] = JString::increment($data['title']);
						$data['alias'] = JString::increment($data['alias'], 'dash');
					}
				}else{
					$data['id'] = 0;
				
					while ($row->load(array('alias' => $data['alias'], 'catid' => $data['catid'])))
					{ 
						$data['title'] = JString::increment($data['title']);
						$data['alias'] =  str_replace(' ', '-', strtolower($data['title']));
					} 
				}

			}
			else
			{
				if ($data['alias'] == $origTable->alias)
				{
					$data['alias'] = '';
				}
			}
		}

		/*---code for  pic upload. ---*/
		 
		$query='select categorythumbnailwidth,categorythumbnailheight from #__vquiz_configuration';
		$this->_db->setQuery($query);
		$configuration_img=$this->_db->loadObject();
		$configuration_width=$configuration_img->categorythumbnailwidth;
		$configuration_height=$configuration_img->categorythumbnailheight;
 
		$image = JRequest::getVar('image', null, 'FILES', 'array');
 		$allowed = array('.jpg', '.jpeg', '.gif', '.png');

		$dirpath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/';
		$thumbPath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/thumbs/'; 

		jimport('joomla.filesystem.file');
		$image_name = str_replace(' ', '', JFile::makeSafe($image['name']));
		$image_tmp = $image['tmp_name'];
		$time = time();
		
		if($image_name <> "" ){
			
			$ext = strrchr($image_name, '.');
			if(!in_array($ext, $allowed)){
				$msg_error=JText::_('THIS_IMAGE_TYPE_NOT_ALLOWED');
				$this->setError($msg_error);
				return false;
			}
	
			$size = getimagesize($image_tmp);
			$src_w = $size[0];
			$src_h = $size[1];
			
			if($src_w > $src_h ){
				if(!empty($configuration_width) and is_numeric($configuration_width)){
					$width = $configuration_width;   
				}else{
					$width = 125; //New width of image 
				}
				if(!empty($configuration_height) and is_numeric($configuration_height)){
					$height =$configuration_height;
				}else{   
					$height = $size[1]/$size[0]*$width; //This maintains proportions
				}
				$width1 = 300; //New width of image    
				$height1 = $size[1]/$size[0]*$width; //This maintains proportions

			}else{
				if(!empty($configuration_height) and is_numeric($configuration_height)){
					$height =$configuration_height;
				}else{
					$height = 125;
				}
				if(!empty($configuration_width) and is_numeric($configuration_width)){
					$width = $configuration_width;   
				}else{
					$width = $size[0]/$size[1]*$height; //This maintains proportions
				}
				$height1 = 360;
				$width1 = $size[0]/$size[1]*$height; //This maintains proportions
			}
			
			$width1 = 265; //New width of image    
			$height1 = $size[1]/$size[0]*$width; //This maintains proportions

			$new_image = imagecreatetruecolor($width, $height);
			$new_image1 = imagecreatetruecolor($width1, $height1);
			
			if($size['mime'] == "image/jpeg"){
				$tmp = imagecreatefromjpeg($image_tmp);
			}elseif($size['mime'] == "image/gif"){
				$tmp = imagecreatefromgif($image_tmp);
			}else{
				$tmp = imagecreatefrompng($image_tmp);
			}
			
			imagecopyresampled($new_image, $tmp,0,0,0,0, $width, $height, $src_w, $src_h);
			
			if($size['mime'] == "image/jpeg"){
				imagejpeg($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
				
			}elseif($size['mime'] == "image/gif"){
				imagegif($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
				
			}else{
				imagepng($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
			}

			imagecopyresampled($new_image1, $tmp,0,0,0,0, $width1, $height1, $src_w, $src_h);
			
			if($size['mime'] == "image/jpeg"){
				imagejpeg($new_image1, $dirpath.$time.'_'.$image_name);
			}elseif($size['mime'] == "image/gif"){
				imagegif($new_image1, $dirpath.$time.'_'.$image_name);
			}else{
				imagepng($new_image1, $dirpath.$time.'_'.$image_name);
			}
			
			if(move_uploaded_file($image_tmp, $dirpath.$time.'_'.$image_name)){
				$data['image'] = $time.'_'.$image_name;
			}
 

		}

			if($data['image'] and !empty($oldimage_path)){
		
			   unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/'.$oldimage_path);
			   unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/thumbs/'.'thumb_'.$oldimage_path);

			}
		

			if (!$row->bind($data)) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
			
			if (!$row->check()) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}

			if (!$row->store()) {
				$this->setError($row->getErrorMsg());
				return false; 
			}
			
			if(!$data['id']){
				
				JRequest::setVar('id', $row->id);
				// On Create Quiz Trigger Jomsocial Stream Plugin.
				$plugin = JPluginHelper::getPlugin('community', 'vquiz_stream');
				
				if($plugin){
					$user = JFactory::getUser();
					JPluginHelper::importPlugin('community','vquiz_stream');
					$dispatcher = JDispatcher::getInstance();
					try{
						$dispatcher->trigger('onCreateQuizStream',array($user,$row->id));
					}catch(Exception $e){
						jexit('{"result":"error", "error":"'.$e->getMessage().'"}');
					}
				}  

			}
			 
			if($session->has('personality_message_session')){
				$tm=$session->get('personality_message_session');
				JRequest::setVar('answer', $tm['answer']);
				JRequest::setVar('category_combination', $tm['category_combination']);
				JRequest::setVar('description', $tm['description']);
				JRequest::setVar('article_id', $tm['article_id']);
				JRequest::setVar('article_link_title', $tm['article_link_title']);
				JRequest::setVar('concate_desc', $tm['concate_desc']);
				JRequest::setVar('color', $tm['color']);
				JRequest::setVar('quizid',$row->id);
				$this->personality_messagestore();
				
			}elseif($session->has('trivia_message_session')){
			
				$tm=$session->get('trivia_message_session');
				JRequest::setVar('score', $tm['score']);
				JRequest::setVar('message', $tm['message']);
				JRequest::setVar('article_link_id', $tm['article_link_id']);
				JRequest::setVar('article_link_title', $tm['article_link_title']);
				JRequest::setVar('quizid',$row->id);
				$this->trivia_messagestore();
	 
			}
			
			//save notification on adding quiz
				
				if(!$data['id']){ 
					
					$data_arr = array();
					$data_arr['itemid'] = $row->id;
					$data_arr['notification_type'] = 6;
					$data_arr['replace_quiztitle'] = $row->title;
						
					if(QuizHelper::checkNotification($data_arr['notification_type'])){
						$data_arr['notify_users'] = QuizHelper::findUsersToNotify('notfify_add_quiz');
						$data_arr['enotify_users'] = QuizHelper::findUsersToEnotify('enotfify_add_quiz');
						//print_r($data_arr); exit;
						QuizHelper::sendNotification($data_arr);
					}
					
				}
			
			return true;
	}



	function trivia_messagestore(){	
 
		$session=JFactory::getSession();
		$data = JRequest::get( 'post' );
		$quizid=JRequest::getInt('quizid',0);
		$data['score']	= JRequest::getVar('score', array(), 'post', 'array');
		$data['message'] = JRequest::getVar('message', array(), 'post', 'array',JREQUEST_ALLOWRAW); 
		$data['article_link_id'] = JRequest::getVar('article_link_id', array(), 'post', 'array');	
		$data['article_link_title'] = JRequest::getVar('article_link_title', array(), 'post', 'array');	
		
		$data['rating']	= JRequest::getVar('rating', array(), 'post', 'array');
		 
		
					
		$query='select id from #__vquiz_trivia_message where quizid='.$quizid.' order by id asc';
		$this->_db->setQuery($query);
		$exid = $this->_db->loadColumn(); 
 
		for($i=0;$i<count($data['score']);$i++)
		{
		    if($quizid and !empty($data['score'])){
				
				if(count($exid)>0)	{
					$id = array_shift($exid);
					$query = 'update #__vquiz_trivia_message set message = '.$this->_db->quote($data['message'][$i]).', score = '.$this->_db->quote($data['score'][$i]).' ,article_link_id = '.$this->_db->quote($data['article_link_id'][$i]).',rating = '.$this->_db->quote($data['rating'][$i]).' where id = '.$this->_db->quote($id);
					
				}else{
					$query = 'insert into #__vquiz_trivia_message(quizid,message,score,article_link_id,rating) values('.$this->_db->quote($quizid).','.$this->_db->quote($data['message'][$i]).','.$this->_db->quote($data['score'][$i]).','.$this->_db->quote($data['article_link_id'][$i]).','.$this->_db->quote($data['rating'][$i]).')';
				}
				
				$this->_db->setQuery($query);
										
				if(!$this->_db->execute()){
				
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
				
				JRequest::setVar('id', $quizid);
				$session->clear('trivia_message_session');
				
			}else{
				 
				$session->set('trivia_message_session',$data);
			}
		}
		 
		if(count($exid)>0 and !empty($data['score'])){
			
			$query = 'delete from #__vquiz_trivia_message where id in ('.implode(', ', $exid).')';
			$this->_db->setQuery( $query );
			if(!$this->_db->execute()){
			
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		
		} 
	 
		return true;
 
	}

	function personality_messagestore(){	
		
			$session=JFactory::getSession();
			$data = JRequest::get('post');
			$quizid=JRequest::getInt('quizid',0);
			$data['answer']	= JRequest::getVar('answer', array(), 'post', 'array');
			$data['description'] = JRequest::getVar('description', array(), 'post', 'array',JREQUEST_ALLOWRAW);
			$data['article_id'] = JRequest::getVar('article_id', array(), 'post', 'array');	
			$data['category_combination'] = JRequest::getVar('category_combination', array(), 'post', 'array');	
			$data['article_link_title'] = JRequest::getVar('article_link_title', array(), 'post', 'array');	
			$data['concate_desc']= JRequest::getVar('concate_desc', array(), 'post', 'array');
			$data['color']= JRequest::getVar('color', array(), 'post', 'array');

	 
			$query='select id from #__vquiz_personality_message where quizid='.$quizid.' order by id asc';
			$this->_db->setQuery($query);
			$exid = $this->_db->loadColumn(); 
	 
	 
			for($i=0;$i<count($data['answer']);$i++)
			{ 
				if($quizid and !empty($data['answer'][$i])){ 
				
					if(count($exid)>0)	{
						$id = array_shift($exid);
						$query = 'update #__vquiz_personality_message set description = '.$this->_db->quote($data['description'][$i]).', answer = '.$this->_db->quote($data['answer'][$i]).',article_id = '.$this->_db->quote($data['article_id'][$i]).',color = '.$this->_db->quote($data['color'][$i]).',concate_desc = '.$this->_db->quote(json_encode($data['concate_desc'][$i])).',category_combination = '.$this->_db->quote($data['category_combination'][$i]).' where id = '.$this->_db->quote($id);
						
					}else{
					
					 $query = 'insert into      #__vquiz_personality_message(quizid,description,answer,article_id,color,concate_desc,category_combination) values('.$this->_db->quote($quizid).','.$this->_db->quote($data['description'][$i]).','.$this->_db->quote($data['answer'][$i]).','.$this->_db->quote($data['article_id'][$i]).','.$this->_db->quote($data['color'][$i]).','.$this->_db->quote(json_encode($data['concate_desc'][$i])).','.$this->_db->quote($data['category_combination'][$i]).')';
					 
				  }
					$this->_db->setQuery($query);
											
					if(!$this->_db->execute()){
						
						$this->setError($this->_db->getErrorMsg());
						return false;
					}
					
					JRequest::setVar('id', $quizid);
					$session->clear('personality_message_session');
				}
				else{
					 
					$session->set('personality_message_session',$data);
				}
			 }
			 
			if(count($exid)>0 and !empty($data['answer']))	{
				
				$query = 'delete from #__vquiz_personality_message where id in ('.implode(', ', $exid).')';
				$this->_db->setQuery( $query );
							
				if(!$this->_db->execute())	
				{
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
			
			} 

			return true;
		}
		
		
	function qgroup_messagescore(){	
		
			$session=JFactory::getSession();

 			$input=JFactory::getApplication()->input;
 			$data=$input->post;
			$data1 = JRequest::get('post');
			//print_r($data);exit;JRequest::getVar('questiongroup_description', '', 'post', 'array', JREQUEST_ALLOWRAW);
			$quizid=$input->get('quizid',0);
			$groupid=$input->get('qorder',0);
			$qgroup_score=$data->get('qgroup_score','',array());
			//$qgroup_message=$data->get('qgroup_message','',array());
			$qgroup_message=JRequest::getVar('qgroup_message', '', 'post', 'array', JREQUEST_ALLOWRAW);
			$qgroup_article_id=$data->get('qgroup_article_id','',array());
			$qgroup_rating=$data->get('qgroup_rating','',array());
					
			if($groupid){
	
					$query=$this->_db->getQuery(true);
					$query->select('id');
					$query->from('#__vquiz_quizzes_questiongroup_message');
					$query->where('groupid='.$this->_db->quote($groupid));
					$query->where('quizid='.$this->_db->quote($quizid));
					$this->_db->setQuery($query);
					$exid = $this->_db->loadColumn(); 
						
						for($i=0;$i<count($qgroup_message);$i++)
						{
							if(!empty($qgroup_message[$i])){
								
								if(count($exid)>0){
									$id = array_shift($exid);
									$query = 'update #__vquiz_quizzes_questiongroup_message set message = '.$this->_db->quote($qgroup_message[$i]).', score = '.$this->_db->quote($qgroup_score[$i]).' ,article_id = '.$this->_db->quote($qgroup_article_id[$i]).',rating = '.$this->_db->quote($qgroup_rating[$i]).' where id = '.$this->_db->quote($id);
									
								}else{
									$query = 'insert into #__vquiz_quizzes_questiongroup_message(quizid,groupid,message,score,article_id,rating) values('.$this->_db->quote($quizid).','.$this->_db->quote($groupid).','.$this->_db->quote($qgroup_message[$i]).','.$this->_db->quote($qgroup_score[$i]).','.$this->_db->quote($qgroup_article_id[$i]).','.$this->_db->quote($qgroup_rating[$i]).')';
								}
								$this->_db->setQuery($query);
														
								if(!$this->_db->execute()){
									$this->setError($this->_db->getErrorMsg());
									return false;
								}					
							}
						}
	 
					 
					if(count($exid)>0){
						
						$query = 'delete from #__vquiz_quizzes_questiongroup_message where id in ('.implode(', ', $exid).')';
						$this->_db->setQuery( $query );
						if(!$this->_db->execute()){
						
							$this->setError($this->_db->getErrorMsg());
							return false;
						}
					
					} 
			}else{
				
				if($session->has('qgroup_message_session'))	{
					$qgroup_messagescore = $session->get('qgroup_message_session');
				}else{
					$qgroup_messagescore = array('qorder'=>array(), 'qgroup_score'=>array(),'qgroup_message'=>array(),'qgroup_article_id'=>array(),'qgroup_rating'=>array());	
				}

				$index_ordr=array_search($qorder,$qgroup_messagescore['qorder']);
				
				if($index_ordr !==false){
					$qgroup_messagescore['qgroup_score'][$index_ordr]=$qgroup_score;
					$qgroup_messagescore['qgroup_message'][$index_ordr]=$qgroup_message;
					$qgroup_messagescore['qgroup_article_id'][$index_ordr]=$qgroup_article_id;
					$qgroup_messagescore['qgroup_rating'][$index_ordr]=$qgroup_rating;
					
				}else{
					array_push($qgroup_messagescore['qorder'],$qorder);
					array_push($qgroup_messagescore['qgroup_score'],$qgroup_score);
					array_push($qgroup_messagescore['qgroup_message'],$qgroup_message);
					array_push($qgroup_messagescore['qgroup_article_id'],$qgroup_article_id);
					array_push($qgroup_messagescore['qgroup_rating'],$qgroup_rating);
					
				}
				$session->set('qgroup_message_session',$qgroup_messagescore);	
				
			}
	
			return true;
		}
		

	function getTrivia_messages(){
			
		$quizid=JRequest::getInt('id',0);
		
		$query=$this->_db->getQuery(true);
		$query->select('i.*,a.title as article_title');
		$query->from($this->_db->quoteName('#__vquiz_trivia_message').' as i');
		$query->join('LEFT',$this->_db->quoteName('#__content').' as a on i.article_link_id=a.id');
		$query->where('i.quizid = ' .(int)$quizid);
		$this->_db->setQuery($query);
		$result = $this->_db->loadObjectList();
		return $result;
	}
	
	function getPersonality_messages(){	
	
		$quizid=JRequest::getInt('id',0);
		
		$query=$this->_db->getQuery(true);
		$query->select('i.*,a.title as article_title');
		$query->from($this->_db->quoteName('#__vquiz_personality_message').' as i');
		$query->join('LEFT',$this->_db->quoteName('#__content').' as a on i.article_id=a.id');
		$query->where('i.quizid = ' .(int)$quizid);
		$this->_db->setQuery($query);
		$result = $this->_db->loadObjectList();

		return $result;
		
	}
	
	function getQgroup_messages(){
			
		$quizid=JRequest::getInt('id',0);
		$qorder=JRequest::getInt('qorder',0);

		$query=$this->_db->getQuery(true);
		$query->select('i.*,a.title as article_title');
		$query->from($this->_db->quoteName('#__vquiz_quizzes_questiongroup_message').' as i');
		$query->join('LEFT',$this->_db->quoteName('#__content').' as a on i.article_id=a.id');
		$query->where('i.groupid = ' .(int)$qorder);
		$query->where('i.quizid = ' .(int)$quizid);
		$this->_db->setQuery($query);
		$result = $this->_db->loadObjectList();
		
		return $result;
	} 

	function publish(){

		$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$task		= JRequest::getCmd( 'task' );
		$publish	= ($task == 'publish')?1:0;
		$n = count( $cid );
		if (empty( $cid )) {
			return JText::_('No item selected');
		}

		$cids = implode( ',', $cid );
		$query = 'UPDATE #__vquiz_quizzes SET published = ' . (int) $publish . ' WHERE id IN ( ' . $cids . ' )';
		$this->_db->setQuery( $query );
	
		if (!$this->_db->query()){
			return $this->_db->getErrorMsg();
		}
		else{
			return ucwords($task).'ed successfully.';
		}
	
	}
	
	function featured(){
		 
			$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
			$task		= JRequest::getCmd( 'task' );
			$featured	= ($task == 'featured')?1:0;
			$n = count( $cid );
			
			if (empty( $cid )) {
				return JText::_('No item selected');
			}
			
			$cids = implode( ',', $cid );
			$query = 'UPDATE #__vquiz_quizzes SET featured = ' . (int) $featured . ' WHERE id IN ( ' . $cids . ' )';
			$this->_db->setQuery( $query );
			
			if (!$this->_db->query()){
				return $this->_db->getErrorMsg();
			}else{
				return ucwords($task).'ed successfully.';
			}
		
		}

				
	function getCategory(){
					
		/* $query ='select a.id , a.quiztitle , a.level ';
		$query .=' from #__vquiz_category As a ';
		$query .=' LEFT join #__vquiz_category AS b ON a.lft > b.lft AND a.rgt < b.rgt';
		
		$where = array();								
		$where[] = 'a.id !=1';
		$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
		$query .= $filter;
		$query .=' group by a.id, a.quiztitle, a.level, a.lft, a.rgt, a.parent_id order by a.lft ASC';
		
		$this->_db->setQuery($query);
		$result=$this->_db->loadObjectList(); */
		
		$query = $this->_db->getQuery(true);
		$query->select('a.id , a.title , a.level');
		$query->from($this->_db->quoteName('#__vquiz_category').' as a');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_category').' AS b ON a.lft > b.lft AND a.rgt < b.rgt');
		$query->where('a.id !=1');
		$query->group('a.id, a.title, a.level, a.lft, a.rgt, a.parent_id');
		$query->order('a.lft ASC');
		$this->_db->setQuery($query);
		$result=$this->_db->loadObjectList();
		
		
		return $result;
		
	}


	function delete(){

		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$row =& $this->getTable();

		if (count( $cids )) {
		
			foreach($cids as $cid) {
						
						$query = ' SELECT image from #__vquiz_quizzes WHERE id = '.$cid;
						$this->_db->setQuery($query);
						$oldimage_path = $this->_db->loadResult();
			 
						if(!empty($oldimage_path)){
							unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/'.$oldimage_path);
							unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/quizzes/thumbs/'.'thumb_'.$oldimage_path);
						}

				if (!$row->delete( $cid )) {

					$this->setError( $row->getErrorMsg() );

					return false;

				}
				
				if($row->delete( $cid )){				
												
					//$query = ' SELECT id FROM #__vquiz_question WHERE quizzesid = '.$cid;

					$query = $this->_db->getQuery(true);
					$query->select('i.id');
					$query->from($this->_db->quoteName('#__vquiz_question').' as i');
					$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').'as q on q.questionid=i.id');
					$query->where('q.quizid ='.$this->_db->quote($cid));

					$this->_db->setQuery( $query );
					$question_id = $this->_db->loadColumn();
					
					if(!empty($question_id)){
					$query = $this->_db->getQuery(true);
					$query->delete($this->_db->quoteName('#__vquiz_question'));
					$query->where('id IN ('.implode(',',$question_id).')');
					$this->_db->setQuery( $query);
					$this->_db->execute();
					}

					if ($this->_db->execute() and !empty($question_id)) {
						
						$q ='delete FROM #__vquiz_option WHERE qid IN ('.implode(',',$question_id).')';
						$this->_db->setQuery( $q );
						$this->_db->execute();
						
						$q ='delete FROM #__vquiz_quiznques WHERE questionid IN ('.implode(',',$question_id).')';
						$this->_db->setQuery( $q );
						$this->_db->execute();
					
					}
						
					$q ='delete FROM #__vquiz_trivia_message WHERE quizid = '.$cid;
					$this->_db->setQuery( $q );
					$this->_db->execute();
					
					$q ='delete FROM #__vquiz_personality_message WHERE quizid = '.$cid;
					$this->_db->setQuery( $q );
					$this->_db->execute();
					
					$q ='delete FROM #__vquiz_quiz_personality_category WHERE quizid = '.$cid;
					$this->_db->setQuery( $q );
					$this->_db->execute();
					
					//$q ='delete FROM #__vquiz_quizdraft WHERE quizid = '.$cid; 
					
					$q ='delete FROM #__vquiz_quizzes_branching WHERE quizid = '.$cid;
					$this->_db->setQuery( $q );
					$this->_db->execute();
					
					$q ='delete FROM #__vquiz_quizzes_questiongroup WHERE quizid = '.$cid;
					$this->_db->setQuery( $q );
					$this->_db->execute();
					
					$q ='delete FROM #__vquiz_quizzes_questiongroup_message WHERE quizid = '.$cid;
					$this->_db->setQuery( $q );
					$this->_db->execute();
					
					$q ='delete FROM #__vquiz_quiz_score_category WHERE quizid = '.$cid;
					$this->_db->setQuery( $q );
					$this->_db->execute();
					
					
				}

			}
			
		}
		return true;
	}
	
	function getAccess(){
	
		$query='select * from #__usergroups order by id asc';
		$this->_db->setQuery($query);
		$result = $this->_db->loadObjectList();
		return $result;
		
	}
						
				
	function movequestion(){
				
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$categoryid = JRequest::getInt('quizcategoryidmove');
		
		if (count( $cids )) {
		
		foreach($cids as $cid) {
			
				$query = 'UPDATE #__vquiz_quizzes SET catid = '.$categoryid.' WHERE id = '.$cid;
				$this->_db->setQuery( $query );

				if (!$this->_db->query()){
					$msg = $this->setError($this->_db->stderr());
					$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
					return false;
				}
			
			}
		}
			return true;
		 
	}
				
				
	function copyquestion(){

		$session=JFactory::getSession();
		$user = JFactory::getUser();
		
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$categoryid = JRequest::getInt('quizcategoryidcopy',0);
		$row =$this->getTable();
		$origTable = clone $row;

		if (count( $cids )) {
		
			foreach($cids as $cid) {
			
			$query='select MAX(ordering) from #__vquiz_quizzes';
			$this->_db->setQuery($query);
			$highest_ordering=$this->_db->loadResult();
			
			$query = ' SELECT * FROM #__vquiz_quizzes WHERE id = '.$cid;
			$this->_db->setQuery( $query );
			$result= $this->_db->loadObject();
			
			$origTable->load($cid);

			if($result->title == $origTable->title){

				while ($row->load(array('alias' => $result->alias, 'catid' => $categoryid)))
				{
					$result->title = JString::increment($result->title);
					$result->alias = JString::increment($result->alias, 'dash');
				}
			 }
 		
			$insert = new stdClass();
			$insert->id = null;
			$insert->catid =$categoryid;
			$insert->startpublish_date = $result->startpublish_date;
			$insert->endpublish_date = $result->endpublish_date;
			$insert->title = $result->title;
			$insert->alias = $result->alias;
			$insert->image = $result->image;
			$insert->set_price = $result->set_price;
			$insert->price = $result->price;
			$insert->passed_score = $result->passed_score;
			$insert->total_timelimit = $result->total_timelimit;
			$insert->totaltime_parameter = $result->totaltime_parameter;
			$insert->random_question = $result->random_question;
			$insert->prev_button = $result->prev_button;
			$insert->skip_button = $result->skip_button;
			$insert->flag = $result->flag;
			
			$insert->livescore =$result->livescore;
			$insert->show_correctans = $result->show_correctans;
			$insert->explanation = $result->explanation;
			$insert->penalty = $result->penalty;
			$insert->userscore = $result->userscore;
			$insert->graph_type = $result->graph_type;
			$insert->paging = $result->paging;
			$insert->paging_limit = $result->paging_limit;
			$insert->accessuser = $result->accessuser;
			$insert->delay_periods = $result->delay_periods;
			$insert->description = $result->description;
			$insert->created = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
			$insert->created_by = $result->created_by;
			
			$insert->featured = $result->featured;
			$insert->ordering = $highest_ordering+1;
			$insert->language = $result->language;
			$insert->access = $result->access;
			$insert->question_limit = $result->question_limit;
			$insert->meta_keyword = $result->meta_keyword;
			$insert->meta_desc = $result->meta_desc;
			$insert->quiztype = $result->quiztype;
			$insert->slider_bar = $result->slider_bar;
			$insert->question_number = $result->question_number;
			$insert->correctans = $result->correctans;
			$insert->question_options_display = $result->question_options_display;
			$insert->attempt_count = $result->attempt_count;
			$insert->count_ipaddress = $result->count_ipaddress;
			$insert->attempt_delay = $result->attempt_delay;
			
			$insert->show_graph = $result->show_graph;
			$insert->answers_type = $result->answers_type;
			$insert->personality_type = $result->personality_type;
			$insert->multi_p_percentage = $result->multi_p_percentage;
			$insert->multi_p_score = $result->multi_p_score;
			$insert->completion_level = $result->completion_level;
			$insert->display_result = $result->display_result;			
			$insert->ipaddress_allow = $result->ipaddress_allow;			
			$insert->random_option = $result->random_option;
			$insert->answer_sheet_option = $result->answer_sheet_option;
			$insert->prev_answer = $result->prev_answer;
			$insert->answer_sheet = $result->answer_sheet;
			$insert->certificate = $result->certificate;
			$insert->textformat = $result->textformat;			
			$insert->start_with = $result->start_with;
			$insert->end_with = $result->end_with;
			
			$insert->cet_digits = $result->cet_digits;
			$insert->cet_format = $result->cet_format;
			$insert->cet_type = $result->cet_type;
			$insert->input_name = $result->input_name;
			$insert->input_email = $result->input_email;
			$insert->input_mobile = $result->input_mobile;
			$insert->answersheet_explanation = $result->answersheet_explanation;
			$insert->lead_generate = $result->lead_generate;
			$insert->lead_generate_mandatory = $result->lead_generate_mandatory;
			$insert->play_users = $result->play_users;			
			$insert->play_user_name = $result->play_user_name;
			$insert->enable_questiongroup = $result->enable_questiongroup;
			$insert->access_token = $result->access_token;
			$insert->questionreview = $result->questionreview;
			
			$insert->questionreview_answer = $result->questionreview_answer;
			$insert->questionreview_option = $result->questionreview_option;
			$insert->questionreview_question = $result->questionreview_question;
			$insert->questionreview_qlink = $result->questionreview_qlink;
			$insert->questionreview_box = $result->questionreview_box;
			$insert->lead_generate_mendatory = $result->lead_generate_mendatory;
			$insert->lead_generate_shows = $result->lead_generate_shows;
			$insert->play_user_ids = $result->play_user_ids;

			$insert->next_quiz = $result->next_quiz;			
			$insert->prev_quiz = $result->prev_quiz;
			$insert->take_snapshot = $result->take_snapshot;
			$insert->quiz_prepare_content = $result->quiz_prepare_content;
			$insert->question_prepare_content = $result->question_prepare_content;
			$insert->continuous_question = $result->continuous_question;
			$insert->later_play = $result->later_play;
			$insert->invite = $result->invite;
			$insert->disable_print_copy_result = $result->disable_print_copy_result;
			$insert->share_button = $result->share_button;
			$insert->share_btn_choosed = $result->share_btn_choosed;
			$insert->question_key = $result->question_key;
			$insert->quiz_certificate = $result->quiz_certificate;
			
			
			 
			if(!$this->_db->insertObject('#__vquiz_quizzes', $insert, 'id')){
				$msg = $this->setError($this->_db->stderr());
				$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
				return false;
			}
			
			$queszid = $this->_db->insertid();

			//$query = ' SELECT * FROM #__vquiz_question WHERE quizzesid = '.$cid;
			
			
			
			$query = $this->_db->getQuery(true);
			$query->select('i.*');
			$query->from($this->_db->quoteName('#__vquiz_question').' as i ');
			$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as q on q.questionid = i.id');
			$query->where('q.quizid ='.$this->_db->quote($cid));
			
			$this->_db->setQuery( $query );
			$question=$this->_db->loadObjectList();


				for($i=0;$i<count($question);$i++)	{ 
				
				$query='select MAX(ordering) from #__vquiz_question';
				$this->_db->setQuery($query);
				$highest_ordering=$this->_db->loadResult();
					
					$insertquestion = new stdClass();
					$insertquestion->id = null;
					$insertquestion->ordering = $highest_ordering+1;
					//$insertquestion->quizid =$queszid;
					$insertquestion->questiontime_parameter = $question[$i]->questiontime_parameter;
					$insertquestion->question_timelimit = $question[$i]->question_timelimit;
					$insertquestion->optiontype = $question[$i]->optiontype;
					$insertquestion->user_comment = $question[$i]->user_comment;
					$insertquestion->flagcount = $question[$i]->flagcount;
					$insertquestion->qtitle = $question[$i]->qtitle;
					$insertquestion->explanation = $question[$i]->explanation;
					$insertquestion->scoretype = $question[$i]->scoretype;
					$insertquestion->score = $question[$i]->score;
					$insertquestion->expire_timescore = $question[$i]->expire_timescore;
					$insertquestion->penalty = $question[$i]->penalty;
					$insertquestion->created = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
					//$insertquestion->modified_date = $question[$i]->modified_date;
					$insertquestion->published = $question[$i]->published;
					$insertquestion->featured = $question[$i]->featured;
					
					$insertquestion->created_by = $result->created_by;
					
					$insertquestion->text_field_ans = $question[$i]->text_field_ans;
					$insertquestion->case_sensitive = $question[$i]->case_sensitive;
					$insertquestion->random_option = $question[$i]->random_option;
					$insertquestion->questiongroup = $question[$i]->questiongroup;					
					$insertquestion->other_option = $question[$i]->other_option;
					
					
											
					if(!$this->_db->insertObject('#__vquiz_question', $insertquestion, 'id'))	{
					
						$msg = $this->setError($this->_db->stderr());
						$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
						return false;
					}
			 
					$qid = $this->_db->insertid();
					
					$query='insert into #__vquiz_quiznques(questionid,quizid) values('.$this->_db->quote($qid).', '.$this->_db->quote($queszid).')';
					$this->_db->setQuery($query);
					
					if(!$this->_db->execute())	{
							
						$msg = $this->setError($this->_db->stderr());
						$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
						
						return false;
					}
					
					
					$query = ' SELECT * FROM #__vquiz_option WHERE qid = '.$question[$i]->id;
					$this->_db->setQuery( $query );
					$option = $this->_db->loadObjectList();
					

					 for($j=0;$j<count($option);$j++)	{
						 
							$insertoption = new stdClass();
							$insertoption->id = null;
							$insertoption->qid =$qid;
							$insertoption->image =$option[$j]->image;
							$insertoption->qoption =$option[$j]->qoption;
							$insertoption->correct_ans = $option[$j]->correct_ans;
							$insertoption->options_score =$option[$j]->options_score;
							$insertoption->personality_optionid =$option[$j]->personality_optionid;
							
							$insertoption->multi_p_options_score =$option[$j]->multi_p_options_score;
							$insertoption->category_score =$option[$j]->category_score;
							$insertoption->ordering =$option[$j]->ordering;
							
							
							if(!$this->_db->insertObject('#__vquiz_option', $insertoption, 'id'))	{
							
								$msg = $this->setError($this->_db->stderr());
								$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
								
								return false;
							}
							
							
						}
					
			
				}
				
				$query = ' SELECT * FROM #__vquiz_personality_message WHERE quizid = '.$cid;
				$this->_db->setQuery( $query );
				$personality_messages=$this->_db->loadObjectList();
				
				for($i=0;$i<count($personality_messages);$i++)	{
					
					$insertpersonality = new stdClass();
					$insertpersonality->id = null;
					$insertpersonality->quizid =$queszid;
					$insertpersonality->answer = $personality_messages[$i]->answer;
					$insertpersonality->description = $personality_messages[$i]->description;
											
					if(!$this->_db->insertObject('#__vquiz_personality_message', $insertpersonality, 'id'))	{
					
					$msg = $this->setError($this->_db->stderr());
					$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
					return false;
					}
				}
				
				
				$query = ' SELECT * FROM #__vquiz_trivia_message WHERE quizid = '.$cid;
				$this->_db->setQuery( $query );
				$trivia_messages=$this->_db->loadObjectList();
				
				for($i=0;$i<count($trivia_messages);$i++)	{
					
					$inserttrivia = new stdClass();
					$inserttrivia->id = null;
					$inserttrivia->quizid =$queszid;
					$inserttrivia->message = $trivia_messages[$i]->message;
					$inserttrivia->score = $trivia_messages[$i]->score;
					$inserttrivia->rating = $trivia_messages[$i]->rating;
					
											
					if(!$this->_db->insertObject('#__vquiz_trivia_message', $inserttrivia, 'id'))	{
					
					$msg = $this->setError($this->_db->stderr());
					$this->setRedirect( 'index.php?option=com_vquiz&view=quizmanager', $msg );
					return false;
					}
				
					
			}			

		}
	}	
		return true;
	 
	}
	
	
		function drawChart(){
	
 				$quizid = JRequest::getInt('quizid',0);
				$charttype = JRequest::getInt('charttype',0);
				$date = JFactory::getDate();						
				$obj = new stdClass();
				$obj->result = "error";
				$obj->charttype=$charttype;
				
				
				/*---Most Choosed user---*/
				if($charttype==1){
					
					//$query = 'SELECT score,count(userid) as totaluser from #__vquiz_quizresult WHERE quizzesid ='.$this->_db->quote($quizzesid).' group by score order by score asc';
					
					$query = $this->_db->getQuery(true);
					$query->select('score , count(userid) as totaluser');
					$query->from($this->_db->quoteName('#__vquiz_quizresult'));
					$query->where('quizid ='.$this->_db->quote($quizid));
					$query->group('score');
					$query->order('score asc ');
					$this->_db->setQuery( $query );	
					$result_score=$this->_db->loadRowList(); 
					$obj->responce1=$result_score;
						
				}else{
					
					$countoption_p=array();
					$p_result_array=array();
					
					//$q =' SELECT personality_result_id from #__vquiz_quizresult WHERE quizzesid ='.$quizzesid.' AND  personality_result_id IS NOT NULL ';
					
									
					$query = $this->_db->getQuery(true);
					$query->select('q.personality_result_id');
					$query->from($this->_db->quoteName('#__vquiz_quiznques').'as q');
					$query->join('LEFT',$this->_db->quoteName('#__vquiz_question').'as i on q.questionid=i.id');
					$query->where('q.quizid ='.$this->_db->quote($quizid));
					$query->where('q.personality_result_id IS NOT NULL');

					$this->_db->setQuery($query);	
					$result_pr=$this->_db->loadColumn(); 
					
					for($i=0;$i<count($result_pr);$i++)	
					{
						$xx=json_decode($result_pr[$i]);

						for($j=0;$j<count($xx);$j++){

							$given_answer=explode(',',$xx[$j]);
							for($k=0;$k<count($given_answer);$k++){
								if($given_answer[$k]!='')
								array_push($countoption_p,$given_answer[$k]);
							}  
						}
					} 

					$chosen_personality_count=array_count_values($countoption_p);
					$personality_keyvalue=array_keys($chosen_personality_count);
					$chosen_pcount=array_values($chosen_personality_count);

					for($i=0;$i<count($personality_keyvalue);$i++){
					
						$p_result=array();
						
						$query = 'select answer from #__vquiz_personality_message where id = '.$this->_db->quote($personality_keyvalue[$i]);
						$this->_db->setQuery( $query );
						$rs=$this->_db->loadResult();
						array_push($p_result,$rs);
						array_push($p_result,$chosen_pcount[$i]);
						array_push($p_result_array,$p_result); 
						
					}
					$obj->responce1=$p_result_array;
					
				}
				
				
				
				/*---Most Choosed Option---*/
				
				//$q = 'SELECT quiz_answers from #__vquiz_quizresult WHERE quizzesid ='.$this->_db->quote($quizzesid);
				
				$query = $this->_db->getQuery(true);
				$query->select('a.answer');
				$query->from($this->_db->quoteName('#__vquiz_quizresult_qna').'as a');
				$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizresult').'as r on r.id=a.resultid');
				$query->where('quizid ='.$this->_db->quote($quizid));
				$this->_db->setQuery( $query );	
				$result_quiz_answer=$this->_db->loadRowList(); 
 
			    $options=array();
				$countoption=array();
				$array=array();
				$maxoption=0;
				
				for($i=0;$i<count($result_quiz_answer);$i++)	
				{
					$xx=json_decode($result_quiz_answer[$i][0]);
					
					for($j=0;$j<count($xx);$j++){
					
						$given_answer=explode(',',$xx[$j]);
						
						for($k=0;$k<count($given_answer);$k++){
							if($given_answer[$k]!=0)
							array_push($countoption,$given_answer[$k]);
						} 
					}
					
				} 

				$choosedoption=array_count_values($countoption);
				$keyvalue=array_keys($choosedoption);


				//$query = 'select id from #__vquiz_question where  quizzesid = '.$this->_db->quote($quizzesid); 
				
				$query = $this->_db->getQuery(true);
				$query->select('i.id');
				$query->from($this->_db->quoteName('#__vquiz_question').'as i');
				$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').'as q on q.questionid=i.id');
				$query->where('q.quizid ='.$this->_db->quote($quizid));
				
				$this->_db->setQuery( $query );
				$loadcolumn = $this->_db->loadColumn();
				
				//$query = 'select count(qid) from #__vquiz_option where qid in ('.implode(',', $loadcolumn).') group by qid' ;
				
				$query = $this->_db->getQuery(true);
				$query->select('count(qid)');
				$query->from($this->_db->quoteName('#__vquiz_option'));
				$query->where('qid in ('.implode(',', $loadcolumn).')');
				$query->group('qid');
				try{
					$this->_db->setQuery( $query );
					$maxid = $this->_db->loadColumn();	
				}catch (Exception $e){
					$maxid =array();	
				}
				
				for($ck=0;$ck<count($maxid);$ck++){
					$xx=$maxid[$ck];
					$maxoption=$xx>$maxoption?$xx:$maxoption;
				}
    
				//$query = 'select id,qtitle from #__vquiz_question where  quizzesid = '.$this->_db->quote($quizzesid).' order by id asc'; 
				
				$query = $this->_db->getQuery(true);
				$query->select('i.id,i.qtitle');
				$query->from($this->_db->quoteName('#__vquiz_question').'as i');
				$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').'as q on q.questionid=i.id');
				$query->where('q.quizid ='.$this->_db->quote($quizid));
				$query->order('id asc');
				
				$this->_db->setQuery( $query );
				$questions = $this->_db->loadObjectList();
 
				$arr = array();
				$qu=array('Question');
				$xx=array();
				for($h=0;$h<$maxoption;$h++){
					array_push($xx,chr(65+$h));	
				}
						
				$merg=array_merge($qu,$xx);
				array_push($arr,$merg);
			
							
			   for($k=0;$k<count($questions);$k++){
					
				$query = 'select id from #__vquiz_option where qid = '.$this->_db->quote($questions[$k]->id).' order by id asc';
				$this->_db->setQuery( $query );
				$options= $this->_db->loadColumn();
				 					
				$oo=array();
					
					for($q=0;$q<$maxoption;$q++){
		
						if (@in_array($options[$q],$keyvalue)) {
							foreach ($choosedoption as $key => $value){
							if($key==$options[$q])	
							array_push($oo,$value);
							}
						}
						else{
							array_push($oo,0);
						}
					}
					
				$ques=array(strip_tags($questions[$k]->title));
				$x[$k]=array_merge($ques,$oo);
				array_push($arr,$x[$k]);
								
				}
 
				$obj->responce2=$arr;	
				$obj->result = "success";

			return $obj;
		} 
		
		
			
			
		function getConfiguration(){
		
			$query='select * from #__vquiz_configuration';
			$this->_db->setQuery($query);
			$result = $this->_db->loadObject();
			return $result;
		}	
		
		 function getScore_category(){
			$query='select * from #__vquiz_quiz_score_category where quizid='.$this->_id;
			$this->_db->setQuery($query);
			$result = $this->_db->loadObjectList();
			return $result;
		}	
		
		function getpersonality_category(){
			$query='select * from #__vquiz_quiz_personality_category where quizid='.$this->_id;
			$this->_db->setQuery($query);
			$result = $this->_db->loadObject();
			return $result;
		}	
		
		function getp_c_personality_view(){
			$quizid=JRequest::getInt('id',0);
			$query='select * from #__vquiz_quiz_personality_category where quizid='.$quizid;
			$this->_db->setQuery($query);
			$result = $this->_db->loadObject();
			return $result;
		}	
		
		
		function getMenuItems(){
			
			
			$query = $this->_db->getQuery(true);
			$user = JFactory::getUser();
			$app = JFactory::getApplication();
		
			$query->select('id,menutype,title');
			$query->from($this->_db->quoteName('#__menu'));
			$query->where('id > 1');
			$query->where('client_id = 0');
			$query->where('(published IN (1))');
			
			/* $parentId = $this->getState('filter.parent_id');

			if (!empty($parentId))
			{
				$query->where('p.id = ' . (int) $parentId);
			}

			// Filter the items over the menu id if set.
			$menuType = $this->getState('filter.menutype');

			if (!empty($menuType))
			{
				$query->where('a.menutype = ' . $this->_db->quote($menuType));
			}

			// Filter on the access level.
			if ($access = $this->getState('filter.access'))
			{
				$query->where('a.access = ' . (int) $access);
			}

			// Implement View Level Access
			if (!$user->authorise('core.admin'))
			{
				$groups = implode(',', $user->getAuthorisedViewLevels());
				$query->where('a.access IN (' . $groups . ')');
			}

			// Filter on the level.
			if ($level = $this->getState('filter.level'))
			{
				$query->where('a.level <= ' . (int) $level);
			}

			// Filter on the language.
			if ($language = $this->getState('filter.language'))
			{
				$query->where('a.language = ' . $this->_db->quote($language));
			} */
		
			$this->_db->setQuery($query);
			$result = $this->_db->loadObjectList();			
			return $result;
		}	
		
		
 		function getCsv()
		{
			
			$cids     = JRequest::getVar( 'cid', array(0), 'post', 'array' );

			$all_data=array();
			$x=0;
	
			//$columnhead_quiz =array('Quiz-ID','Quiz Title','Category id','Quiz image','Quiz Type','Personality type','Answer type','Status','Featured','Randon Question','Random answer','Passed score','Quiz Time','Question Time','Description','Live Score','Progress Bar','Completion level','Next Quiz','Previous Quiz','Skipp Button','Previous Button','Previous answer','Explation Show','Answer Sheet','Quiz Result','Score Graph','Flag','Paging');
			
			$columnhead_quiz = array(JText::_('COM_VQUIZ_EXPORT_QUIZ_ID'),JText::_('COM_VQUIZ_EXPORT_QUIZ_TITLE'),JText::_('COM_VQUIZ_EXPORT_QUIZ_CATEGORY_ID'),JText::_('COM_VQUIZ_EXPORT_QUIZ_IMAGE'),JText::_('COM_VQUIZ_EXPORT_QUIZ_TYPE'),JText::_('COM_VQUIZ_EXPORT_PERSONALITY_TYPE'),JText::_('COM_VQUIZ_EXPORT_ANSWER_TYPE'),JText::_('COM_VQUIZ_EXPORT_STATUS'),JText::_('COM_VQUIZ_EXPORT_FEATURED'),JText::_('COM_VQUIZ_EXPORT_RANDOM_QUESTION'),JText::_('COM_VQUIZ_EXPORT_RANDOM_ANSWER'),JText::_('COM_VQUIZ_EXPORT_PASSED_SCORE'),JText::_('COM_VQUIZ_EXPORT_QUIZ_TIME'),JText::_('COM_VQUIZ_EXPORT_QUESTION_TIME'),JText::_('COM_VQUIZ_EXPORT_DESCRIPTION'),JText::_('COM_VQUIZ_EXPORT_LIVE_SCORE'),JText::_('COM_VQUIZ_EXPORT_PROGRESS_BAR'),JText::_('COM_VQUIZ_EXPORT_COMPLETION_LEVEL'),JText::_('COM_VQUIZ_EXPORT_NEXT_QUIZ'),JText::_('COM_VQUIZ_EXPORT_PREVIOUS_QUIZ'),JText::_('COM_VQUIZ_EXPORT_SKIP_BUTTON'),JText::_('COM_VQUIZ_EXPORT_PREVIOUS_BUTTON'),JText::_('COM_VQUIZ_EXPORT_PREVIOUS_ANSWER'),JText::_('COM_VQUIZ_EXPORT_EXPLANATION_SHOW'),JText::_('COM_VQUIZ_EXPORT_ANSWER_SHEET'),JText::_('COM_VQUIZ_EXPORT_QUIZ_RESULT'),JText::_('COM_VQUIZ_EXPORT_SCORE_GRAPH'),JText::_('COM_VQUIZ_EXPORT_FLAG'),JText::_('COM_VQUIZ_EXPORT_PAGING'));
			
			//$columnhead_question =array('Question-ID','Question Title','Question Explanation','Quiz Type','Answer type','Score','Penalty','published','Question Time','Time Parameter','Comment Box','Flag Count','case_sensitive','Creted By');
			
			$columnhead_question = array(JText::_('COM_VQUIZ_EXPORT_QUESTION_ID'),JText::_('COM_VQUIZ_EXPORT_QUESTION_TITLE'),JText::_('COM_VQUIZ_EXPORT_QUESTION_EXPLANATION'),JText::_('COM_VQUIZ_EXPORT_QUIZ_TYPE'),JText::_('COM_VQUIZ_EXPORT_ANSWEWR_TYPE'),JText::_('COM_VQUIZ_EXPORT_SCORE'),JText::_('COM_VQUIZ_EXPORT_PENALTY'),JText::_('COM_VQUIZ_EXPORT_PUBLISHED'),JText::_('COM_VQUIZ_EXPORT_QUESTION_TIME'),JText::_('COM_VQUIZ_EXPORT_TIME_PARAMETER'),JText::_('COM_VQUIZ_EXPORT_COMMENT_BOX'),JText::_('COM_VQUIZ_EXPORT_FLAG_COUNT'),JText::_('COM_VQUIZ_EXPORT_CASE_SENSITIVE'),JText::_('COM_VQUIZ_EXPORT_CREATED_BY'));
			
			
			
			$columnhead=array_merge($columnhead_quiz,$columnhead_question);
				
			$query = 'select id,title,	catid,image,quiztype,personality_type,answers_type,published,featured,random_question,random_option,passed_score,total_timelimit,question_limit,description,livescore,slider_bar,completion_level,skip_button,prev_button,prev_answer,explanation,answer_sheet,display_result,show_graph,flag,paging from #__vquiz_quizzes WHERE id IN ('.implode(',',$cids).')';
			$this->_db->setQuery( $query );
			$quiz_data  = $this->_db->loadRowList();
			
			$max_option=0;
			 
			for($l=0;$l<count($quiz_data);$l++){
							
				//$query = 'select id,qtitle,explanation,quiztype,optiontype,score,penalty,published,question_timelimit,questiontime_parameter,user_comment,flagcount,case_sensitive,created_by from #__vquiz_question WHERE quizzesid='.$this->_db->quote($quiz_data[$l][0]);
				
				$query = $this->_db->getQuery(true);
				$query->select('i.id,z.title,i.explanation,z.quiztype,i.optiontype,i.score,i.penalty,i.published,i.question_timelimit,i.questiontime_parameter,i.user_comment,i.flagcount,i.case_sensitive,i.created_by');
				$query->from($this->_db->quoteName('#__vquiz_question').'as i');
				$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').'as q on q.questionid=i.id');
				$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes').'as z on q.quizid=i.id');
				$query->where('q.quizid ='.$this->_db->quote($quiz_data[$l][0]));
				
				$this->_db->setQuery( $query );
				$data = $this->_db->loadRowList();
	 
				$count=count($data);
				$max=0;
				
				for($i=0;$i<$count;$i++){

						$q = 'select correct_ans,options_score,personality_optionid,multi_p_options_score,category_score,qoption from #__vquiz_option where qid='.$this->_db->quote($data[$i][0]).' order by id asc';
						$this->_db->setQuery($q);
						$qoption = $this->_db->loadRowList();
						
						unset($correct_array);
						unset($json_array);
						$correct_array=array();
						$json_array=array();
						$json_array_multi_p=array();
						
						$correct=0;
						$max = count($qoption)>$max?count($qoption):$max;
						
						for($j=0;$j<count($qoption);$j++)	{
							if($qoption[$j][0]==1){
								$correct=$j;
								array_push($correct_array,$correct);
							}
						}
						array_push($data[$i],implode(',', $correct_array));
					
						if($quiz_data[$l][3]==2){
						
							for($j=0;$j<count($qoption);$j++){
								array_push($json_array,$qoption[$j][2]);
							}
							
							if($quiz_data[$l][4]==1){
								for($j=0;$j<count($qoption);$j++)	{
									array_push($json_array_multi_p,$qoption[$j][3]);
								}	
							}
						
							array_push($data[$i],implode(',', $json_array));
						
						}elseif($quiz_data[$l][3]==1){
						
							if($quiz_data[$l][5]==0){
								$json_array=$correct_array;
							}elseif($quiz_data[$l][5]==1){
								for($j=0;$j<count($qoption);$j++)	{
									array_push($json_array,$qoption[$j][1]);
								}
							}elseif($quiz_data[$l][5]==2){
								for($j=0;$j<count($qoption);$j++)	{
									array_push($json_array,$qoption[$j][4]);
								}
							}
								array_push($data[$i],implode(',', $json_array));
						}
						
						if($quiz_data[$l][3]==2 and $quiz_data[$l][4]==1){
							array_push($data[$i],implode(',', $json_array_multi_p));
						}
						
						for($j=0;$j<count($qoption);$j++)	{
							array_push($data[$i],$qoption[$j][5]);
						}
						 
						$data[$i]= array_merge($quiz_data[$l],$data[$i]);
								
				}
				
				/* if($quiz_data[$l][3]==2){
				
					array_push($columnhead,"Personality id");
					
					if($quiz_data[$l][4]==1){
						array_push($columnhead,"Multi Personality Weight");
					}
					
				}elseif($quiz_data[$l][3]==1){
				
					if($quiz_data[$l][5]==0){
						array_push($columnhead,"Correct Answer index");
					}elseif($quiz_data[$l][5]==1){
						array_push($columnhead,"Multi Option Score");
					}elseif($quiz_data[$l][5]==2){
						array_push($columnhead,"Category Score");
					}
				} */
				
				$max_option=$max>$max_option?$max:$max_option;

				for($f=0;$f<count($data);$f++){
					$all_data[$x]=$data[$f];
					$x++;
				}
				
				/* $empty_array=array();
				for($z=0;$z<count($columnhead);$z++){
					array_push($empty_array,"");
				}
				for($c=0;$c<2;$c++){
					$all_data[$x]=$empty_array;
					$x++;
				} */
				
		}
			for($i=0;$i<$max_option;$i++){
				array_push($columnhead,JText::_('COM_VQUIZ_EXPORT_OPTION'));
			}

			array_unshift($all_data, $columnhead);
			
			header('Content-Type: text/csv; charset=utf-8');	
			header('Content-Disposition: attachment; filename=Quizzes.csv'); 
 
		    $output = fopen('php://output', 'w');
			 
			foreach ($all_data as $fields) {
				fputcsv($output, $fields, ',', '"');
			}

			fclose($output);
			
			return true;

		} 
		
		function getQuestion_options(){
		
			$question_id=JRequest::getInt('question_id',0);
			$ruleid=JRequest::getInt('ruleid',0);
			$obj = new stdClass();
			$obj->result = "error";	
			
			if($question_id){
			
				$query ='select id,qoption from #__vquiz_option where qid='.$this->_db->quote($question_id);
				$this->_db->setQuery( $query );
				$question_option=$this->_db->loadObjectList();
 
				
				$query=$this->_db->getQuery(true);
				$query->select('rule_optionid');
				$query->from('#__vquiz_quizzes_branching');
				$query->where('rule_questionid='.$this->_db->quote($question_id));
				$query->where('ruleid='.$this->_db->quote($ruleid));
				$query->order(' id desc ');
				$this->_db->setQuery($query);
				$rule_optionid=$this->_db->loadResult();
 
				$html   = '<select name="option_select_rule" id="option_select_rule">';
				for($i=0;$i<count($question_option);$i++){
					if($rule_optionid==$question_option[$i]->id)
						$selected='selected="selected"';
					else
						$selected='';
					$html   .= '<option value="'.$question_option[$i]->id.'" '.$selected.'>'.$question_option[$i]->qoption.'</option>';
					
				}
				$html   .= '</select>';
								
				$obj->question_id=$html;
				$obj->result = "success";

			}
			
			return $obj;
			
		}
		
		function getQuestion_weight(){
		
			$quizid=JRequest::getInt('quizid',0);
			$ruleid=JRequest::getInt('ruleid',0);
			
			$obj = new stdClass();
			$obj->result = "error";	
			
			if($quizid){
			
				//$query ='select DISTINCT(score) from #__vquiz_question where quizzesid='.$this->_db->quote($quizid).' order by score desc';
				
				$query = $this->_db->getQuery(true);
				$query->select('DISTINCT(i.score)');
				$query->from($this->_db->quoteName('#__vquiz_question').'as i');
				$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').'as q on q.questionid=i.id');
				$query->where('q.quizid ='.$this->_db->quote($quizid));
				$query->order('i.score desc');
				
				$this->_db->setQuery( $query );
				$question_weight=$this->_db->loadObjectList();
				
				$query=$this->_db->getQuery(true);
				$query->select('rule_scorepercentile');
				$query->from('#__vquiz_quizzes_branching');
				$query->where('ruleid='.$this->_db->quote($ruleid));
				$this->_db->setQuery($query);
				$rule_scorepercentile=$this->_db->loadResult();
				
				/* $options=array();
				array_push($options,"All Question");
				for($i=0;$i<count($question_weight);$i++){
					$obj_option = new stdClass();
					$obj_option->value = $question_weight[$i]->score;	
					$obj_option->text = 'with '.$question_weight[$i]->score.' weight Upto Question';	
					array_push($options,$obj_option);
				}
				$obj->question_weights =JHTML::_('select.genericlist',$options,'score_percentile'); */
				
				 
				$html   = '<select name="score_percentile" id="score_percentile">';
				$html   .= '<option value="0">'.JText::_('COM_VQUIZ_ALL_QUESTION').'</option>';
				for($i=0;$i<count($question_weight);$i++){
					if($rule_scorepercentile==$question_weight[$i]->score)
						$selected='selected="selected"';
					else
						$selected='';
					
					$html   .= '<option value="'.$question_weight[$i]->score.'" '.$selected.'>with '.$question_weight[$i]->score.' weight Upto Question</option>';
					
				}
				$html   .= '</select>';
				
				$obj->question_weights =$html;
				
				$obj->result = "success";

			}
			
			return $obj;
			
		}
		
		  function getQuestion_weight_apply(){
		
			$quizid=JRequest::getInt('quizid',0);
			$applyid=JRequest::getInt('applyid',0);
			$apply_weight=JRequest::getInt('apply_weight',0);
			
			$obj = new stdClass();
			$obj->result = "error";	
			
			if($quizid){
			
				//$query ='select DISTINCT(score) from #__vquiz_question where quizzesid='.$this->_db->quote($quizid).' order by score desc';
				
				$query = $this->_db->getQuery(true);
				$query->select('DISTINCT(i.score)');
				$query->from($this->_db->quoteName('#__vquiz_question').'as i');
				$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').'as q on q.questionid=i.id');
				$query->where('q.quizid ='.$this->_db->quote($quizid));
				$query->order('i.score desc');
				
				$this->_db->setQuery( $query );
				$question_weight=$this->_db->loadObjectList();
				
				
				
				/* $query=$this->_db->getQuery(true);
				$query->select('apply_weight');
				$query->from('#__vquiz_quizzes_branching');
				$query->where('applyid='.$this->_db->quote($applyid));
				$this->_db->setQuery($query);
				$apply_scorepercentile=$this->_db->loadobject(); */
				
				$html   = '<select name="apply_weight" id="apply_weight" style="width:120px;">';
				$html   .= '<option value="0">'.JText::_('COM_VQUIZ_SELECT').'</option>';
				for($i=0;$i<count($question_weight);$i++){
					if($apply_weight==$question_weight[$i]->score)
						$selected='selected="selected"';
					else
						$selected='';
					
					$html   .= '<option value="'.$question_weight[$i]->score.'" '.$selected.'>Weight '.$question_weight[$i]->score.'</option>';
					
				}
				$html   .= '</select>';
				
				$obj->question_weights =$html;
				
				$obj->result = "success";

			}
			
			return $obj;
			
		}
		
		function getBranching_rule(){

			$query ='select * from #__vquiz_quizzes_branching where quizid='.$this->_db->quote($this->_id);
			$this->_db->setQuery( $query );
			$branching_result=$this->_db->loadObjectList();
			return $branching_result;
			
		}
		
		function getQuestiongroup(){
			
			$query=$this->_db->getQuery(true);
			$query->select('id,title,qorder,description');
			$query->from('#__vquiz_quizzes_questiongroup');
			$query->where('quizid='.$this->_db->quote($this->_id));
			$query->order('id asc');
			$this->_db->setQuery($query);
			$result=$this->_db->loadObjectList();

			return $result;
		}
		
		
		function getSkills(){
		
			$obj = new stdClass();
			if($this->_id){
				$query=$this->_db->getQuery(true);
				$query->select('skillid');
				$query->from($this->_db->quoteName('#__vquiz_quizns'));
				$query->where('quizid ='.$this->_db->quote($this->_id));
				$this->_db->setQuery($query);
				$selectedid=$this->_db->loadColumn();
			}else{
				$selectedid=array();
			}
			$obj->selectedid=$selectedid;
			
			$query=$this->_db->getQuery(true);
			$query->select('id,title');
			$query->from($this->_db->quoteName('#__vquiz_skills'));
			$query->where('published = 1');
			$this->_db->setQuery($query);
			$obj->skillid=$this->_db->loadObjectList();
			return $obj;
		} 
		public function getForm($data=array(),$loadData=true)
		{
			$form=$this->loadForm('com_vquiz.quizmanager','quizmanager',array('control'=>'jform','load_data'=>$loadData));
			
			if(empty($form))
			{
				return false;
			}
			
			return $form;
		}
		
		protected function loadFormData()
			{
				// Check the session for previously entered form data.
				
			//print_r($data);exit;
				if (empty($data))
				{
					$data = $this->getItem();
				}
					//echo "<pre>";print_r($data);exit;
				return $data;
			}  

			
 }