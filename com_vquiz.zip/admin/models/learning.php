<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 www.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.modellist');
 
class VquizModelLearning extends JModelList
{
		function __construct()
		{
			parent::__construct();

			$mainframe = JFactory::getApplication();
			$context	= 'com_vquiz.learning.list.';
			// Get pagination request variables
			$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
			$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );

			// In case limit has been changed, adjust it
			$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
			$this->setState('limit', $limit);
			$this->setState('limitstart', $limitstart);				 
			$array = JRequest::getVar('cid',  0, '', 'array');
			$this->setId((int)$array[0]);

		}

		function _buildQuery()
		{
			
			$user = JFactory::getUser();
			
			$query= 'SELECT i.*,c.title as cat_title FROM #__vquiz_learning as i LEFT JOIN #__vquiz_category c ON i.catid = c.id ';

		 	return $query;
		}

		function setId($id)	
		{
			$this->_id		= $id;
	 		$this->_data	= null;
 		}

		
		function &getItem()
		{
			if (empty( $this->_data )) {
				
				//$query='SELECT i.*';
				//$query .=' FROM #__vquiz_learning as i where i.id = '.$this->_id;	
				
				$query = $this->_db->getQuery(true);
				$query->select('i.*');
				$query->from($this->_db->quoteName('#__vquiz_learning').' as i');
				$query->where('id='.$this->_id);
				$this->_db->setQuery( $query );
				$this->_data = $this->_db->loadObject();

			}


			if (!$this->_data) {
				$this->_data = new stdClass();
				$this->_data->id = 0;
				$this->_data->catid= 0;
				$this->_data->title = null;
				$this->_data->access = 1;
				$this->_data->published = 1;
				$this->_data->language = null;
				$this->_data->start_with = null;
				$this->_data->cet_type = null;
				$this->_data->cet_format = 0;
				$this->_data->cet_digits = 0;
				$this->_data->end_with = 0;
				$this->_data->certificate = 0;
				$this->_data->certificate_multi_item = 0;
				$this->_data->next_quiz_delay = null;
				$this->_data->quizes_order = null;
				$this->_data->description = null;
				$this->_data->alias = null;
				$this->_data->minimum_per =0;
				$this->_data->minimum_custom_per =0;
				$this->_data->delay_periods ='hour';
				$this->_data->urlrestriction =0;
				$this->_data->personality_results =0;
				$this->_data->trivia_results =0;
				$this->_data->article_id =0;
				$this->_data->display_result =null;
				$this->_data->display_certificate =null;
				$this->_data->level_release=null;
				$this->_data->set_price=0;
				$this->_data->price=null;
				//$this->_data->delay_periods =null;
				$this->_data->quiz_lesson =null;
				$this->_data->quiz_lesson_delay =null;
				$this->_data->quiz_lesson_delay_count =null;
				$this->_data->attempt_delay =null;
				$this->_data->attempt_delay_param =null;
				$this->_data->ipaddress_allow =null;				
				$this->_data->attempt_count =0;
 			    $this->_data->startpublish_date= JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString(); 
 				$this->_data->endpublish_date= null;

			}
			return $this->_data;
		}

	function &getItems()			
		{
			// Lets load the data if it doesn't already exist
			if (empty( $this->_data ))
			{
				 $query = $this->_buildQuery();
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();
				 $query .= $filter;
				 $query .= $orderby;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			}
			return $this->_data;
		}
	 
	
		function getTotal()
		{	
			if (empty($this->_total)) {
				$query = $this->_buildQuery();
				$query .= $this->_buildContentFilter();
				$this->_total = $this->_getListCount($query);    
			}
			return $this->_total;
 		}

		function _buildItemOrderBy()
		{
			$mainframe = JFactory::getApplication();
			$context	= 'com_vquiz.learning.list.';
			$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
			$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
			$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
			return $orderby;
		}

		function getPagination()
		{
			// Load the content if it doesn't already exist
			if (empty($this->_pagination)) {
				jimport('joomla.html.pagination');
				$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
			}
			return $this->_pagination;
		}
 
		function _buildContentFilter()
		{
			$mainframe =JFactory::getApplication();

			$context	= 'com_vquiz.learning.list.';
			$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
			$search		= JString::strtolower( $search );
			$catid		= $mainframe->getUserStateFromRequest( $context.'catid', 'catid', 0,	'int' );
			$publish_item		= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );

			$where = array();
			if($publish_item){  
				if ( $publish_item == 'p' ){
					$where[] = 'i.published= 1';
				}elseif($publish_item =='u'){
					$where[] = 'i.published = 0';
				}
			}

			 if($catid ){
				$where[] = 'i.catid = '.$this->_db->Quote( $catid );
			} 

			if($search)
			{	
				if (is_numeric($search)) 
				{		 
					$where[] = 'i.id ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				}
				else
				{
					$where[] = 'lower(i.title) LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
				}
			}
			$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
			return $filter;
		}
		

		function getCats(){
			
			$query ='select a.id , a.title , a.level ';
			$query .=' from #__vquiz_category As a ';
			$query .=' where a.id !=1 group by a.id order by a.lft ASC';
			
			$this->_db->setQuery($query);
			$result=$this->_db->loadObjectList();
			return $result;
		}
 
		function store()
		{	
			$time = time();
			$row =& $this->getTable();
			$data = JRequest::get( 'post' );
			
			/* $data['quizes_order'] = implode(',',JRequest::getVar('quizes_order','','post','array'));
			$data['selected_quizzes_id'] = implode(',',array_diff(JRequest::getVar('quizes_order','','post','array'),array(0)));

			$data['lessons_order'] = implode(',',JRequest::getVar('lessons_order','','post','array'));
			$data['selected_lessons_id'] = implode(',',array_diff(JRequest::getVar('lessons_order','','post','array'),array(0)));
			*/
			
			$data['ipaddress_allow'] =implode(',',JRequest::getVar('ipaddress_allow','', 'post','array'));

			$data['lp_description'] = JRequest::getVar('lp_description', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$data['trivia_results'] = JRequest::getVar('trivia_results', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$data['certificate'] = JRequest::getVar('certificate', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$data['certificate_multi_item'] = JRequest::getVar('certificate_multi_item', '', 'post', 'string', JREQUEST_ALLOWRAW);
			
			$data["alias"] = empty($data["alias"])?$data["title"]:$data["alias"];
			
			$data["alias"]= JFilterOutput::stringURLSafe($data['alias']);
			
			/*---code for  pic upload. ---*/
			 
			$query='select categorythumbnailwidth,categorythumbnailheight from #__vquiz_configuration';
			$this->_db->setQuery($query);
			$configuration_img=$this->_db->loadObject();
			$configuration_width=$configuration_img->categorythumbnailwidth;
			$configuration_height=$configuration_img->categorythumbnailheight;
	 
			$image = JRequest::getVar('image', null, 'FILES', 'array');
			$allowed = array('.jpg', '.jpeg', '.gif', '.png');

			$dirpath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/learning/';
			$thumbPath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/learning/thumbs/'; 

			jimport('joomla.filesystem.file');
			$image_name = str_replace(' ', '', JFile::makeSafe($image['name']));
			$image_tmp = $image['tmp_name'];
			$time = time();
			
			if($image_name <> "" ){
				
				$ext = strrchr($image_name, '.');
				if(!in_array($ext, $allowed)){
					$msg_error=JText::_('THIS_IMAGE_TYPE_NOT_ALLOWED');
					$this->setError($msg_error);
					return false;
				}
		
				$size = getimagesize($image_tmp);
				$src_w = $size[0];
				$src_h = $size[1];
				
				if($src_w > $src_h ){
					if(!empty($configuration_width) and is_numeric($configuration_width)){
						$width = $configuration_width;   
					}else{
						$width = 125; //New width of image 
					}
					if(!empty($configuration_height) and is_numeric($configuration_height)){
						$height =$configuration_height;
					}else{   
						$height = $size[1]/$size[0]*$width; //This maintains proportions
					}
					$width1 = 300; //New width of image    
					$height1 = $size[1]/$size[0]*$width; //This maintains proportions

				}else{
					if(!empty($configuration_height) and is_numeric($configuration_height)){
						$height =$configuration_height;
					}else{
						$height = 125;
					}
					if(!empty($configuration_width) and is_numeric($configuration_width)){
						$width = $configuration_width;   
					}else{
						$width = $size[0]/$size[1]*$height; //This maintains proportions
					}
					$height1 = 360;
					$width1 = $size[0]/$size[1]*$height; //This maintains proportions
				}
				
				$width1 = 265; //New width of image    
				$height1 = $size[1]/$size[0]*$width; //This maintains proportions

				$new_image = imagecreatetruecolor($width, $height);
				$new_image1 = imagecreatetruecolor($width1, $height1);
				
				if($size['mime'] == "image/jpeg"){
					$tmp = imagecreatefromjpeg($image_tmp);
				}elseif($size['mime'] == "image/gif"){
					$tmp = imagecreatefromgif($image_tmp);
				}else{
					$tmp = imagecreatefrompng($image_tmp);
				}
				
				imagecopyresampled($new_image, $tmp,0,0,0,0, $width, $height, $src_w, $src_h);
				
				if($size['mime'] == "image/jpeg"){
					imagejpeg($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
					
				}elseif($size['mime'] == "image/gif"){
					imagegif($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
					
				}else{
					imagepng($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
				}

				imagecopyresampled($new_image1, $tmp,0,0,0,0, $width1, $height1, $src_w, $src_h);
				
				if($size['mime'] == "image/jpeg"){
					imagejpeg($new_image1, $dirpath.$time.'_'.$image_name);
				}elseif($size['mime'] == "image/gif"){
					imagegif($new_image1, $dirpath.$time.'_'.$image_name);
				}else{
					imagepng($new_image1, $dirpath.$time.'_'.$image_name);
				}
				
				if(move_uploaded_file($image_tmp, $dirpath.$time.'_'.$image_name)){
					$data['image'] = $time.'_'.$image_name;
				}
	 

			}

			if($data['image'] and $oldimage_path){
		
			   unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/learning/'.$oldimage_path);
			   unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/learning/thumbs/'.'thumb_'.$oldimage_path);

			}
			
			
			if (!$row->bind($data)) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
			
			if (!$row->check()) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}

			if (!$row->store()) {
				$this->setError( $row->getErrorMsg() );
				return false; 
			}

			JRequest::setVar('id', $row->id);
			
			//save notification on adding
				
				if(!$data['id']){ 
					
					$data_arr = array();
					$data_arr['itemid'] = $row->id;
					$data_arr['notification_type'] = 7;
					$data_arr['replace_learning_title'] = $row->title;
						
					if(QuizHelper::checkNotification($data_arr['notification_type'])){
						$data_arr['notify_users'] = QuizHelper::findUsersToNotify('notify_add_lpath');
						$data_arr['enotify_users'] = QuizHelper::findUsersToEnotify('enotify_add_lpath');
						//print_r($data_arr); exit;
						QuizHelper::sendNotification($data_arr);
					}
					
				}
				
			return true;

		}
 

		function delete()
		{
			$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
			$row =& $this->getTable();
			if (count( $cids )) {
			foreach($cids as $cid) {
				if (!$row->delete( $cid )) {
					$this->setError( $row->getErrorMsg() );
					return false;
					}
				}
			}
			return true;
		}

		function publish(){

			$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
			$task		= JRequest::getCmd( 'task' );
			$publish	= ($task == 'publish')?1:0;
			$n = count( $cid );
			if (empty( $cid )) {
				return JText::_('No item selected');
			}

			$cids = implode( ',', $cid );
			$query = 'UPDATE #__vquiz_learning SET published = ' . (int) $publish . ' WHERE id IN ( ' . $cids . ' )';
			$this->_db->setQuery( $query );
		
			if (!$this->_db->query()){
				return $this->_db->getErrorMsg();
			}
			else{
				return ucwords($task).'ed successfully.';
			}
		
		}
		
		
	function getLessonids(){
		
		$query = $this->_db->getQuery(true);
		$query->select('lessionid,quizid');
		$query->from($this->_db->quoteName('#__vquiz_learning_lnq'));
	    $query->where('learningid='.$this->_id);
		$query->order('ordering asc');
		$this->_db->setQuery( $query ); 
		return $this->_db->loadColumn(); 
		
	}
	
	function getQuizids(){
		
		$query = $this->_db->getQuery(true);
		$query->select('quizid');
		$query->from($this->_db->quoteName('#__vquiz_learning_lnq'));
	    $query->where('learningid='.$this->_id);
		$query->order('ordering asc');
		$this->_db->setQuery( $query );
		return $this->_db->loadColumn();
		

	}
		
		public function getSelectedQuizzes(){

			if($this->_id){
				$obj =new stdClass();
				$learning_quizids=$this->getQuizids();
				$learning_lessionids=$this->getLessonids();
				
				$query=$this->_db->getQuery(true);
				$query->select('id,title as quiztitle');
				$query->from($this->_db->quoteName('#__vquiz_quizzes'));
				$query->where('id IN ('.implode(',',$learning_quizids).')');
				//$query->order('FIELD(id,'.implode(',',$learning_quizids).')');
				try{
					$this->_db->setQuery($query);
					$obj->quizdata=$this->_db->loadObjectList();
					$obj->quizdatacolumn=$this->_db->loadColumn();
				}catch(Exception $e){
					$obj->quizdata=false;
				}
				$query=$this->_db->getQuery(true);
				$query->select('id,title as lessontitle');
				$query->from($this->_db->quoteName('#__vquiz_lessons'));
				$query->where('id IN ('.implode(',',$learning_lessionids).')');
				//$query->order('FIELD(id,'.implode(',',$learning_lessionids).')');
				try{
					$this->_db->setQuery($query);
					$obj->lessondata=$this->_db->loadObjectList();
					$obj->lessondatacolumn=$this->_db->loadColumn();
				}catch(Exception $e){
					$obj->lessondata=false;
				}
 
  				$obj->quizids=$this->getQuizids();
				$obj->lessonids=$this->getLessonids();
				return $obj;
			}
				
			
		} 
		public function getForm($data=array(),$loadData=true)
	{
		$form=$this->loadForm('Vquiz.learning','learning',array('control'=>'jform','load_data'=>$loadData));
		
		if(empty($form))
		{
			return false;
		}
		
		
		return $form;
	}
	
	function getCategory(){					
				
		$query = $this->_db->getQuery(true);
		$query->select('a.id , a.title , a.level');
		$query->from($this->_db->quoteName('#__vquiz_category').' as a');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_category').' AS b ON a.lft > b.lft AND a.rgt < b.rgt');
		$query->where('a.id !=1');
		$query->group('a.id, a.title, a.level, a.lft, a.rgt, a.parent_id');
		$query->order('a.lft ASC');
		$this->_db->setQuery($query);
		$result=$this->_db->loadObjectList();
		
		
		return $result;
		
	}
	function getConfiguration(){
		
			$query='select * from #__vquiz_configuration';
			$this->_db->setQuery($query);
			$result = $this->_db->loadObject();
			return $result;
		}
		
				
}