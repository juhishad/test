<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access

defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');

class VquizModelQuestionpool extends JModelList
{

	function __construct(){
		
		parent::__construct();
		$mainframe = JFactory::getApplication();
		
		$context	= 'com_vquiz.question.list.';
		// Get pagination request variables
		$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		
		// In case limit has been changed, adjust it
		$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
		
		$this->setState('limit', $limit);
		$this->setState('limitstart', $limitstart);
		
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	 }
	 		
	 function _buildQuery()
	 {
		$user = JFactory::getUser();
		
		//$query=" SELECT i.*, u.quizzes_title as categoryname FROM #__vquiz_question as i JOIN #__vquiz_quizzes as u ON i.quizzesid = u.id";
		
		$query = $this->_db->getQuery(true);
		$query->select('i.*,q.title as quizname,a.quizid as quizid');
		$query->from($this->_db->quoteName('#__vquiz_question').' as i');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as a on i.id=a.questionid');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_quizzes').' as q on q.id=a.quizid ');
		
		if (!$user->authorise('core.admin','com_vquiz')){
		
			$groups = implode(',', $user->getAuthorisedViewLevels());
			$query .= ' and u.access IN (' . $groups . ')';
		}
		
		return $query;
	}
 
	function setId($id){
		$this->_id		= $id;
		$this->_data	= null;
	}

 
	function &getItem(){
	
		if (empty( $this->_data )) {	

			$query = ' SELECT * FROM #__vquiz_question '.
			'  WHERE id = '.$this->_id;

			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();

		}

		if (!$this->_data) {
	 
			$this->_data = new stdClass();

			$this->_data->id = 0;
			$this->_data->qtitle = null;
			$this->_data->quiz_categoryid= null; 
			$this->_data->optiontype = null;
			$this->_data->quiztitle = null;
			$this->_data->titleid = null;
			$this->_data->score =1 ;
			$this->_data->penalty =null ;
			$this->_data->attemped_count =null;
			$this->_data->explanation =null;
			$this->_data->published =1;
			$this->_data->flagcount =null;
			$this->_data->ordering =null;
			$this->_data->question_timelimit =null;
			$this->_data->questiontime_parameter =null;
			$this->_data->expire_timescore =null;
			$this->_data->personality_optionid =null;
			$this->_data->user_comment =null;
			$this->_data->text_field_ans =null;
			$this->_data->case_sensitive =null;
			$this->_data->other_option =null;
			$this->_data->questiongroup =0;
			
		}
 		return $this->_data;
 	}
	
	function &getItems(){
	
		if (empty( $this->_data )){
			$query = $this->_buildQuery();
			$filter = $this->_buildContentFilter();
			$orderby = $this->_buildItemOrderBy();
			$query .= $filter;
			$query .= $orderby;
			//$this->_data = $this->_getList( $query );
			$this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
		}

		return $this->_data;
	}
	 
	function getCategory(){
		
		$query = $this->_db->getQuery(true);
		$query->select('a.id , a.title , a.level');
		$query->from($this->_db->quoteName('#__vquiz_category').' as a');
		$query->join('LEFT',$this->_db->quoteName('#__vquiz_category').' AS b ON a.lft > b.lft AND a.rgt < b.rgt');
		$query->where('a.id !=1');
		$query->group('a.id, a.title, a.level, a.lft, a.rgt, a.parent_id');
		$query->order('a.lft ASC');
		$this->_db->setQuery($query);
		$result=$this->_db->loadObjectList();
		
		return $result;
		
	} 

	function getTotal(){

		if (empty($this->_total)) {

			$query = $this->_buildQuery();
			$query .= $this->_buildContentFilter();
			$this->_total = $this->_getListCount($query);    
		}

		return $this->_total;
	}
 
 
 
 
	function _buildItemOrderBy(){

		$mainframe = JFactory::getApplication();
		$context	= 'com_vquiz.question.list.';
		$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
		$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
		$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
		return $orderby;
	}



	function getPagination(){
	
		if (empty($this->_pagination)) {
			jimport('joomla.html.pagination');
			$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit'));
		}
		return $this->_pagination;
	}
 
 

	function _buildContentFilter(){

		$mainframe =JFactory::getApplication();
		$context	= 'com_vquiz.question.list.';
		$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
		$quizid		= $mainframe->getUserStateFromRequest( $context.'quizid', 'quizid',	'',	'string' );
		
		if(empty($quizid)){
			$quizid = JRequest::getInt('quizid', 0);
		}

		$search		= JString::strtolower( $search );
		$publish_item		= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );
		
		$where = array();
	
		if($publish_item){  

			if ( $publish_item == 'p' ){
				$where[] = 'i.published= 1';
				
			}elseif($publish_item =='u'){
			
				$where[] = 'i.published = 0';
			}

		}
		 
		if($search){
		
			if (is_numeric($search)){
			
				$where[] = 'LOWER(  i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				
			}else{
			 $where[] = 'i.qtitle LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );	
			}
		}
		
		if($quizid){
			$where[] = ' a.quizid ='.$this->_db->Quote( $this->_db->escape( $quizid, true ), false );
		}
		
		$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
		return $filter;
	}
			

	function getOptinscoretype(){
	
		$context	= 'com_vquiz.question.list.';
		$mainframe =JFactory::getApplication();
		$quizid = JRequest::getInt('quizid', 0);
		
		$query = ' SELECT * FROM #__vquiz_quizzes  WHERE id = '.$quizid;
		$this->_db->setQuery( $query );
		$quiztype= $this->_db->loadObject();
		
		return $quiztype;
	}
 
 	
	function reorder(){

		$mainframe =& JFactory::getApplication();
		/*--Check for request forgeries
		JRequest::checkToken() or jexit( 'Invalid Token' )--*/;
		$cid 	= JRequest::getVar( 'cid', array(), 'post', 'array' );
		JArrayHelper::toInteger($cid);
		$task	= JRequest::getCmd('task', '');
		$inc	= ($task == 'orderup' ? -1 : 1);
		
		if (empty( $cid )) {
			return JError::raiseWarning( 500, 'No items selected' );
		}
		
		$row =& $this->getTable();
		$row->load( (int) $cid[0] );
		$row->move( $inc  );
		
		return JText::_('reordered successfully');;
	}
		
	 function saveOrder(){
	 
			/*--Check for request forgeries
			JRequest::checkToken() or jexit( 'Invalid Token' )--*/;
			$cid 	= JRequest::getVar( 'cid', array(), 'post', 'array' );
			JArrayHelper::toInteger($cid);
			if (empty( $cid )) {
				return JError::raiseWarning( 500, 'No items selected' );
			}
			$total		= count( $cid );
			$row =& $this->getTable();
			$groupings = array();
			$order 		= JRequest::getVar( 'order', array(0), 'post', 'array' );
			JArrayHelper::toInteger($order);

			for ($i = 0; $i < $total; $i++)
			{
				$row->load( (int) $cid[$i] );
				$groupings[] = $row->position;
				if ($row->ordering != $order[$i])
				{
					$row->ordering = $order[$i];
					if (!$row->store()) {
						return JError::raiseWarning( 500, $this->_db->getErrorMsg() );
					}
				}
			}
	
			// execute updateOrder for each parent group
			$groupings = array_unique( $groupings );
			foreach ($groupings as $group){
				$row->reorder();
			}
			
			return JText::_('New ordering saved');
		}
 
 
	 function store(){
		 
			$time = time();
			$row =& $this->getTable();
			$data = JRequest::get( 'post' );
			print_r($data);exit;
			$user=JFactory::getUser();
			$new_date =JFactory::getDate('now', JFactory::getConfig()->get('offset'));
					
			$data['qtitle'] = JRequest::getVar('qtitle', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$data['explanation'] = JRequest::getVar('explanation', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$data['skills'] =implode(',',JRequest::getVar('skills','', 'post','array'));
			
			if (empty($data['qtitle'])) {
				$msg = JText::_('QUESTION_TITLE_NOT_EMPTY');
				$this->setError($msg);
				return false;
			}
			
			
			$data['qoption']	= JRequest::getVar('qoption', array(), 'post', 'array');
			$data['optiontype']	= JRequest::getInt('optiontype','post',1);
		
			/* if ($data['optiontype']!=4  AND  $data['optiontype']!=5){
			      if (empty($data['qoption'])) { 
					$msg = JText::_('QUESTION_OPTION_EMPTY');
					$this->setError($msg);
					return false;
				  }
			 } */
			 
			
			if($data["id"]==0){
			
				$data['created'] = $new_date->__toString();
				$data['created_by'] = $user->id;
				
				$query='select MAX(ordering) from #__vquiz_question';
				$this->_db->setQuery($query);
				$highest_ordering=$this->_db->loadResult();
				
				$data['ordering'] = $highest_ordering+1;
 
				/*$origTable = clone $row;
				$origTable->load($data['id']);

				if(JRequest::getVar('task','')=='save2copy'){
				
					if($data['qtitle'] == $origTable->qtitle){
						$data['id'] = 0;
					
						while ($row->load(array('alias' => $data['alias'], 'quiz_categoryid' => $data['quiz_categoryid'])))
						{
							$data['qtitle'] = JString::increment($data['qtitle']);
							$data['alias'] = JString::increment($data['alias'], 'dash');
						}
					}

				}
				else
				{
					if ($data['alias'] == $origTable->alias)
					{
						$data['alias'] = '';
					}
				}*/
				
			}else{

				$data['modified'] = $new_date->__toString();
			}

			if (!$row->bind($data)) {
		
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
	 
			if (!$row->check()) {
				$this->setError($this->_db->getErrorMsg());
				return false;
			}
		
			if (!$row->store()) {
				//$this->setError( $row->getErrorMsg() );
				$this->setError($this->_db->getErrorMsg());
				return false; 
			}
				
			if(!$data['id'])
			JRequest::setVar('id', $row->id);
				
				return true;
		}

	function publish(){

		$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$task		= JRequest::getCmd( 'task' );
		$publish	= ($task == 'publish')?1:0;
		$n = count( $cid );
		
		if (empty( $cid )){
			return JText::_('No item selected');
		}

		$cids = implode( ',', $cid );		 
		$query = 'UPDATE #__vquiz_question SET published = ' . (int) $publish . ' WHERE id IN ( ' . $cids . ' )';

		$this->_db->setQuery( $query );				
		if (!$this->_db->query()){
			return $this->_db->getErrorMsg();	
		}else{		
			return ucwords($task).'ed successfully.';
		}
	}

	function delete(){
	
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$row =& $this->getTable();
		if (count( $cids )) {
		foreach($cids as $cid) {
			if (!$row->delete( $cid )) {
				$this->setError( $row->getErrorMsg() );
				return false;
				}
			}
			if($row->delete( $cid )){
				
				$query = ' SELECT image from #__vquiz_option WHERE id = '.$cid;
				$this->_db->setQuery($query);
				$oldimage_path = $this->_db->loadColumn();
				
				if(!empty($oldimage_path)){
					foreach($oldimage_path as $old) {
						unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/'.$old);
						unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/options/thumbs/'.'thumb_'.$old);
					}
				}
				
				$q ='delete FROM #__vquiz_option WHERE qid='.$cid;
				$this->_db->setQuery( $q );
				$this->_db->execute();	
			}
		}

		return true;
	 }

	function getOptions(){
 
		if($this->_data->id!=0){
		
			$query="select * from #__vquiz_option where qid = ".$this->_data->id.' order by id';
			$this->_db->setQuery($query);
			$result = $this->_db->loadObjectList();
 
			return $result;
		}
	}
 

	function getQuizes(){

		$query="select * from #__vquiz_quizzes where published = ".'1'.' order by id asc';
		$this->_db->setQuery($query);
		$result = $this->_db->loadObjectList();
		return $result;

	}
					
			
	function getCsv()
	{
			
			$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
			$quizid=JRequest::getInt('quizid',0);
			
			$query = 'select quiztype,personality_type,answers_type from #__vquiz_quizzes where id='.$this->_db->quote($quizid);
			$this->_db->setQuery($query);
			$quiz_info = $this->_db->loadObject();
			
			$columnhead =array('ID','Question Title','Question Explanation','Quizid','Quiz Type','Answer type','Score','Penalty','published','Question Time','Time Parameter','Comment Box','Flag Count','text_field_ans','case_sensitive','Creted By');
			
		
			$query = 'select id,qtitle,explanation,quizid,quiztype,optiontype,score,penalty,published,question_timelimit,questiontime_parameter,other_option,flagcount,text_field_ans,case_sensitive,created_by from #__vquiz_question WHERE id IN ('.implode(',',$cids).')';
			$this->_db->setQuery( $query );
			$data = $this->_db->loadRowList();
			
			$count=count($data);

			$max=0;
			
			for($i=0;$i<$count;$i++){
			
				$q = 'select correct_ans,options_score,personality_optionid,multi_p_options_score,category_score,qoption,image from #__vquiz_option where qid='.$this->_db->quote($data[$i][0]).' order by id asc';
				$this->_db->setQuery($q);
				$qoption = $this->_db->loadRowList();
				
				unset($correct_array);
				unset($json_array);
				$correct_array=array();
				$json_array=array();
				$json_array_multi_p=array();
				
				$correct=0;
				$max = count($qoption)>$max?count($qoption):$max;
				
				for($j=0;$j<count($qoption);$j++)	{
					if($qoption[$j][0]==1){
						$correct=$j;
						array_push($correct_array,$correct);
					}
				}
			
				if($quiz_info->quiztype==2){
				
					for($j=0;$j<count($qoption);$j++){
						array_push($json_array,$qoption[$j][2]);
					}
					if($quiz_info->personality_type==1){
						for($j=0;$j<count($qoption);$j++)	{
							array_push($json_array_multi_p,$qoption[$j][3]);
						}	
					}
				
					array_push($data[$i],implode(',', $json_array));
				
				}elseif($quiz_info->quiztype==1){
				
					if($quiz_info->answers_type==0){
						$json_array=$correct_array;
					}elseif($quiz_info->answers_type==1){
						for($j=0;$j<count($qoption);$j++)	{
							array_push($json_array,$qoption[$j][1]);
						}
					}elseif($quiz_info->answers_type==2){
						for($j=0;$j<count($qoption);$j++)	{
							array_push($json_array,$qoption[$j][4]);
						}
					}
						array_push($data[$i],implode(',', $json_array));
				}
				
			
				
				if($quiz_info->quiztype==2 and $quiz_info->personality_type==1){
					array_push($data[$i],implode(',', $json_array_multi_p));
				}
				
				 for($j=0;$j<count($qoption);$j++)	{
					array_push($data[$i],$qoption[$j][5]);
					array_push($data[$i],$qoption[$j][6]);
				}

			}
			
			if($quiz_info->quiztype==2){
			
				array_push($columnhead,"Personality id");
				
				if($quiz_info->personality_type==1){
					array_push($columnhead,"Multi Personality Weight");
				}
				
			}elseif($quiz_info->quiztype==1){
			
				if($quiz_info->answers_type==0){
					array_push($columnhead,"Correct Answer index");
				}elseif($quiz_info->answers_type==1){
					array_push($columnhead,"Multi Option Score");
				}elseif($quiz_info->answers_type==2){
					array_push($columnhead,"Category Score");
				}
			}
		
			for($i=0;$i<$max;$i++){
				array_push($columnhead,"Option");
				array_push($columnhead,"Images");
			}
			
		
		array_unshift($data, $columnhead);
		header('Content-Type: text/csv; charset=utf-8');				
		header('Content-Disposition: attachment; filename=Questions.csv');
		$output = fopen('php://output', 'w');
		
		foreach ($data as $fields) {
			fputcsv($output, $fields, ',', '"');
		}
		
		fclose($output);
		return true;
	} 
		
		
				
	function checktotaltime(){
		
		$quizid = JRequest::getInt('quizid', 0);
		$obj = new stdClass();
		$obj->result = "error";					

		$query = 'select total_timelimit from #__vquiz_quizzes where id='.$this->_db->quote($quizid).' order by id asc';
		$this->_db->setQuery( $query );
		$result = $this->_db->loadResult();
		if($result>0){
			$obj->totaltime =1;
		}else{
			$obj->totaltime =0;
		}
		
		$obj->result = "success";
		return $obj;
		 
	} 
				
	function movequestion(){

		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$quizid = JRequest::getInt('quizzesmoveid',0);

		if (count( $cids )) {
			foreach($cids as $cid) {

				//$query = 'UPDATE #__vquiz_question SET quizzesid = '.$quizzesid.' WHERE id = '.$cid;
				$query =$this->_db->getQuery(true);
				$query->update($this->_db->quoteName('#__vquiz_quiznques'));
				$query->set('quizid='.$this->_db->quote($quizid));
				$query->where('questionid='.$this->_db->quote($cid));
				$this->_db->setQuery( $query );
				if (!$this->_db->query()){
					$msg = $this->setError($this->_db->stderr());
					$this->setRedirect( 'index.php?option=com_vquiz&view=questionpool', $msg );
					return false;
				}

			}
		}
		return true;

	}
				

	function copyquestion()
	{

		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$quizid = JRequest::getInt('quizzescopyid',0);

		if (count( $cids )) {
			foreach($cids as $cid) {
			
			$query = ' SELECT * FROM #__vquiz_question WHERE id = '.$cid;
			$this->_db->setQuery( $query );
			$question= $this->_db->loadObject();
				
			$insert = new stdClass();
			$insert->id = null;
			$insert->quizzesid =$quizzesid;
			$insert->quiztype = $question->quiztype;
			$insert->qtitle = $question->qtitle;
			$insert->explanation = $question->explanation;
			$insert->published = $question->published;
			$insert->other_option = $question->other_option;
			$insert->text_field_ans = $question->text_field_ans;
			$insert->case_sensitive = $question->case_sensitive;
			$insert->questiontime_parameter = $question->questiontime_parameter;
			$insert->question_timelimit = $question->question_timelimit;
			$insert->optiontype = $question->optiontype;
			$insert->flagcount = $question->flagcount;
			$insert->score = $question->score;
			$insert->penalty = $question->penalty;
			$insert->ordering = $question->ordering;
			$insert->created = $question->created;
			$insert->modified = $question->modified;
			
								
			if(!$this->_db->insertObject('#__vquiz_question', $insert, 'id'))	{
			
				$msg = $this->setError($this->_db->stderr());
				$this->setRedirect( 'index.php?option=com_vquiz&view=questionpool', $msg );
				return false;
			}
			
									
			$qid = $this->_db->insertid();
				
			$query = ' SELECT * FROM #__vquiz_option WHERE qid = '.$question->id;
			$this->_db->setQuery( $query );
			$option = $this->_db->loadObjectList();


			 for($i=0;$i<count($option);$i++)	{
				 
					$insertoption = new stdClass();
					$insertoption->id = null;
					$insertoption->qid =$qid;
					$insertoption->image =$option[$i]->image;
					$insertoption->qoption =$option[$i]->qoption;
					$insertoption->correct_ans = $option[$i]->correct_ans;
					$insertoption->options_score =$option[$i]->options_score;
					$insertoption->personality_optionid =$option[$i]->personality_optionid;
					
					
					if(!$this->_db->insertObject('#__vquiz_option', $insertoption, 'id'))	{
					
						$msg = $this->setError($this->_db->stderr());
						$this->setRedirect( 'index.php?option=com_vquiz&view=questionpool', $msg );
						
						return false;
					}
				}
					
			}

		}
		return true;
	 
	}
	
	
	function getPersonality_answers(){
	
		$quizid = JRequest::getInt('quizid',0);
		//$query='select * from #__vquiz_personality_score_message where quizid='.$this->_db->Quote($quizid);
		
		$query =$this->_db->getQuery(true);
		$query->select('*');
		$query->from($this->_db->quoteName('#__vquiz_personality_message'));
		$query->where('quizid='.$this->_db->quote($quizid));
		$this->_db->setQuery($query);
		$result = $this->_db->loadObjectList(); 
		return $result;
	}
					
	function getConfiguration(){
		$query='select * from #__vquiz_configuration';
		$this->_db->setQuery($query);
		$result = $this->_db->loadObject();
		return $result;
	}	
	
	
	function getScore_category(){
		$quizid = JRequest::getInt('quizid',0);
		
		//$query='select * from #__vquiz_quiz_score_category where quizid='.$this->_db->Quote($quizid).' order by id asc';
		
		$query =$this->_db->getQuery(true);
		$query->select('*');
		$query->from($this->_db->quoteName('#__vquiz_quiz_score_category'));
		$query->where('quizid='.$this->_db->quote($quizid));
		$this->_db->setQuery($query);

		$result = $this->_db->loadObjectList();
		return $result;
	}
	
	function getpersonality_category(){
		$quizid=JRequest::getInt('quizid',0);
		//$query='select * from #__vquiz_quiz_personality_category where quizid='.$this->_db->Quote($quizid);
		
		$query =$this->_db->getQuery(true);
		$query->select('*');
		$query->from($this->_db->quoteName('#__vquiz_quiz_personality_category'));
		$query->where('quizid='.$this->_db->quote($quizid));
		$this->_db->setQuery($query);
		$result = $this->_db->loadObject();
		return $result;
	}	
		
		
	  function check_pcategory(){
	  
			$result=new stdClass();
			
		
			$quizid=JRequest::getInt('quizid',0);
			
			//$query='select count_column,category from #__vquiz_quiz_personality_category where quizid='.$this->_db->Quote($quizid);
			
			$query =$this->_db->getQuery(true);
			$query->select('count_column,category');
			$query->from($this->_db->quoteName('#__vquiz_quiz_personality_category'));
			$query->where('quizid='.$this->_db->quote($quizid));
			$this->_db->setQuery($query);
			$pcategory_result = $this->_db->loadObject();
			
			
			$all_category = json_decode($pcategory_result->category);
			$personality_category=array_chunk($all_category,$pcategory_result->count_column);

			//$query='select id from #__vquiz_question where quizzesid='.$this->_db->Quote($quizid);
			
			$query =$this->_db->getQuery(true);
			$query->select('i.id');
			$query->from($this->_db->quoteName('#__vquiz_question').' as i');
			$query->from('LEFT',$this->_db->quoteName('#__vquiz_quiznques').' as qq on qq.questionid=i.id');
			$query->where('quizid='.$this->_db->quote($quizid));
			
			$this->_db->setQuery($query);
			$question_id = $this->_db->loadColumn();
			
			$used_pcategory=array();
			
			for($i=0;$i<count($question_id);$i++){
			
				$query='select personality_optionid from #__vquiz_option where qid ='.$this->_db->Quote($question_id[$i]).' limit 1';
				$this->_db->setQuery($query);
				$sp_category = $this->_db->loadResult();
				array_push($used_pcategory,$sp_category);
			}
			 
			$ck_pc=array_unique($used_pcategory);
			$array_key_category=array();
			for($j=0;$j<count($personality_category);$j++){
				$count_p=0;
				$sub_category=$personality_category[$j];
				for($k=0;$k<count($sub_category);$k++){
					if(in_array($sub_category[$k],$ck_pc) AND !in_array($j,$array_key_category)){
						array_push($array_key_category,$j);
					}
				}
				
			}
 
			
			if(count($array_key_category)!=count($personality_category)){
			
				$array_not_used=array_values(array_diff(array_keys($personality_category), $array_key_category));
				function add_number($n)
				{
					return($n+1);
				}
				$result->no_category=json_encode(array_map("add_number", $array_not_used));
				$result->used=1;
				
			}else{
				$result->used=0;
			}

			return $result;
			
		}	
		
		
		function drawChart(){

			$questionid = JRequest::getInt('questionid',0);
			
			//$query = 'select quizzesid from #__vquiz_question where  id = '.$this->_db->quote($questionid); 
			
			$query =$this->_db->getQuery(true);
			$query->select('q.quizid');
			$query->from($this->_db->quoteName('#__vquiz_quiznques').' as q');
			$query->from('LEFT',$this->_db->quoteName('#__vquiz_question').' as i on q.questionid=i.id');
			$query->where('id='.$this->_db->quote($questionid));
			$this->_db->setQuery( $query );
			$quizid = $this->_db->loadResult();

 
			$date = JFactory::getDate();						
			$obj = new stdClass();
			$obj->result = "error";
				
			/*---Most Choosed Option---*/
			
			//$q = 'SELECT quiz_answers from #__vquiz_quizresult WHERE quizzesid ='.$this->_db->quote($quizid);
			
			$query =$this->_db->getQuery(true);
			$query->select('a.quiz_answers');
			$query->from($this->_db->quoteName('#__vquiz_quizresult_qna').' as a');
			$query->from('LEFT',$this->_db->quoteName('#__vquiz_quizresult').' as r on a.resultid=r.id');
			$query->where('r.quizid='.$this->_db->quote($quizid));
			$this->_db->setQuery( $query );	
			$result_quiz_answer=$this->_db->loadRowList(); 
 
			$options=array();
			$countoption=array();
			$array=array();
			$maxoption=0;
			
			for($i=0;$i<count($result_quiz_answer);$i++)	
			{
				$xx=json_decode($result_quiz_answer[$i][0]);
				
				for($j=0;$j<count($xx);$j++){
				
					$given_answer=explode(',',$xx[$j]);
					
					for($k=0;$k<count($given_answer);$k++){
						if($given_answer[$k]!=0)
						array_push($countoption,$given_answer[$k]);
					} 
				}
				
			} 

			$choosedoption=array_count_values($countoption);
			$keyvalue=array_keys($choosedoption);
 
			$query = 'select count(qid) from #__vquiz_option where qid ='.$this->_db->quote($questionid);
			$this->_db->setQuery( $query );
			$maxid = $this->_db->loadColumn();	
			
			for($ck=0;$ck<count($maxid);$ck++){
				$xx=$maxid[$ck];
				$maxoption=$xx>$maxoption?$xx:$maxoption;
			}

			$query = 'select id,qtitle from #__vquiz_question where  id = '.$this->_db->quote($questionid); 
			$this->_db->setQuery( $query );
			$questions = $this->_db->loadObject();

			$arr = array();
			$qu=array('Question');
			$xx=array();
			
			for($h=0;$h<$maxoption;$h++){
				array_push($xx,chr(65+$h));	
			}
						
			$merg=array_merge($qu,$xx);
			array_push($arr,$merg);

					
			$query = 'select id from #__vquiz_option where qid = '.$this->_db->quote($questions->id);
			$this->_db->setQuery( $query );
			$options= $this->_db->loadColumn();
									
			$oo=array();
					
			for($q=0;$q<$maxoption;$q++){

				if (in_array($options[$q],$keyvalue)) {
					foreach ($choosedoption as $key => $value){
					if($key==$options[$q])	
					array_push($oo,$value);
					}
				}
				else{
					array_push($oo,0);
				}
			}
					
				$ques=array(strip_tags($questions->qtitle));
				
				$x[$k]=array_merge($ques,$oo);
				array_push($arr,$x[$k]);
								
  
				
				$obj->responce=$arr;	
				$obj->result = "success";

			return $obj;
		} 
		
		function getQuestiongroup(){
			
			$quizid=JRequest::getInt('quizid',0);
			$query=$this->_db->getQuery(true);
			$query->select('qorder,title');
			$query->from('#__vquiz_quizzes_questiongroup');
			$query->where('quizid='.$this->_db->quote($quizid));
			$this->_db->setQuery($query);
			$result=$this->_db->loadObjectList();

			return $result;
		}

			
		function getSkills(){

			$obj = new stdClass();
			
			$quizid=JRequest::getInt('quizid',0);
			$query=$this->_db->getQuery(true);
			$query->select('skillid');
			$query->from($this->_db->quoteName('#__vquiz_quizns'));
			$query->where('quizid = '.$this->_db->quote($quizid));
			$this->_db->setQuery($query);
			$skills=$this->_db->loadColumn();
			
			if($this->_id){
				$query=$this->_db->getQuery(true);
				$query->select('skillid');
				$query->from($this->_db->quoteName('#__vquiz_quesns'));
				$query->where('questionid ='.$this->_db->quote($this->_id));
				$this->_db->setQuery($query);
				$selectedid=$this->_db->loadColumn();
			}else{
				$selectedid=array();
			}
			$obj->selectedid=$selectedid;
			
			if($skills){
				$query=$this->_db->getQuery(true);
				$query->select('id,title');
				$query->from($this->_db->quoteName('#__vquiz_skills'));
				$query->where('published = 1');
				$query->where('id in('.implode(',',$skills).')');
				$this->_db->setQuery($query);
				$obj->skillid=$this->_db->loadObjectList();
			}else{
				$obj->skillid=null;
			}
			return $obj;
		}
	
		
	
 }