<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
defined('_JEXEC') or die('Restricted access');

JFormHelper::loadFieldClass('list');

/**
 * Form Field class for the Joomla Framework.
 *
 * @package     Joomla.Administrator
 * @subpackage  com_menus
 * @since       1.6
 */
class JFormFieldModal_Categorytype extends JFormField
{
	/**
	 * The form field type.
	 *
	 * @var		string
	 * @since   1.6
	 */
	protected $type = 'Modal_Categorytype';

	 
	protected function getInput()
	{
	  JHtml::_('behavior.modal', 'a.modal');
	  $script = array();
	  
	  $script[] = ' jQuery( document ).ready(function(){ jQuery("#categoryreset").click(function() { ';
	  $script[] = '  document.id("'.$this->id.'_id").value ="";';
	  $script[] = '  document.id("'.$this->id.'_name").value ="Select Category";';
	  $script[] = '});jQuery("#quiztype").change(function() {';
	  $script[] = ' var v=jQuery(this).val();';
	  $script[] = ' var lk=jQuery("#jform_link").val();jQuery("#jform_link").val(lk+"&qtype="+v);';
	  $script[] = '});});';
	  
	  $script[] = '  function jSelectCategory_'.$this->id.'(id, title, object) {';
	  $script[] = '  document.id("'.$this->id.'_id").value = id;';
	  $script[] = '  document.id("'.$this->id.'_name").value = title;';
	  $script[] = '  SqueezeBox.close();';
	  $script[] = '    }';
 
	  // Add to document head
	  JFactory::getDocument()->addScriptDeclaration(implode("\n", $script));
 
	  // Setup variables for display
	  $html = array();
	  $link =JRoute::_('index.php?option=com_vquiz&view=quizcategory'.
                  '&tmpl=component&function=jSelectCategory_'.$this->id);
 
	  $db = JFactory::getDbo();
	  $query = $db->getQuery(true);
	  $query->select('title');
	  $query->from('#__vquiz_category');
	  $query->where('id='.(int)$this->value);
	  $db->setQuery($query);
	  $title = $db->loadResult();
	  /*if (!$title = $db->loadResult()) {
		  JError::raiseWarning(500, $db->getErrorMsg());
	  }*/
	  if (empty($title)) {
		  $title = JText::_('SELECT_CATEGORY');
	  }
	  $title = htmlspecialchars($title, ENT_QUOTES, 'UTF-8');
 
		// The current user display field.
		$html[] = '<div class="fltlft" style="display:inline-block">';
		$html[] = '  <input type="text" id="'.$this->id.'_name" value="'.$title.'" disabled="disabled" size="35" />';
		$html[] = '</div>';

		// The user select button.
		$html[] = '<div class="button2-left" style="display:inline-block">';
		$html[] = '<a class="modal hasTip" title="'.JText::_('COM_VQUIZ_CHANGE_QUIZ').'"  href="'.$link.'&amp;'.JSession::getFormToken().'=1" rel="{handler: \'iframe\', size: {x: 800, y: 450}}"><input class="btn btn-success " type="button" value="'.JText::_('JSELECT').'" /></a>'; 
		$html[] = '</div>';
		$html[] = '<input class="btn btn-danger" id="categoryreset" type="button" name="categoryreset" value="'.JText::_('COM_VQUIZ_RESET').'" />';
		

		// The active article id field.
		if (0 == (int)$this->value) {
			$value = '';
		} else {
			$value = (int)$this->value;
		}

		// class='required' for client side validation
		$class = '';
		if ($this->required) {
			$class = ' class="required modal-value"';
		}

		$html[] = '<input type="hidden" id="'.$this->id.'_id"'.$class.' name="'.$this->name.'" value="'.htmlspecialchars($this->value, ENT_COMPAT, 'UTF-8') .'" />';

	  return implode("\n", $html);
  }
}
