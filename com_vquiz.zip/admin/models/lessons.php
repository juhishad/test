<?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/ 
defined( '_JEXEC' ) or die( 'Restricted access' );
 
jimport('joomla.application.component.modellist');
 
class VquizModelLessons extends JModelList
{
	 	function __construct()
		{
			parent::__construct();

			$mainframe = JFactory::getApplication();
			$context	= 'com_vquiz.lessons.list.';
			// Get pagination request variables
			$limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
			$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );

			// In case limit has been changed, adjust it
			$limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
			$this->setState('limit', $limit);
			$this->setState('limitstart', $limitstart);				 
			$array = JRequest::getVar('cid',  0, '', 'array');
			$this->setId((int)$array[0]);

		}

		function _buildQuery()
		{
			
			$user = JFactory::getUser();
			
			$query= 'SELECT i.*, case when c.id !=0 then c.title else "---" end as category FROM #__vquiz_lessons as i Left join #__vquiz_category as c on i.catid=c.id';

			
		 	return $query;
		}

		function setId($id)	
		{
			$this->_id		= $id;
	 		$this->_data	= null;
 		}

		
		function &getItem()
		{
			if (empty( $this->_data )) {
				$query='SELECT i.*';
				$query .=' FROM #__vquiz_lessons as i where i.id = '.$this->_id;	

				$this->_db->setQuery( $query );
				$this->_data = $this->_db->loadObject();
			}


			if (!$this->_data) {
				$this->_data = new stdClass();
				$this->_data->id = 0;
				$this->_data->catid = 0;
				$this->_data->title = null;
				$this->_data->description = null;
				$this->_data->type = null;
				$this->_data->files = null;
				$this->_data->access = 1;
				$this->_data->published = 1;
				$this->_data->language = null;
				$this->_data->thumbnail = null;
				$this->_data->alias= null;
				$this->_data->slide_img= null;
				$this->_data->num_carousel= 0;
				$this->_data->moveslides= 0;
				$this->_data->slide_control= 0;
				$this->_data->auto_slide= 0;
				$this->_data->slidesdelay= 0;
				$this->_data->skills= 0;

				

			}
			return $this->_data;
		}




	function &getItems()
			
		{
			// Lets load the data if it doesn't already exist
			if (empty( $this->_data ))
			{
				 $query = $this->_buildQuery();
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();
				 
				 $query .= $filter;
				 $query .= $orderby;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			}
	
			return $this->_data;
		}
	 
	
		function getTotal()
		{
				
			if (empty($this->_total)) {
			$query = $this->_buildQuery();
			$query .= $this->_buildContentFilter();
			$this->_total = $this->_getListCount($query);    
			}
			return $this->_total;
 		}



		function _buildItemOrderBy()
			{
				$mainframe = JFactory::getApplication();
				$context	= 'com_vquiz.lessons.list.';
				$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'id', 'cmd' );
				$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );
				$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
				return $orderby;
			}



			function getPagination()
			{
				// Load the content if it doesn't already exist
				if (empty($this->_pagination)) {
					jimport('joomla.html.pagination');
					$this->_pagination = new JPagination($this->getTotal(), $this->getState('limitstart'), $this->getState('limit') );
				}
				return $this->_pagination;
			}
 
 
 
		function _buildContentFilter()
		{
			$mainframe =JFactory::getApplication();

			$context	= 'com_vquiz.lessons.list.';
			
			$selected_userlesson	= $mainframe->getUserStateFromRequest( $context.'selected_userlesson', 'selected_userlesson',	'',	'string' );
			
			$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );
			$search		= JString::strtolower( $search );

			$catid		= $mainframe->getUserStateFromRequest( $context.'catid', 'catid', 0,	'int' );

			$publish_item		= $mainframe->getUserStateFromRequest( $context.'publish_item', 'publish_item',	'',	'string' );

			$where = array();

			if($publish_item){  

				if ( $publish_item == 'p' ){
					$where[] = 'i.published= 1';

				}elseif($publish_item =='u'){
					$where[] = 'i.published = 0';
				}

			}

			if($catid ){
		
				$where[] = 'i.catid = '.$this->_db->Quote( $catid );
		
			}

			if($search)
			{	
				if (is_numeric($search)) 
				{		 
					$where[] = 'i.id ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				}
				else
				{
					$where[] = 'lower(i.title) LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
				}
			}
			if($selected_userlesson){			
				//$where[] = ' i.id not in('.$selected_userlesson.')';
			}

			$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';

			return $filter;
		}

		function getCats(){
					
			$query ='select a.id , a.title , a.level ';
			$query .=' from #__vquiz_category As a ';
			
			$query .=' where a.id !=1 group by a.id order by a.lft ASC';
			
			$this->_db->setQuery($query);
			$result=$this->_db->loadObjectList();
			return $result;

		}
 
		function store()
		{	

			$time = time();
			$row = $this->getTable();
			$data = JRequest::get( 'post' );
			$data['description'] = JRequest::getVar('description', '', 'post', 'string', JREQUEST_ALLOWRAW);
			$data['files']=JRequest::getVar('files',null,'FILES','array');
			if($data['type']=="video" and empty($data['files']))
			{
				$data['files']=$data['filename'];
			}
			//echo "<pre>"; print_r($data['files']); jexit();
			$data["alias"] = empty($data["alias"])?$data["title"]:$data["alias"];
			$data["alias"]=JFilterOutput::stringURLSafe($data['alias']);
			$data["skills"]=implode(',',JRequest::getVar('skills',array(0), 'post', 'array'));
			/*---   Slide Upload -----*/
			if($data['type']!="slide" and !empty($data['files']))
				$uploaded_file=$this->upload_files();
			else
				$uploaded_file=$this->slide_upload();
			
			/*---code for  thumbnail upload. ---*/
			
			if($data["id"]){
				$query = ' SELECT thumbnail from #__vquiz_lessons WHERE id = '.$data["id"];
				$this->_db->setQuery( $query );
				$oldimage_path = $this->_db->loadResult();
			}
			 
			$query='select categorythumbnailwidth,categorythumbnailheight from #__vquiz_configuration';
			$this->_db->setQuery($query);
			$configuration_img=$this->_db->loadObject();
			$configuration_width=$configuration_img->categorythumbnailwidth;
			$configuration_height=$configuration_img->categorythumbnailheight;
	 
			$image = JRequest::getVar('thumbnail', null, 'FILES', 'array');
			$allowed = array('.jpg', '.jpeg', '.gif', '.png');

			$dirpath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/lessons/';
			$thumbPath = JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/lessons/thumbs/'; 

			jimport('joomla.filesystem.file');
			$image_name = str_replace(' ', '', JFile::makeSafe($image['name']));
			$image_tmp = $image['tmp_name'];
			$time = time();
			
			if($image_name <> "" ){
				
				$ext = strrchr($image_name, '.');
				if(!in_array($ext, $allowed)){
					$msg_error=JText::_('THIS_IMAGE_TYPE_NOT_ALLOWED');
					$this->setError($msg_error);
					return false;
				}
		
				$size = getimagesize($image_tmp);
				$src_w = $size[0];
				$src_h = $size[1];
				
				if($src_w > $src_h ){
					if(!empty($configuration_width) and is_numeric($configuration_width)){
						$width = $configuration_width;   
					}else{
						$width = 125; //New width of image 
					}
					if(!empty($configuration_height) and is_numeric($configuration_height)){
						$height =$configuration_height;
					}else{   
						$height = $size[1]/$size[0]*$width; //This maintains proportions
					}
					$width1 = 300; //New width of image    
					$height1 = $size[1]/$size[0]*$width; //This maintains proportions

				}else{
					if(!empty($configuration_height) and is_numeric($configuration_height)){
						$height =$configuration_height;
					}else{
						$height = 125;
					}
					if(!empty($configuration_width) and is_numeric($configuration_width)){
						$width = $configuration_width;   
					}else{
						$width = $size[0]/$size[1]*$height; //This maintains proportions
					}
					$height1 = 360;
					$width1 = $size[0]/$size[1]*$height; //This maintains proportions
				}
				
				$width1 = 265; //New width of image    
				$height1 = $size[1]/$size[0]*$width; //This maintains proportions

				$new_image = imagecreatetruecolor($width, $height);
				$new_image1 = imagecreatetruecolor($width1, $height1);
				
				if($size['mime'] == "image/jpeg"){
					$tmp = imagecreatefromjpeg($image_tmp);
				}elseif($size['mime'] == "image/gif"){
					$tmp = imagecreatefromgif($image_tmp);
				}else{
					$tmp = imagecreatefrompng($image_tmp);
				}
				
				imagecopyresampled($new_image, $tmp,0,0,0,0, $width, $height, $src_w, $src_h);
				
				if($size['mime'] == "image/jpeg"){
					imagejpeg($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
					
				}elseif($size['mime'] == "image/gif"){
					imagegif($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
					
				}else{
					imagepng($new_image, $thumbPath.'thumb_'.$time.'_'.$image_name);
				}

				imagecopyresampled($new_image1, $tmp,0,0,0,0, $width1, $height1, $src_w, $src_h);
				
				if($size['mime'] == "image/jpeg"){
					imagejpeg($new_image1, $dirpath.$time.'_'.$image_name);
				}elseif($size['mime'] == "image/gif"){
					imagegif($new_image1, $dirpath.$time.'_'.$image_name);
				}else{
					imagepng($new_image1, $dirpath.$time.'_'.$image_name);
				}
				
				if(move_uploaded_file($image_tmp, $dirpath.$time.'_'.$image_name)){
					$data['thumbnail'] = $time.'_'.$image_name;
				}
	 

			}

			if($data['thumbnail'] and $oldimage_path){
		
			   unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/lessons/'.$oldimage_path);
			   unlink(JPATH_ROOT.'/media/com_vquiz/vquiz/images/photoupload/lessons/thumbs/'.'thumb_'.$oldimage_path);

			}
			
			
			if(!$data["id"]){
				//$date =& JFactory::getDate();
				$data['created'] = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
			}
			//print_r($data);exit;
			if (!$row->bind($data)) {
			$this->setError($this->_db->getErrorMsg());
			return false;
			}

			if (!$row->check()) {
			$this->setError($this->_db->getErrorMsg());
			return false;
			}

			if (!$row->store()) {
			$this->setError( $row->getErrorMsg() );
			return false; 
			}
			
			JRequest::setVar('id', $row->id);
			if(!empty($uploaded_file) && $data['type']!="slide")
			{
				$query = 'update #__vquiz_lessons set files = '.$this->_db->quote($uploaded_file).' where id = '.$this->_db->quote($row->id);
				$this->_db->setQuery($query);
										
				if(!$this->_db->execute()){
				
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
			}
			else if(!empty($uploaded_file) && $data['type']=="slide"){
				$query = 'update #__vquiz_lessons set slide_img = '.$this->_db->quote($uploaded_file).' where id = '.$this->_db->quote($row->id);
				$this->_db->setQuery($query);
										
				if(!$this->_db->execute()){
				
					$this->setError($this->_db->getErrorMsg());
					return false;
				}
			}
			//save notification on adding
				
				if(!$data['id']){ 
					
					$data_arr = array();
					$data_arr['itemid'] = $row->id;
					$data_arr['notification_type'] = 8;
					$data_arr['replace_lesson_title'] = $row->title;
						
					if(QuizHelper::checkNotification($data_arr['notification_type'])){
						$data_arr['notify_users'] = QuizHelper::findUsersToNotify('notify_add_lesson');
						$data_arr['enotify_users'] = QuizHelper::findUsersToEnotify('enotify_add_lesson');
						//print_r($data_arr); exit;
						QuizHelper::sendNotification($data_arr);
					}
					
				}

			return true;
			
			

		}
 

	function delete()
	{
		
		// Check for request forgeries
		
		$cids = JRequest::getVar( 'cid', array(), 'post', 'array' );

		if (count( $cids ) < 1) {
			$this->setError( JText::_( 'Select minimum one Record', true ) );
			return false;
		}
		
		$row =  $this->getTable();

		foreach ($cids as $id)
		{	
			
			$query=$this->_db->getQuery(true);
			$query->select('files');
			$query->from('#__vquiz_lessons');
			$query->where('id='.$id);
			$this->_db->setQuery($query);
			$result=$this->_db->loadResult();
			$path=JPATH_ROOT."/media/com_vquiz/vquiz/images/files/";
			 //echo $path.$result; die;
			if(!$row->delete($id))	{
				$this->setError($row->getError());
				return false;
				
			}else{
				if($result && file_exists($path.$result)){
					 
					JFile::delete($path.$result); 
				
				}
				
			}

		}
		
		return true;
		
	}

	function publish(){

		$cid		= JRequest::getVar( 'cid', array(), 'post', 'array' );
		$task		= JRequest::getCmd( 'task' );
		$publish	= ($task == 'publish')?1:0;
		$n = count( $cid );
		if (empty( $cid )) {
			return JText::_('No item selected');
		}

		$cids = implode( ',', $cid );
		$query = 'UPDATE #__vquiz_lessons SET published = ' . (int) $publish . ' WHERE id IN ( ' . $cids . ' )';
		$this->_db->setQuery( $query );
	
		if (!$this->_db->query()){
			return $this->_db->getErrorMsg();
		}
		else{
			return ucwords($task).'ed successfully.';
		}
	
	}
	
	public function saveorder($pks = array(), $order = null)
	{
		$table = $this->getTable();
		$tableClassName = get_class($table);
		$contentType = new JUcmType;
		$type = $contentType->getTypeByTable($tableClassName);
		$tagsObserver = $table->getObserverOfClass('JTableObserverTags');
		$conditions = array();

		if (empty($pks))
		{
			return JError::raiseWarning(500, JText::_($this->text_prefix . '_ERROR_NO_ITEMS_SELECTED'));
		}

		// Update ordering values
		foreach ($pks as $i => $pk)
		{
			$table->load((int) $pk);

			if ($table->ordering != $order[$i])
			{
				$table->ordering = $order[$i];

				if ($type)
				{
					$this->createTagsHelper($tagsObserver, $type, $pk, $type->type_alias, $table);
				}

				if (!$table->store())
				{
					$this->setError($table->getError());

					return false;
				}
			}
		}

		return true;
	}
	
	function upload_files()
	{
		$files = JRequest::getVar('files',null,'FILES','array');
		$time = time();
		$file_name=str_replace(' ', '', JFile::makeSafe($files['name']));
		$temp=$files["tmp_name"];
		if(!empty($file_name))
		{			
			$url=JPATH_SITE.'/media/com_vquiz/vquiz/images/files/'.$time.'_'.$file_name;								
			if(!move_uploaded_file($temp, $url))	{echo "NO--";
				$this->setError(JText::_('FILE_NOT_UPLOADED'));
				return false;
			}		
			$profilepic= $time.'_'.$file_name;			
		}
		return $profilepic;		
	}
 
	function slide_upload(){
	
		$id = JRequest::getInt('id',0);
		
		/* $query = $this->_db->getQuery(true);
		$query->select('slide_img');
		$query->from('#__vquiz_lessons');
		$query->where('id='.$id);
		$this->_db->setQuery($query);
		$slide_img_array = json_decode($this->_db->loadResult(),TRUE); */
		
		$slide_img_array = JRequest::getVar('slide_img_order',array(0),'post','array');
		

		if(empty($slide_img_array[0])){
			$slide_img_array=array();
			$old_profle_pic=array();
		}else{
			$old_profle_pic=$slide_img_array;
		}
		
				
	
 
		$slide_img = JRequest::getVar("slide_img", array(), 'files', 'array');
 
		for($i=0; $i<count($slide_img['name']); $i++) {
			
			$time = time().$i;
			$slide_img_name=str_replace(' ', '', JFile::makeSafe($slide_img['name'][$i]));	
			$temp=$slide_img["tmp_name"][$i];
		
			if(!empty($slide_img_name))	{
			
				$url=JPATH_SITE.'/media/com_vquiz/vquiz/images/slide/'.$time.$slide_img_name;
								
				if(!move_uploaded_file($temp, $url))	{echo "NO--";
					$this->setError(JText::_('FILE_NOT_UPLOADED'));
					return false;
				}
		
				$profilepic= $time.$slide_img_name;
				
				array_push($slide_img_array,$profilepic);

				/* if(!empty($old_profle_pic[$i]) and is_file(JPATH_SITE.'/media/com_vquiz/vquiz/images/slide/'.$old_profle_pic[$i]))
				unlink(JPATH_SITE.'/media/com_vquiz/vquiz/images/slide/'.$old_profle_pic[$i]); */
				
			}

		}
		

		if(!empty($slide_img_array)){
			$slide_img_json = json_encode(array_values($slide_img_array));
		}else{
			$slide_img_json = $slide_img_array;
		}

		return $slide_img_json;
		
	}
	

	function getSkills(){

		$obj = new stdClass();
		if($this->_id){
			$query=$this->_db->getQuery(true);
			$query->select('skillid');
			$query->from($this->_db->quoteName('#__vquiz_lns'));
			$query->where('lessionid ='.$this->_db->quote($this->_id));
			$this->_db->setQuery($query);
			$selectedid=$this->_db->loadColumn();
		}else{
			$selectedid=array();
		}
		$obj->selectedid=$selectedid;
		
		$query=$this->_db->getQuery(true);
		$query->select('id,title');
		$query->from($this->_db->quoteName('#__vquiz_skills'));
		$query->where('published = 1');
		$this->_db->setQuery($query);
		$obj->skillid=$this->_db->loadObjectList();
		return $obj;
	}
				
}
?>