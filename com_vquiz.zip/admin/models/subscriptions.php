 <?php
/*------------------------------------------------------------------------
# com_vquiz - vQuiz
# ------------------------------------------------------------------------
# author    Team WDMtech
# copyright Copyright (C) 2018 wwww.wdmtech.com. All Rights Reserved.
# @license - https://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
# Websites: https://www.wdmtech.com
# Technical Support:  Forum - https://www.wdmtech.com/support-forum
-----------------------------------------------------------------------*/
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport('joomla.application.component.modellist');
class VquizModelSubscriptions extends JModelList
{
	var $_total = null;
	var $_pagination = null;
	
	function __construct()
	{
		parent::__construct();
        $mainframe = JFactory::getApplication();
		
		$context	= 'com_vquiz.subscriptions.list.';
        // Get pagination request variables
        $limit = $mainframe->getUserStateFromRequest($context.'limit', 'limit', $mainframe->getCfg('list_limit'), 'int');
		$limitstart = $mainframe->getUserStateFromRequest( $context.'limitstart', 'limitstart', 0, 'int' );
		$filter_language		= $mainframe->getUserStateFromRequest( $context.'filter_language',	'filter_language',	'' );
		
        // In case limit has been changed, adjust it
        $limitstart = ($limit != 0 ? (floor($limitstart / $limit) * $limit) : 0);
		
 
        $this->setState('limit', $limit);
        $this->setState('limitstart', $limitstart);
		
		
		$array = JRequest::getVar('cid',  0, '', 'array');
		$this->setId((int)$array[0]);
	}

 
 	function _buildQuery()
 	{
		$db =JFactory::getDBO();
		$user = JFactory::getUser();
		
 		 $query="SELECT i.* , p.title, `u`.`name` FROM #__vquiz_plans_subscription as i left join #__vquiz_plans as p ON i.plan_id = p.id left join `#__users` as `u` on `u`.`id`=`i`.`user_id`";
		 
   
		 return $query; 
	}
 
	function setId($id)
	{
		// Set id and wipe data
		$this->_id		= $id;
		$this->_data	= null;
	}
    
	
	function &getItem()
	{ 
		
		// Load the data
		if (empty( $this->_data )) {
		$query = ' SELECT * FROM #__vquiz_plans_subscription '.
					'  WHERE id = '.$this->_id;
			$this->_db->setQuery( $query );
			$this->_data = $this->_db->loadObject();
		}

		if (!$this->_data) {
			$this->_data = new stdClass();
			$this->_data->id = 0;
			$this->_data->user_id = null;
			$this->_data->plan_id = null;
			$this->_data->total = null;
			$this->_data->status = null;
					
			
			$this->_data->subscription_date= null;
			$this->_data->expiration_date= null;
			
			$this->_data->created_by= null;
			
			
		}

		return $this->_data; 

	}
	
	

		function &getItems()
			
		{ 
			// Lets load the data if it doesn't already exist
			
				 $query = $this->_buildQuery(); 
				 
				 $filter = $this->_buildContentFilter();
				 $orderby = $this->_buildItemOrderBy();  
				
				 
				 $query .= $filter;
				 $query .= $orderby; 
				// echo $query ; //exit;
				 //$this->_data = $this->_getList( $query );
				 $this->_data = $this->_getList($query, $this->getState('limitstart'), $this->getState('limit'));
			   
			return $this->_data;
		}
	 
	 
 
			function getTotal()
			{
		
			 if (empty($this->_total)) {
				$query = $this->_buildQuery();
				$query .= $this->_buildContentFilter();
				$query  .= $this->_buildItemOrderBy();
				$this->_total = $this->_getListCount($query);    
		 
				}
			   return $this->_total;
			}
		 
		 
			function _buildItemOrderBy()
			{
				$mainframe = JFactory::getApplication();
				
				$context	= 'com_vquiz.subscriptions.list.';
		 
				$filter_order     = $mainframe->getUserStateFromRequest( $context.'filter_order', 'filter_order', 'i.id', 'cmd' );
				$filter_order_Dir = $mainframe->getUserStateFromRequest( $context.'filter_order_Dir', 'filter_order_Dir', 'desc', 'word' );substr(strrchr($filter_order, "."), 1);
				
		        if (!array_key_exists((string)substr(strrchr($filter_order, "."), 1), $this->getTable('Subscriptions', 'Table')->getFields()))
			        $filter_order = 'i.id';
		 		
				$orderby = ' group by i.id order by '.$filter_order.' '.$filter_order_Dir . ' ';
		 
				return $orderby;
			}

	function _buildContentFilter()
	{

			$mainframe =JFactory::getApplication();
	 
			$context	= 'com_vquiz.subscriptions.list.';
			$search		= $mainframe->getUserStateFromRequest( $context.'search', 'search',	'',	'string' );			
			$search		= JString::strtolower( $search );
			
			$planid		= $mainframe->getUserStateFromRequest( $context.'planid', 'planid',	'',	'int' );
			
			$expiration_date= $mainframe->getUserStateFromRequest( $context.'expiration_date', 'expiration_date',	array(),	'ARRAY' );
			$subscription_date= $mainframe->getUserStateFromRequest( $context.'subscription_date', 'subscription_date',	array(),	'ARRAY' );
	 
			$where = array();
			
			if(count($expiration_date)>0){
				if(isset($expiration_date[0]) && !empty($expiration_date[0]))
					$where[] = 'i.expiration_date >= '.$this->_db->quote($expiration_date[0]);
				if(isset($expiration_date[1]) && !empty($expiration_date[1]))
					$where[] = 'i.expiration_date <= '.$this->_db->quote($expiration_date[1]);
			}
			if(count($subscription_date)>0){
				if(isset($subscription_date[0]) && !empty($subscription_date[0]))
					$where[] = 'i.subscription_date >= '.$this->_db->quote($subscription_date[0]);
				if(isset($subscription_date[1]) && !empty($subscription_date[1]))
					$where[] = 'i.subscription_date <= '.$this->_db->quote($subscription_date[1]);
			}
			
			if($planid)
			{ 
				$where[] = 'p.id='.$this->_db->quote($planid);
			}
			 
			if($search)
			{	
				if (is_numeric($search)) 
				{		 
					$where[] = 'LOWER( i.id ) ='.$this->_db->Quote( $this->_db->escape( $search, true ), false );
				}
				else
				{
	 
				 $where[] = 'p.title LIKE '.$this->_db->Quote( '%'.$this->_db->escape( $search, true ).'%', false );
	
				
				}
			}
			  
				$filter = count($where) ? ' WHERE ' . implode(' AND ', $where) : '';
	 
			return $filter;
	}
		
	
	
 
		 
 

	function delete()
	{
		$cids = JRequest::getVar( 'cid', array(0), 'post', 'array' );
		$row =& $this->getTable();
		if (count( $cids )) {
		foreach($cids as $cid) {
			if (!$row->delete( $cid )) {
				$this->setError( $row->getErrorMsg() );
				return false;
				}
				
			$query = 'DELETE FROM `#__vquiz_plans_order` where `subscr_id`='.$this->_db->quote($cid);
					$this->_db->setQuery($query);
					$this->_db->execute();
			}
		}
		return true;
	}			
					
	
							
		
	
	function store()
	{	
		
		
		$config = QuizHelper::getConfiguration();
		
		$time = JFactory::getDate('now', JFactory::getConfig()->get('offset'))->__toString();
		
		$session=JFactory::getSession();
		$user = JFactory::getUser();
	    $row =$this->getTable();
		$data = JRequest::get('post');
		
		$create_order = false;
		
		
		$plan = QuizHelper::planDetail($data['plan_id']);
		if($data['status'] == QuizHelper::SUBSCRIPTION_ACTIVE && !isset($data['subscription_date']) && !isset($data['expiration_date'])){
		 
		 $data['expiration_date'] = QuizHelper::addExpiration($plan->expiration);
		 $create_order =true;
		}
		$total = $config->tax_enable==1?QuizHelper::pricewithtax($plan->price):$plan->price; 
  		$data['total'] = $total;
		
		if(!$data["id"])
		{
			$data['subscription_date'] = $time;
			
			$query='select MAX(ordering) from #__vquiz_plans_subscription';
			$this->_db->setQuery($query);
			$highest_ordering=$this->_db->loadResult();

			$data['ordering'] = $highest_ordering+1;
		}
		
		if($data['id']){
				$data['modified_date'] = $time;
		}
		
		$param = new stdClass();
		$param->expirationtype = $plan->expirationtype;
		$param->expiration = $plan->expiration;
		$param->price = $total;
		$param->title = $plan->title;
		$data['params']  = json_encode($param);  
		
									//echo "<pre>";print_r($data); exit;
		if (!$row->bind($data)) {
		$this->setError($this->_db->getErrorMsg());
		return false;
		}

		if (!$row->check()) {
		$this->setError($this->_db->getErrorMsg());
		return false;
		}
			
		if (!$row->store()) {
		$this->setError( $row->getErrorMsg() );
		return false; 
		}

		JRequest::setVar('id', $row->id);
		
		 if($create_order==true)
		 {
			
			$order =  $this->getTable('Orders', 'Table');
			$order->subscr_id = $row->id;
			
			$order->tax = $config->tax_enable==1?$total-$plan->price:'0.00000';
			$order->currency = $config->currencyname;
			
			
			$order->total = $total;
			$order->subtotal = $total;//$coupon_value!=0?$total-$coupon_value:$total; 
			$order->status = (int)$data['status']+30;
		
			$order->app_id = !isset($data['app_id'])?1:$data['app_id'];
			//$order->coupon_code = '';
			$order->buyer_id = $data['user_id'];
			$order->created_date = $time;
			$order->modified_date = $time;
			$order->paid_date = $time;
			$order->order_key = QuizHelper::generateSerialCode(12);
			$param = new stdClass();
			$param->expirationtype = $plan->expirationtype;
			$param->expiration = $plan->expiration;
			$param->price = $total;
			$param->title = $plan->title;
			$order->params = json_encode($param); 
			
			if (!$order->store()) {
				$this->setError( $order->getErrorMsg() );
				return false;
			}
			
			$subscription =  $this->getTable('subscriptions', 'Table');
			$subscription->load($row->id);
			$subscription->total = $order->subtotal; 
			$param = new stdClass();
			$param->expirationtype = $plan->expirationtype;
			$param->expiration = $plan->expiration;
			$param->title = $plan->title;
			$param->order_id = $order->order_id;
			$param->order_key = $order->order_key;
			$param->price = $order->subtotal;
			$subscription->params = json_encode($param);
			$subscription->store();
		
		 }

		return true;

	}
	
	function getPlans(){
		$query = 'select `id`, `title` from `#__vquiz_plans` where `published`=1;';
		$this->_db->setQuery($query);
		return $this->_db->loadObjectList();
	}
	function getUsers(){
		$query = 'select `id`, `name`, `username` from `#__users` where `block`=0;';
		$this->_db->setQuery($query);
		return $this->_db->loadObjectList();
	}
	
	function getInvoices()
		{
			
			$invoices = array();
			if ($this->_id )
			{
			$query = ' SELECT * FROM #__vquiz_plans_order '.
					'  WHERE `subscr_id` = '.$this->_id;
			$this->_db->setQuery( $query );
			$invoices = $this->_db->loadObjectList(); 
			return $invoices;
		   }
		   return $invoices;
		}
	
	
 
 }